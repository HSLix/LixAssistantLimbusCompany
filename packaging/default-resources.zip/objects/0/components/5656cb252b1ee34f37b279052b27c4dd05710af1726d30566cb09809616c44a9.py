"""结束镜牢探索的编排：halt 点击 → 结算弹窗处理（不领取奖励）→ 确认入口回到未开始。"""
import re

from lalc import ExecutionFailure, RunContext, sub_workflow

INFO_REGION = {"x": 890, "y": 130, "width": 320, "height": 55}
POPUP_REGION = {"x": 210, "y": 90, "width": 850, "height": 510}
# 以下文本均为去掉空白和符号后的小写形式，便于和 OCR 结果比较
BEFORE_TEXT = "beforeentry"
REWARD_TEXT = "explorationreward"
GIVE_UP_TEXT = "giveuprewards"
MAX_RETRIES = 10
POLL_SECONDS = 0.8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 把按钮读成 GiveUpRewards 这类连写形式。"""
    return re.sub(r"[^a-z0-9]", "", text.lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _region_texts(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回规范化小写文本；不刷新截图。"""
    left = int(region["x"])
    top = int(region["y"])
    right = left + int(region["width"])
    bottom = top + int(region["height"])
    parts: list[str] = []
    for item in items:
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if left <= x <= right and top <= y <= bottom:
            text = str(item.get("text", ""))
            if text:
                parts.append(text)
    return _norm(" ".join(parts))



@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """优先等待正常过渡，再有界分派；同一分支连续第四次命中或总预算耗尽时失败。"""
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, 30 + 1):
        meta = ctx.action("observe.capture_screen")
        # 每轮只做一次整屏 OCR：入口信息栏与弹窗文字都从这份结果里按区域过滤
        items = _screen_items(ctx)
        # 正常加载／联网过渡先于业务分派（Run 637）：过渡帧上入口信息栏仍可读，
        # 先分派业务会据此重复点击或提前判定完成；等待后业务分支从 1 重新计数。
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        result = None
        if BEFORE_TEXT in _region_texts(items, INFO_REGION):
            return {"completed": True, "reason": "入口已回到未开始", "page": "before_entry"}
        popup = _region_texts(items, POPUP_REGION)
        if REWARD_TEXT in popup:
            hit("step.mirror_exploration_reward")
            ctx.log(f"第{round_index}轮：结算弹窗在，放弃奖励只点一次 Give Up")
            ctx.call("step.mirror_exploration_reward", claim=False)
            continue
        if "willyouenter" in popup:
            hit("step.mirror_decline_enter_prompt")
            ctx.log(f"第{round_index}轮：进入提示弹窗在，只点一次 Cancel")
            ctx.call("step.mirror_decline_enter_prompt")
            continue
        if ctx.action("observe.match_asset", asset="mirror/entry") or "dungeonprogress" in popup:
            hit("step.mirror_halt")
            ctx.log(f"第{round_index}轮：入口页或进度弹窗在，只执行一次 halt 动作")
            ctx.call("step.mirror_halt")
            continue
        hit("unknown")
        ctx.log(f"第{round_index}轮：未识别到 halt 相关页面，等待后重新观察")
        ctx.action("observe.wait", seconds=1.0)
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
