"""镜牢战斗失败页面：只选右侧最下面的 Accept results 选项，再点一次 Confirm。"""
import re

from lalc import ExecutionFailure, RunContext, step

# 战斗失败弹窗区域（1280x720 客户区）：左侧 Floor In Progress 卡片 + 右侧三个选项 + 下方 Confirm
DEFEAT_REGION = {"x": 320, "y": 205, "width": 690, "height": 365}
# 以下文本均为去掉空白和符号后的小写形式，便于和 OCR 结果比较
FLOOR_LABEL = "floorinprogress"
RETRY_LABEL = "retrystage"
ACCEPT_LABEL = "acceptresults"
CONFIRM_LABEL = "confirm"
# 右侧最下面选项整行可点，取该项文字行的回退坐标
ACCEPT_FALLBACK = (790, 441)
# Confirm 按钮在 1280x720 客户区中的回退坐标
CONFIRM_FALLBACK = (664, 527)
# 点选选项后游戏会播放选中动画，确认后再等页面切换（含加载画面）
SELECT_SETTLE_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或连写影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回战斗失败弹窗区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=DEFEAT_REGION) or {}
    return list(result.get("items") or [])


def _texts(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _defeat_visible(texts: str) -> bool:
    """
    战斗失败页面的特征：左侧 Floor In Progress 进度卡与右侧 Stage 相关选项同时出现。
    只看到其中一项时不足以判定，避免把别的 Stage Select 类页面当成失败页。
    """
    return FLOOR_LABEL in texts and (ACCEPT_LABEL in texts or RETRY_LABEL in texts)


def _accept_centers(items: list[dict]) -> list[tuple[int, int]]:
    """
    找出含 Accept results 文字的选项中心。
    只认标题行（Accept results and return to Stage select），描述文字里没有 acceptresults，
    因此不会把 Accept the current battle results… 这段说明当成选项。
    """
    centers: list[tuple[int, int]] = []
    for item in items:
        if ACCEPT_LABEL not in _norm(str(item.get("text", ""))):
            continue
        center = item.get("centerxy")
        if center:
            centers.append((int(center[0]), int(center[1])))
    return centers


def _confirm_center(items: list[dict]) -> tuple[int, int] | None:
    """找出文字正好是 Confirm 的按钮中心，识别不到时返回 None。"""
    for item in items:
        if _norm(item.get("text", "")) != CONFIRM_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            return (int(center[0]), int(center[1]))
    return None


def _click_accept(ctx: RunContext, items: list[dict]) -> None:
    """点击右侧最下面的 Accept results 选项；未识别到文本时用回退坐标并记录 warning。"""
    centers = _accept_centers(items)
    if not centers:
        ctx.log(
            f"未识别到 Accept results 文本，点击右侧最下面选项的回退坐标 {ACCEPT_FALLBACK}",
            level="warning",
            screenshot=True,
        )
        ctx.action("control.click", x=ACCEPT_FALLBACK[0], y=ACCEPT_FALLBACK[1])
        return

    if len(centers) > 1:
        ctx.log(f"Accept results 选项命中 {len(centers)} 处，按最下方一处点击", level="warning")
    target = max(centers, key=lambda point: point[1])
    ctx.log(f"点击右侧最下方的 Accept results 选项 @ {target}")
    ctx.action("control.click", centerxy=target)


@step
def execute(ctx: RunContext) -> None:
    """
    处理镜牢战斗失败页面（All participating Sinners have been killed / Floor In Progress），只做一组固定动作：
    - 截图后看不到 Floor In Progress 与右侧选项（不是失败页）时零输入返回；
    - 否则只选右侧最下面的 Accept results and return to Stage select（不点 Return to Stage Select 与 Retry Stage），
      等 1 秒让选中动画结束，再点一次 Confirm（文本优先，未识别到用固定坐标），之后交回。
    是否已离开失败页、是否进入下一个弹窗由 task.mirror 下一轮重新观察，本步不轮询、不重试。
    """
    items = _region_items(ctx)
    if not _defeat_visible(_texts(items)):
        ctx.log("当前不是镜牢战斗失败页面，不做任何输入")
        return

    _click_accept(ctx, items)
    ctx.log(f"等待 {SELECT_SETTLE_SECONDS} 秒让 Accept results 选中状态生效")
    ctx.action("observe.wait", seconds=SELECT_SETTLE_SECONDS)

    confirm = _confirm_center(_region_items(ctx))
    if confirm:
        ctx.log(f"点击一次 Confirm @ {confirm}")
        ctx.action("control.click", centerxy=confirm)
    else:
        ctx.log(
            f"未识别到 Confirm 文本，点击回退坐标 {CONFIRM_FALLBACK}",
            level="warning",
            screenshot=True,
        )
        ctx.action("control.click", x=CONFIRM_FALLBACK[0], y=CONFIRM_FALLBACK[1])
