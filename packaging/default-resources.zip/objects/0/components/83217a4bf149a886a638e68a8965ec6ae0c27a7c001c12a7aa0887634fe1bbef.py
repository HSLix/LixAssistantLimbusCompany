"""体力兑换弹窗收起：按一次 esc 并做一次有界等待，不判断弹窗状态。"""
from lalc import RunContext, step

WAIT_AFTER_CLOSE_SECONDS = 1.0


@step
def execute(ctx: RunContext) -> None:
    """按一次 esc 收起当前弹窗，等固定秒数后交回；是否收起由上层重新截图判断。"""
    ctx.log(f"按 esc 收起体力兑换弹窗，等 {WAIT_AFTER_CLOSE_SECONDS} 秒后交回")
    ctx.action("control.key_press", key="esc")
    ctx.action("observe.wait", seconds=WAIT_AFTER_CLOSE_SECONDS)
