"""队伍列表：左侧有可选队伍列表时，按队伍号点中目标队伍行，不进入战斗、不调整出战人数。

Luxcavation 战斗准备页与镜牢入口队伍页（左上 Preset #n、右下 Starlight Bonus + Confirm）
共用同一个左侧队伍列表：列表标题 TEAMS、每行文字 TEAMS #n，按队伍号从小到大排列，
一屏可见 6~7 行，队伍名可以随意编辑。
镜牢局内战斗准备页（右下 To Battle!、底部 Total Participants）也有同样的右侧页签和左上 Preset 卡，
但左侧只有本场这一张 Preset 卡、没有 TEAMS 队伍列表，不属于本 Step 的页面：
Run 380 就是在这里把战斗准备页当成队伍选择页去滚列表、按行点击，日志也跟着记成在选队伍。
所以页面判定除了右侧页签／Starlight Bonus，还必须看到左侧 TEAMS 列表行，否则零输入交回上层。
本 Step 不区分是 Luxcavation 准备页还是镜牢入口队伍页，只用鼠标滚轮翻页（拖动会被游戏当成拖拽换位，会改掉队伍顺序）：
先用滚轮滚回顶部，再按实测的「每 10 格 ≈ 6 个队伍」向下翻到目标页，最后按固定行位点击目标队伍。
"""
import re

from lalc import RunContext, step

# 三种页面都有的右侧页签：只作第一层筛选用，单独它不能证明左侧有可选队伍列表
TEAM_LIST_ASSETS = (
    "prepare_team/all_identities",
    "prepare_team/all_ego",
    "prepare_team/facades",
)
# 镜牢入口队伍页独有标识（右下角 Starlight Bonus）：只用于页面判定兜底，不影响选行
MIRROR_TEAM_ASSET = "mirror/team_select"
# 左侧队伍列表的实测区域（1280x720）：列表标题 TEAMS 固定在列表上方，行文字是 TEAMS #n，
# 滚到任何位置都能读到 TEAMS；镜牢局内战斗准备页的同一区域只有一张 Preset 卡，读不到 TEAMS
TEAM_LIST_REGION = {"x": 55, "y": 265, "width": 150, "height": 320}
TEAM_LIST_KEYWORD = "teams"
TEAM_COUNT = 40
# 滚轮落点取列表中部，避开上方 TEAMS 标题与底部按钮区
LIST_X = 130
LIST_Y = 420
ROW_HEIGHT = 36.2
# 顶部对齐时首行中心 y：战斗前准备页 316、镜牢入口队伍页 311，取中间值两页都落在行内
FIRST_ROW_Y = 313
# control.scroll 单次最多 10 格
SCROLL_CHUNK = 10
# 实测（滚动后停 1 秒再截图）：滚轮每格约 21.3px ≈ 0.59 行，6 行约需 10 格，所以一页按 6 个队伍翻
PX_PER_NOTCH = 21.3
PAGE_ROWS = 6
# 滚到底停稳后首行是队伍 36、首行中心 y≈311（1 秒时还在惯性滑动，实测会再滑约 50px）
BOTTOM_TOP_TEAM = 36
BOTTOM_FIRST_ROW_Y = 311
# 回滚到顶部：整个列表最大滚动量约 1214px，6 批 10 格足够夹到顶部
RESET_BATCHES = 6
# 滚动后先停 1 秒再截图，等列表停稳
SETTLE_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _list_text(ctx: RunContext) -> str:
    """对当前帧左侧队伍列做一次局部 OCR，返回规范小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=TEAM_LIST_REGION) or {}
    items = result.get("items") or []
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _on_team_list_page(ctx: RunContext) -> tuple[bool, str]:
    """
    当前页面左侧是否有可选队伍列表：Luxcavation 战斗准备页与镜牢入口队伍页都算。
    先按右侧页签／Starlight Bonus 确认是带队伍选择的页面，再用左侧列表区域里的 TEAMS 文字
    确认列表真的存在；返回 (是否命中, 列表区域文字)。镜牢局内战斗准备页没有 TEAMS 列表，不入本 Step。
    """
    page_hit = any(ctx.action("observe.match_asset", asset=asset) for asset in TEAM_LIST_ASSETS)
    if not page_hit and not ctx.action("observe.match_asset", asset=MIRROR_TEAM_ASSET):
        return False, ""
    text = _list_text(ctx)
    return TEAM_LIST_KEYWORD in text, text


def _scroll(ctx: RunContext, direction: str, notches: int) -> None:
    """按批发送滚轮（单次最多 SCROLL_CHUNK 格），不点击；等待和观察由调用方负责。"""
    remaining = max(0, notches)
    while remaining > 0:
        steps = min(remaining, SCROLL_CHUNK)
        ctx.action("control.scroll", direction=direction, steps=steps, x=LIST_X, y=LIST_Y)
        remaining -= steps


def _reset_to_top(ctx: RunContext) -> None:
    """向上滚回顶部：滚动量超过整个列表会被顶部夹住，所以不需要识别当前位置。"""
    total = RESET_BATCHES * SCROLL_CHUNK
    _scroll(ctx, "up", total)
    ctx.action("observe.wait", seconds=SETTLE_SECONDS)
    ctx.log(f"已向上滚动{total}格，队伍列表回到顶部")


@step
def execute(ctx: RunContext, *, team_index: int) -> dict[str, str]:
    """
    在左侧队伍列表里选中第 team_index 个队伍（1~40），不区分是 Luxcavation 战斗准备页还是镜牢入口队伍页。
    先把列表滚回顶部，再按「每页 6 个队伍」把「6×行高 ÷ 每格位移」四舍五入成整格数向下翻（不逐页累错），
    停 1 秒后重新截图，按固定行位点击目标队伍；目标超过底部首行队伍时列表会夹在底部，
    改按底部首行（队伍 36）的实测位置点击。
    本步不点 To Battle／Confirm、不调整出战人数，是否已换成目标队伍由上层下一轮重新截图判断。
    """
    if type(team_index) is not int or not 1 <= team_index <= TEAM_COUNT:
        raise ValueError(f"team_index 必须是 1~{TEAM_COUNT} 的整数")

    ctx.action("observe.capture_screen")
    on_list, list_text = _on_team_list_page(ctx)
    if not on_list:
        ctx.log(
            f"当前页面左侧没有可选队伍列表（列表区域文字 {list_text!r}），本 Step 不滚动也不点击，交回上层",
            level="warning",
            screenshot=True,
        )
        return {"completed": "false", "reason": "no_team_list"}

    _reset_to_top(ctx)

    if team_index > BOTTOM_TOP_TEAM:
        # 目标在底部首行之后：先滚到底，再滚一次让惯性停下并确认夹住，然后按实测底部首行点击
        total = RESET_BATCHES * SCROLL_CHUNK
        _scroll(ctx, "down", total)
        ctx.action("observe.wait", seconds=SETTLE_SECONDS)
        _scroll(ctx, "down", total)
        ctx.action("observe.wait", seconds=SETTLE_SECONDS)
        ctx.action("observe.capture_screen")
        click_y = BOTTOM_FIRST_ROW_Y + int(round((team_index - BOTTOM_TOP_TEAM) * ROW_HEIGHT))
        ctx.log(
            f"第{team_index}个队伍在列表底部：滚到底停稳后，"
            f"按底部首行队伍{BOTTOM_TOP_TEAM}点击第{team_index - BOTTOM_TOP_TEAM + 1}行 ({LIST_X}, {click_y})"
        )
        ctx.action("control.click", x=LIST_X, y=click_y)
        ctx.action("observe.wait", seconds=SETTLE_SECONDS)
        return {
            "completed": "true",
            "reason": "bottom_page",
            "team": str(team_index),
            "y": str(click_y),
        }

    pages = (team_index - 1) // PAGE_ROWS
    slot = (team_index - 1) % PAGE_ROWS
    # 把整段需要滚过的距离一次换算成整格数，误差不逐页累积
    notches = int(pages * PAGE_ROWS * ROW_HEIGHT / PX_PER_NOTCH + 0.5)
    _scroll(ctx, "down", notches)
    ctx.action("observe.wait", seconds=SETTLE_SECONDS)
    ctx.action("observe.capture_screen")
    click_y = FIRST_ROW_Y + int(round(slot * ROW_HEIGHT))
    ctx.log(
        f"目标队伍{team_index}：向下滚动{notches}格（{pages}页×{PAGE_ROWS}个队伍），"
        f"点击第{slot + 1}行 ({LIST_X}, {click_y})"
    )
    ctx.action("control.click", x=LIST_X, y=click_y)
    ctx.action("observe.wait", seconds=SETTLE_SECONDS)
    return {
        "completed": "true",
        "reason": "局部目标已确认",
        "team": str(team_index),
        "page": str(pages),
        "slot": str(slot),
        "y": str(click_y),
    }
