"""镜牢 reward card 页提交一次 Enter：让已选卡片生效，或触发未选择奖励的确认弹窗。"""
from lalc import RunContext, step

# 按 Enter 后的固定等待，再由上层重新观察
WAIT_SECONDS = 1.0


@step
def execute(ctx: RunContext) -> None:
    """
    在 Select Encounter Reward Card 页面按一次 Enter：已选到卡片时确认并离开本页；
    没有选到卡片时游戏会弹出 “You have not selected a reward yet.” 确认弹窗。
    本步只负责这一次按键与固定 1 秒等待，不判断页面是否已经离开：
    页面是否已切换、是否弹出确认弹窗由 sub_workflow.mirror_reward_card 下一轮重新观察。
    """
    ctx.log(f"reward card 页面按一次 Enter，等 {WAIT_SECONDS} 秒后交回上层重新观察")
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=WAIT_SECONDS)
