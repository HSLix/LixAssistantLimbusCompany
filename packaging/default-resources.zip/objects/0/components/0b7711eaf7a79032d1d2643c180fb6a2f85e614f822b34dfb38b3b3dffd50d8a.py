"""镜牢 reward card 页的未选择奖励确认弹窗：按 ESC 返回并等待 1 秒，再交回上层重新选卡。"""
import re

from lalc import RunContext, step

# 弹窗文案区域：You have not selected a reward yet. / Continue without choosing a reward?
POPUP_REGION = {"x": 340, "y": 180, "width": 600, "height": 350}
POPUP_KEYWORDS = ("notselectedareward", "withoutchoosingareward")
# 按 ESC 后固定等待 1 秒，让弹窗关闭动画结束，之后由上层重新观察


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """刷新截图并对指定区域做一次局部 OCR，返回规范化小写文本。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _popup_open(ctx: RunContext) -> bool:
    """当前帧是否仍在未选择奖励的确认弹窗上。"""
    text = _region_text(ctx, POPUP_REGION)
    return any(keyword in text for keyword in POPUP_KEYWORDS)


@step
def execute(ctx: RunContext) -> None:
    """
    只在出现 “You have not selected a reward yet. / Continue without choosing a reward?” 弹窗时
    按一次 ESC 取消这次提交，等固定 1 秒后交回；不在该弹窗时不按任何键，
    避免在正常的卡片页上误触 Cancel。
    弹窗是否已关闭由 sub_workflow.mirror_reward_card 下一轮重新观察，本步不轮询。
    """
    if not _popup_open(ctx):
        ctx.log("当前没有未选择奖励的确认弹窗，本步不按 ESC")
        return

    ctx.log(f"未选择奖励的确认弹窗按 ESC 返回，等 {WAIT_SECONDS} 秒后交回上层重新选卡")
    ctx.action("control.key_press", key="esc")
    ctx.action("observe.wait", seconds=WAIT_SECONDS)
