
"""通过一次按键推进画面；仅用于可安全重复的按键。"""
from lalc import RunContext, step


@step
def execute(
    ctx: RunContext,
    *,
    key: str,
    success_assets: list[str],
    success_count: int = 1,
) -> None:
    """重新观察一次：同帧已命中 success_count 个完成素材则零输入返回，否则按一次 key 后交回。"""
    # TODO: 通用按键缺少可操作入口判据；遇到具体调用情景时，尝试提取其独特特征并补入口检查。
    if (
        not isinstance(key, str)
        or not key.strip()
        or not success_assets
        or any(not name.strip() for name in success_assets)
    ):
        raise ValueError("按键和完成素材不能为空")

    if (
        type(success_count) is not int
        or not 1 <= success_count <= len(set(success_assets))
    ):
        raise ValueError("success_count 必须为正整数，且不能超过不同完成素材的数量")

    ctx.action("observe.capture_screen")
    matched = [
        asset
        for asset in dict.fromkeys(success_assets)
        if ctx.action("observe.match_asset", asset=asset)
    ]
    if len(matched) >= success_count:
        ctx.log(f"同帧已确认完成状态：{matched}，无需按键")
        return

    ctx.action("control.key_press", key=key)
    ctx.log(f"已按一次 {key}，结果由上层重新截图判断")
