"""镜牢结算编排：按 mirror.settings 的 reward_rules 与本场刚结算结果，选择领取或放弃奖励。"""
import re

from lalc import ExecutionFailure, RunContext, sub_workflow

# Exploration Complete 结算页：左上角标题 + 右下角 Claim Rewards 按钮
TITLE_REGION = {"x": 140, "y": 80, "width": 200, "height": 95}
TITLE_KEYWORD = "explorationcomplete"
BUTTON_REGION = {"x": 1030, "y": 555, "width": 210, "height": 90}
BUTTON_KEYWORDS = ("claim", "rewards")
# Exploration Reward 结算弹窗标题
POPUP_TITLE_REGION = {"x": 500, "y": 90, "width": 300, "height": 60}
POPUP_TITLE_KEYWORD = "explorationreward"
# 页面配置与本场刚结算结果在 RunState.settings 中的位置
SETTINGS_PAGE_ID = "mirror.settings"
RULES_KEY = "reward_rules"
RUNTIME_KEY = "mirror.runtime"
LAST_RESULT_KEY = "last_result"
EXPLORATION_COMPLETE_KEY = "exploration_complete"
MODE_CLAIM = "claim"
MODE_GIVE_UP = "give_up"
# 未配置或配置非法时的默认值：刚胜利默认领取，刚失败与未知默认不领取
DEFAULT_MODES = {"victory": MODE_CLAIM, "defeat": MODE_GIVE_UP, "unknown": MODE_GIVE_UP}
CONDITIONS = ("victory", "defeat", "unknown")
MAX_ROUNDS = 20


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _in_region(item: dict, region: dict[str, int]) -> bool:
    """该 OCR 条目的中心是否落在给定区域。"""
    center = item.get("centerxy") or (0, 0)
    x, y = int(center[0]), int(center[1])
    return (
        int(region["x"]) <= x <= int(region["x"]) + int(region["width"])
        and int(region["y"]) <= y <= int(region["y"]) + int(region["height"])
    )


def _region_text(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回规范化小写文本；不刷新截图。"""
    texts = [str(item.get("text", "")) for item in items if _in_region(item, region)]
    return _norm(" ".join(text for text in texts if text))


def _page_here(items: list[dict]) -> bool:
    """当前帧是否为 Exploration Complete 结算页：标题与右下角 Claim Rewards 按钮都要命中。"""
    if TITLE_KEYWORD not in _region_text(items, TITLE_REGION):
        return False
    button = _region_text(items, BUTTON_REGION)
    return all(word in button for word in BUTTON_KEYWORDS)


def _popup_here(items: list[dict]) -> bool:
    """当前帧是否已打开 Exploration Reward 结算弹窗。"""
    return POPUP_TITLE_KEYWORD in _region_text(items, POPUP_TITLE_REGION)


def _runtime(ctx: RunContext) -> dict:
    """返回 RunState.settings 里的 mirror.runtime 字典；不存在时返回空字典。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return runtime if isinstance(runtime, dict) else {}


def _decision(ctx: RunContext) -> tuple[str, str]:
    """
    按本场刚结算结果读取 reward_rules，返回 (模式, 判定说明)。
    刚胜利默认领取，刚失败与未知默认不领取；读不到或值非法时按下表默认值处理。
    """
    runtime = _runtime(ctx)
    last = str(runtime.get(LAST_RESULT_KEY) or "unknown").strip().lower()
    if last not in CONDITIONS:
        last = "unknown"
    page = (ctx.run_state.settings or {}).get(SETTINGS_PAGE_ID)
    rules = page.get(RULES_KEY) if isinstance(page, dict) else None
    value = ""
    if isinstance(rules, dict):
        value = str(rules.get(last) or "").strip().lower()
    mode = value if value in (MODE_CLAIM, MODE_GIVE_UP) else DEFAULT_MODES[last]
    return mode, f"last_result={last}，规则 {mode}"


def _settled(ctx: RunContext) -> bool:
    """本场镜牢是否已执行过结算流程；已结算时不再重复点任何按钮。"""
    return _runtime(ctx).get(EXPLORATION_COMPLETE_KEY) is True


def _mark_settled(ctx: RunContext) -> None:
    """把本场镜牢领取／放弃已完成写进 RunState.settings，供 step.mirror_finished 做收尾判定。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录镜牢结算完成状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[EXPLORATION_COMPLETE_KEY] = True
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢结算完成 {EXPLORATION_COMPLETE_KEY}=True")


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    结算编排：每轮重新观察后推进一步，结算规则只在入口按刚结算结果判定一次。
    已结算过则零动作交回，避免重复点击；结算弹窗已在时按决定调用领取 Step（含确认弹窗）
    或放弃 Step；只在结算页时领取走 step.mirror_exploration_complete，
    放弃先用 step.mirror_open_reward_popup 打开弹窗再下一轮处理。
    弹窗关闭即视为结算完成，记录刚完成状态并交回；领取分支在这一刻立即调一次
    step.mirror_team_rotate 把队伍顺序真实轮换一格（写页面 team_order 资源与本次 Run 的列表），
    放弃分支不推进；同一分支连续第四次命中或总轮数耗尽时失败。
    """
    if _settled(ctx):
        ctx.log("本场镜牢结算流程已执行过，不再重复点击")
        return {"completed": True, "reason": "本场镜牢已结算", "page": "settled"}

    decision, detail = _decision(ctx)
    ctx.log(
        f"镜牢结算规则：{detail} → "
        + ("领取奖励（Claim）" if decision == MODE_CLAIM else "放弃奖励（Give Up Rewards）")
    )

    settled = False
    acted = False
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, MAX_ROUNDS + 1):
        meta = ctx.action("observe.capture_screen")
        # 每轮只做一次整屏 OCR：结算页标题、按钮与弹窗标题都从这份结果里按区域过滤
        items = _screen_items(ctx)
        popup = _popup_here(items)
        # 结算已执行过且弹窗已关闭：无论结算页是否还在，都不再重复点击
        if acted and not popup:
            settled = True
            _mark_settled(ctx)
            if decision == MODE_CLAIM:
                # 领取已完成：立刻执行一次队伍轮换 Step（把整份列表轮换一格写回页面与本次 Run），
                # 放弃奖励不推进，下一场镜牢仍用同一支队伍
                ctx.call("step.mirror_team_rotate")
            return {"completed": True, "reason": "镜牢结算已完成", "page": "settled"}
        page = _page_here(items)
        if not popup and not page:
            ctx.log("当前既不是结算页也没有结算弹窗，交回上层重新分派", level="warning", screenshot=True)
            return {"completed": False, "reason": "当前不在镜牢结算页", "page": "not_settlement"}
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            # 通用等待是循环最后一个分支：复用本轮整屏 OCR（文字＋中心点），不再让检测 Step 重复识别一次
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue

        if popup:
            if decision == MODE_CLAIM:
                hit("claim-popup")
                ctx.log(f"第{round_index}轮：结算弹窗在，调用一次领取 Step")
                ctx.call("step.mirror_exploration_complete")
            else:
                hit("give-up-popup")
                ctx.log(f"第{round_index}轮：结算弹窗在，调用一次放弃 Step")
                ctx.call("step.mirror_exploration_reward", claim=False)
        elif decision == MODE_CLAIM:
            hit("open-claim")
            ctx.log(f"第{round_index}轮：结算页在，调用一次领取 Step 打开弹窗")
            ctx.call("step.mirror_exploration_complete")
        else:
            hit("step.mirror_open_reward_popup")
            ctx.log(f"第{round_index}轮：结算页在，先调用一次打开结算弹窗")
            ctx.call("step.mirror_open_reward_popup")
            continue
        # 领取／放弃 Step 已执行：下一轮若弹窗已消失即视为结算完成
        acted = True
    raise ExecutionFailure("workflow_rounds_exhausted", "镜牢结算流程预算耗尽")
