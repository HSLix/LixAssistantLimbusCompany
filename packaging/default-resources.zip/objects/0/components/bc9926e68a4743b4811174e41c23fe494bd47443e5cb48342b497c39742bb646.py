"""镜牢 Rewards Acquired 到账弹窗：识别弹窗标题后点击固定坐标的 Confirm 关闭。

优先级提醒：该弹窗会盖在 Exploration Complete 结算页之上，
所以 task.mirror 必须在 exploration_complete 分支之前判定本 Step，
否则会把被弹窗盖住的结算页当成当前业务页，误点下层的 Claim Rewards。
"""
import re

from lalc import RunContext, step

# Rewards Acquired 弹窗标题区域（1280x720 客户区）：要包住整行标题
TITLE_REGION = {"x": 480, "y": 220, "width": 320, "height": 70}
# OCR 会把标题切成 "Rewards" 与 "s Acquired" 两段，所以按两个词分别匹配，不用整句关键字
TITLE_KEYWORDS = ("rewards", "acquired")
# 弹窗内 Confirm 按钮（含左侧对勾）的固定坐标
CONFIRM_POINT = (655, 472)
# 点击后等待弹窗关闭的轮询间隔与轮数


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _title_text(ctx: RunContext) -> str:
    """对当前帧弹窗标题区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=TITLE_REGION) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _popup_here(ctx: RunContext) -> bool:
    """当前帧是否出现 Rewards Acquired 弹窗标题（容忍 OCR 把标题切成多段）。"""
    text = _title_text(ctx)
    return all(word in text for word in TITLE_KEYWORDS)


@step
def execute(ctx: RunContext) -> None:
    """复查当前操作入口，适用时仅点击一次。"""
    ctx.action("observe.capture_screen")
    if not _popup_here(ctx):
        ctx.log("当前没有 Rewards Acquired 弹窗，无需点击 Confirm")
        return

    ctx.log(f"Rewards Acquired 弹窗：点击固定坐标的 Confirm {CONFIRM_POINT}")
    ctx.action("control.click", x=CONFIRM_POINT[0], y=CONFIRM_POINT[1])
