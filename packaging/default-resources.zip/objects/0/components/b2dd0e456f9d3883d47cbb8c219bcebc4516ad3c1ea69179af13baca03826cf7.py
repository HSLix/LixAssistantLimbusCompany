"""镜牢 Select Encounter Reward Card 页面选卡：把能定位到的卡片按优先级从低到高各点一次，最后停在最高优先级。"""
import re

from lalc import RunContext, step

# 页面标题条：Select Encounter Reward Card
TITLE_REGION = {"x": 270, "y": 100, "width": 540, "height": 70}
TITLE_KEYWORD = "encounterrewardcard"
# 卡片图标所在区域：卡片上部的图标行
CARD_REGION = {"x": 330, "y": 175, "width": 640, "height": 290}
# 卡片优先级：靠前的先选；以后新增卡类只要按优先级往这个元组里加素材逻辑名
# coin（镜牢局内 Coin 货币）排在 starlight 之后，与下面文字 OCR 的关键词优先级一致
# cost_and_gift_chance（Cost 与 E.G.O 礼品概率）卡片图标在卡面上有缩放与形变，
# 因此与其它卡类一样走特征匹配；优先级低于 coin、高于 random_gift
CARD_PRIORITY = (
    "mirror/reward_card/starlight",
    "mirror/reward_card/coin",
    "mirror/reward_card/cost_and_gift_chance",
    "mirror/reward_card/random_gift",
)
# 卡片说明文字所在区域：从 (120, 300) 到 (1200, 500)；优先在这里用 OCR 读卡片效果文案
CARD_TEXT_REGION = {"x": 120, "y": 300, "width": 1080, "height": 200}
# 卡片文案的关键词优先级（全部小写匹配）：
# starlight → coin / cost（且不含 gift）→ gift → resource
# 镜牢局内 Coin 货币卡的英文文案写作 "Gain x~y Cost"，没有 coin 字样，
# 所以 cost 与 coin 视为同一档（Run 292 里只认 coin 时这张卡不参与排名，结果选了 gift）
KEYWORD_STARLIGHT = "starlight"
KEYWORD_COIN = "coin"
KEYWORD_COST = "cost"
KEYWORD_GIFT = "gift"
KEYWORD_RESOURCE = "resource"
# 同一张卡片文字块的判定：包围框水平间隙不超过这个像素数算同一块；
# 同一行文字判定：包围框中心 y 相差不超过这个像素数算同一行
BLOCK_GAP_X = 40
LINE_TOLERANCE_Y = 12
# 横向重叠的文字块仍属于同一张卡：同一张卡的说明文字被拆成多块时合并成一个点击点。
# 同一张卡点第二次会把已选中的卡取消掉，所以每个点击点只能点一次
# 读不到任何关键词的卡片按最低优先级处理，最先点
UNKNOWN_RANK = 99
# 同一张卡片的判定：两个点击点横纵都靠得这么近就视为同一处，不重复点击
SAME_POINT_PX = 40
# 单张奖励卡说明文字块的宽度上限：同一页相邻两张卡的说明文字列间距只有 30~40 px，
# 比 BLOCK_GAP_X 还小，换页过渡帧里多列文字会被链式串成一块（Run 617 的 Acquire E.G.O Gift 帧
# 就并出 760 px 宽的一块，中心落在 (635,400)）。实测单张卡的说明文字块不超过 190 px，
# 所以超过这个宽度的块一定跨了多列，不能当作一张卡去点。
MAX_CARD_WIDTH = 300
# 每点一张卡片后的固定等待秒数：等选中状态生效再点下一张
AFTER_CLICK_SECONDS = 0.5


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_items(ctx: RunContext, region: dict[str, int]) -> list[dict]:
    """在入口那一帧上对指定区域做 OCR；不刷新截图，保证标题校验与取点用同一帧。"""
    result = ctx.action("observe.ocr", region=region) or {}
    return list(result.get("items") or [])


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _title_text(ctx: RunContext) -> str:
    """对当前帧的标题条做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=TITLE_REGION) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _box(item: dict) -> tuple[int, int, int, int]:
    """取 OCR 条目的包围框 (x, y, width, height)；缺字段时按 0 处理。"""
    box = item.get("box") or {}
    return (
        int(box.get("x", 0)),
        int(box.get("y", 0)),
        int(box.get("width", 0)),
        int(box.get("height", 0)),
    )


def _gap_x(first: tuple[int, int, int, int], second: tuple[int, int, int, int]) -> int:
    """两个包围框的水平间隙，重叠时返回 0。"""
    ax, _, aw, _ = first
    bx, _, bw, _ = second
    return max(0, bx - (ax + aw), ax - (bx + bw))


def _blocks(items: list[dict]) -> list[list[dict]]:
    """
    把 OCR 条目聚成每张卡片一个文字块：水平间隙不超过 BLOCK_GAP_X 的条目属于同一张卡片。
    不同卡片的说明文字之间间隙明显更大，因此不会被并到同一块里。
    """
    blocks: list[list[dict]] = []
    for item in sorted(items, key=lambda entry: _box(entry)[0]):
        if not str(item.get("text") or "").strip():
            continue
        item_box = _box(item)
        for block in blocks:
            if any(_gap_x(item_box, _box(member)) <= BLOCK_GAP_X for member in block):
                block.append(item)
                break
        else:
            blocks.append([item])
    return blocks


def _block_text(block: list[dict]) -> tuple[str, tuple[int, int, int, int]]:
    """
    把一个卡片文字块按 y 相近合并成行，行内按 x 顺序拼接，返回整块小写文案与合并后的包围框。
    """
    lines: list[dict] = []
    for item in sorted(block, key=lambda entry: _box(entry)[1] + _box(entry)[3] / 2):
        center = _box(item)[1] + _box(item)[3] / 2
        for line in lines:
            if abs(line["center"] - center) <= LINE_TOLERANCE_Y:
                line["items"].append(item)
                break
        else:
            lines.append({"center": center, "items": [item]})

    lines.sort(key=lambda line: line["center"])
    texts = [
        " ".join(str(entry.get("text") or "") for entry in sorted(line["items"], key=lambda it: _box(it)[0]))
        for line in lines
    ]
    boxes = [_box(entry) for entry in block]
    left = min(box[0] for box in boxes)
    top = min(box[1] for box in boxes)
    right = max(box[0] + box[2] for box in boxes)
    bottom = max(box[1] + box[3] for box in boxes)
    return " ".join(texts).strip(), (left, top, right - left, bottom - top)


def _rank(text: str) -> tuple[int, str] | None:
    """
    按卡片文案关键词排名（小写匹配）：starlight 最优，其次是 Coin 货币卡
    （含 coin，或文案为 "Gain x~y Cost" 而含 cost，且不含 gift），再次是含 gift 的，
    最后是含 resource 的；都不含时返回 None，表示不参与选择。
    """
    lowered = str(text).lower()
    if KEYWORD_STARLIGHT in lowered:
        return 0, KEYWORD_STARLIGHT
    if KEYWORD_GIFT not in lowered:
        if KEYWORD_COIN in lowered:
            return 1, KEYWORD_COIN
        if KEYWORD_COST in lowered:
            return 1, KEYWORD_COST
    if KEYWORD_GIFT in lowered:
        return 2, KEYWORD_GIFT
    if KEYWORD_RESOURCE in lowered:
        return 3, KEYWORD_RESOURCE
    return None


def _union_box(first: tuple[int, int, int, int], second: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    """两个包围框的并集，用来把同一张卡被拆开的文字块合成一个点击区域。"""
    left = min(first[0], second[0])
    top = min(first[1], second[1])
    right = max(first[0] + first[2], second[0] + second[2])
    bottom = max(first[1] + first[3], second[1] + second[3])
    return left, top, right - left, bottom - top


def _x_overlap(first: tuple[int, int, int, int], second: tuple[int, int, int, int]) -> int:
    """两个包围框的横向重叠像素数；不大于 0 说明分属不同的卡片列。"""
    return min(first[0] + first[2], second[0] + second[2]) - max(first[0], second[0])


def _card_entries(ctx: RunContext) -> list[dict]:
    """
    在入口那一帧上对卡片说明文字区做一次 OCR，把横向重叠的文字块合并成同一张卡。
    返回 [{"rank", "keyword", "text", "point"}]，按画面上从左到右排列；一张也定位不到时返回空列表。
    读不到 starlight / coin / cost / gift / resource 关键词的卡片也保留，按最低优先级处理；
    合并后宽度超过 MAX_CARD_WIDTH 的块视为跨了多列（不是一张卡），警告后丢弃，不参与点击。
    """
    items = _region_items(ctx, CARD_TEXT_REGION)
    blocks = _blocks(items)
    cards: list[dict] = []
    for block in blocks:
        text, box = _block_text(block)
        rank = _rank(text)
        for card in cards:
            if _x_overlap(card["box"], box) > 0:
                card["box"] = _union_box(card["box"], box)
                card["text"] = f"{card['text']} {text}".strip()
                if rank is not None and (card["rank"] is None or rank[0] < card["rank"][0]):
                    card["rank"] = rank
                break
        else:
            cards.append({"text": text, "box": box, "rank": rank})

    entries: list[dict] = []
    for card in cards:
        left, top, width, height = card["box"]
        if width > MAX_CARD_WIDTH:
            # 说明文字区里跨了多列（换页过渡帧上的 Acquire E.G.O Gift 三张饰品卡就是这样，Run 617）：
            # 这不是一张卡，合并出来的中心也不是可点目标，直接丢弃，
            # 不再按 UNKNOWN_RANK 去点屏幕中间
            ctx.log(
                f"文字块合并后宽 {width} px，超过单张卡片上限 {MAX_CARD_WIDTH} px，"
                f"判定为跨列合并，跳过不点击：{card['text'][:60]}",
                level="warning",
            )
            continue
        entries.append(
            {
                "rank": card["rank"][0] if card["rank"] else UNKNOWN_RANK,
                "keyword": card["rank"][1] if card["rank"] else "unknown",
                "text": card["text"],
                "point": (left + width // 2, top + height // 2),
            }
        )
    return entries


def _click_order(entries: list[dict]) -> list[dict]:
    """
    按优先级从低到高排序：读不到关键词的卡最先点，之后 resource → gift → coin／cost → starlight。
    最后点的是本页最高优先级的一张，用它的选择覆盖前面点过的卡。
    """
    return sorted(entries, key=lambda entry: -int(entry["rank"]))


def _feature_clicks(ctx: RunContext) -> int:
    """
    OCR 定位不到卡片时的兜底：按 CARD_PRIORITY 的逆序（低优先级先点）逐个素材做特征匹配，
    每处命中都点一次；同一位置不重复点击，避免把已经选中的同一张卡又点成未选。返回点击次数。
    全部匹配都用入口那一帧，避免中途换页后拿着旧页面的命中去点新页面。
    """
    clicked: list[tuple[int, int]] = []
    for asset in reversed(CARD_PRIORITY):
        hits = ctx.action("observe.match_feature", asset=asset, region=CARD_REGION) or []
        for hit in sorted(hits, key=lambda item: -float(item.get("score", 0.0))):
            center = hit.get("centerxy") or (0, 0)
            point = (int(center[0]), int(center[1]))
            if any(
                abs(point[0] - other[0]) <= SAME_POINT_PX and abs(point[1] - other[1]) <= SAME_POINT_PX
                for other in clicked
            ):
                continue
            clicked.append(point)
            ctx.log(f"OCR 定位不到卡片，按特征匹配点击 {asset} 卡片图标 {point}")
            ctx.action("control.click", centerxy=point)
            ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
    return len(clicked)


@step
def execute(ctx: RunContext) -> None:
    """
    在镜牢 Select Encounter Reward Card 页面把能定位到的卡片全部点一遍：
    - 不在本页（标题条读不到 Encounter Reward Card）时零输入返回；
    - 先对卡片说明文字区 OCR，按「优先级最低 → 优先级最高」各点一次，
      最后点的是本页最高优先级的一张，用它的选择覆盖前面点过的卡，确保一定选中；
      同一张卡只点一次（同一张卡点第二次会把已选中的卡取消掉）；
    - OCR 定位不到卡片时退回特征匹配 CARD_PRIORITY 的逆序，同样全部点击；两者都没命中时不点击。
    点完只等固定等待秒数交回；是否已提交、是否需要先按 ESC 由
    sub_workflow.mirror_reward_card 下一轮重新观察，本步不读 Selectable 计数、不轮询。
    """
    # 本步只截这一帧：标题校验与取点都用它，避免两次截图之间页面已经切换
    # （Run 617 就是在标题校验后重新截图，对着 Acquire E.G.O Gift 页按旧页面的取点规则点到了画面中间）
    ctx.action("observe.capture_screen")
    if TITLE_KEYWORD not in _title_text(ctx):
        ctx.log("当前不是 reward card 可选卡片页，本步不点击")
        return

    entries = _card_entries(ctx)
    if entries:
        ordered = _click_order(entries)
        ctx.log(
            "选卡顺序（低→高）："
            + "、".join(f"{entry['keyword']}({entry['point'][0]},{entry['point'][1]})" for entry in ordered)
        )
        for entry in ordered:
            ctx.action("control.click", centerxy=entry["point"])
            ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
        return

    ctx.log("卡片说明文字区没有定位到卡片，改用特征匹配按低→高优先级点击")
    if _feature_clicks(ctx):
        return

    ctx.log(
        "OCR 与特征匹配都没有选出已知奖励卡片，本步不点击；"
        "新卡类需要先在素材库补充 mirror/reward_card/ 下的图标",
        level="warning",
        screenshot=True,
    )
