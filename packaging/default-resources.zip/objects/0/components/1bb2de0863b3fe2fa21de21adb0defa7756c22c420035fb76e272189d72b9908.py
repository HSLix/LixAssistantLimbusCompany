"""处理 Will you enter Mirror of Sisyphe? 提示：不进入探索，点 Cancel 留在镜牢入口页。"""
import re

from lalc import ExecutionFailure, RunContext, step

POPUP_REGION = {"x": 210, "y": 90, "width": 850, "height": 510}
# 提示文案：Will you enter Mirror of Sisyphe?
PROMPT_TEXT = "willyouentermirrorofsisyphe"
CANCEL_LABEL = "cancel"
# Cancel 按钮在 1280x720 客户区中的回退坐标
CANCEL_FALLBACK = (538, 485)
# 点击 Cancel 后的固定等待秒数；不在此判断提示是否已关闭
AFTER_CLICK_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行导致匹配失败。"""
    return re.sub(r"[^a-z0-9]", "", text.lower())


def _region_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回弹窗区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=POPUP_REGION) or {}
    return list(result.get("items") or [])


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _click_cancel(ctx: RunContext, items: list[dict]) -> None:
    """点击文字包含 cancel 的按钮，识别不到时退回固定坐标。"""
    candidates = [
        item for item in items if CANCEL_LABEL in _norm(str(item.get("text", "")))
    ]
    if not candidates:
        ctx.log(f"提示里未识别到 Cancel 文本，点击回退坐标 {CANCEL_FALLBACK}", level="warning")
        ctx.action("control.click", x=CANCEL_FALLBACK[0], y=CANCEL_FALLBACK[1])
        return

    def distance(item: dict) -> float:
        """候选按钮中心到回退坐标的距离。"""
        center = item.get("centerxy") or CANCEL_FALLBACK
        return (
            (center[0] - CANCEL_FALLBACK[0]) ** 2 + (center[1] - CANCEL_FALLBACK[1]) ** 2
        ) ** 0.5

    target = min(candidates, key=distance)
    ctx.log(f"提示点击 Cancel @ {target.get('centerxy')}")
    ctx.action("control.click", centerxy=tuple(target.get("centerxy")))


@step
def execute(ctx: RunContext) -> None:
    """
    截图后没看到 Will you enter Mirror of Sisyphe? 提示时零输入返回；
    有该提示时只点一次 Cancel（不进入探索），等固定 1 秒后交回。
    提示是否已关闭由上层下一轮重新观察，本步不轮询。
    """
    items = _region_items(ctx)
    if PROMPT_TEXT not in _items_text(items):
        ctx.log("当前没有 Will you enter Mirror of Sisyphe? 提示，无需处理")
        return

    _click_cancel(ctx, items)
    ctx.log(f"已点击 Cancel，等 {AFTER_CLICK_SECONDS} 秒后交回上层重新观察提示是否关闭")
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
