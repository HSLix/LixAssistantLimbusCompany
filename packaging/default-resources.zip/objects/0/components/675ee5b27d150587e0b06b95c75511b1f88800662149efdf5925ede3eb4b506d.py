"""镜牢商店融合：把右侧 Gifts Owned 列表往下滚一格，并报告滚动条是否到底／消失。

现场（1280x720，Run 507/509）实测：融合页右侧滚动条与售出弹窗是同一套 UI，
滑块模板 mirror/shop/sell_gift_scroll_end（28x76）在融合页同样命中（实测 (1122,236) 分数 0.983），
滑轨顶端滑块中心 y≈235、底端沿用售出弹窗实测 y≈466。列表较短、没有滚动条时模板不命中，
这时按「没有更多屏」处理（对应开发者要求的「滚动块消失」）。
本步按「先判断，能滚才滚」的顺序推进：直接在当前帧上用滑块模板判断滚动块是否存在／是否到底；
只有滚动块存在且没到底时才向下滚 4 格并等待 1s，交上层重新观察并重新匹配耗材。
本步不点击任何固定坐标，也不点击任何卡片（开发者要求：滚动前不做固定坐标点击）。
"""
import re

from lalc import RunContext, step

# 融合页标识：标题横幅用素材 mirror/shop/fuse/fuse_ego_gift（425x44）做原尺寸模板匹配，
# 不再读标题文字，也不再读右上角 Fusion Guide 文字。
FUSE_TITLE_ASSET = "mirror/shop/fuse/fuse_ego_gift"
FUSE_TITLE_REGION = {"x": 390, "y": 55, "width": 500, "height": 90}
FUSE_TITLE_THRESHOLD = 0.85
# 关键词弹窗：出现时不能滚动（会改变弹窗状态），零输入返回
FUSE_KEYWORD_TITLE_REGION = {"x": 380, "y": 70, "width": 520, "height": 60}
FUSE_KEYWORD_TITLE_KEYWORD = "fusionkeywordselection"
# 右侧滚动条区域与滑块模板（与 sub_workflow.mirror_sell_gift_maintain 一致）。
# 售出弹窗实测滑块在 x≈1122；融合页的滑轨在面板更外侧（Run 524 现场截图 x≈1175~1195，
# y≈200~480），原来 45px 宽的窄区域在融合页正好是空白，会误判 no_scrollbar 提前结束融合，
# 因此区域同时覆盖两处：x 1100~1200。
SCROLL_REGION = {"x": 1100, "y": 195, "width": 100, "height": 320}
SCROLL_THUMB_ASSET = "mirror/shop/sell_gift_scroll_end"
SCROLL_THUMB_THRESHOLD = 0.8
SCROLL_THUMB_BOTTOM_Y = 466
SCROLL_BOTTOM_TOLERANCE = 6
# 滚动落点：右侧列表中部，避免落在 Fusion Available 标签或底部按钮上
SCROLL_POINT = (900, 470)
SCROLL_STEPS = 4
SCROLL_WAIT_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _fuse_popup_open(ctx: RunContext) -> bool:
    """当前帧是否在 Fuse E.G.O Gift 弹窗上：只用标题横幅素材 mirror/shop/fuse/fuse_ego_gift 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=FUSE_TITLE_ASSET,
            region=FUSE_TITLE_REGION,
            threshold=FUSE_TITLE_THRESHOLD,
        )
    )


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    先截屏，再用滑块模板判断滚动块位置（不做固定坐标点击）：
    - 没命中滑块 → no_scrollbar（列表短、没有滚动块，也没有更多屏）并结束；
    - 命中且中心 y 到滑轨底部 → at_bottom（滚动块到底，没有更多耗材屏）并结束；
    - 命中但还没到底 → 在列表中部向下滚 SCROLL_STEPS 格、等待 1s 后返回 scrolled，
      由上层重新观察并重新匹配耗材；
    - 不在融合页或关键词弹窗开着 → 零输入返回，不动列表。
    本步不点击礼物卡、不判断业务完成。
    """
    ctx.action("observe.capture_screen")
    if FUSE_KEYWORD_TITLE_KEYWORD in _region_text(ctx, FUSE_KEYWORD_TITLE_REGION):
        ctx.log("融合流派选择弹窗开着，本步不滚动列表")
        return {"action": "keyword_popup"}
    if not _fuse_popup_open(ctx):
        ctx.log("当前不在 Fuse E.G.O Gift 弹窗上，本步不滚动列表", level="warning", screenshot=True)
        return {"action": "not_fuse_popup"}

    # 直接在当前帧上用滑块模板判断滚动块是否存在／是否到底，不做固定坐标点击
    hits = (
        ctx.action(
            "observe.match_asset",
            asset=SCROLL_THUMB_ASSET,
            region=SCROLL_REGION,
            threshold=SCROLL_THUMB_THRESHOLD,
        )
        or []
    )
    ys = [int(hit["centerxy"][1]) for hit in hits if hit.get("centerxy")]
    if not ys:
        ctx.log(
            f"右侧滚动条没有匹配到滑块模板 {SCROLL_THUMB_ASSET}，按列表已无更多屏处理",
            level="info",
            screenshot=True,
        )
        return {"action": "no_scrollbar"}
    thumb_y = max(ys)
    if thumb_y >= SCROLL_THUMB_BOTTOM_Y - SCROLL_BOTTOM_TOLERANCE:
        ctx.log(f"滚动条滑块中心 y={thumb_y}，已到滑轨底部，列表到底")
        return {"action": "at_bottom", "thumb_y": str(thumb_y)}
    ctx.log(f"滚动条滑块中心 y={thumb_y}，还没到底，在融合页右侧列表 {SCROLL_POINT} 向下滚 {SCROLL_STEPS} 格")
    ctx.action(
        "control.scroll",
        direction="down",
        steps=SCROLL_STEPS,
        centerxy=SCROLL_POINT,
    )
    ctx.action("observe.wait", seconds=SCROLL_WAIT_SECONDS)
    ctx.log(f"已向下滚 {SCROLL_STEPS} 格并等待 {SCROLL_WAIT_SECONDS}s，交上层重新匹配耗材")
    return {"action": "scrolled", "thumb_y": str(thumb_y)}
