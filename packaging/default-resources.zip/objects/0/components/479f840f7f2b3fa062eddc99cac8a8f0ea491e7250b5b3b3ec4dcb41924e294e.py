"""镜牢商店融合子流程：购买循环结束后执行一次 Fuse Gifts。

融合耗材名单（开发者要求）：取「饰品配置 shop_gifts.preferences」里的 mirror/gift/<流派>/<名字> 条目
（键就是素材逻辑名），流派只取素材目录段、名字只取目录名，条目里没有名称标签；这份配置由页面每次按
素材目录重建，手工直接加进素材库的饰品也在里面（饰品图鉴资源已退役，不再读它）。
按流派去掉「本队商店购买流派」（队伍配置 teams[].shop_keywords，缺该键时退回 gift_keyword），
再减去「饰品配置」里设为「优先获取」（preferences=prefer）的饰品，剩下就是融合耗材。
另外并入本次 Run 的临时新增饰品字典 mirror.runtime.new_gifts（step.mirror_sell_gift_slot 保存的、
「饰品配置」里还没有的饰品，按 default 偏好参与，仍受本队流派与「优先获取」过滤）：
页面重建前刚收录的饰品因此也能在本次 Run 的后续商店参与融合，跨 Run 仍需页面重建。
配置里没有条目时仍会打开融合页：现成融合（Fusion Available）不依赖耗材名单。

每轮（对应开发者步骤 1~4）：
- 先处理 Fusion - Keyword Selection 弹窗与 Select a Keyword 提示，按本队流派选关键词；
- 有 Fusion Available → 点标签下方第一件礼物（现成配方）并 Fuse＋确认，进入下一轮；
- 没有现成融合 → 检查左侧 final_fuse_place 空位：空位还在就一次匹配右侧列表里的耗材卡并逐个点入，
  每点一张复查空位；空位消失就 Fuse＋确认；空位本来就不在（已点满）也直接 Fuse＋确认；
- 本帧没有耗材 → 向下滚动右侧列表；滚动条到底或消失说明没有更多屏。
- 融合确认后会弹出 E.G.O Gift GET! 到手弹窗（盖住融合页）：用素材 mirror/ego_gift_get 做
  原尺寸模板匹配识别，交 step.mirror_gift_get_confirm 按一次 Enter 确认后回到融合循环。

退出条件（开发者步骤 5）：用完耗材（本帧与滚动后都没有可点的耗材卡）、final_fuse_place 仍存在，
且右侧滚动条消失或已到滑轨底部。退出前统一调用 step.mirror_shop_fuse_close 关闭融合弹窗，
把商店页交回上层做最后的饰品自维护与离开商店。任何一步都不点 Sell、不卖饰品。
同一动作连续命中超过 MAX_REPEAT_HITS 次仍在原地时抛 workflow_branch_limit 交恢复规则处理。
"""
import re

from lalc import ExecutionFailure, RunContext, sub_workflow

# 商店页标识（与购买循环一致）
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 融合页标题横幅：用素材 mirror/shop/fuse/fuse_ego_gift（425x44）做原尺寸模板匹配，不再读标题文字，
# 也不再读右上角 Fusion Guide 文字；搜索区域按 1280x720 现场标题位置放宽，保证能完整容纳模板。
FUSE_TITLE_ASSET = "mirror/shop/fuse/fuse_ego_gift"
FUSE_TITLE_REGION = {"x": 390, "y": 55, "width": 500, "height": 90}
FUSE_TITLE_THRESHOLD = 0.85
FUSE_KEYWORD_TITLE_REGION = {"x": 380, "y": 70, "width": 520, "height": 60}
FUSE_KEYWORD_TITLE_KEYWORD = "fusionkeywordselection"
FUSE_KEYWORD_PROMPT_REGION = {"x": 730, "y": 350, "width": 250, "height": 60}
FUSE_KEYWORD_PROMPT = "selectakeyword"
# 融合确认后的 E.G.O Gift GET! 到手弹窗：用素材 mirror/ego_gift_get（430x34 标题横幅）做原尺寸模板匹配，
# 不再读标题文字；搜索区域按 1280x720 现场标题位置放宽，保证能完整容纳模板。
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
# 页面配置（饰品镜像与队伍配置）
MIRROR_PAGE_ID = "mirror.settings"
SHOP_GIFTS_KEY = "shop_gifts"
GIFT_PREFERENCE_KEY = "preferences"
PREFERENCE_PREFER = "prefer"
TEAM_PAGE_ID = "sinners.team_presets"
TEAMS_KEY = "teams"
SHOP_KEYWORDS_KEY = "shop_keywords"
INITIAL_KEYWORD_KEY = "gift_keyword"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
KEYWORD_NONE = "none"
RUNTIME_KEY = "mirror.runtime"
TEAM_USED_KEY = "team_used"
# 本次 Run 临时新增饰品字典：{饰品逻辑名: 收录来源}，由 step.mirror_sell_gift_slot 在保存成功后写入，
# 存的是「已入库但「饰品配置」里还没有」的饰品；融合名单计算时并入，按 default 偏好参与，
# 仍受本队流派与「优先获取」过滤，且只在本次 Run 内有效（跨 Run 需要页面按素材目录重建）。
NEW_GIFTS_KEY = "new_gifts"
GIFT_PREFIX = "mirror/gift/"
# 同一个动作连续命中太多次仍未推进时，在执行前抛错
MAX_ROUNDS = 60
MAX_REPEAT_HITS = 15
# 连续滚动这么多次仍没有点入任何耗材，说明滚动不生效或耗材识别持续失败
MAX_STALLED_SCROLLS = 20
# 不在商店页/融合页时（融合动画、切换过渡）有界重试几次
MAX_PAGE_RETRIES = 3
PAGE_RETRY_SECONDS = 1.0
# 融合名单 debug 日志每行最多列多少个饰品逻辑名
GIFT_LOG_CHUNK = 12


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _on_shop(ctx: RunContext) -> bool:
    """当前帧是否为镜牢商店页。"""
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


def _fuse_popup_open(ctx: RunContext) -> bool:
    """当前帧是否在 Fuse E.G.O Gift 弹窗上：只用标题横幅素材 mirror/shop/fuse/fuse_ego_gift 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=FUSE_TITLE_ASSET,
            region=FUSE_TITLE_REGION,
            threshold=FUSE_TITLE_THRESHOLD,
        )
    )


def _keyword_popup_open(ctx: RunContext) -> bool:
    """当前帧是否叠着 Fusion - Keyword Selection 弹窗。"""
    return FUSE_KEYWORD_TITLE_KEYWORD in _region_text(ctx, FUSE_KEYWORD_TITLE_REGION)


def _keyword_prompt(ctx: RunContext) -> bool:
    """融合页右侧是否还显示 Select a Keyword。"""
    return FUSE_KEYWORD_PROMPT in _region_text(ctx, FUSE_KEYWORD_PROMPT_REGION)


def _gift_get_popup(ctx: RunContext) -> bool:
    """当前帧是否叠着融合确认后的 E.G.O Gift GET! 到手弹窗：只用素材 mirror/ego_gift_get 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=GIFT_GET_ASSET,
            region=GIFT_GET_REGION,
            threshold=GIFT_GET_THRESHOLD,
        )
    )


def _settings(ctx: RunContext) -> dict:
    """RunState.settings；不可用时按空字典处理。"""
    settings = ctx.run_state.settings
    return settings if isinstance(settings, dict) else {}


def _team_index(ctx: RunContext) -> int:
    """本场镜牢实际使用的队伍序号：只读 mirror.runtime.team_used；缺失时按第 1 个队伍处理。"""
    runtime = _settings(ctx).get(RUNTIME_KEY)
    used = runtime.get(TEAM_USED_KEY) if isinstance(runtime, dict) else None
    if type(used) is int and 1 <= used <= MAX_TEAMS:
        return used
    ctx.log(
        f"没有可用的本场队伍记录 {TEAM_USED_KEY}={used!r}，按第{DEFAULT_TEAM}个队伍处理",
        level="warning",
    )
    return DEFAULT_TEAM


def _archetype(value: str) -> str:
    """把图鉴流派归一成与队伍配置同一个键：sink/sinking → sinking，general/keywordless/none → keywordless。"""
    key = _norm(value)
    if key in ("sink", "sinking"):
        return "sinking"
    if key in ("general", "keywordless", "none"):
        return "keywordless"
    return key


def _shop_keywords(ctx: RunContext) -> set[str]:
    """读取本场队伍在队伍配置页勾选的「商店购买饰品流派」。"""
    settings = _settings(ctx)
    team_index = _team_index(ctx)
    teams_page = settings.get(TEAM_PAGE_ID) or {}
    teams = teams_page.get(TEAMS_KEY) if isinstance(teams_page, dict) else None
    if not isinstance(teams, list) or not 1 <= team_index <= len(teams):
        ctx.log(f"队伍配置里没有第{team_index}个队伍，按没有购买流派处理（所有流派饰品都算耗材）",
                level="warning")
        return set()
    entry = teams[team_index - 1]
    if not isinstance(entry, dict):
        return set()
    raw = entry.get(SHOP_KEYWORDS_KEY)
    if isinstance(raw, list):
        return {_archetype(value) for value in raw if str(value).strip()}
    keyword = str(entry.get(INITIAL_KEYWORD_KEY) or "").strip()
    return set() if not keyword or _norm(keyword) == KEYWORD_NONE else {_archetype(keyword)}


def _preferences(ctx: RunContext) -> dict[str, str]:
    """读取「饰品配置」里每件饰品的获取偏好（键是饰品逻辑名 mirror/gift/<流派>/<名字>）。"""
    page = _settings(ctx).get(MIRROR_PAGE_ID) or {}
    gifts = page.get(SHOP_GIFTS_KEY) if isinstance(page, dict) else None
    raw = gifts.get(GIFT_PREFERENCE_KEY) if isinstance(gifts, dict) else None
    return dict(raw) if isinstance(raw, dict) else {}


def _log_gift_group(ctx: RunContext, title: str, assets: list[str]) -> None:
    """按组用 debug 级别记录饰品逻辑名；条目多时每行 GIFT_LOG_CHUNK 个，便于逐屏核对名单。"""
    if not assets:
        ctx.log(f"融合名单 {title}：0 件", level="debug")
        return
    for start in range(0, len(assets), GIFT_LOG_CHUNK):
        part = assets[start:start + GIFT_LOG_CHUNK]
        ctx.log(
            f"融合名单 {title} [{start + 1}-{start + len(part)}/{len(assets)}]："
            + ", ".join(part),
            level="debug",
        )


def _gift_leaf(key) -> str:
    """饰品逻辑名必须是 mirror/gift/<流派>/<名字>；形状不符时返回空串（旧格式条目直接丢弃）。"""
    text = str(key)
    if not text.startswith(GIFT_PREFIX):
        return ""
    parts = text.split("/")
    return parts[3] if len(parts) == 4 and parts[3] else ""


def _new_gifts(ctx: RunContext) -> dict[str, str]:
    """
    本次 Run 的临时新增饰品字典：{饰品逻辑名: 收录来源}，由 step.mirror_sell_gift_slot 在保存成功后写入。
    字典缺失、非字典或空时返回空字典（配置镜像仍是唯一来源，行为与改动前一致）。
    """
    runtime = _settings(ctx).get(RUNTIME_KEY)
    record = runtime.get(NEW_GIFTS_KEY) if isinstance(runtime, dict) else None
    if not isinstance(record, dict):
        return {}
    return {str(name): str(source) for name, source in record.items()}


def _asset_gifts(ctx: RunContext) -> set[str]:
    """
    融合名单的饰品全集 = 素材库镜像里的饰品逻辑名 ∪ 本次 Run 临时新增饰品字典。
    - 配置部分：页面「饰品配置」每次都按素材目录 mirror/gift/<流派>/<名字> 重建（手工直接加进素材库的
      饰品也会带一条 default 偏好），所以 preferences 的键就是素材库现有饰品；
    - 临时字典部分：自维护刚收录、页面还没重建的饰品（本 Run 内有效），补上配置镜像的滞后；
    工作流无法直接枚举素材库，两者合起来就是本步能知道的所有饰品。形状不符的键一律丢弃。
    """
    assets = {str(name) for name in _preferences(ctx) if _gift_leaf(name)}
    assets.update(name for name in _new_gifts(ctx) if _gift_leaf(name))
    return assets


def _consumables(ctx: RunContext) -> list[str]:
    """
    融合耗材名单：「饰品配置」（素材库镜像）里的所有 mirror/gift/<流派>/<名字> 条目，
    去掉本队商店购买流派，再减去「优先获取」的饰品。返回按逻辑名排序、去重的素材名列表。
    饰品配置的键由页面按素材目录重建，所以手工直接加进素材库的饰品也在里面；
    饰品图鉴资源已退役，本流程不再读写它。
    流派只取素材目录段、名字取最后一段，条目没有名称标签，所以这里没有第二份名字数据要对。
    整理过程按开发者要求用 debug 级别记录总饰品、自己流派饰品、优先获取饰品、
    其他流派饰品，最后记录实际参与融合的耗材饰品名字。
    """
    assets = _asset_gifts(ctx)
    if not assets:
        ctx.log(
            "「饰品配置」里没有 mirror/gift/<流派>/<名字> 条目，融合耗材名单为空"
            "（仍会打开融合页处理现成融合）",
            level="warning",
        )
        return []
    configured = {str(name) for name in _preferences(ctx) if _gift_leaf(name)}
    merged = {name for name in _new_gifts(ctx) if _gift_leaf(name)}
    added = sorted(merged - configured)
    ctx.log(
        f"融合名单 来源：「饰品配置」（素材库镜像）{len(configured)} 件"
        + (
            f"；并入本次 Run 临时新增饰品 {len(added)} 件（字典共 {len(merged)} 件，其中 "
            f"{len(merged & configured)} 件配置里已经有）"
            if merged
            else "；本次 Run 临时新增饰品字典为空"
        )
        + f"，合并后共 {len(assets)} 件",
        level="debug",
    )
    _log_gift_group(
        ctx, "本次 Run 临时新增饰品（配置镜像里还没有，按 default 参与融合）", added
    )
    keywords = _shop_keywords(ctx)
    preferences = _preferences(ctx)
    ctx.log(f"融合名单 本队商店购买流派：{sorted(keywords) or '无'}", level="debug")
    total: list[str] = []
    own: list[str] = []
    prefer: list[str] = []
    result: set[str] = set()
    for asset in sorted(assets):
        parts = asset.split("/")
        # 流派只取素材目录段（id 就是 mirror/gift/<流派>/<名字>）；名字就是最后一段
        archetype = _archetype(parts[2])
        if not archetype:
            continue
        total.append(asset)
        if archetype in keywords:
            own.append(asset)
            continue
        if preferences.get(asset) == PREFERENCE_PREFER:
            prefer.append(asset)
            continue
        result.add(asset)
    _log_gift_group(ctx, "总饰品", sorted(total))
    _log_gift_group(ctx, "自己流派饰品（不参与融合）", sorted(own))
    _log_gift_group(ctx, "优先获取饰品（不参与融合）", sorted(prefer))
    _log_gift_group(ctx, "其他流派饰品", sorted(result))
    names = sorted(result)
    _log_gift_group(ctx, "融合耗材饰品", names)
    ctx.log(
        f"融合耗材名单：{len(names)} 件（本队商店购买流派 {sorted(keywords)} 排除 {len(own)} 件，"
        f"「优先获取」排除 {len(prefer)} 件，本次 Run 临时新增饰品并入 {len(added)} 件）"
    )
    return names


def _page_state(ctx: RunContext) -> str:
    """当前页面类别：gift_get / keyword / fuse / shop / other。"""
    if _gift_get_popup(ctx):
        return "gift_get"
    if _keyword_popup_open(ctx):
        return "keyword"
    if _fuse_popup_open(ctx):
        return "fuse"
    if _on_shop(ctx):
        return "shop"
    return "other"


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    购买循环结束后执行一次融合：
    先算耗材名单，再按「选流派 → 现成融合 / 点耗材 → 滚动列表」的有界循环推进；
    融合确认后出现的 E.G.O Gift GET! 到手弹窗由 step.mirror_gift_get_confirm 确认后回到本循环；
    退出时关闭融合弹窗回到商店页。返回 completed、reason、fused（成功融合次数）、consumables（名单件数）。
    不在商店页/融合页（可能已离开商店或页面异常）时返回 completed=False，不做任何输入。
    """
    consumables = _consumables(ctx)
    names = "|".join(consumables)
    fused = 0
    stalled_scrolls = 0
    previous = ""
    consecutive = 0

    def hit(action: str) -> None:
        """同一动作连续命中超过 MAX_REPEAT_HITS 次时在执行前抛错。"""
        nonlocal previous, consecutive
        consecutive = consecutive + 1 if action == previous else 1
        previous = action
        if consecutive > MAX_REPEAT_HITS:
            raise ExecutionFailure(
                "workflow_branch_limit",
                f"融合流程连续 {MAX_REPEAT_HITS + 1} 次停在动作 {action}",
            )

    for round_index in range(1, MAX_ROUNDS + 1):
        ctx.action("observe.capture_screen")
        state = _page_state(ctx)
        if state == "other":
            # 融合动画/页面切换：有界重试，不在被动画遮住的画面上点任何东西
            for attempt in range(1, MAX_PAGE_RETRIES + 1):
                ctx.log(
                    f"第{round_index}轮：既不在商店页也不在融合页，第{attempt}次等待后重新观察",
                    level="warning",
                )
                ctx.action("observe.wait", seconds=PAGE_RETRY_SECONDS)
                ctx.action("observe.capture_screen")
                state = _page_state(ctx)
                if state != "other":
                    break
            if state == "other":
                ctx.log("融合流程没有回到商店页/融合页，停止并交回上层", level="warning", screenshot=True)
                return {"completed": False, "reason": "fuse_page_missing", "fused": str(fused),
                        "consumables": str(len(consumables)), "closed": ""}

        if state == "gift_get":
            hit("gift_get")
            confirm = ctx.call("step.mirror_gift_get_confirm") or {}
            action = str(confirm.get("action") or "")
            ctx.log(f"第{round_index}轮：E.G.O Gift GET! 到手弹窗处理返回 {action}")
            if action == "confirmed":
                # 到手弹窗已关闭：融合格与右侧列表都已重排，下一轮重新观察融合页
                previous = ""
                consecutive = 0
            continue

        if state in ("keyword", "shop") or (state == "fuse" and _keyword_prompt(ctx)):
            hit("open")
            result = ctx.call("step.mirror_shop_fuse_open") or {}
            action = str(result.get("action") or "")
            ctx.log(f"第{round_index}轮：融合弹窗/流派推进返回 {action}")
            if action == "no_keyword":
                ctx.log("本队没有可用的融合流派关键词，本次不做融合，关闭弹窗", level="warning")
                break
            if action in ("not_in_shop", "open_failed"):
                ctx.log(f"融合弹窗打不开（{action}），停止融合", level="warning", screenshot=True)
                return {"completed": False, "reason": "fuse_open_failed", "fused": str(fused),
                        "consumables": str(len(consumables)), "closed": ""}
            continue

        if state != "fuse":
            break

        hit("pick")
        pick = ctx.call("step.mirror_shop_fuse_pick", consumables=names) or {}
        action = str(pick.get("action") or "")
        ctx.log(f"第{round_index}轮：融合动作 {action}（{pick}）")
        if action == "fused":
            fused += 1
            stalled_scrolls = 0
            previous = ""
            consecutive = 0
            continue
        if action == "materials_added":
            stalled_scrolls = 0
            previous = ""
            consecutive = 0
            continue
        if action == "keyword_required":
            previous = ""
            consecutive = 0
            continue
        if action == "not_fuse_popup":
            previous = ""
            consecutive = 0
            continue
        if action != "no_consumable":
            ctx.log(f"未知融合动作 {action!r}，停止融合交回上层", level="warning", screenshot=True)
            break

        hit("scroll")
        scroll = ctx.call("step.mirror_shop_fuse_scroll") or {}
        scroll_action = str(scroll.get("action") or "")
        ctx.log(f"第{round_index}轮：滚动右侧列表返回 {scroll_action}（{scroll}）")
        if scroll_action in ("at_bottom", "no_scrollbar"):
            ctx.log(
                "本帧没有可点的融合耗材，右侧列表已到底或没有滚动条，"
                "final_fuse_place 仍在 → 按开发者退出条件结束融合"
            )
            break
        if scroll_action == "scrolled":
            stalled_scrolls += 1
            if stalled_scrolls > MAX_STALLED_SCROLLS:
                raise ExecutionFailure(
                    "workflow_branch_limit",
                    f"融合列表连续滚动 {MAX_STALLED_SCROLLS + 1} 次仍没有点入任何耗材",
                )
            continue
        if scroll_action in ("not_fuse_popup", "keyword_popup"):
            previous = ""
            consecutive = 0

    closed = ctx.call("step.mirror_shop_fuse_close") or {}
    ctx.log(
        f"融合流程结束：成功融合 {fused} 次、耗材名单 {len(consumables)} 件，"
        f"关闭返回 {closed.get('action')}"
    )
    return {
        "completed": True,
        "reason": "done",
        "fused": str(fused),
        "consumables": str(len(consumables)),
        "closed": str(closed.get("action") or ""),
    }
