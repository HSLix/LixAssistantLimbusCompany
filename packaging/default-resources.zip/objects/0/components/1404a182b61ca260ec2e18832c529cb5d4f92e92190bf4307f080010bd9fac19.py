"""镜牢 E.G.O Gift GET! 到手弹窗：只用素材 mirror/ego_gift_get 识别弹窗，按一次 Enter 确认后交回。

融合确认、购买饰品、楼层饰品选择等操作后游戏都会弹出同一个 E.G.O Gift GET! 弹窗（标题横幅
430x34），它盖住下层页面。这里统一用标题横幅做原尺寸模板匹配，不再读标题文字：
命中后按一次 Enter 确认，仍看到标题横幅时用鼠标点一次 Confirm 兜底，然后交回上层重新观察。
"""
import re

from lalc import RunContext, step

# 到手弹窗标题横幅：素材 mirror/ego_gift_get（430x34），搜索区域按 1280x720 现场标题位置放宽，
# 保证能完整容纳模板；区域与阈值与 task.mirror 的 gift_get 判定保持一致
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
# 弹窗整体区域：只用于找 Confirm 按钮（标题已用模板匹配判定）
POPUP_REGION = {"x": 250, "y": 150, "width": 720, "height": 450}
CONFIRM_LABEL = "confirm"
# 1280x720 客户区里 Confirm 的回退坐标（与 step.mirror_gift_submit 保持一致）
CONFIRM_FALLBACK = (765, 495)
# 按 Enter 后的固定等待，以及点击 Confirm 后的固定等待
ENTER_WAIT_SECONDS = 1.0
CONFIRM_WAIT_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或连写影响按钮文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _gift_get(ctx: RunContext) -> bool:
    """当前帧是否叠着 E.G.O Gift GET! 到手弹窗：只用素材 mirror/ego_gift_get 匹配标题横幅。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=GIFT_GET_ASSET,
            region=GIFT_GET_REGION,
            threshold=GIFT_GET_THRESHOLD,
        )
    )


def _confirm_center(ctx: RunContext) -> tuple[int, int] | None:
    """在弹窗区域找文字为 Confirm 的按钮中心；识别不到返回 None。"""
    result = ctx.action("observe.ocr", region=POPUP_REGION) or {}
    for item in result.get("items") or []:
        if _norm(item.get("text", "")) != CONFIRM_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            return (int(center[0]), int(center[1]))
    return None


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    复查入口后最多确认一次到手弹窗：
    - 当前帧没有 E.G.O Gift GET! 弹窗 → 零输入返回 not_gift_get；
    - 有弹窗 → 按一次 Enter，等固定 1 秒后重新截图；标题横幅仍在时点一次 Confirm
      （识别不到 Confirm 文字时用回退坐标），再等固定 1 秒后交回上层重新观察。
    返回 confirmed（弹窗已关闭）或 still_open（弹窗仍在），不轮询、不重复按键。
    """
    ctx.action("observe.capture_screen")
    if not _gift_get(ctx):
        ctx.log("当前没有 E.G.O Gift GET! 到手弹窗，本步不做输入")
        return {"action": "not_gift_get"}

    ctx.log("识别到 E.G.O Gift GET! 到手弹窗，按一次 Enter 确认")
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=ENTER_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    if not _gift_get(ctx):
        return {"action": "confirmed"}

    center = _confirm_center(ctx) or CONFIRM_FALLBACK
    ctx.log(
        f"按 Enter 后弹窗标题横幅仍在，改用鼠标点击 Confirm {center}",
        level="info",
        screenshot=True,
    )
    ctx.action("control.click", x=int(center[0]), y=int(center[1]))
    ctx.action("observe.wait", seconds=CONFIRM_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    if _gift_get(ctx):
        ctx.log("按 Enter 与点击 Confirm 后弹窗标题横幅仍在，交回上层重新观察", level="warning", screenshot=True)
        return {"action": "still_open"}
    return {"action": "confirmed"}
