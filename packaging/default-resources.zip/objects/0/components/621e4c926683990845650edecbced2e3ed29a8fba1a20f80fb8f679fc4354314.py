"""镜牢战斗失败结算页：点一次右下角 Confirm，结果由上层重新观察。"""
from lalc import RunContext, step

# Defeat 结算页标识：右上角 Defeat 文字模板
DEFEAT_ASSET = "battle/defeat"
# 结算页右下角 Confirm 按钮（含左侧对勾）模板：命中时点它的 centerxy
CONFIRM_ASSET = "battle/confirm"
# 未识别到 Confirm 模板时的回退坐标（1280x720 客户区）
CONFIRM_POINT = (1147, 570)
# 点击后的固定等待：先让结算页切换，避免在过渡动画里重复输入
SETTLE_SECONDS = 1.5
# 本场镜牢刚结算结果在 RunState.settings 中的位置；结算规则据此决定是否领取奖励
RUNTIME_KEY = "mirror.runtime"
LAST_RESULT_KEY = "last_result"
RESULT_DEFEAT = "defeat"


def _mark_last_result(ctx: RunContext, value: str) -> None:
    """把本场镜牢刚结算结果写进 RunState.settings，供结算规则决定是否领取奖励。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录本场镜牢刚结算结果", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[LAST_RESULT_KEY] = value
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢刚结算结果 {LAST_RESULT_KEY}={value}")


def _defeat_here(ctx: RunContext) -> bool:
    """对当前帧匹配 Defeat 标识，判断是否仍停在失败结算页；不刷新截图。"""
    return bool(ctx.action("observe.match_asset", asset=DEFEAT_ASSET))


def _confirm_target(ctx: RunContext) -> tuple[int, int] | None:
    """
    对当前帧匹配右下角 Confirm 按钮模板，返回点击坐标；不刷新截图。
    多命中时记 warning 并取最右下的一处，不自动认定点击对象。
    """
    hits = list(ctx.action("observe.match_asset", asset=CONFIRM_ASSET) or [])
    if not hits:
        return None
    if len(hits) > 1:
        ctx.log(f"Confirm 模板命中 {len(hits)} 处，按最右下的一处点击", level="warning")
    point = max(hits, key=lambda hit: (tuple(hit["centerxy"])[1], tuple(hit["centerxy"])[0]))
    center = tuple(point["centerxy"])
    return (int(center[0]), int(center[1]))


@step
def execute(ctx: RunContext) -> None:
    """
    先截图复查入口：看不到 Defeat 标识（当前不在失败结算页）时零输入返回；
    确在失败结算页才点一次右下角 Confirm（模板匹配优先，未识别到时用固定坐标），
    等固定 1.5 秒后交回。
    同时把本场刚结算结果写进 RunState（不是返回值），供结算规则决定是否领取奖励；
    Defeat 是否消失、落到哪一页由 task.mirror 下一轮重新观察，本步不轮询。
    """
    ctx.action("observe.capture_screen")
    if not _defeat_here(ctx):
        ctx.log("当前不是 Defeat 结算页，不点击 Confirm")
        return

    _mark_last_result(ctx, RESULT_DEFEAT)
    target = _confirm_target(ctx)
    if target is None:
        ctx.log(
            f"未识别到 Confirm 模板，点击回退坐标 {CONFIRM_POINT}",
            level="warning",
            screenshot=True,
        )
        ctx.action("control.click", x=CONFIRM_POINT[0], y=CONFIRM_POINT[1])
    else:
        ctx.log(f"点击一次 Defeat 结算页右下角 Confirm @ {target}")
        ctx.action("control.click", centerxy=target)
    ctx.action("observe.wait", seconds=SETTLE_SECONDS)
