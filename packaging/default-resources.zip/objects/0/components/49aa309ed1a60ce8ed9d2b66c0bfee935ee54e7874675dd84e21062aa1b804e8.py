"""对已分派的正常加载执行有界复查等待，不输入游戏，也不返回完成标记。

等待期间就地处理盖在加载页上的 Could Not Load Notice 弹窗：识别到文案就立即点 Confirm，
再重新截图复查；Server Error 仍抛错交恢复规则，本步不点 Retry。
"""
import time

from lalc import ExecutionFailure, RunContext, step

# 单次调用的等待预算：预算内每秒新截一帧复查，提示消失或预算到期都正常返回
WAIT_BUDGET_SECONDS = 30.0
# 每次复查之间的等待秒数；截图与识别耗时也计入预算，剩余不足一次整秒等待时不再开始新的等待
POLL_SECONDS = 1.0
# 区域按 1280x720 设计基准给出，实际客户端分辨率不同时按比例换算
SERVER_ERROR_BOX = (380, 270, 520, 150)
# 正常加载的三处提示区域与关键词；一帧只做一次整屏 OCR，再按区域与关键词筛选
LOADING_BOXES = (
    ((1000, 0, 250, 120), ("connecting",)),
    ((780, 120, 500, 480), ("combat", "tips")),
    ((900, 600, 380, 120), ("nowloading",)),
)
# Could Not Load Notice 弹窗文案：Could not load notices. Please check your network connection.
NOTICE_KEYWORD = "couldnotload"
CONFIRM_LABEL = "confirm"
# Confirm 按钮在 1280x720 客户区中的回退坐标（与 recovery.popup_could_not_load_notice 一致）
CONFIRM_FALLBACK = (650, 500)
# 一次等待调用内最多处理几轮 Notice 弹窗；耗尽后交回上层重新截图分派，不在同一画面上反复点击
MAX_NOTICE_CLICKS = 3


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return "".join(char for char in str(text).lower() if char.isalnum())


def _center(item) -> tuple[float, float]:
    """取一条 OCR 结果的中心坐标：优先用 centerxy，缺省时用 box 推算。"""
    center = item.get("centerxy")
    if center:
        return float(center[0]), float(center[1])
    box = item.get("box") or {}
    return (
        float(box.get("x", 0)) + float(box.get("width", 0)) / 2,
        float(box.get("y", 0)) + float(box.get("height", 0)) / 2,
    )


def _scaled(box: tuple[int, int, int, int], width: int, height: int) -> tuple[int, int, int, int]:
    """把 1280x720 设计坐标的观察区域按当前客户区缩放，避免换分辨率后区域错位。"""
    x, y, box_width, box_height = box
    return (
        x * width // 1280,
        y * height // 720,
        max(1, box_width * width // 1280),
        max(1, box_height * height // 720),
    )


def _box_text(items: list[dict], width: int, height: int, box: tuple[int, int, int, int]) -> str:
    """从一帧整屏 OCR 结果里筛出中心落在该区域的条目，合并成规范化小写文本。"""
    left, top, box_width, box_height = _scaled(box, width, height)
    right, bottom = left + box_width, top + box_height
    parts = []
    for item in items:
        center_x, center_y = _center(item)
        if left <= center_x < right and top <= center_y < bottom:
            text = str(item.get("text", ""))
            if text:
                parts.append(text)
    return _norm(" ".join(parts))


def _all_text(items: list[dict]) -> str:
    """整屏 OCR 结果的整体规范化文本，用于识别可能出现在任意位置的弹窗文案。"""
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _confirm_center(items: list[dict]) -> tuple[int, int] | None:
    """找出文字正好是 Confirm 的按钮中心，识别不到时返回 None。"""
    for item in items:
        if _norm(item.get("text", "")) != CONFIRM_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            return int(center[0]), int(center[1])
    return None


def _frame(ctx: RunContext) -> tuple[dict, list[dict]]:
    """新截一帧并整屏识别一次：加载标识、错误弹窗与 Notice 文案都从这一份条目里筛选。"""
    meta = ctx.action("observe.capture_screen")
    items = (ctx.action("observe.ocr") or {}).get("items") or []
    return meta, list(items)


def _server_error(items: list[dict], width: int, height: int) -> bool:
    """居中区域出现 Server Error 文案即为要交恢复规则的拦截性错误。"""
    return "servererror" in _box_text(items, width, height, SERVER_ERROR_BOX)


def _loading(items: list[dict], width: int, height: int) -> bool:
    """按区域的文案与关键词判断当前帧是否仍处在通用加载过渡中。"""
    for box, words in LOADING_BOXES:
        text = _box_text(items, width, height, box)
        if all(word in text for word in words):
            return True
    return False


def _click_confirm(ctx: RunContext, meta: dict, items: list[dict], attempt: int) -> None:
    """点掉 Notice 弹窗：优先点识别到的 Confirm，识别不到时按回退坐标点击。"""
    center = _confirm_center(items)
    if center:
        ctx.log(
            f"等待期间检测到 Could Not Load Notice 弹窗，点击识别到的 Confirm @ {center}（第{attempt}次）"
        )
        ctx.action("control.click", centerxy=center)
        return
    width, height = int(meta["width"]), int(meta["height"])
    point = (CONFIRM_FALLBACK[0] * width // 1280, CONFIRM_FALLBACK[1] * height // 720)
    ctx.log(
        f"等待期间检测到 Could Not Load Notice 弹窗，未识别到 Confirm 文本，点击回退坐标 {point}（第{attempt}次）",
        level="warning",
        screenshot=True,
    )
    ctx.action("control.click", x=point[0], y=point[1])


@step
def execute(ctx: RunContext) -> None:
    """
    预算内每秒新截图复查错误弹窗、Notice 与加载标识：
    - 先复查当前帧，提示已消失就立即返回，不做无意义等待；
    - 识别到 Could Not Load Notice（Could not load notices. Please check your network connection.）
      就立即点 Confirm，等一秒后重新截图再检测，不把它当成加载完成或未知画面；
    - 仍在加载且剩余预算够一次整秒等待时 observe.wait 一秒后继续复查；
    - 提示消失、预算到期或剩余不足一次整秒等待都正常返回，不抛失败，
      由上层重新截图分派（等待是否结束不由本步的返回值证明）；
    - 等待期间识别到 Server Error 立即抛错交恢复规则，不继续等待；
      同一次调用内 Notice 已处理 MAX_NOTICE_CLICKS 次仍未消失时记 error 交回上层。
    """
    started = time.monotonic()
    notice_clicks = 0
    while True:
        meta, items = _frame(ctx)
        width, height = int(meta["width"]), int(meta["height"])
        if _server_error(items, width, height):
            raise ExecutionFailure("server_error_popup", "检测到 Server Error 弹窗")
        if NOTICE_KEYWORD in _all_text(items):
            notice_clicks += 1
            if notice_clicks > MAX_NOTICE_CLICKS:
                ctx.log(
                    f"Could Not Load Notice 弹窗在本轮等待中已处理 {MAX_NOTICE_CLICKS} 次仍未消失，"
                    "交回上层重新截图分派",
                    level="error",
                    screenshot=True,
                )
                return
            _click_confirm(ctx, meta, items, notice_clicks)
            # 点击后重新截图再检测：重试的加载或再次出现的弹窗都由下一轮判断
            ctx.action("observe.wait", seconds=POLL_SECONDS)
            continue
        if not _loading(items, width, height):
            return
        elapsed = time.monotonic() - started
        remaining = WAIT_BUDGET_SECONDS - elapsed
        if remaining < POLL_SECONDS:
            ctx.log(
                f"正常加载已等待约 {elapsed:.1f} 秒，达到 {WAIT_BUDGET_SECONDS:.0f} 秒等待预算，"
                "按预算到期正常交回上层重新截图分派",
                level="warning",
                screenshot=True,
            )
            return
        ctx.action("observe.wait", seconds=POLL_SECONDS)

