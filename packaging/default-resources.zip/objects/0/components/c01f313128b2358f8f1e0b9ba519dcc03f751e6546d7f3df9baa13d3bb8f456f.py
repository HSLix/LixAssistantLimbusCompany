"""镜牢情景判定：观测当前页面，判断任务此刻处于镜牢的哪个情景，只识别、不做任何点击。"""
import re

from lalc import RunContext, task_workflow, sub_workflow, ExecutionFailure

# 主界面：底部导航的 Drive 图标，或 Window 页图标
MAIN_ASSETS = ("main_navigate/drive", "main_navigate/window", "main_navigate/window_selected")
DRIVE_ASSET = "drive/inferno"
ENTRY_ASSET = "mirror/entry"
# 进副本前的镜牢队伍准备页：和战斗前准备页外观相近，必须先用这个模板区分
TEAM_ASSET = "mirror/team_select"
STAR_ASSET = "mirror/star"
# star 页点一次 Enter 后会弹出 Select Grace of Stars 确认框（Continue with selected effects?）。
# 该弹窗压暗并盖住 star 页，mirror/star 模板此时不再命中（Run 352 连续四轮 unknown 的原因），
# 因此必须先按弹窗文案单独识别，再交 step.mirror_star_bonus 的弹窗分支点一次 Confirm，
# 否则只会在弹窗上反复累计未知轮，等分支上限耗尽才失败。
STAR_DIALOG_REGION = {"x": 500, "y": 150, "width": 300, "height": 105}
STAR_DIALOG_KEYWORDS = ("selectgraceofstars", "continuewithselectedeffects")
# 外部中断：The weekly record has been reset. / Moving over to the Window.（Run 639 第 99~102 轮现场）
# 该通知盖在寻路页等业务页之上，压暗后的页面模板（含 mirror/train_head）都不再命中，
# 只能落到 unknown，连续第四次就撞分支上限失败。用两句文案单独识别，交 step.mirror_weekly_reset_cancel
# 点一次 Cancel 留在当前探索；Confirm 会离开本次探索转到 Window，不采用。
WEEKLY_RESET_KEYWORDS = ("weeklyrecordhasbeenreset", "movingovertothewindow")
GIFT_ASSET = "mirror/gift_select"
# 楼层通关后的 Acquire E.G.O Gift 页面：每张饰品卡各有一个手形图标
FLOOR_GIFT_ASSET = "mirror/acquire_ego_gift_hand"
# 三张饰品卡上方的 Acquire E.G.O Gift 标题，手形模板漏识别时用它兜底
FLOOR_GIFT_TITLE_REGION = {"x": 350, "y": 140, "width": 700, "height": 50}
FLOOR_GIFT_TITLE_KEYWORD = "acquireegogift"
# E.G.O Gift GET! 弹窗：会盖在寻路页等下层页面之上，先识别它，避免把下层页面当成当前业务页继续操作。
# 用素材 mirror/ego_gift_get（430x34 的标题横幅）做原尺寸模板匹配，不再读标题文字；
# 搜索区域按 1280x720 现场标题位置放宽，保证能完整容纳模板。
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
# 火车头模板同样由 plan 传入（path_train_asset），本层不再复制素材名
# 商店页标识改用左下角三个页签（Enhance Gifts／Fuse Gifts／Sell Gifts），不再用右上角两个 Refresh 按钮模板：
# 三个页签始终排在左下方同一横带里，任意识别到两颗就按商店页分派。
# 区域与坐标取自 Run 642 现场（642/254~642/256 与开发者现场截图）：Enhance+Gifts 中心 (177,385)/(177,399)、
# Fuse+Gifts (296,386)/(295,399)、Sell+Gifts (414,385)/(414,399)；横带只包这一行标签，
# 避开下方 Not Enough Cost 与右侧商品区。
# 保留左上角 Shop 标题 OCR 作为独立兜底（页签被压暗到读不出时标题通常仍在）；
# 不再要求右下角 Leave 文字：Run 415 里同一帧 Shop 标题正常、Leave 区域却返回空条目，
# 购买循环因此误判「已不是商店页」提前返回。
SHOP_TABS_REGION = {"x": 130, "y": 360, "width": 330, "height": 60}
SHOP_TAB_KEYWORDS = ("enhance", "fuse", "sell")
MIN_SHOP_TABS = 2
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 商店的技能替换弹窗会盖住商店页（左上角 Shop 标题被挡住），用弹窗标题 Replace <罪人>'s Skill 单独识别
SHOP_SKILL_TITLE_REGION = {"x": 180, "y": 105, "width": 430, "height": 60}
SHOP_SKILL_TITLE_KEYWORDS = ("replace", "skill")
# 商店的 Keyword Refresh 弹窗（Shop - Keyword Refresh）同样盖住 Shop 标题与商品区：
# 只用素材 mirror/shop/shop_keyword_refresh（388x37）做模板匹配识别为商店情景，不再读标题文字；
# 否则 Run 中途停在弹窗上会落到 unknown 无法回到购买循环
SHOP_KEYWORD_TITLE_ASSET = "mirror/shop/shop_keyword_refresh"
SHOP_KEYWORD_TITLE_REGION = {"x": 300, "y": 100, "width": 620, "height": 52}
SHOP_KEYWORD_TITLE_THRESHOLD = 0.85
# 已买过的商店卡片被再点一次时，游戏弹的是只读的 E.G.O Gift Info 弹窗（只有 Confirm）：它压暗商店页，
# 刷新按钮模板与 Shop 标题都不再可靠（Run 487 就是靠漏网的 Shop 标题反复判成商店）。
# 单独识别它并交 step.mirror_shop_gift_pick 关掉，避免在本层反复重入商店子流程直到撞分支上限。
GIFT_INFO_TITLE_REGION = {"x": 520, "y": 160, "width": 240, "height": 46}
GIFT_INFO_TITLE_KEYWORD = "egogiftinfo"
# 商店的 Fuse E.G.O Gift 融合页与 Fusion - Keyword Selection 流派弹窗都会盖住商店页：
# 分别识别为融合情景，交 sub_workflow.mirror_shop_fuse 继续或关闭，避免落到 unknown。
# 融合页标题横幅改用素材 mirror/shop/fuse/fuse_ego_gift（425x44）做原尺寸模板匹配，不再读标题文字，
# 也不再读右上角 Fusion Guide 文字；搜索区域放宽到能完整容纳模板。
FUSE_POPUP_TITLE_ASSET = "mirror/shop/fuse/fuse_ego_gift"
FUSE_POPUP_TITLE_REGION = {"x": 390, "y": 55, "width": 500, "height": 90}
FUSE_POPUP_TITLE_THRESHOLD = 0.85
FUSE_KEYWORD_TITLE_REGION = {"x": 380, "y": 70, "width": 520, "height": 60}
FUSE_KEYWORD_TITLE_KEYWORD = "fusionkeywordselection"
# 对局内战斗准备页判据：右下角 Clear Selection 模板命中即算。
# 不再要求右侧三个页签模板，也不用 OCR 文案兜底：页签是队伍／罪人选择页的标签，
# 放到对局内准备页会被队伍数量、贴边与皮肤影响而低于阈值（Run 646 三个页签模板全空返回、
# 只有 clear_selection 命中 0.934）。
CLEAR_SELECTION_ASSET = "prepare_team/clear_selection"
# 战斗界面素材由 plan 统一定义后传入（battle_assets），本层不再复制素材名
# 事件判定选人页：底部成功率档次标签（与 sub_workflow.event 的 PASS_TIER_ASSETS 一致）
# 任意一档命中就交给通用 event 子流程推进。选中罪人后标签仍在，不依赖右下角 SKIP／Commence 文案
PASS_TIER_ASSETS = (
    "event/pass/veryhigh",
    "event/pass/high",
    "event/pass/normal",
    "event/pass/low",
    "event/pass/verylow",
)
# 五档成功率标签统一使用 0.8 的模板匹配阈值（observe.match_asset 默认 0.9，更严格）；
# _hit 还服务其他素材，所以这里单独传阈值，不改 _hit 的默认行为
PASS_TIER_THRESHOLD = 0.8
# 战斗失败结算页标识：右上角 Defeat 文字模板。Victory 结算页有独立分支，且它的 Confirm 按钮
# 也会命中 battle/confirm，因此这里只用 Defeat 标识判定，不靠 Confirm 区分两个结算页
DEFEAT_ASSET = "battle/defeat"
# Victory 结算页标识：右上角 Victory 文字模板
VICTORY_ASSET = "battle/victory"
# 【优先级】Rewards Acquired 到账弹窗盖在 Exploration Complete 结算页之上，
# task.mirror 必须先判本分支再判 exploration_complete，否则会把被弹窗盖住的结算页当成业务页，
# 误点下层的 Claim Rewards。
REWARDS_ACQUIRED_REGION = {"x": 480, "y": 220, "width": 320, "height": 70}
# OCR 会把标题切成 "Rewards" 与 "s Acquired"，按两个词分别匹配，不要求整句
REWARDS_ACQUIRED_KEYWORDS = ("rewards", "acquired")
# 【优先级】Pass Level Up 弹窗同样盖在 Exploration Complete 结算页之上，
# 也必须在 exploration_complete 之前判定。标题区域只包住标题行，避免读到下方 Pass Level / Battle Pass XP。
PASS_LEVEL_UP_REGION = {"x": 480, "y": 220, "width": 320, "height": 70}
PASS_LEVEL_UP_KEYWORDS = ("pass", "level")
# 【优先级】Exploration Complete 结算页必须排在 Rewards Acquired 之后：
# 只有没有到账弹窗时才按结算页判定。识别用左上角标题 + 右下角 Claim Rewards 按钮。
EXPLORATION_TITLE_REGION = {"x": 140, "y": 80, "width": 200, "height": 95}
EXPLORATION_TITLE_KEYWORD = "explorationcomplete"
EXPLORATION_BUTTON_REGION = {"x": 1030, "y": 555, "width": 210, "height": 90}
EXPLORATION_BUTTON_KEYWORDS = ("claim", "rewards")
# 主题包选择页标题 SELECT FLOOR n THEME PACK
PACK_HEADER_REGION = {"x": 470, "y": 92, "width": 340, "height": 56}
# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上就算寻路界面；
# 素材名由 plan 统一定义后传入（与战斗子流程共用同一份），本层只保留区域与命中阈值；
# 不再用左上角 Exploring 文字，那段文字会忽明忽暗闪烁
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2
# 战斗后的 Select Encounter Reward Card 页面：标题条；被未选择奖励的确认弹窗压暗时用弹窗文案兜底
REWARD_TITLE_REGION = {"x": 270, "y": 100, "width": 540, "height": 70}
REWARD_TITLE_KEYWORD = "encounterrewardcard"
REWARD_POPUP_REGION = {"x": 340, "y": 180, "width": 600, "height": 350}
REWARD_POPUP_KEYWORDS = ("notselectedareward", "withoutchoosingareward")

# 普通／灰化 SKIP 按钮模板的匹配区域（1280x720 客户区），与 event／battle 子流程一致。
# 灰化 SKIP 模板是整颗按钮的裁剪（240x95），宽度正好等于原来的按钮区域 240：搜索区域没有横向余量时
# 模板只有唯一一个可放置位置，按钮相对裁剪位置偏几个像素就永远匹配不到（Run 540 第 40~43 轮在镜牢
# 事件叙述页连续 unknown，证据 540/566 就是那一帧灰化 SKIP）。因此改用带余量的右下角区域，
# 让普通／灰化两个模板都能按按钮在画面里的实际位置滑动匹配。
EVENT_BUTTON_REGION = {"x": 980, "y": 560, "width": 300, "height": 160}
# 页面切换和加载有延迟，一次判定落空时有界重试
MAX_ATTEMPTS = 3
POLL_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _hit(ctx: RunContext, assets: list[str] | tuple[str, ...]) -> str:
    """按同一帧依次匹配素材，返回第一个命中的逻辑名；都没有命中返回空字符串。"""
    for asset in assets:
        if ctx.action("observe.match_asset", asset=asset):
            return asset
    return ""


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮情景判定需要的区域文案都从这份结果里过滤。"""
    result = ctx.action("observe.ocr") or {}
    return list(result.get("items") or [])


def _text_in(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，合并成规范化小写文本；不刷新截图。"""
    left = int(region["x"])
    top = int(region["y"])
    right = left + int(region["width"])
    bottom = top + int(region["height"])
    parts: list[str] = []
    for item in items:
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if left <= x <= right and top <= y <= bottom:
            text = str(item.get("text", ""))
            if text:
                parts.append(text)
    return _norm(" ".join(parts))


def _all_text(items: list[dict]) -> str:
    """整屏 OCR 结果的整体规范化文本，用于未知页面的 Server Error 兑底确认。"""
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _path_icons(ctx: RunContext, path_icon_assets: list[str]) -> int:
    """对当前帧右上角匹配寻路界面按钮素材，返回命中数量；不刷新截图。"""
    return sum(
        1
        for asset in path_icon_assets
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )


def _shop_tabs(items: list[dict]) -> int:
    """从本轮整屏 OCR 结果里统计左下角三个商店页签（Enhance／Fuse／Sell Gifts）的命中数量；不刷新截图。"""
    tabs = _text_in(items, SHOP_TABS_REGION)
    return sum(1 for keyword in SHOP_TAB_KEYWORDS if keyword in tabs)


def _scaled(meta: dict, region: dict[str, int]) -> dict[str, int]:
    """把 1280x720 基准坐标的观察区域按当前客户区缩放，避免换分辨率后区域错位。"""
    width, height = int(meta["width"]), int(meta["height"])
    return {
        "x": region["x"] * width // 1280,
        "y": region["y"] * height // 720,
        "width": max(1, region["width"] * width // 1280),
        "height": max(1, region["height"] * height // 720),
    }


def _server_error(ctx: RunContext, meta: dict) -> bool:
    """对当前帧的居中弹窗区域做一次局部 OCR，判断是否出现 Server Error 弹窗；不刷新截图。"""
    return SERVER_ERROR_KEYWORD in _region_text(ctx, _scaled(meta, SERVER_ERROR_REGION))


def _server_error_fullscreen(items: list[dict]) -> bool:
    # 复用调用方那一次整屏 OCR 的结果，不再额外识别一次
    """居中区域漏识别时对当前帧整屏 OCR 兜底；不刷新截图。"""
    return SERVER_ERROR_KEYWORD in _all_text(items)


def _raise_server_error(ctx: RunContext) -> None:
    """把 Server Error 弹窗报给恢复规则：主循环只抛 ExecutionFailure，不自行点 Retry。"""
    ctx.log(
        "镜牢主循环检测到 Server Error 弹窗，报错交恢复规则 recovery.popup_server_error 处理",
        level="error",
        screenshot=True,
    )
    raise ExecutionFailure("mirror_server_error", "镜牢主循环检测到 Server Error 弹窗")


def _title_persists(ctx: RunContext) -> bool:
    """
    标题特征命中后做有界宽限观察：每轮等待后重新截图，用新一帧的整屏 OCR 交给通用过渡检测。
    期间出现正常加载／联网过渡，或标题特征已经消失，返回 False（当前不是静止停在标题界面）；
    整段宽限都停在标题界面才返回 True，由调用方报错交恢复规则 recovery.title_to_main。
    """
    for _ in range(TITLE_GRACE_POLLS):
        ctx.action("observe.wait", seconds=TITLE_GRACE_SECONDS)
        meta = ctx.action("observe.capture_screen")
        items = _screen_items(ctx)
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[
                [int(center[0]), int(center[1])]
                for center in (item.get("centerxy") or [0, 0] for item in items)
            ],
        ):
            return False
        if not ctx.action("observe.match_asset", asset=TITLE_ASSET):
            return False
    return True


def _pick(
    ctx: RunContext,
    items: list[dict],
    battle_assets: list[str],
    path_train_asset: str,
    path_icon_assets: list[str],
    event_assets: list[str],
    event_skip_assets: list[str],
) -> tuple[str, str]:
    """
    按当前帧判定情景，返回 (情景名, 判定依据)。先匹配素材，再用本轮那一次整屏 OCR 的结果补充：
    所有区域文案都从 items 里按区域过滤（_text_in），不再对同一帧反复裁切识别；
    E.G.O Gift GET! 弹窗与 Select Grace of Stars 确认框都盖在下层页面之上，优先识别；
    进副本前的队伍准备页排在战斗前准备页之前，避免两者外观相近时误判。
    """

    # 【优先级】每周记录重置通知盖在所有镜牢页面之上：先按两句文案识别，交上层点一次 Cancel 留在当前探索，
    # 不把它当成未知页面空转，也不让被压暗的寻路页继续按其它分支误判
    screen = _all_text(items)
    if all(word in screen for word in WEEKLY_RESET_KEYWORDS):
        return "weekly_reset", "weekly record reset notice"
    # E.G.O Gift GET! 弹窗会盖在寻路页等页面之上：先按标题横幅模板识别它，
    # 命中就走 gift_get 分支，不把被盖住的下层页面当成当前业务页继续操作
    if ctx.action(
        "observe.match_asset",
        asset=GIFT_GET_ASSET,
        region=GIFT_GET_REGION,
        threshold=GIFT_GET_THRESHOLD,
    ):
        return "gift_get", GIFT_GET_ASSET
    # 商店的技能替换弹窗盖在商店页之上并挡住 Shop 标题，必须先按弹窗标题识别，
    # 否则会落到 unknown 无法分派
    if all(word in _text_in(items, SHOP_SKILL_TITLE_REGION) for word in SHOP_SKILL_TITLE_KEYWORDS):
        return "shop_skill", "replace skill popup"
    # 商店的 Keyword Refresh 弹窗也盖住 Shop 标题：同样按商店情景分派，
    # 交给购买循环里的关键字刷新分支按本队流派选关键词并提交；只用模板匹配弹窗，不再读标题文字
    if ctx.action(
        "observe.match_asset",
        asset=SHOP_KEYWORD_TITLE_ASSET,
        region=SHOP_KEYWORD_TITLE_REGION,
        threshold=SHOP_KEYWORD_TITLE_THRESHOLD,
    ):
        return "shop", SHOP_KEYWORD_TITLE_ASSET
    # 只读的 E.G.O Gift Info 弹窗（点已买过的商品卡会弹出）：它压暗商店页，
    # 单独识别后交 step.mirror_shop_gift_pick 关闭，不交给购买循环（那里只看商品区）
    if GIFT_INFO_TITLE_KEYWORD in _text_in(items, GIFT_INFO_TITLE_REGION):
        return "shop_info", "ego gift info popup"
    # 融合页与 Fusion - Keyword Selection 弹窗同样盖住商店页：先识别为融合情景，
    # 交融合子流程继续推进或关闭，不能落到 unknown 后反复空转。
    # 融合页标题只用模板匹配，不再读 Fusion Guide 文字
    if ctx.action(
        "observe.match_asset",
        asset=FUSE_POPUP_TITLE_ASSET,
        region=FUSE_POPUP_TITLE_REGION,
        threshold=FUSE_POPUP_TITLE_THRESHOLD,
    ):
        return "shop_fuse", FUSE_POPUP_TITLE_ASSET
    if FUSE_KEYWORD_TITLE_KEYWORD in _text_in(items, FUSE_KEYWORD_TITLE_REGION):
        return "shop_fuse", "fusion keyword selection popup"
    # star 页按 Enter 后出现的 Select Grace of Stars 确认框会压暗 star 页，素材模板不再命中：
    # 先按弹窗文案识别，交 step.mirror_star_bonus 的弹窗分支点 Confirm
    if any(word in _text_in(items, STAR_DIALOG_REGION) for word in STAR_DIALOG_KEYWORDS):
        return "star_confirm", "select grace of stars dialog"
    asset = _hit(ctx, (TEAM_ASSET,))
    if asset:
        return "team", asset
    asset = _hit(ctx, (STAR_ASSET,))
    if asset:
        return "star", asset
    # 楼层通关后的 Acquire E.G.O Gift 页面：手形图标模板优先，漏识别时用卡片上方的标题文字兜底
    asset = _hit(ctx, (FLOOR_GIFT_ASSET,))
    if asset:
        return "floor_gift", asset
    if FLOOR_GIFT_TITLE_KEYWORD in _text_in(items, FLOOR_GIFT_TITLE_REGION):
        return "floor_gift", "acquire ego gift"
    asset = _hit(ctx, (GIFT_ASSET,))
    if asset:
        return "gift", asset
    asset = _hit(ctx, (path_train_asset,))
    if asset:
        return "path", asset
    # 对局内战斗准备页只用右下角 Clear Selection 模板判定（对局内准备页不应用右侧三个页签模板）：
    # 命中即算准备页，不再用页签模板或 To Battle!／Participants 文案二次确认
    if ctx.action("observe.match_asset", asset=CLEAR_SELECTION_ASSET):
        return "prepare", CLEAR_SELECTION_ASSET
    # 战斗后的奖励卡片页：标题栏 Select Encounter Reward Card 是独有文案；
    # 弹窗压暗时标题可能读不到，用弹窗里的 not selected a reward / without choosing a reward 兜底
    if REWARD_TITLE_KEYWORD in _text_in(items, REWARD_TITLE_REGION):
        return "reward_card", "select encounter reward card"
    reward_popup = _text_in(items, REWARD_POPUP_REGION)
    if any(keyword in reward_popup for keyword in REWARD_POPUP_KEYWORDS):
        return "reward_card", "not selected reward popup"
    asset = _hit(ctx, battle_assets)
    if asset:
        return "battle", asset
    if _hit(ctx, (DEFEAT_ASSET,)):
        return "defeat", DEFEAT_ASSET
    asset = _hit(ctx, (DRIVE_ASSET,))
    if asset:
        return "drive", asset
    asset = _hit(ctx, (ENTRY_ASSET,))
    if asset:
        return "entry", asset
    asset = _hit(ctx, MAIN_ASSETS)
    if asset:
        return "main", asset
    pack = _text_in(items, PACK_HEADER_REGION).replace(" ", "")
    if "selectfloor" in pack and "themepack" in pack:
        return "themepack", "select floor theme pack"
    # 商店页：左下角三个页签（Enhance／Fuse／Sell Gifts）命中两颗以上，或左上角读到 Shop 标题
    shop_tabs = _shop_tabs(items)
    if shop_tabs >= MIN_SHOP_TABS:
        return "shop", f"商店页签 {shop_tabs}/3"
    if SHOP_TITLE_KEYWORD in _text_in(items, SHOP_TITLE_REGION):
        return "shop", "左上角 Shop 标题"
    icons = _path_icons(ctx, path_icon_assets)
    if icons >= MIN_PATH_ICONS:
        return "path", f"右上角按钮 {icons}/{len(path_icon_assets)}"
    if _hit(ctx, event_assets):
        # 事件选项／结果页标题模板：素材名由 plan 传入，与各 task／event 子流程共用
        return "event", "event 选项／结果页模板"
    if any(
        ctx.action("observe.match_asset", asset=asset, threshold=PASS_TIER_THRESHOLD)
        for asset in PASS_TIER_ASSETS
    ):
        # 事件判定选人页：右下角可能已经变成亮色 Commence（不再是 SKIP 文案），
        # 只靠 SKIP 文字会落到 unknown；先用档次标签模板识别，交给 event 子流程继续选人／开始判定
        return "event", "skill check select"
    for asset in event_skip_assets:
        if ctx.action("observe.match_asset", asset=asset, region=EVENT_BUTTON_REGION):
            # 叙述页右下角 SKIP：普通与灰化都用模板匹配，不读 OCR 文案；
            # 依据里带上命中的素材名，日志可以直接区分普通 SKIP 与灰化 SKIP
            return "event", f"skip {asset}"
    # 【优先级】先判 Rewards Acquired 到账弹窗：它盖在 Exploration Complete 结算页之上，
    # 不先判就会误点被盖住的 Claim Rewards。
    if all(word in _text_in(items, REWARDS_ACQUIRED_REGION) for word in REWARDS_ACQUIRED_KEYWORDS):
        return "rewards_acquired", "rewards acquired popup"
    # 【优先级】再判 Pass Level Up 弹窗：同样盖在结算页之上，必须早于 exploration_complete
    if all(word in _text_in(items, PASS_LEVEL_UP_REGION) for word in PASS_LEVEL_UP_KEYWORDS):
        return "pass_level_up", "pass level up popup"
    # 【优先级】Exploration Complete 结算页排在 Rewards Acquired 之后，只在没有到账弹窗时判定
    if EXPLORATION_TITLE_KEYWORD in _text_in(items, EXPLORATION_TITLE_REGION):
        if all(
            word in _text_in(items, EXPLORATION_BUTTON_REGION)
            for word in EXPLORATION_BUTTON_KEYWORDS
        ):
            return "exploration_complete", "exploration complete title + claim rewards"
    # Victory 结算页优先级最低：前面的镜牢情景都不成立时才按胜利结算页判定
    if _hit(ctx, (VICTORY_ASSET,)):
        return "victory", VICTORY_ASSET
    return "unknown", ""




# 单场镜牢共用一个有界大循环：每轮观测情景并推进一个状态。
# 实测一场三层推进（含战斗、事件、商店子流程）要 50 轮上下，Run 415 在第 50 轮才进商店、
# 子流程返回时预算已耗尽直接失败；这里把预算提高到 999，仍是有界上限（同一分支连续第四次命中依旧先报错）。
MAX_ROUNDS = 999
# 镜牢设置页（sinners.team_presets 保存每个队伍的罪人顺序；队伍顺序只存在页面资源 team_order）
MIRROR_PAGE_ID = "mirror.settings"
# 唯一的队伍顺序配置：页面资源 team_order。页面显示、页面保存、本场选队与轮换写回都只用这一份
ORDER_RESOURCE = "team_order"
ORDER_TEAMS_KEY = "teams"
# 资源读取状态：整份缺失（读到 None，通常是页面资源目录被删除或清空）与内容非法分开记日志；
# 两种情况的兜底动作相同（按第 DEFAULT_TEAM 个队伍），但提示必须能区分，否则分不清是数据丢了还是内容写坏
ORDER_STATE_OK = "ok"
ORDER_STATE_MISSING = "missing"
ORDER_STATE_INVALID = "invalid"
# 本场实际使用的队伍序号（1 起）：进场时写入，step.mirror_team_rotate 用它核对轮换对象
TEAM_USED_KEY = "team_used"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
# 本场镜牢是否已经选过出战顺序：记在 RunState.settings 的独立键下，同一 Run 内共享
RUNTIME_KEY = "mirror.runtime"
TEAM_SELECTED_KEY = "battle_team_selected"
# 本场镜牢是否已经点选过星光：由 step.mirror_star_bonus 写入，新一场镜牢开始时复位，
# 避免上一场的记录让下一场跳过星光点选；点击会消耗星光，因此只在确认新一场开始时复位
STAR_CONFIGURED_KEY = "star_configured"
# 本场镜牢刚完成状态：由 step.mirror_exploration_complete 置位，收尾判定读取；新一场镜牢开始时复位
EXPLORATION_COMPLETE_KEY = "exploration_complete"
# 本场镜牢刚结算结果：由 step.mirror_victory_confirm 与 step.mirror_defeat_confirm 写入，
# 结算规则据此决定是否领取奖励；plan 进入 task.mirror 前刷新为 unknown，新一场镜牢开始时同样复位
LAST_RESULT_KEY = "last_result"
RESULT_UNKNOWN = "unknown"
# 本楼层商店已处理过的技能替换商品：由 step.mirror_refresh_shop_state 在主题包选择成功、开始新楼层时清空；
# 同一楼层的商店重入时保留，避免重复购买或重复取消
SHOP_SKILL_HANDLED_KEY = "shop_skill_handled"
# Server Error 弹窗（A server error has occurred. / Please try again in a moment.）是盖在所有页面之上的
# 居中模态：主循环每轮优先识别，命中立即抛 ExecutionFailure 交恢复规则 recovery.popup_server_error
# 点击 Retry，不在被盖住的业务页上继续点 Close／Leave／商品。区域按 1280x720 设计，判定时按实际客户区缩放。
SERVER_ERROR_REGION = {"x": 380, "y": 270, "width": 520, "height": 150}
SERVER_ERROR_KEYWORD = "servererror"
# 服务端维护通知（Server is under Scheduled Maintenance. / You will be able to login after 12:00 (KST)）
# 盖在所有镜牢页面之上：下层页面被压暗，但融合页标题横幅等特征仍然命中，主循环会把被盖住的业务页
# 当成当前页面反复输入（Run 639 第 99~102 轮就在融合页连点 Close，第四次撞分支上限失败）。
# 文案直接复用本轮整屏 OCR 的结果判定；维护期内点掉通知会让客户端弹出 Cannot operate the game.
# 并退回标题界面（Run 639 证据 639/12961），所以本层不输入也不空转，命中即报错交恢复规则
# recovery.popup_server_maintenance：按弹窗里的“after HH:MM (KST)”等待维护结束，多等 1 分钟再关通知。
MAINTENANCE_KEYWORD = "scheduledmaintenance"
# 无法操作通知（Cannot operate the game. / Shutting down now.）盖在融合页等业务页之上：游戏准备关闭，
# 主循环点它不会推进任何业务（Run 639 现场 639/12961 就是关掉维护通知后出现的这一帧）。
# 命中即抛 ExecutionFailure 交恢复规则 recovery.popup_cannot_operate 重启游戏，不在正要退出的画面上
# 累计 4 次 unknown 后报成误导性的分支上限。
CANNOT_OPERATE_KEYWORD = "cannotoperatethegame"
# 游戏标题界面（TOUCH TO START）：左下角 Clear all caches 是最独特的稳定特征（恢复规则
# recovery.title_to_main 也用同一素材）。镜牢情景只能在游戏内分派，停在标题界面（例如服务端维护
# 期间客户端退回登录前，现场 639/12961 之后就是这一页）时本任务无法推进：连续 4 轮 unknown
# 只会报出误导性的分支上限，因此这里直接报错交恢复规则 title_to_main 处理。
# 右上角 Connecting 的登录过渡仍先由 step.detect_normal_transition 处理，不在加载中途报错。
TITLE_ASSET = "restart/clear_all_caches"
# 标题特征命中后先做有界宽限观察（Run 642 第 12 轮现场 642/203→642/208）：更新下载结束后
# 客户端自己重连，Connecting 消失到画面切到 Now Loading 之间约 2 秒仍只显示标题页
# （Clear all caches 在，TOUCH TO START 与 Connecting 都不在）。此时直接报错会让恢复规则
# 在同一画面上反复重入，最终被判成「同一入口反复失败」而交给人修复。宽限期内只要标题特征
# 消失或出现正常过渡就按过渡继续，整段都停在标题界面才报错交 recovery.title_to_main。
TITLE_GRACE_POLLS = 5
TITLE_GRACE_SECONDS = 1.0
# 本场镜牢是否已经进过商店并做完离开商店前的事务（技能替换等）：记在 RunState.settings 的
# mirror.runtime 里，跨 Step／失败重入都保留。True 时再判定为商店页就直接执行离开商店，不重复处理商品。
# 刷新点①：购买循环 sub_workflow.mirror_shop 完成（离开前事务做完）时置 True；
# 刷新点②：主题包选择成功后由 step.mirror_refresh_shop_state 复位为 False，新楼层的商店要重新处理事务。
SHOP_VISITED_KEY = "shop_visited"
# 商店设置的融合饰品开关（mirror.settings: shop_fuse_gifts，默认开启）：
# 关闭时购买结束后不做融合，遇到融合弹窗也只关闭它。
SHOP_FUSE_SWITCH_KEY = "shop_fuse_gifts"


def _saved_order(ctx: RunContext) -> tuple[list[int], str]:
    """
    读取页面 team_order 资源里保存的队伍顺序，返回 (队伍顺序, 状态)。
    状态 ok 表示读到可用顺序；missing 表示资源整份不存在（读到 None）；invalid 表示资源在但内容不合形状。
    后两种都返回空顺序，由调用方分别记日志，便于区分「资源丢了」与「内容写坏」。
    """
    value = ctx.action("page_resource.read_json", page_id=MIRROR_PAGE_ID, name=ORDER_RESOURCE)
    raw = value.get(ORDER_TEAMS_KEY) if isinstance(value, dict) else None
    teams: list[int] = []
    if isinstance(raw, list):
        for item in raw:
            text = str(item).strip()
            if not text.isdigit():
                continue
            team = int(text)
            if 1 <= team <= MAX_TEAMS and team not in teams:
                teams.append(team)
    if teams:
        return teams, ORDER_STATE_OK
    if value is None:
        _create_empty_order(ctx)
        return [], ORDER_STATE_MISSING
    return [], ORDER_STATE_INVALID


def _create_empty_order(ctx: RunContext) -> None:
    """
    页面资源整份不存在时按规范空形状创建：写入会立即建立这份资源文件（数据目录不存在时由宿主一并创建），
    让资源不再停在「文件不存在」状态；具体队伍顺序仍要在镜牢设置页选好后点「确定」，由页面写入。
    """
    ctx.action(
        "page_resource.write_json",
        page_id=MIRROR_PAGE_ID,
        name=ORDER_RESOURCE,
        value={ORDER_TEAMS_KEY: []},
    )
    ctx.log(f"页面资源 {ORDER_RESOURCE} 不存在，已按空顺序创建（{ORDER_TEAMS_KEY}=[]）")


def _team_index(ctx: RunContext) -> int:
    """
    本场镜牢要用的队伍序号（1 起）：唯一来源是页面资源 team_order 的第一支。
    资源缺失或内容非法时记 warning 并按第 DEFAULT_TEAM 个队伍处理，
    不再读页面 settings 里的历史字段，也不再往 RunState 写第二份顺序。
    """
    teams, state = _saved_order(ctx)
    if not teams:
        reason = (
            f"页面资源 {ORDER_RESOURCE} 不存在（读到 None：可能是页面资源被删除或清空）"
            if state == ORDER_STATE_MISSING
            else f"页面资源 {ORDER_RESOURCE}.{ORDER_TEAMS_KEY} 内容非法"
        )
        ctx.log(
            f"{reason}，按第{DEFAULT_TEAM}个队伍处理（请在镜牢设置页重新选择队伍顺序并点「确定」）",
            level="warning",
        )
        return DEFAULT_TEAM
    team = teams[0]
    ctx.log(f"镜牢队伍：使用第{team}个队伍（当前顺序 {teams}，每场领取奖励后整份顺序轮换一格）")
    return team


def _set_team_used(ctx: RunContext, team: int) -> None:
    """记录本场镜牢实际使用的队伍序号，供 plan 在领取奖励后按它推导下一支队伍。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录本场镜牢使用的队伍", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[TEAM_USED_KEY] = team
    settings[RUNTIME_KEY] = runtime


def _team_selected(ctx: RunContext) -> bool:
    """本场镜牢是否已经选过出战顺序；没有记录时按还没选过处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(TEAM_SELECTED_KEY) is True


def _set_team_selected(ctx: RunContext, selected: bool) -> None:
    """
    记录本场镜牢的出战顺序状态；新一场镜牢开始时复位为 False。
    首次写入时 RunState 里还没有这个记录，拿到的是空 dict，
    必须写回 settings 并立即赋值，否则记录不生效，下一场战斗准备仍会被当成没选过而再清空一次。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录本场镜牢的出战顺序状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[TEAM_SELECTED_KEY] = selected
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢出战顺序状态 {TEAM_SELECTED_KEY}={selected}")


def _set_star_configured(ctx: RunContext, configured: bool) -> None:
    """记录／复位本场镜牢的星光点选状态；新一场镜牢开始时复位为 False，避免跳过本场的星光点选。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法更新星光点选状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[STAR_CONFIGURED_KEY] = configured
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢星光点选状态 {STAR_CONFIGURED_KEY}={configured}")


def _set_exploration_complete(ctx: RunContext, completed: bool) -> None:
    """记录／复位本场镜牢刚完成状态；新一场镜牢开始时复位为 False，避免上一场的完成状态误触发收尾。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法更新镜牢刚完成状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[EXPLORATION_COMPLETE_KEY] = completed
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢刚完成状态 {EXPLORATION_COMPLETE_KEY}={completed}")


def _set_last_result(ctx: RunContext, value: str) -> None:
    """复位本场镜牢刚结算结果；新一场镜牢开始时置回 unknown，避免上一场的胜利／失败残留。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法复位镜牢刚结算结果", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[LAST_RESULT_KEY] = value
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"复位本场镜牢刚结算结果 {LAST_RESULT_KEY}={value}")


# 本次商店是否已经跑过「自维护饰品」（打开 Sell E.G.O Gift 弹窗，把还没存过的饰品存进素材库）：
# 同一楼层只跟一次，避免购买循环重入时反复开弹窗；新楼层由 step.mirror_refresh_shop_state 复位。
SELL_GIFT_MAINTAINED_KEY = "sell_gift_maintained"


def _shop_visited(ctx: RunContext) -> bool:
    """本楼层是否已经进过商店并做完离开商店前的事务；没有记录时按还没进过商店处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(SHOP_VISITED_KEY) is True


def _set_shop_visited(ctx: RunContext, visited: bool) -> None:
    """
    记录本楼层是否已进过商店并做完离开商店前的事务（含义同 SHOP_VISITED_KEY）。
    刷新点：购买循环 sub_workflow.mirror_shop 结束时置 True，之后再判定为商店页就直接离开；
    复位为 False 由 step.mirror_refresh_shop_state 在主题包选择成功后统一执行。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法更新本场镜牢已进过商店标记", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[SHOP_VISITED_KEY] = visited
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本楼层已进过商店标记 {SHOP_VISITED_KEY}={visited}")


def _sell_gift_maintained(ctx: RunContext) -> bool:
    """本次商店是否已经跑过饰品自维护；没有记录时按还没跑过处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(SELL_GIFT_MAINTAINED_KEY) is True


def _set_sell_gift_maintained(ctx: RunContext, maintained: bool) -> None:
    """
    记录本次商店是否已跑过饰品自维护（含义同 SELL_GIFT_MAINTAINED_KEY）。
    购买循环与融合结束后、离开商店前置 True，之后同一楼层重入商店不再重复开 Sell E.G.O Gift 弹窗；
    新楼层由 step.mirror_refresh_shop_state 复位为 False。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法更新饰品自维护标记", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[SELL_GIFT_MAINTAINED_KEY] = maintained
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本次商店饰品自维护标记 {SELL_GIFT_MAINTAINED_KEY}={maintained}")


# 本次商店是否已经跑过融合（Fuse Gifts）：购买循环结束后跑一次，完成后置 True；
# 中途失败/被打断时保持 False，下一轮按 shop_fuse 或商店分支继续；新楼层由
# step.mirror_refresh_shop_state 复位为 False。
SHOP_FUSED_KEY = "shop_fused"


def _shop_fused(ctx: RunContext) -> bool:
    """本楼层商店是否已经跑过融合；没有记录时按还没跑过处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(SHOP_FUSED_KEY) is True


def _set_shop_fused(ctx: RunContext, fused: bool) -> None:
    """记录本楼层商店是否已跑过融合（含义同 SHOP_FUSED_KEY）；新楼层由刷新步骤复位。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法更新商店融合标记", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[SHOP_FUSED_KEY] = fused
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本楼层商店融合标记 {SHOP_FUSED_KEY}={fused}")


def _shop_fuse_enabled(ctx: RunContext) -> bool:
    """读取镜牢设置页「商店设置」的融合饰品开关；缺失或非布尔值时按开启处理。"""
    page = (ctx.run_state.settings or {}).get(MIRROR_PAGE_ID)
    raw = page.get(SHOP_FUSE_SWITCH_KEY) if isinstance(page, dict) else None
    return raw if isinstance(raw, bool) else True






@task_workflow
def execute(
    ctx: RunContext,
    *,
    battle_assets: list[str],
    path_train_asset: str,
    path_icon_assets: list[str],
    event_choices_asset: str,
    event_result_asset: str,
    event_skip_asset: str,
    event_grey_skip_asset: str,
    gift_get_asset: str,
) -> dict[str, str]:
    """优先等待正常过渡，再有界分派；同一分支连续第四次命中或总预算耗尽时失败。"""
    # 本场要用的队伍：直接取队伍顺序的第一支（真实轮换后的顺序），进场时算一次，本场中途重入不变
    team = _team_index(ctx)
    _set_team_used(ctx, team)
    ctx.log(f"task.mirror 开始：使用第{team}个队伍")
    # 战斗、事件与寻路标识都由 plan 统一定义后传入：本层只用它们做情景分派，不再维护自己的素材表
    event_assets = [event_choices_asset, event_result_asset]
    event_skip_assets = [event_skip_asset, event_grey_skip_asset]
    # 镜牢入口队伍页分两轮推进：先按设置页的队伍序号点中左侧列表行 → 再点 Confirm
    entry_team_clicked = False
    # 队伍列表是否已用拖拽拉回顶部：与点击选队分开，每次重新进入队伍页时先做一遍上划
    team_list_reset = False
    # 本场任务里体力转换是否已经尝试失败过：失败后不再重复进该子流程，避免同一分支连续命中到
    # 第四次把整场镜牢任务打断（Run 490：读数误判成 4856% 溢出 + 「»」素材未命中）。
    # 体力转换只是避免自然恢复撞上限的优化，失败时继续进入镜牢，只记 warning。
    stamina_convert_blocked = False
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, MAX_ROUNDS + 1):
        meta = ctx.action("observe.capture_screen")
        # 情景判定前只做一次整屏 OCR：所有区域文案判据都从这份条目里按区域过滤，
        # 不再对同一帧分别裁切识别（未知页的 Server Error 兜底也复用同一份结果）
        items = _screen_items(ctx)
        # 【最高优先级】Server Error 弹窗盖住过渡提示和所有业务页，只有恢复规则点 Retry 才能消除：
        # 先于正常过渡、收尾与页面分派识别，命中立即抛 ExecutionFailure 进入恢复，
        # 不在被盖住的页面上继续点 Close／Leave／商品，也不把它当成未知页面累计无效轮
        if SERVER_ERROR_KEYWORD in _text_in(items, _scaled(meta, SERVER_ERROR_REGION)):
            _raise_server_error(ctx)
        # 【高优先级】服务端维护通知盖住所有业务页：维护期内点掉它只会让客户端弹出
        # Cannot operate the game. 并退回标题界面（Run 639 证据 639/12961），所以本层不输入、不空转，
        # 直接交恢复规则 recovery.popup_server_maintenance：按弹窗里的“after HH:MM (KST)”等待维护结束，
        # 多等 1 分钟再关通知，然后重新进入本任务
        if MAINTENANCE_KEYWORD in _all_text(items):
            ctx.log(
                f"第{round_index}轮：检测到服务端维护通知，交恢复规则 "
                f"recovery.popup_server_maintenance 等待维护结束后重试",
                level="error",
                screenshot=True,
            )
            raise ExecutionFailure(
                "server_maintenance", "服务端维护通知仍在，交恢复规则等待维护结束后重试"
            )
        # 【高优先级】Cannot operate the game.／Shutting down now.：游戏准备关闭，点它没有任何推进作用，
        # 命中即交恢复规则重启游戏，不把正要退出的画面当成未知页空转
        if CANNOT_OPERATE_KEYWORD in _all_text(items):
            ctx.log(
                f"第{round_index}轮：检测到 Cannot operate the game 弹窗（游戏准备关闭），"
                f"交恢复规则 recovery.popup_cannot_operate 处理",
                level="error",
                screenshot=True,
            )
            raise ExecutionFailure("game_cannot_operate", "检测到 Cannot operate the game 弹窗，游戏准备关闭")
        # 【优先级】正常加载／联网过渡先于业务分派：Run 637 里确认 Enter 后客户端进入 CONNECTING，
        # 入口页模板与右上角信息栏仍在，业务分支会继续命中并对同一画面重复输入，第 4 次撞上分支上限。
        # 这里复用本轮整屏 OCR（文字＋中心点），不再让检测 Step 重复识别；只清零同一分支的连续计数，
        # 不重置总轮次预算。
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        # 标题界面（TOUCH TO START）不是镜牢情景：登录过渡不成立时游戏停在登录前，
        # 本任务内没有任何可推进的动作，报错交恢复规则 recovery.title_to_main 登录后再重入
        # 更新／登录过渡的尾帧也会命中同一标题特征（Run 642 第 12 轮），所以先有界宽限观察：
        # 整段宽限都停在标题界面才报错，期间已离开就回到循环顶部按新帧重新观测
        if ctx.action("observe.match_asset", asset=TITLE_ASSET):
            if _title_persists(ctx):
                ctx.log(
                    f"第{round_index}轮：游戏停在标题界面（TOUCH TO START），不在镜牢内，"
                    f"交恢复规则 recovery.title_to_main 处理",
                    level="error",
                    screenshot=True,
                )
                raise ExecutionFailure(
                    "mirror_game_not_started", "游戏停在标题界面（TOUCH TO START），不在镜牢内"
                )
            previous_branch = ""
            consecutive_hits = 0
            ctx.log(
                f"第{round_index}轮：标题特征只出现在登录过渡的尾帧，游戏已自行离开标题界面，"
                "回到循环顶部重新观测"
            )
            continue
        # 收尾判定放在最前面：本场镜牢领奖完成后重新回到主界面，直接结束整个 mirror 任务
        finished = ctx.call("step.mirror_finished")
        if finished["completed"]:
            ctx.log(f"镜牢收尾：{finished}")
            return {"status": "finished", "page": str(finished.get("page", "main"))}
        page, evidence = _pick(
            ctx,
            items,
            battle_assets,
            path_train_asset,
            path_icon_assets,
            event_assets,
            event_skip_assets,
        )
        ctx.log(f"镜牢第{round_index}轮：{page}，依据 {evidence}")
        # 居中区域漏识别时的兜底：未知页面再整屏确认一次 Server Error，
        # 否则只会累计无效轮，等三次耗尽才进恢复，期间还可能在被盖住的页面上误点
        if page == "unknown" and _server_error_fullscreen(items):
            _raise_server_error(ctx)
        if page != "team":
            entry_team_clicked = False
            team_list_reset = False
        if page in ("main", "drive", "entry"):
            if page in ("main", "drive"):
                # 主界面左下角体力读数：比例超过 70% 时先把体力换成脑啡肽模块，
                # 避免自然恢复撞上限被浪费；本 Step 只识别，是否转换由这里决定
                stamina = ctx.call("step.check_stamina_overflow")
                if stamina.get("overflow"):
                    if stamina.get("module_full"):
                        # 模块达到 999 上限时没有兑换余量：再点「最大」也只能换出很小数量，
                        # 比例降不下来还会反复重入，所以直接跳过本次转换
                        ctx.log(
                            f"主界面体力 {stamina.get('current')}/{stamina.get('max')}"
                            f"（{float(stamina.get('ratio') or 0.0):.1%}）超过阈值，但脑啡肽模块已满"
                            f"（{stamina.get('modules')}），没有兑换余量，跳过体力转换",
                            level="warning",
                        )
                    elif stamina_convert_blocked:
                        # 本场已经试过一次没成功：不再重复重入，直接按主界面继续进入镜牢
                        ctx.log(
                            f"主界面体力 {stamina.get('current')}/{stamina.get('max')}"
                            f"（{float(stamina.get('ratio') or 0.0):.1%}）仍超过阈值，"
                            f"但本场已尝试过体力转换且未成功，不再重复转换，继续进入镜牢",
                            level="warning",
                        )
                    else:
                        hit("sub_workflow.stamina_convert")
                        ctx.log(
                            f"主界面体力 {stamina.get('current')}/{stamina.get('max')}"
                            f"（{float(stamina.get('ratio') or 0.0):.1%}）超过阈值，先做体力转换"
                        )
                        converted = ctx.call("sub_workflow.stamina_convert") or {}
                        ctx.log(f"体力转换结果：{converted}")
                        if converted.get("completed"):
                            # 转换后重新观察：比例仍未降下来会在下一轮再次处理
                            continue
                        # 转换没完成（如「»」素材在当前弹窗皮肤下未命中）：只记 warning 并停止重试，
                        # 不让这个可选优化项把整场镜牢任务拖到分支上限失败
                        stamina_convert_blocked = True
                        ctx.log(
                            f"体力转换未完成（{converted.get('reason')}），本场不再重复尝试体力转换，"
                            f"继续进入镜牢",
                            level="warning",
                        )
            hit("sub_workflow.mirror_enter")
            ctx.call("sub_workflow.mirror_enter")
        elif page == "team":
            _set_team_selected(ctx, False)
            # 新一场镜牢开始：复位上一场的刚完成状态、刚结算结果与星光点选记录
            _set_exploration_complete(ctx, False)
            _set_last_result(ctx, RESULT_UNKNOWN)
            _set_star_configured(ctx, False)
            if not team_list_reset:
                # 上划阶段：只用拖拽把列表拉回顶部，每次拖拽后由子流程截图并做一次通用等待检测；
                # 与下面的点击阶段分开，避免拖拽途中的突发弹窗干扰选队
                hit("sub_workflow.team_list_drag_top")
                reset = ctx.call("sub_workflow.team_list_drag_top") or {}
                ctx.log(f"队伍列表上划结果：{reset}")
                if str(reset.get("completed")) == "true":
                    team_list_reset = True
                continue
            if not entry_team_clicked:
                # 点击阶段：先对点击前的一帧再做一次通用等待检测，弹窗未清就不要点队伍行
                click_meta = ctx.action("observe.capture_screen")
                if ctx.call(
                    "step.detect_normal_transition",
                    width=int(click_meta["width"]),
                    height=int(click_meta["height"]),
                ):
                    previous_branch = ""
                    consecutive_hits = 0
                    ctx.call("step.wait_normal_transition")
                    continue
                # 该页左侧是同一种可选队伍列表，选中哪一行整场镜牢就用哪个队伍；
                # 不先点中目标队伍时 Confirm 只会沿用游戏里上一次选中的队伍
                hit("step.select_team_by_index")
                ctx.call("step.select_team_by_index", team_index=team)
                entry_team_clicked = True
            else:
                hit("step.mirror_confirm_team")
                ctx.call("step.mirror_confirm_team")
        elif page in ("star", "star_confirm"):
            _set_team_selected(ctx, False)
            # star_confirm 是 star 页 Enter 后的确认弹窗：同一步骤的弹窗分支只点一次 Confirm，
            # 点完由下一轮重新观察是否已进入饰品选择页
            hit("step.mirror_star_bonus")
            ctx.call("step.mirror_star_bonus")
        elif page == "weekly_reset":
            # 每周记录重置通知：只点一次 Cancel 留在当前探索，不点 Confirm（会离开本次探索转到 Window）；
            # 通知是否已关闭由下一轮重新观察
            hit("step.mirror_weekly_reset_cancel")
            ctx.call("step.mirror_weekly_reset_cancel")
        elif page == "gift":
            hit("sub_workflow.mirror_gift_select")
            ctx.call("sub_workflow.mirror_gift_select")
        elif page in ("floor_gift", "gift_get"):
            # gift_get 的 E.G.O Gift GET! 弹窗同样由 floor_gift Step 的入口分支按 Enter 确认
            hit(page)
            ctx.call("step.mirror_floor_gift_select")
        elif page == "themepack":
            # 情景名 themepack：SELECT FLOOR n THEME PACK 主题包选择页（原情景名 left）
            # 收录与选择都交给主题包子流程：先等 2 秒让页面动画结束，把没收录的主题包按弹窗标题
            # 裁成 mirror/theme_pack/<名字>（新收录按默认选择等级处理），再按 优先 → 默认 → 尽量不选
            # 的偏好下拉选择；没有优先选择时先点一次右上角 Refresh 重掷，再收录、再按同一顺序选。
            hit("sub_workflow.mirror_theme_pack")
            selected = ctx.call("sub_workflow.mirror_theme_pack") or {}
            ctx.log(
                f"主题包选择结果：{selected.get('reason')}"
                f"（page={selected.get('page')}，completed={selected.get('completed')}）"
            )
            # 主题包下拉即开始新楼层探索：紧接着按新楼层刷新一次商店运行时记录（不读其返回）
            hit("step.mirror_refresh_shop_state")
            ctx.call("step.mirror_refresh_shop_state")
        elif page == "shop_info":
            # 只读的 E.G.O Gift Info 弹窗：交饰品 Step 点一次 Confirm 关掉，落点由下一轮重新观察
            hit("step.mirror_shop_gift_pick")
            ctx.call("step.mirror_shop_gift_pick")
        elif page == "shop":
            if _shop_visited(ctx):
                # 本楼层已经在商店做过离开前的事务：不再重复处理商品，直接执行离开商店
                ctx.log(f"本楼层已进过商店（{SHOP_VISITED_KEY}=True），直接执行离开商店")
                hit("step.mirror_shop_leave")
                # assume_shop=True：本层已经用同一帧的整屏 OCR 把本页判成商店页，
                # 不该再由 Step 独立确认一次（Run 645 就是 Step 自己识别不到→零输入→连续四轮撞分支上限）
                ctx.call("step.mirror_shop_leave", assume_shop=True)
            else:
                # 购买循环：技能替换有要的就买，买不到要的罪人就普通 Refresh 重掷商品；
                # 停止条件由子流程观察 Cost、阈值与 Purchased 商品后返回 completed
                hit("sub_workflow.mirror_shop")
                shop = ctx.call("sub_workflow.mirror_shop")
                if shop["completed"]:
                    # 购买循环结束后先做融合（Fuse Gifts，位置在购买循环后面）：
                    # 现成融合优先，否则点本队购买流派之外的耗材；融合页由子流程自己关闭。
                    if not _shop_fused(ctx) and not _shop_fuse_enabled(ctx):
                        # 融合开关关闭：跳过融合并记为已跑过，本楼层不再重复判断；
                        # 后续饰品自维护与离开商店照旧执行
                        ctx.log("商店设置的融合饰品已关闭，跳过购买结束后的融合，继续饰品自维护与离开商店")
                        _set_shop_fused(ctx, True)
                    if not _shop_fused(ctx):
                        hit("sub_workflow.mirror_shop_fuse")
                        fused = ctx.call("sub_workflow.mirror_shop_fuse") or {}
                        ctx.log(
                            f"融合结果：{fused.get('reason')}（成功融合 {fused.get('fused')} 次、"
                            f"耗材名单 {fused.get('consumables')} 件、关闭 {fused.get('closed')}）"
                        )
                        if not fused.get("completed"):
                            # 融合页/商店页异常：本轮不继续自维护与离开，下一轮重新观察后再处理
                            ctx.log(
                                "融合没有完成，本轮不做饰品自维护与离开商店，交下一轮重新观察",
                                level="warning",
                                screenshot=True,
                            )
                            continue
                        # 融合子流程已整轮跑过（无论成功融合几次）就记为已跑过：
                        # 即使弹窗没关掉，下一轮也只关闭弹窗，不会重复消耗礼物
                        _set_shop_fused(ctx, True)
                        if str(fused.get("closed") or "") == "still_open":
                            ctx.log(
                                "融合弹窗没有关掉，本轮不做饰品自维护与离开商店，"
                                "下一轮按 shop_fuse 继续关闭",
                                level="warning",
                                screenshot=True,
                            )
                            continue
                    # 离开商店前的最后一步：自维护饰品图鉴（打开 Sell E.G.O Gift 弹窗，
                    # 只对 mirror/gift 整组匹配达不到默认阈值 0.9 的格子逐个点选：无论这格是新饰品还是已入库
                    # 但外观与现有模板差得较多，都在点选后补一张裁剪（已有同名目录时追加到原逻辑名下，
                    # 新饰品才按流派建目录）；只选中、不售卖，绝不点弹窗里的 Sell 按钮）
                    if not _sell_gift_maintained(ctx):
                        _set_sell_gift_maintained(ctx, True)
                        ctx.log("离开商店前最后一步：自维护饰品图鉴（打开 Sell E.G.O Gift 弹窗，只对 mirror/gift 整组匹配达不到默认阈值 0.9 的格子逐格点选——无论新老饰品都把裁剪补进素材库）")
                        maintained = ctx.call("sub_workflow.mirror_sell_gift_maintain") or {}
                        ctx.log(
                            f"自维护饰品结束：{maintained.get('reason')}"
                            f"（写入素材 {maintained.get('saved')} 张、涉及 {maintained.get('distinct')} 个饰品名、"
                            f"跳过 {maintained.get('skipped')}、空格 {maintained.get('empty')}、"
                            f"屏数 {maintained.get('screens')}；写入数不是图鉴新增饰品数）"
                        )
                    # 购买阶段已结束：立即记进 RunState，离开失败重入时直接离开，不再花 Cost
                    _set_shop_visited(ctx, True)
                    hit("step.mirror_shop_leave")
                    # assume_shop=True：同上，本轮的 shop 分派就是上层的判据，Step 不再要求另一次独立确认
                    ctx.call("step.mirror_shop_leave", assume_shop=True)
        elif page == "shop_fuse":
            # 融合弹窗（或 Fusion - Keyword Selection 弹窗）开着：交融合子流程继续推进或关闭；
            # 本楼层商店事务已做完或融合已跑过时只关闭弹窗，不重复购买/融合
            if _shop_visited(ctx) or _shop_fused(ctx) or not _shop_fuse_enabled(ctx):
                hit("step.mirror_shop_fuse_close")
                ctx.call("step.mirror_shop_fuse_close")
            else:
                hit("sub_workflow.mirror_shop_fuse")
                ctx.call("sub_workflow.mirror_shop_fuse")
        elif page == "shop_skill":
            # 技能替换弹窗已经打开：本楼层已做过商店事务就只处理弹窗，否则回到购买循环
            if _shop_visited(ctx):
                hit("step.mirror_shop_skill_replace")
                ctx.call("step.mirror_shop_skill_replace")
            else:
                hit("sub_workflow.mirror_shop")
                ctx.call("sub_workflow.mirror_shop")
        elif page == "reward_card":
            hit("sub_workflow.mirror_reward_card")
            ctx.call("sub_workflow.mirror_reward_card")
        elif page == "path":
            hit("sub_workflow.mirror_pathfind")
            pathfind = ctx.call("sub_workflow.mirror_pathfind")
            if pathfind.get("page") == "exit":
                # 寻路界面里找不到火车头：已判定寻路失败，退出镜牢回到主界面后重新分派
                ctx.log("寻路流程判定寻路失败，执行退出镜牢流程")
                ctx.call("sub_workflow.mirror_exit")
        elif page == "event":
            # event 处理是通用的：镜牢与 Luxcavation 共用同一个子流程，用 entry 标明本任务是 mirror 入口，
            # 子流程据此在事件结束后把寻路页／奖励卡片页／楼层饰品页／E.G.O Gift GET! 到手弹窗（gift_get_asset）
            # 当退出信号交回本层，由本层的 gift_get 分支按 Enter 确认弹窗
            hit("sub_workflow.event")
            ctx.call(
                "sub_workflow.event",
                entry="mirror",
                event_choices_asset=event_choices_asset,
                event_result_asset=event_result_asset,
                event_skip_asset=event_skip_asset,
                event_grey_skip_asset=event_grey_skip_asset,
                path_train_asset=path_train_asset,
                gift_get_asset=gift_get_asset,
            )
        elif page == "prepare":
            # 【页面区分】局内战斗准备页左侧只有本场这一张 Preset 卡，没有 TEAMS 队伍列表（Run 380）：
            # 本场队伍在进镜牢前的队伍页（page == "team"）已经选定，这里不能再用 step.select_team_by_index，
            # 否则会把战斗准备页当成队伍选择页去滚列表、按行点击。这里只按配置重排出战顺序，再确认出战。
            # 两项都是动作 Step：是否生效由下一轮重新观察后分流
            if not _team_selected(ctx):
                hit("step.select_team_sinners")
                ctx.call("step.select_team_sinners", team_index=team, first_clear_selection=True)
                _set_team_selected(ctx, True)
            else:
                hit("step.confirm_team_battle")
                ctx.call("step.confirm_team_battle")
        elif page == "battle":
            hit("sub_workflow.battle_till_end")
            ctx.call(
                "sub_workflow.battle_till_end",
                battle_assets=battle_assets,
                path_asset=path_train_asset,
                event_assets=event_assets,
                event_skip_assets=event_skip_assets,
            )
        elif page == "victory":
            # 胜利结算页：只点一次右下角 Confirm 并写 last_result，落点由下一轮重新观察
            hit("step.mirror_victory_confirm")
            ctx.call("step.mirror_victory_confirm")
        elif page == "defeat":
            # 失败结算页：同样只点一次右下角 Confirm 并写 last_result
            hit("step.mirror_defeat_confirm")
            ctx.call("step.mirror_defeat_confirm")
        elif page == "rewards_acquired":
            # 到账弹窗：点一次 Confirm 关闭，分派优先级在 _pick 中已高于 exploration_complete
            hit("step.mirror_rewards_acquired")
            ctx.call("step.mirror_rewards_acquired")
        elif page == "pass_level_up":
            # Battle Pass 升级弹窗：同样点一次 Confirm 关闭
            hit("step.mirror_pass_level_up")
            ctx.call("step.mirror_pass_level_up")
        elif page == "exploration_complete":
            # 结算页：按 reward_rules 与刚结算结果选择领取或放弃（子流程返回契约不变）
            hit("sub_workflow.mirror_reward_settlement")
            ctx.call("sub_workflow.mirror_reward_settlement")
        else:
            hit("unknown")
            ctx.log(f"第{round_index}轮：未识别到可推进的镜牢情景，等待后重新观察")
            ctx.action("observe.wait", seconds=1.0)
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
