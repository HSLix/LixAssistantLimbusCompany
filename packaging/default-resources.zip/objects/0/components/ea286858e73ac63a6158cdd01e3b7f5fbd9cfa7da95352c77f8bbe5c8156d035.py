"""镜牢 Select Encounter Reward Card 页面：把卡片按优先级从低到高全部点一遍，按一次 Enter 提交，再等提交生效。"""
import re
import time

from lalc import RunContext, sub_workflow, ExecutionFailure

# 页面标题条（1280x720 客户区）：Select Encounter Reward Card
TITLE_REGION = {"x": 270, "y": 100, "width": 540, "height": 70}
TITLE_KEYWORD = "encounterrewardcard"
# 未选择奖励时的确认弹窗文案区域：
# You have not selected a reward yet. / Continue without choosing a reward?
POPUP_REGION = {"x": 340, "y": 180, "width": 600, "height": 350}
POPUP_KEYWORDS = ("notselectedareward", "withoutchoosingareward")
# E.G.O Gift GET! 弹窗：选卡提交后拿到饰品时的正常结果页，会盖在奖励卡页上方（Run 292）。
# 用素材 mirror/ego_gift_get（430x34 的标题横幅）做原尺寸模板匹配，不再读标题文字；
# 区域与阈值跟 task.mirror 的 gift_get 判定保持一致
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
# 「选卡 → 提交」的往返上限：按 Enter 提交这么多次后仍停在奖励卡页就判定提交失败，
# 不再无限重复「全部点一遍 → 按 Enter」（Run 611 就反复停在同一张奖励卡页）。
# 正常流程只要 1 次：选卡 Step 已把卡片全部点过，最后停在最高优先级，按一次 Enter 就该离开本页。
MAX_SUBMIT_CYCLES = 3
# 提交后的确认观察窗口（Run 623）：按 Enter 后约 1.05 秒抓到的帧仍是完整的奖励卡页
# （标题、三张卡、Selectable 1/1、Confirm 都在），直到约 5~6 秒后标题才消失——
# 这是面板淡出动画，不是「Enter 没生效」。所以提交后进入 confirming 阶段：只观察、不点卡。
# 本阶段最多观察这么久：窗口内页面一变就立即离开，窗口用尽仍停在奖励卡页才判定 Enter 未生效。
# 窗口内调用的通用等待按它自己的预算跑完，不因窗口计时到点而被截断。
CONFIRM_WINDOW_SECONDS = 10.0
# confirming 阶段每次重新抓帧之间的等待秒数（该阶段不发任何输入）
CONFIRM_POLL_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _in_region(item: dict, region: dict[str, int]) -> bool:
    """该 OCR 条目的中心是否落在给定区域。"""
    center = item.get("centerxy") or (0, 0)
    x, y = int(center[0]), int(center[1])
    return (
        int(region["x"]) <= x <= int(region["x"]) + int(region["width"])
        and int(region["y"]) <= y <= int(region["y"]) + int(region["height"])
    )


def _region_text(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回规范化小写文本；不刷新截图。"""
    texts = [str(item.get("text", "")) for item in items if _in_region(item, region)]
    return _norm(" ".join(text for text in texts if text))


def _state(ctx: RunContext, items: list[dict]) -> tuple[str, str]:
    """
    按当前帧判定状态，返回 (状态, 判定依据)。
    gift_get：拿到饰品的 E.G.O Gift GET! 弹窗，属于奖励卡流程的正常退出信号（会盖在奖励卡页上方，所以先判）；
    popup：未选择奖励的确认弹窗（会压暗整页，所以先判）；reward_card：可选卡片页；
    other：本页已不在（标题读不到）。本子流程只认自己这一页，不识别后续页面属于哪种情景：
    主题包、Acquire E.G.O Gift、寻路页等一律只报 other，交回 task.mirror 下一轮重新分派。
    """
    if ctx.action(
        "observe.match_asset",
        asset=GIFT_GET_ASSET,
        region=GIFT_GET_REGION,
        threshold=GIFT_GET_THRESHOLD,
    ):
        return "gift_get", GIFT_GET_ASSET
    popup = _region_text(items, POPUP_REGION)
    if any(keyword in popup for keyword in POPUP_KEYWORDS):
        return "popup", popup
    title = _region_text(items, TITLE_REGION)
    if TITLE_KEYWORD in title:
        return "reward_card", title
    return "other", title


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    优先等待正常过渡，再有界分派；同一分支连续第四次命中或总预算耗尽时失败。
    不读 Selectable 的选卡计数：每轮先让 step.mirror_reward_card_pick 把当前能定位到的卡片
    按优先级从低到高各点一次（最后停在优先级最高的一张，覆盖前面的选择），再按一次 Enter 提交。
    提交后回到循环顶部重新观察：出现 E.G.O Gift GET! 弹窗算本页完成；
    一旦本页已不在（other），只报告并交回上层重新识别，不猜后续页面类型、也不替上层推进。
    连续 MAX_SUBMIT_CYCLES 次「全部点一遍 → Enter」后页面仍停在奖励卡页，
    按 reward_card_not_submitted 失败，不无限重按。

    提交后进入 confirming 阶段：只观察、不再点卡，窗口最多 CONFIRM_WINDOW_SECONDS 秒。
    期间照常做通用加载检测；检测到加载就调用通用等待，通用等待按自己的预算跑完，
    即使本阶段窗口计时已到点也不截断它。
    页面一变（gift_get / other / popup）就按该状态处理或直接交回上层；
    窗口用尽仍停在奖励卡页，才判定这次 Enter 未生效，退回选卡重提。
    """
    previous_branch = ""
    consecutive_hits = 0
    # 本轮该选卡、还是等待提交生效：先选卡，提交后进入 confirming，页面离开后回顶层
    stage = "pick"
    # 已经按 Enter 提交过几次仍没离开本页：有界上限，避免在同一页无限重按
    submit_cycles = 0
    # confirming 阶段的开始时间：窗口 CONFIRM_WINDOW_SECONDS 秒用尽前不判定提交失败
    confirm_started = 0.0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    # 每轮最多消耗一次 1 秒级观察；confirming 阶段最多占 CONFIRM_WINDOW_SECONDS / CONFIRM_POLL_SECONDS 轮，
    # 再叠加最多 MAX_SUBMIT_CYCLES 次「选卡 → 提交」，30 轮不够用，放到 60 轮
    for round_index in range(1, 60 + 1):
        meta = ctx.action("observe.capture_screen")
        # 每轮对同一帧只做一次整屏 OCR：弹窗与标题都从这份结果里按区域过滤
        items = _screen_items(ctx)
        page, evidence = _state(ctx, items)
        ctx.log(f"第{round_index}轮奖励卡状态 {page}：{evidence}")
        if page == "gift_get":
            # 拿到饰品后的 E.G.O Gift GET! 弹窗是奖励卡流程的正常结束：直接交回上层，
            # 由 task.mirror 的 gift_get 分支按 Enter 确认，不在这里重复按 Enter，也不计未达成
            return {
                "completed": True,
                "reason": "已出现 E.G.O Gift GET! 弹窗，奖励卡已提交完成",
                "page": "gift_get",
            }
        if page == "other":
            # 本页已不在：本子流程只管奖励卡页本身，不替上层判断后续是主题包、饰品页还是别的情景，
            # 也不在这里点任何东西，直接交回 task.mirror 下一轮重新识别并分派
            ctx.log(f"已不在奖励卡页（{evidence or '标题未命中'}），交回上层重新识别")
            return {
                "completed": False,
                "reason": "已不在奖励卡页，交回上层重新识别",
                "page": "other",
            }
        if page == "popup":
            hit("step.mirror_reward_card_decline")
            ctx.log("未选择奖励弹窗在，只按一次 ESC")
            ctx.call("step.mirror_reward_card_decline")
            # ESC 取消后卡片恢复未选状态：回到选卡阶段重新按低→高顺序点一遍
            stage = "pick"
            continue
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            # 通用等待是循环最后一个分支：复用本轮整屏 OCR（文字＋中心点），不再让检测 Step 重复识别一次
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        if stage == "confirming":
            # 提交后的确认阶段（Run 623）：面板淡出期间画面仍是同一张奖励卡页，
            # 这时点卡只会把已经选中的卡再点一次（同一张卡点第二次会取消选中），所以本阶段不发任何输入。
            # 通用加载的检测与等待由上方的 detect_normal_transition / wait_normal_transition 分支负责：
            # 窗口到点只影响「要不要再开一轮观察」，不影响已经在跑的通用等待——它会按自己的预算跑完；
            # 所以本阶段的窗口最多 CONFIRM_WINDOW_SECONDS 秒，但不会被内部等待拖到判定失效。
            elapsed = time.monotonic() - confirm_started
            if elapsed >= CONFIRM_WINDOW_SECONDS:
                ctx.log(
                    f"奖励卡提交后已观察 {elapsed:.1f} 秒仍停在 Select Encounter Reward Card，"
                    "判定这次 Enter 未生效，退回选卡重提",
                    level="warning",
                    screenshot=True,
                )
                stage = "pick"
                continue
            ctx.log(
                f"奖励卡提交后确认中：已观察 {elapsed:.1f}/{CONFIRM_WINDOW_SECONDS:.0f} 秒，"
                f"页面仍是奖励卡页，只等待不点卡，{CONFIRM_POLL_SECONDS:.1f} 秒后重新观察"
            )
            ctx.action("observe.wait", seconds=CONFIRM_POLL_SECONDS)
            continue
        if stage == "pick":
            if submit_cycles >= MAX_SUBMIT_CYCLES:
                # 提交过 MAX_SUBMIT_CYCLES 次仍停在奖励卡页：Enter 没生效，交给上层／人工，
                # 不再继续「选卡 → 提交」空转（Run 611 就是在这条路径上反复停在同一页）
                raise ExecutionFailure(
                    "reward_card_not_submitted",
                    f"奖励卡已按顺序全部点选并连续 {MAX_SUBMIT_CYCLES} 次按 Enter，"
                    "页面仍停在 Select Encounter Reward Card，未提交成功",
                )
            hit("step.mirror_reward_card_pick")
            ctx.log("奖励卡选卡：按优先级从低到高把当前能定位到的卡片各点一次，最后停在优先级最高的一张")
            ctx.call("step.mirror_reward_card_pick")
            stage = "enter"
            continue
        hit("step.mirror_reward_card_enter")
        ctx.log(f"奖励卡已全部点选，按一次 Enter 提交（第 {submit_cycles + 1}/{MAX_SUBMIT_CYCLES} 次）")
        ctx.call("step.mirror_reward_card_enter")
        submit_cycles += 1
        # 提交后不立刻回到选卡：先进入 confirming 只观察页面是否离开，不再点卡
        stage = "confirming"
        confirm_started = time.monotonic()
        continue
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
