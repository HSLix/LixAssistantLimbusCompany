"""镜牢 star 页面：按设置页保存的星光配置逐卡点一次，再按一次 Enter，落点由上层观察。

游戏里 + / ++ 只调整档位，不会选中强化本身，所以每张卡在点完档位后还要再点一次卡面本体。
"""
from lalc import RunContext, step

STAR_ASSET = "mirror/star"
GIFT_ASSET = "mirror/gift_select"
DIALOG_REGION = {"x": 420, "y": 160, "width": 440, "height": 400}
DIALOG_TEXT = "select grace of stars"
# 每张卡点完档位或卡面后留给界面的反应时间（属于同一组固定动作）
CLICK_WAIT_SECONDS = 0.4
# 点击 star 页 Enter、以及确认弹窗 Confirm 后的固定等待秒数
AFTER_ENTER_SECONDS = 1.0
AFTER_CONFIRM_SECONDS = 1.0

# 星光配置来自镜牢设置页的「星光强化」分页：档位与是否启用分开保存
PAGE_ID = "mirror.settings"
STAR_LEVELS_KEY = "star_levels"
STAR_ENABLED_KEY = "star_selected"
# 档位上限，与设置页的 + / ++ 两个按钮一致
MAX_LEVEL = 2
# 本场镜牢是否已经点选过星光：点击会消耗星光，重入时不能重复点
RUNTIME_KEY = "mirror.runtime"
STAR_CONFIGURED_KEY = "star_configured"

# 卡片按游戏界面从左到右、从上到下编号，键与设置页 STAR_CARDS 一致。
# 每项依次是：键、+ 按钮、++ 按钮、卡面本体；坐标取自 1280x720 固定窗口的实测位置。
STAR_CARDS = (
    ("star_of_the_beginning", (188, 347), (269, 347), (229, 250)),
    ("cumulating_starcloud", (387, 347), (468, 347), (428, 250)),
    ("interstellar_travel", (585, 347), (665, 347), (627, 250)),
    ("star_shower", (784, 347), (864, 347), (820, 250)),
    ("binary_star_shop", (982, 347), (1062, 347), (1025, 250)),
    ("moon_star_shop", (188, 586), (269, 586), (229, 500)),
    ("favor_of_the_nebulae", (387, 586), (468, 586), (420, 500)),
    ("starlight_guidance", (585, 586), (665, 586), (620, 500)),
    ("chance_comet", (784, 586), (864, 586), (820, 500)),
    ("perfected_possibility", (982, 586), (1062, 586), (1025, 500)),
)


def _region_texts(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做 OCR，返回合并后的小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    return " ".join(str(item.get("text", "")) for item in items if item.get("text")).lower()


def _region_items(ctx: RunContext, region: dict[str, int]) -> list[dict]:
    """刷新截图并返回指定区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=region) or {}
    return list(result.get("items") or [])


def _click_popup_button(
    ctx: RunContext, items: list[dict], label: str, fallback: tuple[int, int]
) -> None:
    """在弹窗内点击文字完全匹配且最接近 fallback 的按钮，否则退回固定坐标。"""
    candidates = [
        item for item in items if str(item.get("text", "")).strip().lower() == label
    ]
    if not candidates:
        ctx.log(f"弹窗未识别到 {label} 文本，点击回退坐标 {fallback}", level="warning")
        ctx.action("control.click", x=fallback[0], y=fallback[1])
        return

    def distance(item: dict) -> float:
        """候选按钮中心到回退坐标的距离。"""
        center = item.get("centerxy") or fallback
        return ((center[0] - fallback[0]) ** 2 + (center[1] - fallback[1]) ** 2) ** 0.5

    target = min(candidates, key=distance)
    ctx.log(f"弹窗点击 {label} @ {target.get('centerxy')}")
    ctx.action("control.click", centerxy=tuple(target.get("centerxy")))


def _page_settings(ctx: RunContext) -> dict:
    """读取镜牢设置页保存的配置；没有该页配置或类型不对时按空配置处理。"""
    settings = ctx.run_state.settings or {}
    page = settings.get(PAGE_ID) if isinstance(settings, dict) else None
    return page if isinstance(page, dict) else {}


def _target_levels(ctx: RunContext) -> dict[str, int]:
    """读取每张卡的目标档位：只接受已知卡片的 0~2 整数，缺失或非法值按 0 处理。"""
    raw = _page_settings(ctx).get(STAR_LEVELS_KEY)
    raw = raw if isinstance(raw, dict) else {}
    levels = {}
    for key, _, _, _ in STAR_CARDS:
        value = raw.get(key)
        levels[key] = value if type(value) is int and 0 <= value <= MAX_LEVEL else 0
    return levels


def _enabled_keys(ctx: RunContext, levels: dict[str, int]) -> set[str]:
    """读取启用（对勾）状态；旧配置没有该字段时按档位 > 0 推断，与设置页一致。"""
    raw = _page_settings(ctx).get(STAR_ENABLED_KEY)
    known = {key for key, _, _, _ in STAR_CARDS}
    if isinstance(raw, list):
        return {str(item) for item in raw if str(item) in known}
    return {key for key, level in levels.items() if level > 0}


def _star_configured(ctx: RunContext) -> bool:
    """本场镜牢是否已经点选过星光；没有记录时按还没点过处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(STAR_CONFIGURED_KEY) is True


def _set_star_configured(ctx: RunContext, configured: bool) -> None:
    """
    记录／复位本场镜牢的星光点选状态；新一场镜牢开始时由 task.mirror 复位。
    写入前 RunState 里可能还没有这个记录，拿到的是空 dict，必须写回 settings 才会生效。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录星光点选状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[STAR_CONFIGURED_KEY] = configured
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢星光点选状态 {STAR_CONFIGURED_KEY}={configured}")


def _select_graces(ctx: RunContext, levels: dict[str, int], enabled: set[str]) -> int:
    """按配置逐张点击档位（+ / ++）再点卡面本体，返回实际处理的卡片数量。"""
    handled = 0
    for key, plus, plus2, body in STAR_CARDS:
        if key not in enabled:
            continue
        level = levels[key]
        if level > 0:
            point = plus if level == 1 else plus2
            ctx.action("control.click", x=point[0], y=point[1])
            ctx.log(f"星光 {key} 点击 {level} 档按钮 @ {point}")
            ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
        # 档位按钮只调等级，不选中强化本身，必须再点卡面本体
        ctx.action("control.click", x=body[0], y=body[1])
        ctx.log(f"星光 {key} 点击卡面本体 @ {body}")
        ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
        handled += 1
    return handled


@step
def execute(
    ctx: RunContext,
    *,
    enter_x: int = 1195,
    enter_y: int = 671,
    confirm_x: int = 752,
    confirm_y: int = 533,
) -> None:
    """
    先截图复查入口：
    已在饰品选择页零动作返回（同时复位本场星光点选记录）；
    Select Grace of Stars 弹窗已在时只点一次 Confirm，等固定 1 秒后交回；
    不在 star 页面时零输入返回。
    确在 star 页面才按镜牢设置页的星光配置逐卡点一次档位按钮再点一次卡面本体（这是本步的固定动作组），
    然后点一次 Enter，等固定 1 秒后交回。
    是否已到饰品选择页、确认弹窗是否出现由上层下一轮重新观察，本步不轮询。
    """
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=GIFT_ASSET):
        ctx.log("已在饰品选择页，无需再点选星光")
        _set_star_configured(ctx, False)
        return

    if DIALOG_TEXT in _region_texts(ctx, DIALOG_REGION):
        items = _region_items(ctx, DIALOG_REGION)
        _click_popup_button(ctx, items, "confirm", (confirm_x, confirm_y))
        ctx.log(f"Select Grace of Stars 弹窗已打开，点击 Confirm，等 {AFTER_CONFIRM_SECONDS} 秒后交回")
        ctx.action("observe.wait", seconds=AFTER_CONFIRM_SECONDS)
        return

    if not ctx.action("observe.match_asset", asset=STAR_ASSET):
        ctx.log("当前不是 star 页面，不点选星光", level="warning", screenshot=True)
        return

    if _star_configured(ctx):
        ctx.log("本场镜牢已经点选过星光强化，重入只重新确认，不重复消耗星光", level="warning")
    else:
        levels = _target_levels(ctx)
        enabled = _enabled_keys(ctx, levels)
        handled = _select_graces(ctx, levels, enabled)
        ctx.log(f"按镜牢设置页配置点选 {handled} 张星光强化")
        # 点击会消耗星光，先记录已点选，避免后续重入重复消耗
        _set_star_configured(ctx, True)

    ctx.action("control.click", x=enter_x, y=enter_y)
    ctx.log(f"点击 star 页面 Enter ({enter_x}, {enter_y})，等 {AFTER_ENTER_SECONDS} 秒后交回")
    ctx.action("observe.wait", seconds=AFTER_ENTER_SECONDS)
