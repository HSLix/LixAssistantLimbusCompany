"""事件判定页：先复查入口，再执行一组固定动作；选人是否生效、判定是否完成都交回上层重新观察。"""
import re

from lalc import RunContext, step

# 成功率档次标签就是判定选择阶段的唯一页内标识（任意一档命中即算）；下面按从高到低排列，veryhigh 最优先
TIER_ASSETS = (
    "event/pass/veryhigh",
    "event/pass/high",
    "event/pass/normal",
    "event/pass/low",
    "event/pass/verylow",
)
# 五档成功率标签统一使用 0.8 的模板匹配阈值（observe.match_asset 默认 0.9，更严格）
TIER_THRESHOLD = 0.8
# 档次标签位于罪人头像上方，点击标签中心后下移到头像中部
PORTRAIT_OFFSET_Y = 30
# 判定结果面板：Threshold／Outcome 数值与 Check Passed／Check Failed 出现的位置。
# Run 286 的证据显示结果面板亮起时底部成功率档次标签仍留在画面上，
# 所以判定是否已完成只能看这块结果面板，不能看档次标签是否消失
CHECK_RESULT_REGION = {"x": 740, "y": 340, "width": 460, "height": 180}
CHECK_RESULT_KEYWORDS = ("checkpassed", "checkfailed", "outcome")
# 判定已完成（结果面板已显示）时不再选择罪人：先连续按 Enter RESULT_ENTER_TIMES 次
# （每次间隔 RESULT_ENTER_SECONDS 秒），再点击一次右下角固定坐标推进结算
RESULT_ENTER_TIMES = 2
RESULT_ENTER_SECONDS = 1.0
# 要点击的右下角固定坐标（1280x720 客户区）：
# 与结果页 Proceed／Continue／SKIP 共用的同一位置，避免依赖按钮文案
OUTCOME_CLICK_POINT = (1140, 650)
# 点击后等待页面响应的秒数：本步动作后只做这一次固定等待
OUTCOME_CLICK_SECONDS = 0.7
# 判定结果面板亮起时右下角是亮色 SKIP：点击它可以跳过判定结果，再按 Enter 推进
BUTTON_REGION = {"x": 1020, "y": 590, "width": 240, "height": 120}
SKIP_KEYWORD = "skip"
SKIP_CLICK_SECONDS = 0.8
SKIP_ENTER_TIMES = 2
SKIP_ENTER_SECONDS = 0.5
# 选中罪人后，右下角按钮由灰 SKIP 变成亮色 Commence：只有点它才真正开始判定。
# Run 412 连续 4 轮停在选人阶段，就是选人后按 Enter——Enter 会把已选中的罪人取消，
# 画面始终回到 Predicted ??? ，所以这里必须先识别并点击 Commence
COMMENCE_KEYWORD = "commence"
COMMENCE_CLICK_SECONDS = 1.0
# 点击罪人头像后的固定等待秒数
CANDIDATE_WAIT_SECONDS = 0.7
# 选人与确认判定合并到同一次调用：点完罪人头像后右下角由灰 SKIP 变成亮色 Commence 需要一小段过渡，
# 这里在同一步内重新截图确认，等到就紧接着点它一次，省掉上层为「确认判定」再多花一整轮重新分派。
# 等待必须有界：CONFIRM_ATTEMPTS 次都用完仍没读到 Commence 就交回上层，由下一轮的 Commence 分支继续确认
CONFIRM_ATTEMPTS = 4
CONFIRM_RETRY_SECONDS = 0.5


def _check_page(ctx: RunContext) -> bool:
    """按成功率档次标签判断当前帧是否还在判定选择阶段：任意一档命中即算，不读 OCR 文案。"""
    return any(
        ctx.action("observe.match_asset", asset=asset, threshold=TIER_THRESHOLD)
        for asset in TIER_ASSETS
    )


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或标点影响关键字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _button_point(ctx: RunContext, keyword: str) -> tuple[int, int] | None:
    """当前帧右下角按钮区读到指定文字的按钮中心；读不到返回 None，不刷新截图。

    选人阶段的灰 SKIP 常常读不到，选中罪人后同一位置变成亮色 Commence；
    两个关键字共用这一块区域，按调用方要点的按钮分别识别。
    """
    result = ctx.action("observe.ocr", region=BUTTON_REGION) or {}
    items = result.get("items") or []
    for item in items:
        if keyword in _norm(item.get("text", "")):
            center = item.get("centerxy") or (0, 0)
            return int(center[0]), int(center[1])
    return None


def _result_hint(ctx: RunContext) -> str:
    """当前帧右下结果面板命中的判定结算关键字（outcome／checkpassed／checkfailed），没有返回空串。

    该面板出现说明判定已经完成；只有它能和选人阶段区分开，
    因为结果面板亮起时底部成功率档次标签依然存在（Run 286 证据）。
    """
    result = ctx.action("observe.ocr", region=CHECK_RESULT_REGION) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    text = _norm(joined)
    for keyword in CHECK_RESULT_KEYWORDS:
        if keyword in text:
            return keyword
    return ""


def _candidates(ctx: RunContext) -> list[tuple[str, list[int]]]:
    """按档次从高到低、同档按分数从高到低收集候选罪人头像点击点。"""
    candidates: list[tuple[str, list[int]]] = []
    for asset in TIER_ASSETS:
        tier = asset.rsplit("/", 1)[-1]
        matches = ctx.action("observe.match_asset", asset=asset, threshold=TIER_THRESHOLD) or []
        if not matches:
            continue
        ranked = sorted(matches, key=lambda item: float(item.get("score", 0.0)), reverse=True)
        for match in ranked:
            center = match.get("centerxy") or (0, 0)
            candidates.append((tier, [int(center[0]), int(center[1]) + PORTRAIT_OFFSET_Y]))
    return candidates


@step
def execute(ctx: RunContext) -> None:
    """
    事件判定页的一次局部尝试，进入后只做一组固定动作，不判定业务是否完成；
    「点击罪人参与判定」与「点右下角确认判定」合并在这同一次调用里完成：
    1. 先重新截图：右下结果面板已出现 Outcome／Check Passed／Check Failed 时说明判定已完成，
       不再选择罪人：先连续按 Enter RESULT_ENTER_TIMES（2）次、每次间隔 RESULT_ENTER_SECONDS 秒，
       再点击一次右下角固定坐标 OUTCOME_CLICK_POINT，等 OUTCOME_CLICK_SECONDS 秒后返回。
    2. 右下角读到亮色 Commence 说明已选好罪人（含上一轮点过罪人但确认没读到的情形），
       点击它一次（等 COMMENCE_CLICK_SECONDS 秒）返回；
       这里不按 Enter：判定页的 Enter 会把已选中的罪人取消，画面回到 Predicted ???。
    3. 右下角识别到亮色 SKIP 且仍在判定选择阶段时，点击该 SKIP 一次，
       再按 Enter SKIP_ENTER_TIMES 次（间隔 SKIP_ENTER_SECONDS 秒）后返回。
    4. 不在判定页（没有任何成功率档次标签）时零输入返回。
    5. 否则按档次从高到低（veryhigh → high → normal → low → verylow）收集候选罪人头像，
       只点击第一个一次，等 CANDIDATE_WAIT_SECONDS 秒后重新截图复查右下角：
       读到亮色 Commence 就接着点击它一次（再等 COMMENCE_CLICK_SECONDS 秒），
       选人与确认判定在同一次调用内合并完成；最多复查 CONFIRM_ATTEMPTS 次（每次间隔
       CONFIRM_RETRY_SECONDS 秒），仍没读到就返回，由上层下一轮的 Commence 分支继续确认。
    判定是否真的开始与结算如何，仍由上层下一轮重新截图判定：
    本步不逐个尝试其他罪人，不重复点击已点过的罪人，也不返回任何局部结果。
    选人后的确认复查是有界等待，只用于等 Commence 按钮出现的过渡动画，不重置上层预算。
    """
    ctx.action("observe.capture_screen")
    hint = _result_hint(ctx)
    if hint:
        ctx.log(
            f"右下结果面板已出现 {hint}（Outcome／Check Passed／Check Failed），说明判定已经完成，"
            f"不再选择罪人：先连续按 Enter {RESULT_ENTER_TIMES} 次（间隔 {RESULT_ENTER_SECONDS} 秒），"
            "再点击右下角固定坐标一次",
            screenshot=True,
        )
        for index in range(1, RESULT_ENTER_TIMES + 1):
            ctx.action("control.key_press", key="enter")
            ctx.action("observe.wait", seconds=RESULT_ENTER_SECONDS)
            ctx.log(f"第{index}/{RESULT_ENTER_TIMES}次按 Enter 推进已完成的判定")
        click_x, click_y = OUTCOME_CLICK_POINT
        ctx.log(f"连续按 Enter 后点击右下角固定坐标 ({click_x}, {click_y}) 继续推进结算")
        ctx.action("control.click", x=click_x, y=click_y)
        ctx.action("observe.wait", seconds=OUTCOME_CLICK_SECONDS)
        return

    on_check = _check_page(ctx)
    commence_point = _button_point(ctx, COMMENCE_KEYWORD)
    if commence_point is not None:
        point = f"{commence_point[0]},{commence_point[1]}"
        ctx.log(
            f"已选好罪人，右下角出现 Commence ({point})，点击它一次开始判定；"
            "此处不按 Enter，Enter 会取消已选中的罪人"
        )
        ctx.action("control.click", centerxy=commence_point)
        ctx.action("observe.wait", seconds=COMMENCE_CLICK_SECONDS)
        return

    skip_point = _button_point(ctx, SKIP_KEYWORD)
    if skip_point is not None and on_check:
        point = f"{skip_point[0]},{skip_point[1]}"
        ctx.log(
            f"判定选择阶段右下角已出现亮色 SKIP，点击 SKIP ({point})，"
            f"再按 Enter {SKIP_ENTER_TIMES} 次（间隔 {SKIP_ENTER_SECONDS} 秒）",
            screenshot=True,
        )
        ctx.action("control.click", centerxy=skip_point)
        ctx.action("observe.wait", seconds=SKIP_CLICK_SECONDS)
        for index in range(1, SKIP_ENTER_TIMES + 1):
            ctx.action("control.key_press", key="enter")
            ctx.action("observe.wait", seconds=SKIP_ENTER_SECONDS)
            ctx.log(f"第{index}/{SKIP_ENTER_TIMES}次按 Enter 推进判定")
        return

    if not on_check:
        ctx.log("当前不在事件判定页，不选择罪人也不确认判定", level="warning", screenshot=True)
        return

    candidates = _candidates(ctx)
    if not candidates:
        ctx.log("已命中成功率档次标签但没有可点击的候选罪人，本步不点击", level="warning", screenshot=True)
        return

    tier, point = candidates[0]
    if len(candidates) > 1:
        ctx.log(
            f"共命中{len(candidates)}个候选罪人头像：{[item[1] for item in candidates]}，"
            f"取档次最高的一个（{tier}）",
            level="debug",
        )
    ctx.log(
        f"点击 {tier} 档次罪人头像 ({point[0]}, {point[1]}) 一次，"
        f"等 {CANDIDATE_WAIT_SECONDS} 秒后在同一轮内复查右下角确认判定"
    )
    ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=CANDIDATE_WAIT_SECONDS)
    # 选人与确认判定合并：点过罪人后立刻重新截图，右下角出现亮色 Commence 就紧接着点它一次，
    # 不必再让上层多花一轮重新分派到这个分支
    for attempt in range(1, CONFIRM_ATTEMPTS + 1):
        ctx.action("observe.capture_screen")
        confirm_point = _button_point(ctx, COMMENCE_KEYWORD)
        if confirm_point is not None:
            ctx.log(
                f"点过罪人后第{attempt}/{CONFIRM_ATTEMPTS}次复查读到右下角 Commence "
                f"({confirm_point[0]},{confirm_point[1]})，紧接着点击它一次开始判定"
            )
            ctx.action("control.click", centerxy=confirm_point)
            ctx.action("observe.wait", seconds=COMMENCE_CLICK_SECONDS)
            return
        ctx.action("observe.wait", seconds=CONFIRM_RETRY_SECONDS)
    ctx.log(
        f"点过罪人后 {CONFIRM_ATTEMPTS} 次复查（每次间隔 {CONFIRM_RETRY_SECONDS} 秒）仍未读到右下角 Commence，"
        "交回上层下一轮由本步的 Commence 分支继续确认，不再重复点击罪人",
        level="warning",
        screenshot=True,
    )
