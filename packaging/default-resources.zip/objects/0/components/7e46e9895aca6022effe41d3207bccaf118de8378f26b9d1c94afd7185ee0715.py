"""镜牢 Exploration Complete 结算页：每次只做领取流程剩下的一个动作。"""
import re

from lalc import RunContext, step

# Exploration Complete 标题（左上角两行文字）与右下角 Claim Rewards 按钮的区域（1280x720 客户区）
TITLE_REGION = {"x": 140, "y": 80, "width": 200, "height": 95}
TITLE_KEYWORD = "explorationcomplete"
BUTTON_REGION = {"x": 1030, "y": 555, "width": 210, "height": 90}
BUTTON_KEYWORDS = ("claim", "rewards")
# 点击后弹出的 Exploration Reward 结算弹窗标题：点击生效的证据，也是本 Step 的退出信号
POPUP_TITLE_REGION = {"x": 500, "y": 90, "width": 300, "height": 60}
POPUP_TITLE_KEYWORD = "explorationreward"
# 右下角 Claim Rewards 按钮（含左侧对勾）的固定坐标
CLAIM_REWARDS_POINT = (1148, 598)
# Exploration Reward 弹窗内最右侧 Claim 按钮（含左侧对勾，右侧 -5 Starlight 图标）的固定坐标
POPUP_CLAIM_POINT = (861, 545)
# 点击弹窗内 Claim 后弹出的确认弹窗文案：既是点击生效的证据，也是本 Step 的退出信号。
# 现场有两种：Spend your Weekly Bonuses（带周常加成时）与 Claim the rewards?（Run 487 的正常结算，
# 叠在 Exploration Reward 弹窗之上，文字中心约 (641,346)）。只认前者时 Step 会一直以为自己在结算弹窗里，
# 反复点被确认弹窗遮住的 Claim，上层因此连续命中 claim-popup 后失败。
CLAIM_CONFIRM_REGION = {"x": 400, "y": 300, "width": 480, "height": 90}
CLAIM_CONFIRM_KEYWORDS = ("spendyourweeklybonuses", "claimtherewards")
# 领取确认弹窗内 Confirm 按钮（含左侧对勾）的固定坐标
CONFIRM_POINT = (781, 493)
# 每次点击后的固定等待秒数；阶段推进由上层下一轮重新观察
AFTER_ACTION_SECONDS = 0.6
# 本场镜牢刚完成状态：领取流程成功后写入 RunState.settings，供 step.mirror_finished 与 task.mirror 判定
RUNTIME_KEY = "mirror.runtime"
EXPLORATION_COMPLETE_KEY = "exploration_complete"


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _page_here(ctx: RunContext) -> bool:
    """当前帧是否为 Exploration Complete 结算页：左侧标题与右下角 Claim Rewards 按钮都要命中。"""
    if TITLE_KEYWORD not in _region_text(ctx, TITLE_REGION):
        return False
    button = _region_text(ctx, BUTTON_REGION)
    return all(word in button for word in BUTTON_KEYWORDS)


def _reward_popup_here(ctx: RunContext) -> bool:
    """当前帧是否已出现 Exploration Reward 结算弹窗，作为 Claim Rewards 点击生效的退出信号。"""
    return POPUP_TITLE_KEYWORD in _region_text(ctx, POPUP_TITLE_REGION)


def _claim_confirm_here(ctx: RunContext) -> bool:
    """当前帧是否已弹出领取确认弹窗：Spend your Weekly Bonuses 或 Claim the rewards? 都算。"""
    text = _region_text(ctx, CLAIM_CONFIRM_REGION)
    return any(keyword in text for keyword in CLAIM_CONFIRM_KEYWORDS)


def _mark_completed(ctx: RunContext) -> None:
    """
    把本场镜牢刚完成状态写进 RunState.settings。
    首次写入时 RunState 里还没有这个记录，拿到的是空 dict，
    必须写回 settings 才生效，否则 step.mirror_finished 读不到完成状态。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录镜牢刚完成状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[EXPLORATION_COMPLETE_KEY] = True
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢刚完成状态 {EXPLORATION_COMPLETE_KEY}=True")


@step
def execute(ctx: RunContext) -> None:
    """
    处理镜牢 Exploration Complete 结算页领取流程，每次进入只做「剩下那一步」：
    - 领取确认弹窗（Spend your Weekly Bonuses 或 Claim the rewards?）在时点一次 Confirm，
      登记本场镜牢刚完成状态，等 0.6 秒交回；
    - Exploration Reward 弹窗在时点一次弹窗内的 Claim，等 0.6 秒交回；
    - Exploration Complete 结算页在时点一次右下角 Claim Rewards，等 0.6 秒交回；
    - 三者都不在时零输入返回。
    领取流程是否走完由 sub_workflow.mirror_reward_settlement 下一轮重新观察，
    本步不轮询，也不再自己连点三步。
    """
    # 领取路径：由 sub_workflow.mirror_reward_settlement 在 reward_rules 判定为领取时调用；
    # 放弃路径由 step.mirror_exploration_reward 负责，不在本 Step 重复。
    ctx.action("observe.capture_screen")
    if _claim_confirm_here(ctx):
        ctx.log(f"领取确认弹窗（Spend your Weekly Bonuses／Claim the rewards?）：点击一次固定坐标的 Confirm {CONFIRM_POINT}")
        ctx.action("control.click", x=CONFIRM_POINT[0], y=CONFIRM_POINT[1])
        # 领取流程已顺利执行：记录本场镜牢刚完成状态（RunState 写入，不是返回值）
        _mark_completed(ctx)
        ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
        return

    if _reward_popup_here(ctx):
        ctx.log(f"Exploration Reward 弹窗：点击一次固定坐标的 Claim {POPUP_CLAIM_POINT}")
        ctx.action("control.click", x=POPUP_CLAIM_POINT[0], y=POPUP_CLAIM_POINT[1])
        ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
        return

    if not _page_here(ctx):
        ctx.log("当前不是 Exploration Complete 结算页，也没有结算弹窗，无需处理")
        return

    ctx.log(f"Exploration Complete 结算页：点击一次右下角 Claim Rewards {CLAIM_REWARDS_POINT}")
    ctx.action("control.click", x=CLAIM_REWARDS_POINT[0], y=CLAIM_REWARDS_POINT[1])
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
