"""镜牢主题包选择页：把指定主题包卡片向下拉一次完成选择，落点由上层重新观察。"""
import re

from lalc import RunContext, step

PATH_ASSET = "mirror/train_head"
# 主题包选择页标题 SELECT FLOOR n THEME PACK
HEADER_REGION = {"x": 470, "y": 92, "width": 340, "height": 56}
# 三个主题包卡片下方的标题行，仅用于日志说明当前可选的是哪些主题包
TITLE_REGION = {"x": 340, "y": 430, "width": 620, "height": 60}
# 下拉卡片的持续时间与下拉后的固定等待
DRAG_SECONDS = 1.0
AFTER_DRAG_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响标题匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_texts(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做 OCR，返回合并后的规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _pack_titles(ctx: RunContext) -> str:
    """对当前帧主题包标题行做 OCR，返回原始文本，仅用于日志。"""
    result = ctx.action("observe.ocr", region=TITLE_REGION) or {}
    items = result.get("items") or []
    return " / ".join(
        str(item.get("text", "")).strip() for item in items if str(item.get("text", "")).strip()
    )


def _theme_page(ctx: RunContext) -> bool:
    """主题包选择页特征：标题区域同时出现 SELECT FLOOR 与 THEME PACK。"""
    header = _region_texts(ctx, HEADER_REGION)
    return "selectfloor" in header and "themepack" in header


@step
def execute(
    ctx: RunContext,
    *,
    pack_x: int = 415,
    pack_y: int = 300,
    pull_pixels: int = 220,
) -> None:
    """
    先截图复查入口：已在寻路页面时零输入返回；不在主题包选择页时也不执行动作。
    确在主题包选择页则从 pack_x／pack_y 按住向下拉一次完成选择，等固定 1 秒后交回。
    pack_x／pack_y 由上层 sub_workflow.mirror_theme_pack 按已收录模板的命中中心给出（裁出来的
    封面中心，必然落在卡片主体上）；缺省值保留旧行为，指向左边第一张卡片的卡片主体。
    下拉是否生效、是否已进入寻路页由上层重新观察：下拉未生效时上层会重新调用本步，
    因此不再做点击卡片兜底，也不轮询寻路页。
    """
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=PATH_ASSET):
        ctx.log("已在镜牢寻路页面，无需再选择主题包")
        return
    if not _theme_page(ctx):
        ctx.log("当前不是镜牢主题包选择页，不执行主题包下拉", level="warning", screenshot=True)
        return

    titles = _pack_titles(ctx)
    ctx.log(f"当前可选主题包：{titles}；本次下拉卡片主体中心 ({pack_x}, {pack_y})")
    ctx.log(f"在主题包卡片主体 ({pack_x}, {pack_y}) 按住向下拉 {pull_pixels}px")
    ctx.action(
        "control.drag",
        x=pack_x,
        y=pack_y,
        end_x=pack_x,
        end_y=pack_y + pull_pixels,
        seconds=DRAG_SECONDS,
    )
    ctx.action("observe.wait", seconds=AFTER_DRAG_SECONDS)
