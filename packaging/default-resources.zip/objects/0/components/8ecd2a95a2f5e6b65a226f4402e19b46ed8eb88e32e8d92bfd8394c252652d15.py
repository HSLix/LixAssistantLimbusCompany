"""镜牢寻路界面：点击最右上角的齿轮设置按钮，并确认 Dungeon Progress 弹窗出现。"""
import re

from lalc import RunContext, step

# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上就算寻路界面
PATH_ICON_ASSETS = ("mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects")
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2
# 齿轮设置按钮；素材漏识别时退回固定坐标
SETTINGS_ASSET = "mirror/path/settings"
SETTINGS_REGION = {"x": 1190, "y": 18, "width": 84, "height": 56}
SETTINGS_FALLBACK = (1227, 46)
# Dungeon Progress 弹窗：标题是弹窗独有文案
POPUP_REGION = {"x": 350, "y": 165, "width": 580, "height": 400}
POPUP_KEYWORD = "dungeonprogress"
# 点击齿轮后的固定等待秒数；弹窗是否出现交给上层下一轮重新观察
AFTER_CLICK_SECONDS = 0.8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响弹窗标题匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _texts(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做 OCR，返回合并后的规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _icons(ctx: RunContext) -> int:
    """对当前帧右上角匹配三个按钮素材，返回命中数量；不刷新截图。"""
    return sum(
        1
        for asset in PATH_ICON_ASSETS
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )


@step
def execute(ctx: RunContext) -> None:
    """
    先截图复查入口：Dungeon Progress 弹窗已经打开时零输入返回；
    右上角寻路界面按钮不足两个（当前不在寻路界面）时也不点击；
    确在寻路界面才点击一次最右上角的齿轮（素材匹配优先，漏识别用固定坐标兜底），
    等固定 0.8 秒后交回。Dungeon Progress 弹窗是否打开由 sub_workflow.mirror_exit 下一轮重新观察。
    """
    ctx.action("observe.capture_screen")
    if POPUP_KEYWORD in _texts(ctx, POPUP_REGION):
        ctx.log("Dungeon Progress 弹窗已经打开，不再重复点击齿轮")
        return

    icons = _icons(ctx)
    if icons < MIN_PATH_ICONS:
        ctx.log(
            f"右上角按钮只命中 {icons}/{len(PATH_ICON_ASSETS)} 个，当前不是寻路界面，不点齿轮",
            level="warning",
            screenshot=True,
        )
        return

    matches = ctx.action("observe.match_asset", asset=SETTINGS_ASSET, region=SETTINGS_REGION) or []
    if matches:
        center = matches[0].get("centerxy") or SETTINGS_FALLBACK
        point = (int(center[0]), int(center[1]))
        how = "素材匹配"
    else:
        point = SETTINGS_FALLBACK
        how = "固定坐标兜底"
    ctx.action("control.click", centerxy=point)
    ctx.log(f"点击寻路界面右上角齿轮 {point}（{how}），等 {AFTER_CLICK_SECONDS} 秒后交回")
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
