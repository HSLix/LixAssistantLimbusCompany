"""镜牢商店「自维护饰品」收尾一步：点弹窗左下角的 Close 关掉 Sell E.G.O Gift 弹窗。

绝不点弹窗里的 Sell 按钮（会真的卖出饰品且不可撤回）。关不掉时只记 warning 返回 still_open，
由上层再试一次，避免把弹窗留在商店页上影响后面的购买循环。
"""
import re

from lalc import RunContext, step

# 弹窗左下角 Close 按钮（实测文字 "× Close" 中心 (492,586)）
CLOSE_BUTTON = (492, 586)
POPUP_TITLE_REGION = {"x": 500, "y": 76, "width": 300, "height": 54}
POPUP_TITLE_WORDS = ("sell", "gift")
POPUP_CLOSE_REGION = {"x": 438, "y": 560, "width": 116, "height": 48}
POPUP_CLOSE_WORD = "close"
# 点完 Close 到弹窗滑出完成的固定等待
CLOSE_SETTLE_SECONDS = 0.8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响按钮文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _popup_open(ctx: RunContext) -> bool:
    """当前帧是否还开着 Sell E.G.O Gift 弹窗：标题为主，左下角 Close 按钮为后备。"""
    text = _region_text(ctx, POPUP_TITLE_REGION)
    if all(word in text for word in POPUP_TITLE_WORDS):
        return True
    return POPUP_CLOSE_WORD in _region_text(ctx, POPUP_CLOSE_REGION)


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    先截一帧判断弹窗是否还开着：已经关掉就零输入返回 already_closed；
    否则点一次 Close，等 CLOSE_SETTLE_SECONDS 后重新截图确认弹窗消失。
    返回 status=already_closed/closed/still_open。
    """
    ctx.action("observe.capture_screen")
    if not _popup_open(ctx):
        ctx.log("Sell E.G.O Gift 弹窗已经关着，无需再点 Close")
        return {"status": "already_closed"}
    ctx.log(f"点击 Sell E.G.O Gift 弹窗的 Close 按钮 {CLOSE_BUTTON}（不点 Sell 按钮）")
    ctx.action("control.click", x=CLOSE_BUTTON[0], y=CLOSE_BUTTON[1])
    ctx.action("observe.wait", seconds=CLOSE_SETTLE_SECONDS)
    ctx.action("observe.capture_screen")
    if _popup_open(ctx):
        ctx.log("点过 Close 后弹窗标题仍在，本次没能关掉", level="warning", screenshot=True)
        return {"status": "still_open"}
    ctx.log("Sell E.G.O Gift 弹窗已关闭，交回商店页")
    return {"status": "closed"}
