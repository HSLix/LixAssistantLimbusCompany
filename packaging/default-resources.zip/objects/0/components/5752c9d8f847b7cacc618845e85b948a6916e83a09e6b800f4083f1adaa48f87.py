
"""通过一次素材点击推进画面；仅用于可安全重复的点击。导致游戏状态不可回退变化的最好单独封装。"""
from lalc import RunContext, step


@step
def execute(
    ctx: RunContext,
    *,
    click_asset: str,
    success_assets: list[str],
    success_count: int = 1,
) -> None:
    """重新观察一次：同帧已命中 success_count 个完成素材则零输入返回，否则按 centerxy 点击一次后交回。"""
    if (
        not click_asset.strip()
        or not success_assets
        or any(not name.strip() for name in success_assets)
    ):
        raise ValueError("点击素材和完成素材不能为空")

    if (
        type(success_count) is not int
        or not 1 <= success_count <= len(set(success_assets))
    ):
        raise ValueError("success_count 必须为正整数，且不能超过不同完成素材的数量")

    ctx.action("observe.capture_screen")
    matched = [
        asset
        for asset in dict.fromkeys(success_assets)
        if ctx.action("observe.match_asset", asset=asset)
    ]
    if len(matched) >= success_count:
        ctx.log(f"同帧已确认完成状态：{matched}，无需点击")
        return

    matches = ctx.action("observe.match_asset", asset=click_asset)
    if not matches:
        ctx.log(
            f"当前帧未匹配到可点击素材 {click_asset}，不输入，交回上层",
            level="warning",
            screenshot=True,
        )
        return
    if len(matches) > 1:
        ctx.log(f"{click_asset} 命中{len(matches)}个，存在歧义，按第一个命中点击", level="warning")

    ctx.action("control.click", centerxy=matches[0]["centerxy"])
    ctx.log(f"已点击 {click_asset} @ {matches[0]['centerxy']}，结果由上层重新截图判断")
