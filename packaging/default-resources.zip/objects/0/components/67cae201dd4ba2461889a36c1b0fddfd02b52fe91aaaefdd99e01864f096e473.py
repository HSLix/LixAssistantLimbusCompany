"""Run 开始时确认游戏已离开标题界面，供 plan 最先调用。"""
from lalc import RunContext, task_workflow

TITLE_ASSET = "restart/clear_all_caches"
# 首次就绪检查可能遇到刚置前的黑帧；Step 未确认点击时允许再检查一次，第二次仍不足则交回主流程
MAX_ATTEMPTS = 2


def _title_hits(ctx: RunContext) -> list[dict]:
    """在当前帧匹配标题界面的 Clear all caches 特征，返回全部命中。"""
    return list(ctx.action("observe.match_asset", asset=TITLE_ASSET) or [])


@task_workflow
def execute(ctx: RunContext) -> dict[str, str]:
    """有界调用就绪检查 Step，每次自行重新截图判断标题特征是否仍在或已进入正常过渡。"""
    for attempt in range(1, MAX_ATTEMPTS + 1):
        info = ctx.call("step.check_game_ready")
        state = str(info.get("state") or "") if isinstance(info, dict) else ""
        meta = ctx.action("observe.capture_screen")
        if _title_hits(ctx):
            if state == "clicked":
                ctx.log("点击后标题特征仍在，游戏尚未离开标题界面", level="warning")
                return {"completed": "false", "reason": "title_still_visible"}
            if state == "download_popup":
                ctx.log("下载询问弹窗仍盖在标题界面上，本 Task 不点击，交回主流程", level="warning")
                return {"completed": "false", "reason": "download_popup"}
            if attempt < MAX_ATTEMPTS:
                ctx.log(
                    f"第 {attempt} 次就绪检查 Step 未确认点击（state={state or 'unknown'}），"
                    "新帧仍命中 Clear all caches，重新检查一次",
                    level="warning",
                )
                continue
            ctx.log("标题特征仍在，但就绪检查 Step 未确认点击，交回主流程", level="warning")
            return {"completed": "false", "reason": "title_still_visible"}
        # 离开标题界面后会进入加载过渡（Connecting／Combat Tips／Now Loading），
        # 交给通用过渡检测统一判定，本 Task 不再维护第二份 Connecting 区域与关键词
        if ctx.call("step.detect_normal_transition", width=meta["width"], height=meta["height"]):
            ctx.log("识别到正常过渡标识，已离开标题界面")
            return {"completed": "true", "reason": "transition"}
        ctx.log("未检测到标题特征，也没有进入正常过渡，按已离开标题界面处理")
        return {"completed": "true", "reason": "title_gone"}
    return {"completed": "false", "reason": "title_still_visible"}
