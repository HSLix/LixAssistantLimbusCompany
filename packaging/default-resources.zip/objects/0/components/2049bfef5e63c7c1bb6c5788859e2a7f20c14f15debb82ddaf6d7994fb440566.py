"""镜牢进入确认阶段：点击确认 Enter／Resume，固定等待 1 秒后交回，不设置退出信号。"""
from lalc import RunContext, step

CONFIRM_TEXT = "will you enter"
PROGRESS_TEXT = "dungeon progress"

# 客户区固定 1280x720：中央弹窗区域
POPUP_REGION = {"x": 420, "y": 175, "width": 440, "height": 365}
# 弹窗动画稳定后重新取一次文本，再据此选择按钮，避开上一帧的位置
STABLE_WAIT_SECONDS = 0.6
# 点击确认后的固定等待：进入镜牢后的落点页面太多，且与 task.mirror 的分派分支重合，
# 本步不再轮询退出信号，等 1 秒就把画面交回主循环完整分派
AFTER_CLICK_SECONDS = 1.0


def _popup_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回中央弹窗区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=POPUP_REGION) or {}
    return list(result.get("items") or [])


def _popup_kind(ctx: RunContext) -> str:
    """判断中央弹窗类型：progress（进度弹窗）、confirm（进入确认）或 none。"""
    text = " ".join(str(item.get("text", "")) for item in _popup_items(ctx)).lower()
    if PROGRESS_TEXT in text:
        return "progress"
    if CONFIRM_TEXT in text:
        return "confirm"
    return "none"


def _click_popup_button(
    ctx: RunContext, items: list[dict], label: str, fallback: tuple[int, int]
) -> None:
    """在弹窗内点击文字完全匹配且最接近 fallback 的按钮，否则退回固定坐标。"""
    candidates = [
        item for item in items if str(item.get("text", "")).strip().lower() == label
    ]
    if not candidates:
        ctx.log(f"弹窗未识别到 {label} 文本，点击回退坐标 {fallback}", level="warning")
        ctx.action("control.click", x=fallback[0], y=fallback[1])
        return

    def distance(item: dict) -> float:
        """候选按钮中心到回退坐标的距离。"""
        center = item.get("centerxy") or fallback
        return ((center[0] - fallback[0]) ** 2 + (center[1] - fallback[1]) ** 2) ** 0.5

    target = min(candidates, key=distance)
    ctx.log(f"弹窗点击 {label} @ {target.get('centerxy')}")
    ctx.action("control.click", centerxy=tuple(target.get("centerxy")))


@step
def execute(ctx: RunContext, *, confirm_x: int = 779, confirm_y: int = 485, resume_x: int = 639, resume_y: int = 398) -> None:
    """点击确认 Enter／Resume 一次，等固定 1 秒后交回，不设置退出信号。

    进入镜牢后的落点页面（队伍、主题包、寻路、事件叙述等）种类太多，与 task.mirror 的分派分支完全重合，
    所以本步只看当前帧的弹窗文案就点一次按钮，不再轮询落地页：
    落点由上层主循环重新观察后完整分派。
    弹窗不在、或动画稳定后的同一帧没有独特文案时零输入返回。
    """
    popup = _popup_kind(ctx)
    if popup == "none":
        ctx.log("中央没有开始确认或继续探索弹窗，不点击", level="warning")
        return
    # 动画稳定后重新取帧，同一帧仍须含弹窗独特文案，不能仅凭按钮位置输入
    ctx.action("observe.wait", seconds=STABLE_WAIT_SECONDS)
    items = _popup_items(ctx)
    text = " ".join(str(item.get("text", "")) for item in items).lower()
    if popup == "progress" and PROGRESS_TEXT in text:
        label, fallback = "resume", (resume_x, resume_y)
    elif popup == "confirm" and CONFIRM_TEXT in text:
        label, fallback = "enter", (confirm_x, confirm_y)
    else:
        ctx.log("弹窗文案已变化，本轮不点击，交回上层重新观察", level="warning", screenshot=True)
        return
    _click_popup_button(ctx, items, label, fallback)
    # 点完只等固定 1 秒就交回，不再检查落在哪个页面
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
