"""在 Thread 的 Level Select 弹窗中选择最高难度，并进入到队伍准备页面。"""
import re

from lalc import ExecutionFailure, RunContext, step

POPUP_ASSET = "luxcavation/thread_level_select"
PREPARE_ASSETS = ["prepare_team/all_identities", "prepare_team/all_ego", "prepare_team/facades"]
LIST_REGION = {"x": 350, "y": 160, "width": 580, "height": 380}
DRAG_FROM = (700, 470)
DRAG_TO = (700, 250)
# 拖动后固定等惯性停稳再识别，避免 OCR 读到滑动中的画面
DRAG_SETTLE_SECONDS = 0.8
# 点击 Enter 后固定等一秒让画面响应；是否已进入准备页由上层重新截图判断
ENTER_WAIT_SECONDS = 1.0
# OCR 常把数字 0 识别成字母 O 或圆圈符号，先放宽字符集再归一化
LEVEL_PATTERN = re.compile(r"Lv\s*([0-9Oo○〇]{1,3})", re.IGNORECASE)
ZERO_LOOKALIKES = str.maketrans({"O": "0", "o": "0", "○": "0", "〇": "0"})


def _normalize_level_text(digits: str) -> int | None:
    """把等级文本中的 O/o/○/〇 归一为 0；仍不是纯数字时返回 None。"""
    normalized = digits.translate(ZERO_LOOKALIKES)
    return int(normalized) if normalized.isdigit() else None


def _level_rows(items: list[dict]) -> list[tuple[int, int]]:
    """从 OCR 结果中提取 (难度等级, 行中心 y)；忽略没有等级数字的条目。"""
    rows: list[tuple[int, int]] = []
    for item in items:
        matched = LEVEL_PATTERN.search(str(item.get("text", "")))
        center = item.get("centerxy") or (0, 0)
        if not matched or not center:
            continue
        level = _normalize_level_text(matched.group(1))
        if level is None:
            continue
        rows.append((level, int(center[1])))
    return rows


def _enter_button(items: list[dict], row_y: int) -> list[int] | None:
    """在同一行内寻找 Enter 按钮的文字条目，返回其中心坐标。"""
    best: tuple[int, list[int]] | None = None
    for item in items:
        text = str(item.get("text", "")).strip().lower()
        center = item.get("centerxy") or None
        if text != "enter" or not center:
            continue
        distance = abs(int(center[1]) - row_y)
        if distance <= 12 and (best is None or distance < best[0]):
            best = (distance, [int(center[0]), int(center[1])])
    return best[1] if best else None


@step
def execute(ctx: RunContext) -> None:
    """已在准备页时零输入返回；否则在 Level Select 弹窗里拖动一次列表，点当前可见最高等级的 Enter。"""
    ctx.action("observe.capture_screen")
    if any(ctx.action("observe.match_asset", asset=asset) for asset in PREPARE_ASSETS):
        ctx.log("已在队伍准备页面，无需选择难度")
        return
    if not ctx.action("observe.match_asset", asset=POPUP_ASSET):
        ctx.log("未检测到 Thread 的 Level Select 弹窗，本 Step 不操作，交回上层", level="warning")
        return

    ctx.log(f"向上拖动等级列表一次：{DRAG_FROM} → {DRAG_TO}")
    ctx.action(
        "control.drag",
        x=DRAG_FROM[0],
        y=DRAG_FROM[1],
        end_x=DRAG_TO[0],
        end_y=DRAG_TO[1],
    )
    ctx.action("observe.wait", seconds=DRAG_SETTLE_SECONDS)
    ctx.action("observe.capture_screen")

    items = (ctx.action("observe.ocr", region=LIST_REGION) or {}).get("items", [])
    rows = _level_rows(items)
    if not rows:
        ctx.log("拖动后未识别到难度等级，交回上层", level="warning", screenshot=True)
        return

    level, row_y = max(rows)
    target = _enter_button(items, row_y)
    if target is None:
        ctx.log(
            f"未找到等级 Lv{level} 的 Enter 按钮，识别结果：{rows}",
            level="warning",
            screenshot=True,
        )
        return
    if len([1 for _, other_y in rows if abs(other_y - row_y) <= 12]) > 1:
        ctx.log(f"等级 Lv{level} 存在多个同行条目，按最接近行中心选择", level="warning")

    ctx.log(f"选择当前可见最高难度 Lv{level}，点击 Enter：{target}")
    ctx.action("control.click", x=target[0], y=target[1])
    ctx.action("observe.wait", seconds=ENTER_WAIT_SECONDS)
