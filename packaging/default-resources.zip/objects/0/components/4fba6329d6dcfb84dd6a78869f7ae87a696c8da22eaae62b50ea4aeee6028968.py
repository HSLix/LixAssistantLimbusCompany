"""镜牢寻路页面：把火车头（当前所在位置）拖到目标位置 (140, 330)，横纵误差各 ±40px。"""
import math

from lalc import ExecutionFailure, RunContext, step

TRAIN_ASSET = "mirror/train_head"
# 只用特征匹配（SIFT），缩放、暗角下更稳；模板匹配回退已移除，失配即视为找不到火车头
# 【开发者要求】越近拖得越慢：残差几何距离 ≥600px 用 200px/s，≤300px 用 100px/s，中间用 150px/s。
# 时长 = 本次实际位移 / 对应档位速度，没有上限，只保留 0.1 秒极小值保护
SPEED_FAR_DISTANCE = 600.0
SPEED_NEAR_DISTANCE = 300.0
DRAG_SPEED_FAR = 200.0
DRAG_SPEED_MID = 150.0
DRAG_SPEED_NEAR = 100.0
MIN_DRAG_SECONDS = 0.1
# 每次拖拽或找回平移后的固定等待秒数，等平移缓动收尾（拖后观测要等镜头停稳）
AFTER_DRAG_SECONDS = 0.8
# 【实测校准】快拖的位移兑现率与拖拽速度强相关（多次试运行实测）：
#   260px/s（1.17/1.30 秒）兑现 0.89~0.95 → 从 (468,255) 落在 (171,325)/(157,333)；
#   170px/s（1.99 秒）兑现 1.23~1.41 → 冲过头落在 (41,363)/(181,298)（Run 591 三次复位耗尽失败）；
#   235px/s（1.40 秒）长拖兑现 0.91 → 落在 (161,330)（Run 592）；短拖（0.9 秒下限）兑现 1.3~1.4。
# 所以速度取 235px/s，并把容差放宽到 ±40（开发者要求）：0.91 兑现的 (161,330) 直接算到位，不再补拖。
# SLOP 仍为 10：收手后再多推 10px，抵消快拖略不足的那一小截
SLOP = 10
# 【开发者要求】收手系数统一 0.9：不论残差多远，都只走残差的 90%，不再按几何距离分档
EARLY_SCALE = 0.9
# 指针终点离开客户区边缘的最小距离，避免手势尾巴跑到窗口外（只夹指针，不再是位移上限）
EDGE_MARGIN = 40
SCREEN_W = 1280
SCREEN_H = 720
# 火车头被拖到画面外时，从地图中部固定点向右平移，把它带回画面重新定位
PAN_X = 500
PAN_Y = 400
PAN_DISTANCE = 260
# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上就算寻路界面；
# 用于区分“火车头被拖出画面”和“根本不在寻路页”；左上角 Exploring 文字会闪烁，已废弃
PATH_ICON_ASSETS = ("mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects")
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2


def _drag_speed(distance: float) -> float:
    """按残差几何距离选拖拽速度：≥600px 用 200px/s，≤300px 用 100px/s，中间 150px/s。"""
    if distance >= SPEED_FAR_DISTANCE:
        return DRAG_SPEED_FAR
    if distance <= SPEED_NEAR_DISTANCE:
        return DRAG_SPEED_NEAR
    return DRAG_SPEED_MID


def _drag_seconds(displacement: int, speed: float) -> float:
    """时长 = 本次实际位移 / 该档位速度，没有上限，只保留 0.1 秒极小值保护。"""
    return max(MIN_DRAG_SECONDS, float(displacement) / speed)


def _path_page(ctx: RunContext) -> bool:
    """对当前帧右上角匹配三个按钮素材，命中两个及以上才算寻路界面；不刷新截图。"""
    hits = sum(
        1
        for asset in PATH_ICON_ASSETS
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )
    return hits >= MIN_PATH_ICONS


@step
def execute(
    ctx: RunContext,
    *,
    target_x: int = 140,
    target_y: int = 330,
    tolerance: int = 40,
    pan: int = 1,
) -> None:
    """
    把火车头向目标位置 (140, 330)（横纵各 ±40px）拖一次：
    - 已在容差内时零输入返回，不重放动作；
    - 未命中火车头且右上角没有寻路界面按钮标识时，说明不在寻路页，零输入返回；
    - 未命中火车头但仍在寻路页时，判定被拖出画面，从地图中部向右平移一次找回后交回；
    - 否则从火车头中心拖拽一次（残差统一按 0.9 收手；速度按残差距离分档：≥600px 用 200px/s、
      ≤300px 用 100px/s、中间 150px/s，时长按实际位移换算、没有上限），等固定 AFTER_DRAG_SECONDS 后交回。
    pan 只影响“火车头不在画面里”时的平移找回方向：+1 向右平移（找回被拖到左侧画面外的火车头）、
    -1 向左平移；上层 sub_workflow.mirror_pathfind 会两个方向各试一次。
    是否已到位由 sub_workflow.mirror_pathfind 下一轮重新观察，本步不循环、不重试。
    容差放宽到 ±40：快拖的位移兑现率在 0.91~1.4 之间摆动，±20 时每次都要补拖一次，
    ±40 能容下 0.91 兑现的偏差，把常见的“一拖一补”变成单次拖拽完成。
    """
    if tolerance < 0:
        raise ValueError("容差不能为负数")
    if pan not in (-1, 1):
        raise ValueError("pan 只能是 +1（向右平移找回）或 -1（向左平移找回）")

    ctx.action("observe.capture_screen")
    matches = ctx.action("observe.match_feature", asset=TRAIN_ASSET) or []
    if not matches:
        if not _path_page(ctx):
            ctx.log(
                "未匹配到火车头，右上角也没有寻路界面按钮标识，当前不是镜牢寻路页面",
                level="warning",
                screenshot=True,
            )
            return
        ctx.log(
            f"未匹配到火车头，判定为被拖出画面，从 ({PAN_X}, {PAN_Y})"
            f"向{'右' if pan > 0 else '左'}平移 {PAN_DISTANCE}px 找回",
            level="warning",
            screenshot=True,
        )
        ctx.action(
            "control.drag",
            x=PAN_X,
            y=PAN_Y,
            end_x=PAN_X + pan * PAN_DISTANCE,
            end_y=PAN_Y,
            seconds=_drag_seconds(PAN_DISTANCE, _drag_speed(PAN_DISTANCE)),
        )
        ctx.action("observe.wait", seconds=AFTER_DRAG_SECONDS)
        return

    if len(matches) > 1:
        centers = [match.get("centerxy") for match in matches]
        ctx.log(
            f"火车头同时命中{len(matches)}处：{centers}，按最高分命中处理",
            level="warning",
            screenshot=True,
        )
    best = max(matches, key=lambda item: float(item.get("score", 0.0)))
    score = float(best.get("score", 0.0))
    center = best.get("centerxy") or (0, 0)
    center_x = int(center[0])
    center_y = int(center[1])
    on_target = abs(center_x - target_x) <= tolerance and abs(center_y - target_y) <= tolerance
    ctx.log(
        f"火车头中心 ({center_x}, {center_y})，特征匹配识别（内点 {int(score)}），"
        f"目标 ({target_x}, {target_y})，容差 ±{tolerance}，是否到位：{on_target}"
    )
    if on_target:
        ctx.log("火车头已在目标位置附近，无需拖拽")
        return

    residual_x = target_x - center_x
    residual_y = target_y - center_y
    # 【开发者要求】越近拖得越慢：按几何距离选速度档位
    distance = math.hypot(residual_x, residual_y)
    early_scale = EARLY_SCALE
    speed = _drag_speed(distance)
    residual_x = int(residual_x * early_scale)
    residual_y = int(residual_y * early_scale)
    end_x = center_x + residual_x + (SLOP if residual_x >= 0 else -SLOP)
    end_y = center_y + residual_y + (SLOP if residual_y >= 0 else -SLOP)
    end_x = min(max(end_x, EDGE_MARGIN), SCREEN_W - EDGE_MARGIN)
    end_y = min(max(end_y, EDGE_MARGIN), SCREEN_H - EDGE_MARGIN)
    # 提前结束：按本次实际要走的像素量算时长，不再固定 4 秒（Run 588 是每次固定 4 秒 + 1 秒等待）
    drag_seconds = _drag_seconds(max(abs(residual_x), abs(residual_y)), speed)
    ctx.log(
        f"拖拽一次：({center_x}, {center_y}) → ({end_x}, {end_y})，残差 ({residual_x}, {residual_y})，"
        f"几何距离 {distance:.0f}px → 收手系数 {early_scale:.2f}、速度 {speed:.0f}px/s，"
        f"时长 {drag_seconds:.2f} 秒"
    )
    ctx.action(
        "control.drag",
        x=center_x,
        y=center_y,
        end_x=end_x,
        end_y=end_y,
        seconds=drag_seconds,
    )
    ctx.action("observe.wait", seconds=AFTER_DRAG_SECONDS)
