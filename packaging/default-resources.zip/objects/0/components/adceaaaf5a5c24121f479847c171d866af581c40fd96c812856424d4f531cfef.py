"""镜牢饰品选择页：按配置顺序点击右侧三个饰品，用 Select 右侧计数确认每次点击生效，不离开本页。"""
import re

from lalc import ExecutionFailure, RunContext, step

GIFT_ASSET = "mirror/gift_select"
# 右侧三个饰品行（上→下）的可点击中心，对应设置页里的第 1/2/3 个方框
SLOT_POINTS = ((1000, 265), (1000, 365), (1000, 465))
# 底部按钮区域：Refuse Gift、Select 与 Select 右侧的 已选/上限 计数
BOTTOM_REGION = {"x": 760, "y": 550, "width": 480, "height": 80}
MAX_SLOTS = 3
# 每次点击饰品后的固定等待（属于同一组固定动作，点完不复查计数）
CLICK_WAIT_SECONDS = 0.6
COUNTER_PATTERN = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s*$")


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或连写影响按钮文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _slot_number(value) -> int:
    """把配置里的序号转成整数，非法值返回 0。"""
    text = str(value).strip()
    return int(text) if text.isdigit() else 0


def _sanitize(slots: list[int] | None) -> list[int]:
    """只保留 1~3 的合法序号并去重，保持配置里的点击顺序。"""
    order: list[int] = []
    for value in slots or []:
        slot = _slot_number(value)
        if 1 <= slot <= MAX_SLOTS and slot not in order:
            order.append(slot)
    return order[:MAX_SLOTS]


def _bottom_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回底部按钮区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=BOTTOM_REGION) or {}
    return list(result.get("items") or [])


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _gift_page(ctx: RunContext) -> bool:
    """判断是否还在饰品选择页：优先用 Selected E.G.O Gift 模板，其次用 Refuse Gift 文字。"""
    if ctx.action("observe.match_asset", asset=GIFT_ASSET):
        return True
    return "refusegift" in _items_text(_bottom_items(ctx))


def _counter(items: list[dict]) -> tuple[int, int] | None:
    """解析 Select 右侧的 已选/上限 计数，读不到时返回 None。"""
    for item in items:
        match = COUNTER_PATTERN.match(str(item.get("text") or ""))
        if match:
            return int(match.group(1)), int(match.group(2))
    return None


@step
def execute(ctx: RunContext, *, slots: list[int] | None = None) -> None:
    """
    在镜牢饰品选择页按配置顺序点击右侧饰品：1=上、2=中、3=下。
    先截图复查入口：未配置点击顺序、或不在饰品选择页时零输入返回。
    Select 右侧的 已选/上限 计数决定本次最多点几个；已经选中的前几个跳过，剩下的按配置顺序各点一次，
    这是一组固定动作（最多 3 个），点完不复查计数、不补点。
    本步不点 Select/Refuse Gift、不离开页面；每次点击是否生效由 sub_workflow.mirror_gift_select
    下一轮重新读计数判断。
    """
    order = _sanitize(slots)
    if not order:
        ctx.log("未配置右侧饰品点击顺序，本步不点击任何饰品")
        return

    ctx.action("observe.capture_screen")
    if not _gift_page(ctx):
        ctx.log("当前不在镜牢饰品选择页面，不点击右侧饰品", level="warning", screenshot=True)
        return

    counter = _counter(_bottom_items(ctx))
    if counter:
        allowed = counter[1]
        done = min(counter[0], allowed)
        ctx.log(f"饰品可拿上限 {allowed}，当前已选 {counter[0]}/{allowed}")
    else:
        allowed = len(order)
        done = 0
        ctx.log(
            "未识别到 Select 右侧的 已选/上限 计数，按配置顺序直接点击",
            level="warning",
            screenshot=True,
        )

    plan = order[:allowed]
    if not plan:
        ctx.log("饰品可拿数量上限为 0，本步不点击任何饰品", level="warning")
        return
    if done:
        ctx.log(
            f"已有 {done} 个饰品处于选中状态，跳过配置顺序里的前 {done} 个：{plan[:done]}",
            level="warning",
        )

    for index in range(done, len(plan)):
        slot = plan[index]
        point = SLOT_POINTS[slot - 1]
        ctx.log(f"点击右侧第 {slot} 个饰品 {point}（配置顺序第 {index + 1} 次）")
        ctx.action("control.click", x=point[0], y=point[1])
        ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
    ctx.log(
        f"右侧饰品点击完成，本次点击顺序：{','.join(str(slot) for slot in plan[done:])}；"
        "是否已选满由上层重新读计数判断"
    )
