"""标定用：用鼠标滚轮逐批滚动左侧队伍列表，并记录每批滚动后的可见队伍行。"""
import re

from lalc import RunContext, step

PREPARE_ASSETS = (
    "prepare_team/all_identities",
    "prepare_team/all_ego",
    "prepare_team/facades",
)
# 左侧列表名字区（不含上方 TEAMS 标题与下方按钮区）
LIST_REGION = {"x": 80, "y": 292, "width": 116, "height": 252}
# 滚轮落点取列表中部，避开标题与底部按钮区
LIST_X = 130
LIST_Y = 420
# control.scroll 单次最多 10 格，格间隔固定 0.2 秒
MAX_STEPS = 10
MAX_BATCHES = 10


def _norm(text) -> str:
    """去掉空白和符号并转小写，便于记录队伍行名字。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _rows(ctx: RunContext) -> list[tuple[str, int]]:
    """重新截图后返回列表区域内识别到的队伍行 (规范化名字, 行中心 y)，按 y 升序。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=LIST_REGION) or {}
    items: list[tuple[str, int]] = []
    for item in result.get("items") or []:
        center = item.get("centerxy") or None
        name = _norm(item.get("text"))
        if not name or not center:
            continue
        items.append((name, int(center[1])))
    items.sort(key=lambda row: row[1])

    rows: list[tuple[str, int]] = []
    for name, y in items:
        if rows and y - rows[-1][1] < 18:
            rows[-1] = (rows[-1][0] + name, rows[-1][1])
            continue
        rows.append((name, y))
    return rows


@step
def execute(
    ctx: RunContext,
    *,
    steps: int = 5,
    batch_count: int = 5,
    reset_steps: int = 10,
    reset_batches: int = 6,
    settle: float = 1.0,
) -> dict[str, str]:
    """
    标定实验：先用滚轮把左侧队伍列表滚回顶部，再以固定 steps 格连续向下滚 batch_count 批，
    每批滚动后停 settle 秒再截图识别可见队伍行并记录，用来换算「滚几格前进几个队伍」。
    本步只滚列表，不点击队伍、不进入战斗，也不使用拖动（拖动会被游戏当成拖拽换位）。
    """
    if not 1 <= steps <= MAX_STEPS:
        raise ValueError(f"steps 必须在 1~{MAX_STEPS} 之间")
    if not 1 <= reset_steps <= MAX_STEPS:
        raise ValueError(f"reset_steps 必须在 1~{MAX_STEPS} 之间")
    if not 1 <= batch_count <= MAX_BATCHES:
        raise ValueError(f"batch_count 必须在 1~{MAX_BATCHES} 之间")
    if not 1 <= reset_batches <= MAX_BATCHES:
        raise ValueError(f"reset_batches 必须在 1~{MAX_BATCHES} 之间")
    if not 0.2 <= settle <= 5.0:
        raise ValueError("settle 必须在 0.2~5.0 之间")

    ctx.action("observe.capture_screen")
    if not any(ctx.action("observe.match_asset", asset=asset) for asset in PREPARE_ASSETS):
        return {"completed": "false", "reason": "not_team_list_page"}

    for _ in range(reset_batches):
        ctx.action("control.scroll", direction="up", steps=reset_steps, x=LIST_X, y=LIST_Y)
        ctx.action("observe.wait", seconds=0.4)
    ctx.action("observe.wait", seconds=settle)
    ctx.log(f"标定起点（已用滚轮向上滚回顶部）：{_rows(ctx)}")

    for index in range(batch_count):
        ctx.action("control.scroll", direction="down", steps=steps, x=LIST_X, y=LIST_Y)
        ctx.action("observe.wait", seconds=settle)
        ctx.log(f"第{index + 1}批向下滚 {steps} 格后（停 {settle}s）：{_rows(ctx)}")

    ctx.log(f"标定结束：每批 {steps} 格，共 {batch_count} 批，停 {settle}s")
    return {"steps": str(steps), "batches": str(batch_count), "completed": "true", "reason": "局部目标已确认"}
