"""队伍列表：用一次拖拽把左侧 TEAMS 列表向顶部方向带回，不点击任何队伍行。

原实现用鼠标滚轮向上滚回顶部；滚轮在突发弹窗（如 Could Not Load Notice）出现后会失效，
所以改成拖拽手势。拖拽让列表内容跟着指针走：指针从上往下带 250px，内容随之下移，
露出更靠前的队伍，等价于原来的滚轮向上。
本 Step 只做一次拖拽，不等待、不判断是否已经到顶、不点击队伍；
每次拖拽后的「等 1 秒 → 截图 → 全屏 OCR → 通用检测」与是否继续由 sub_workflow.team_list_drag_top 负责。
镜牢局内战斗准备页左侧只有一张 Preset 卡、没有 TEAMS 列表，入口判定不通过时零输入返回。
"""
import re

from lalc import RunContext, step

# 三种页面都有的右侧页签：只作第一层筛选用，单独它不能证明左侧有可选队伍列表
TEAM_LIST_ASSETS = (
    "prepare_team/all_identities",
    "prepare_team/all_ego",
    "prepare_team/facades",
)
# 镜牢入口队伍页独有标识（右下角 Starlight Bonus）：只用于页面判定兜底，不影响拖拽
MIRROR_TEAM_ASSET = "mirror/team_select"
# 左侧队伍列表的实测区域（1280x720）：列表标题 TEAMS 固定在列表上方，行文字是 TEAMS #n；
# 镜牢局内战斗准备页的同一区域只有一张 Preset 卡，读不到 TEAMS
TEAM_LIST_REGION = {"x": 55, "y": 265, "width": 150, "height": 320}
TEAM_LIST_KEYWORD = "teams"
# 拖拽落点取列表中部，与原来的滚轮落点一致
DRAG_X = 130
DRAG_FROM_Y = 320
# 【开发者要求】每次拖拽位移约 250px、速度约 250px/s；最多几次由上层 sub_workflow.team_list_drag_top 控制
DRAG_DISTANCE = 250
DRAG_SPEED = 250.0
DRAG_SECONDS = DRAG_DISTANCE / DRAG_SPEED


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _on_team_list_page(ctx: RunContext) -> tuple[bool, str]:
    """
    当前页面左侧是否有可选队伍列表：Luxcavation 战斗准备页与镜牢入口队伍页都算。
    先按右侧页签／Starlight Bonus 确认是带队伍选择的页面，再用左侧列表区域里的 TEAMS 文字
    确认列表真的存在；镜牢局内战斗准备页没有 TEAMS 列表，不入本 Step。
    """
    page_hit = any(ctx.action("observe.match_asset", asset=asset) for asset in TEAM_LIST_ASSETS)
    if not page_hit and not ctx.action("observe.match_asset", asset=MIRROR_TEAM_ASSET):
        return False, ""
    result = ctx.action("observe.ocr", region=TEAM_LIST_REGION) or {}
    items = result.get("items") or []
    text = _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))
    return TEAM_LIST_KEYWORD in text, text


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    在左侧队伍列表上做一次从上往下的拖拽（250px、250px/s），把列表内容往顶部方向带回。
    入口不在队伍列表页时零输入返回；拖完立即交回，拖后的「等 1 秒 → 截图 → 全屏 OCR → 通用检测」
    以及是否继续由上层 sub_workflow.team_list_drag_top 统一处理。
    """
    ctx.action("observe.capture_screen")
    on_list, list_text = _on_team_list_page(ctx)
    if not on_list:
        ctx.log(
            f"当前页面左侧没有可选队伍列表（列表区域文字 {list_text!r}），本 Step 不拖拽，交回上层",
            level="warning",
            screenshot=True,
        )
        return {"completed": "false", "reason": "no_team_list"}

    end_y = DRAG_FROM_Y + DRAG_DISTANCE
    ctx.action(
        "control.drag",
        x=DRAG_X,
        y=DRAG_FROM_Y,
        end_x=DRAG_X,
        end_y=end_y,
        seconds=DRAG_SECONDS,
    )
    ctx.log(
        f"队伍列表拖拽一次：({DRAG_X}, {DRAG_FROM_Y}) → ({DRAG_X}, {end_y})，"
        f"位移 {DRAG_DISTANCE}px、速度 {DRAG_SPEED:.0f}px/s、时长 {DRAG_SECONDS:.2f} 秒"
    )
    return {
        "completed": "true",
        "reason": "dragged",
        "from_y": str(DRAG_FROM_Y),
        "to_y": str(end_y),
    }
