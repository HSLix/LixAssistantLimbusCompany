import re

from lalc import RunContext, step, ExecutionFailure


def _hit(ctx: RunContext, assets: list[str]) -> list[str]:
    """按同一截图统计命中素材，返回命中名称。"""
    return [asset for asset in assets if ctx.action("observe.match_asset", asset=asset)]


# 战斗结束信号：镜牢战斗后可能直接进入 Select Encounter Reward Card 奖励卡片页，
# 此时没有战果页素材可用，用标题条的独有文案（与 step.mirror_reward_card_probe 保持一致）
REWARD_CARD_TITLE_REGION = {"x": 270, "y": 100, "width": 540, "height": 70}
REWARD_CARD_TITLE_KEYWORD = "encounterrewardcard"
# 事件进入信号：战斗结束后可能直接进入事件节点（选项页／结果页标题模板，或叙述页右下角的 SKIP 按钮）。
# 素材名由 plan 统一定义、作为参数传入（event_assets／event_skip_assets），本步只保留按钮区域；
# 叙述页用普通与灰化 SKIP 两种模板匹配，与 sub_workflow.event 一致。
# 灰化 SKIP 模板是整颗按钮的裁剪（240x95），宽度与原来的按钮区域相同；区域没有横向余量时模板只有
# 唯一位置可放，按钮偏移几个像素就匹配不到（Run 540 第 40~43 轮的事件叙述页即为此），
# 因此用带余量的右下角区域，让普通／灰化两个模板都能按实际位置滑动
EVENT_SKIP_REGION = {"x": 980, "y": 560, "width": 300, "height": 160}
# 楼层通关后的 Acquire E.G.O Gift 选择页（floor E.G.O gift select）：战斗结束后可能直接落到该页，
# 每张饰品卡各有一个手形图标，漏识别时用三张卡上方的标题文字兜底
# （与 step.mirror_floor_gift_select 的识别保持一致）
FLOOR_GIFT_ASSET = "mirror/acquire_ego_gift_hand"
FLOOR_GIFT_TITLE_REGION = {"x": 350, "y": 140, "width": 700, "height": 50}
FLOOR_GIFT_TITLE_KEYWORD = "acquireegogift"
# 队伍全灭后的战斗失败弹窗（左侧 Floor in Progress 进度卡 + 右侧三个 Stage 选项 + 下方 Confirm）：
# 该弹窗会一直停在画面上等玩家选择，没有任何战果素材、停战标识或加载标识可命中，只靠轮询会一路空转到预算耗尽。
# 识别特征与选项处理与 step.mirror_battle_defeat 保持一致：只选最下方的 Accept results（放弃本场战斗），
# 不点 Return to Stage Select 与 Retry Stage；点击后交回上层，由上层用新画面验收失败结算页
DEFEAT_PROMPT_REGION = {"x": 320, "y": 205, "width": 690, "height": 365}
DEFEAT_FLOOR_LABEL = "floorinprogress"
DEFEAT_ACCEPT_LABEL = "acceptresults"
DEFEAT_RETRY_LABEL = "retrystage"
DEFEAT_CONFIRM_LABEL = "confirm"
# 未识别到文本时的回退坐标（1280x720 客户区，与 step.mirror_battle_defeat 一致），使用时按实际客户区缩放
DEFEAT_ACCEPT_FALLBACK = (790, 441)
DEFEAT_CONFIRM_FALLBACK = (664, 527)
# 点选选项后游戏会播放选中动画，点 Confirm 前先等它生效
DEFEAT_SELECT_SETTLE_SECONDS = 1.0
# 同一入口最多点几轮 Accept results + Confirm；点击后仍停留在弹窗就判定需要人工确认，不在弹窗上无限重放点击
MAX_DEFEAT_PROMPT_CLICKS = 3
# 上层通用等待的标识：Connecting／Combat Tips／Now Loading。战斗结束后可能直接进入较长的
# 正常加载，这类过渡不在本步里等待，识别到就立即返回，把加载等待交回上层统一处理。
# 这是全仓唯一保留的本地过渡判定：Step 不能用 ctx.call 调 step.detect_normal_transition
# （校验器报 component_call_forbidden），而本步 999 轮长循环必须能及时交回，
# 因此区域与关键词刻意与通用检测保持一致，改动时要同步 step.detect_normal_transition。
TRANSITION_SIGNALS = (
    ("connecting", (1000, 0, 250, 120), ("connecting",)),
    ("combat_tips", (780, 120, 500, 480), ("combat", "tips")),
    ("now_loading", (900, 600, 380, 120), ("nowloading",)),
)


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _reward_card_here(ctx: RunContext) -> bool:
    """对当前帧的奖励卡片页标题条做一次局部 OCR，是否已经进入 Select Encounter Reward Card 页面。"""
    result = ctx.action("observe.ocr", region=REWARD_CARD_TITLE_REGION) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return REWARD_CARD_TITLE_KEYWORD in _norm(joined)


def _event_here(ctx: RunContext, event_assets: list[str], event_skip_assets: list[str]) -> bool:
    """当前帧是否已进入事件页面：选项／结果页标题模板，或叙述页右下角的普通／灰化 SKIP 按钮模板。"""
    if any(ctx.action("observe.match_asset", asset=asset) for asset in event_assets):
        return True
    return any(
        ctx.action("observe.match_asset", asset=asset, region=EVENT_SKIP_REGION)
        for asset in event_skip_assets
    )


def _floor_gift_here(ctx: RunContext) -> bool:
    """当前帧是否已在楼层通关后的 Acquire E.G.O Gift 选择页：手形模板优先，标题文字兜底。"""
    if ctx.action("observe.match_asset", asset=FLOOR_GIFT_ASSET):
        return True
    result = ctx.action("observe.ocr", region=FLOOR_GIFT_TITLE_REGION) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return FLOOR_GIFT_TITLE_KEYWORD in _norm(joined)


def _scaled(meta: dict, region: dict[str, int]) -> dict[str, int]:
    """把 1280x720 基准坐标的观察区域按当前客户区缩放，避免换分辨率后区域错位。"""
    width, height = int(meta["width"]), int(meta["height"])
    return {
        "x": region["x"] * width // 1280,
        "y": region["y"] * height // 720,
        "width": max(1, region["width"] * width // 1280),
        "height": max(1, region["height"] * height // 720),
    }


def _scaled_point(meta: dict, point: tuple[int, int]) -> tuple[int, int]:
    """把 1280x720 基准坐标的点按当前客户区缩放。"""
    width, height = int(meta["width"]), int(meta["height"])
    return (point[0] * width // 1280, point[1] * height // 720)


def _defeat_prompt(ctx: RunContext, meta: dict) -> list[dict] | None:
    """
    对当前帧做一次战斗失败弹窗区域的局部 OCR；命中「Floor in Progress 与 Accept results／Retry Stage
    同时出现」时返回该区域条目，否则返回 None。不刷新截图，也不点任何按钮。
    """
    result = ctx.action("observe.ocr", region=_scaled(meta, DEFEAT_PROMPT_REGION)) or {}
    items = list(result.get("items") or [])
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    text = _norm(joined)
    if DEFEAT_FLOOR_LABEL in text and (DEFEAT_ACCEPT_LABEL in text or DEFEAT_RETRY_LABEL in text):
        return items
    return None


def _defeat_accept_center(ctx: RunContext, items: list[dict]) -> tuple[int, int] | None:
    """
    找出标题行含 Accept results 的选项中心。描述文字里没有 acceptresults，因此不会把说明文字当成选项；
    多命中时记 warning 并取最下方一处，不自动认定点击对象。
    """
    centers: list[tuple[int, int]] = []
    for item in items:
        if DEFEAT_ACCEPT_LABEL not in _norm(str(item.get("text", ""))):
            continue
        center = item.get("centerxy")
        if center:
            centers.append((int(center[0]), int(center[1])))
    if not centers:
        return None
    if len(centers) > 1:
        ctx.log(f"Accept results 选项命中 {len(centers)} 处，按最下方一处点击", level="warning")
    return max(centers, key=lambda point: point[1])


def _defeat_confirm_center(items: list[dict]) -> tuple[int, int] | None:
    """找出文字正好是 Confirm 的按钮中心，识别不到时返回 None。"""
    for item in items:
        if _norm(str(item.get("text", ""))) != DEFEAT_CONFIRM_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            return (int(center[0]), int(center[1]))
    return None


def _resolve_defeat_prompt(ctx: RunContext, meta: dict, items: list[dict]) -> None:
    """
    队伍全灭的战斗失败弹窗：按当前帧选最下方的 Accept results（放弃本场战斗），
    等选中动画生效后在新画面上点 Confirm。只做一组固定动作，是否已离开由上层用新画面验收。
    """
    target = _defeat_accept_center(ctx, items)
    if target is None:
        fallback = _scaled_point(meta, DEFEAT_ACCEPT_FALLBACK)
        ctx.log(
            f"未识别到 Accept results 文本，点击右侧最下面选项的回退坐标 {fallback}",
            level="warning",
            screenshot=True,
        )
        ctx.action("control.click", x=fallback[0], y=fallback[1])
    else:
        ctx.log(f"点击战斗失败弹窗右侧最下方的 Accept results 选项 @ {target}")
        ctx.action("control.click", centerxy=target)
    ctx.action("observe.wait", seconds=DEFEAT_SELECT_SETTLE_SECONDS)

    fresh_meta = ctx.action("observe.capture_screen")
    fresh_items = _defeat_prompt(ctx, fresh_meta)
    if fresh_items is None:
        ctx.log("选择 Accept results 后战斗失败弹窗已消失，交回上层验收新画面")
        return
    confirm = _defeat_confirm_center(fresh_items)
    if confirm is not None:
        ctx.log(f"点击战斗失败弹窗的 Confirm @ {confirm}")
        ctx.action("control.click", centerxy=confirm)
    else:
        fallback = _scaled_point(fresh_meta, DEFEAT_CONFIRM_FALLBACK)
        ctx.log(f"未识别到 Confirm 文本，点击回退坐标 {fallback}", level="warning", screenshot=True)
        ctx.action("control.click", x=fallback[0], y=fallback[1])


def _transition(ctx: RunContext, meta: dict) -> str:
    """按当前帧识别上层通用等待标识（Connecting／Combat Tips／Now Loading），命中返回标识名。"""
    width, height = int(meta["width"]), int(meta["height"])
    for name, (x, y, w, h), words in TRANSITION_SIGNALS:
        region = {
            "x": x * width // 1280,
            "y": y * height // 720,
            "width": max(1, w * width // 1280),
            "height": max(1, h * height // 720),
        }
        result = ctx.action("observe.ocr", region=region) or {}
        items = result.get("items") or []
        text = "".join(
            char for item in items for char in str(item.get("text", "")).lower() if char.isalnum()
        )
        if all(word in text for word in words):
            return name
    return ""


# 本步确实需要很长的轮次预算：战斗动画、技能与 EGO 播放期间画面可能长时间没有可用标识，
# 连续 60 轮未知画面是动画等待而不是业务轮询；总等待预算 999 轮覆盖长战斗的动画播放，
# 且不会被持续战斗信号重置。这两个上限按现场证据保留，不压缩为短轮询。
# 轮次之间只保留 0.1 秒最小间隔：每轮检测本身耗时已足够，原因见循环末尾。
# 连续未知画面的等待上限：连续 60 轮没有可用标识就判定等待失败
MAX_RETRIES = 60
# 总轮询预算不会被持续战斗信号重置；999 轮由开发者指定。
MAX_TOTAL_WAITS = 999


@step
def execute(
    ctx: RunContext,
    *,
    continue_battle_assets: list[str],
    battleing_signal_assets: list[str],
    result_assets: list[str],
    path_assets: list[str] | None = None,
    event_assets: list[str] | None = None,
    event_skip_assets: list[str] | None = None,
) -> dict[str, str]:
    """战斗页面中，负责等待战斗部分动画播放完毕，由于 EGO 播放期间可能会有相当长时间没有可用标识物，需要一定的冗余空循环以及及时退出的标识。

    result_assets 之外的退出标识：path_assets 传入镜牢寻路页特征（如 mirror/train_head），
    战斗结束后直接回到寻路页时也能正常返回，不把这类正常落点拖到轮询耗尽后抛异常。
    另外，Select Encounter Reward Card 奖励卡片页（标题条 OCR）也视为战斗结束信号：
    镜牢战斗后可能直接进入该页，没有任何战果素材或停战标识可命中。
    事件节点的进入信号（event 选项／结果页模板，或叙述页右下角的 SKIP 按钮模板，含灰化 SKIP）
    同样视为脱离战斗，遇到时直接返回，由上层 event 子流程接管。
    楼层通关后的 Acquire E.G.O Gift 选择页（手形图标模板，或卡片上方的标题文字）同样是脱离战斗的标识：
    战斗结束后可能直接落到该页，没有任何战果素材或停战标识可命中。
    队伍全灭后的战斗失败弹窗（Floor in Progress 与 Stage 选项同时出现）会一直停在画面上等玩家选择，
    同样没有任何战果素材或过渡标识可命中：按既有失败处理选最下方的 Accept results 放弃本场战斗并点 Confirm，
    然后交回上层用新画面验收失败结算页，不在这里等整条失败结算链结束。
    通用等待标识（Connecting／Combat Tips／Now Loading）优先级最高：战斗结束后可能直接进入
    较长的正常加载，识别到就立即返回，由上层 step.wait_normal_transition 统一等待，
    不把加载当成未知画面耗尽预算；本步是 Step，不能用 ctx.call 调通用检测，
    所以本地保留与 step.detect_normal_transition 一致的区域／关键词副本。
    连续 60 轮没有可用标识时抛失败，总轮询预算 999 轮不随持续战斗信号重置。
    退出时返回 {"reason", "detail"}：transition（通用加载）、result（战果页）、continue（可推进战斗页）、
    path（镜牢寻路页）、reward_card（奖励卡片页）、floor_gift（楼层饰品页）、event（事件进入信号）；
    子流程据此决定退出还是继续推进，不再由子流程自己复制这些判据。
    """
    wait_circle = 0
    continue_battle = False
    defeat_clicks = 0
    event_assets = event_assets or []
    event_skip_assets = event_skip_assets or []
    for _ in range(MAX_TOTAL_WAITS):
        meta = ctx.action("observe.capture_screen")
        wait_circle += 1

        if transition := _transition(ctx, meta):
            # 通用等待标识优先于战斗落点：加载等待交回上层，不在这里继续空轮询
            ctx.log(f"第{wait_circle}轮等待后出现通用等待标识：{transition}，战斗已结束并交回上层等待")
            return {"reason": "transition", "detail": transition}
        if len(battleing_signal := _hit(ctx, battleing_signal_assets)) > 1: # 这里面大于一是为了避免误识别 pause
            if not continue_battle:
                ctx.log(f"发现持续战斗信号：{battleing_signal}，等待战斗结束")
                continue_battle = True
            else:
                ctx.log(f"发现持续战斗信号：{battleing_signal}，继续等待战斗结束", level="debug")
            wait_circle = 0
        elif result := _hit(ctx, result_assets):
            ctx.log(f"第{wait_circle}轮战斗后出现脱离战斗标识：{result}")
            return {"reason": "result", "detail": ",".join(result)}
        elif continue_battle_signal := _hit(ctx, continue_battle_assets):
            ctx.log(f"发现继续战斗信号：{continue_battle_signal}，终止轮询等待，继续下一轮战斗")
            return {"reason": "continue", "detail": ",".join(continue_battle_signal)}
        elif path_signal := _hit(ctx, path_assets or []):
            # 镜牢战斗结束后可能不经过战果页直接回到寻路页，这里把它作为脱离战斗的标识
            ctx.log(f"第{wait_circle}轮等待后出现镜牢寻路标识：{path_signal}，战斗已结束并回到寻路页")
            return {"reason": "path", "detail": ",".join(path_signal)}
        elif (defeat_items := _defeat_prompt(ctx, meta)) is not None:
            # 队伍全灭后的战斗失败弹窗会一直停在画面上，不处理就会在未知画面里一路空转到预算耗尽
            if defeat_clicks >= MAX_DEFEAT_PROMPT_CLICKS:
                ctx.log(
                    f"连续点击战斗失败弹窗 {defeat_clicks} 次后仍停留在该弹窗，请人工确认游戏状态",
                    level="error",
                    screenshot=True,
                )
                raise ExecutionFailure("battle_defeat_prompt_stuck", "战斗失败弹窗点击后仍停留")
            defeat_clicks += 1
            ctx.log(
                f"第{wait_circle}轮识别到队伍全灭的战斗失败弹窗，选择最下方的 Accept results 放弃本场战斗"
                f"（第{defeat_clicks}次）"
            )
            _resolve_defeat_prompt(ctx, meta, defeat_items)
            wait_circle = 0
            continue_battle = False
            continue
        elif _reward_card_here(ctx):
            # 镜牢战斗结束后可能直接进入 Select Encounter Reward Card 奖励卡片页，作为脱离战斗的标识
            ctx.log(f"第{wait_circle}轮等待后出现 Select Encounter Reward Card 奖励卡片页，战斗已结束")
            return {"reason": "reward_card", "detail": "encounter reward card"}
        elif _floor_gift_here(ctx):
            # 战斗结束后可能直接进入楼层通关的 Acquire E.G.O Gift 选择页，作为脱离战斗的标识
            ctx.log(f"第{wait_circle}轮等待后出现楼层 E.G.O Gift 选择页，战斗已结束")
            return {"reason": "floor_gift", "detail": "acquire ego gift"}
        elif _event_here(ctx, event_assets, event_skip_assets):
            # 战斗结束后可能直接进入事件节点，作为脱离战斗的标识，交回上层 event 子流程处理
            ctx.log(f"第{wait_circle}轮等待后出现事件进入信号，战斗已结束并进入事件")
            return {"reason": "event", "detail": "event entry"}
        else:
            ctx.log(f"没有检测到可用标识，还有{MAX_RETRIES - wait_circle}次等待机会，继续等待战斗结束")
            continue_battle = False

        if wait_circle >= MAX_RETRIES:
            raise ExecutionFailure("battle_unknown_wait_exhausted", "连续未知画面的等待预算耗尽")
        # 轮次之间只保留 0.1 秒的极短间隔：本步每轮都要 capture_screen，并在未知画面上依次做
        # 通用过渡区域 OCR、多组 match_asset 和三轮局部 OCR（失败弹窗／奖励卡片／楼层饰品），
        # 单轮检测本身耗时已经比较久，天然起到轮询节流作用；这里只补一个最小间隔让画面推进，
        # 不再使用 0.5 秒这类较长固定等待，避免把长战斗的空转时间成倍拉长。
        # 整体节奏仍由轮次预算（MAX_RETRIES／MAX_TOTAL_WAITS）约束。
        ctx.action("observe.wait", seconds=0.1)

    ctx.log("战斗总等待预算 999 轮耗尽", level="error", screenshot=True)
    raise ExecutionFailure("battle_total_wait_exhausted", "战斗总等待预算耗尽")
