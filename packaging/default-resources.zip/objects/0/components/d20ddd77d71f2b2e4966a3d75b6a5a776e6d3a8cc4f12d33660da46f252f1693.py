"""Run 开始前检查游戏是否已离开标题界面；停在标题界面时按恢复规则的思路点击屏幕中间进入游戏。"""
from lalc import RunContext, step

TITLE_ASSET = "restart/clear_all_caches"
# 标题界面上的下载询问弹窗需要人工或弹窗恢复规则处理，本 Step 不盲目点击
DOWNLOAD_POPUP_ASSET = "popup/download_data_notice"
# 1280x720 客户区中点；标题界面点击此处即进入游戏
CLICK_X = 640
CLICK_Y = 360
# 点击后只固定等一秒让画面响应，是否离开标题界面由 task.check_game_ready 重新截图判断
WAIT_SECONDS = 1.0


@step
def execute(ctx: RunContext) -> None:
    """下载弹窗在或不在标题界面时零输入返回；否则点一次屏幕中间后交回。"""
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=DOWNLOAD_POPUP_ASSET):
        ctx.log("标题界面上仍有下载询问弹窗，本 Step 不点击，交回主流程处理", level="warning")
        return

    hits = ctx.action("observe.match_asset", asset=TITLE_ASSET) or []
    if not hits:
        ctx.log("未检测到 Clear all caches，游戏不在标题界面")
        return
    if len(hits) > 1:
        ctx.log(f"Clear all caches 命中 {len(hits)} 个，存在歧义，仍按固定坐标点击", level="warning")

    ctx.log(f"游戏停在标题界面，点击屏幕中间 {(CLICK_X, CLICK_Y)}")
    ctx.action("control.click", x=CLICK_X, y=CLICK_Y)
    ctx.action("observe.wait", seconds=WAIT_SECONDS)
