"""处理标题界面询问是否下载数据的弹窗；模板避开了中间会变化的下载体积文字。"""
from lalc import RunContext

POPUP_NAME = "Download data notice"
POPUP_ASSET = "popup/download_data_notice"
# Confirm 按钮在 1280x720 客户区中的固定坐标，模板不包含这个按钮文字
CONFIRM_X = 747
CONFIRM_Y = 457
# 3 次 × 2 秒；耗尽后交还主流程，由外部「恢复规则→重试→恢复规则」再次介入
MAX_RETRIES = 3
POLL_SECONDS = 2
# 弹窗消失后，最多再观察 10 次×2 秒，确认下载中状态已经出现
START_POLLS = 10


def _download_started(ctx: RunContext) -> bool:
    """OCR 找下载中特征：Download 字样或独立百分比，用于确认点击 Confirm 后真的开始下载。"""
    ctx.action("observe.capture_screen")
    ocr = ctx.action("observe.ocr") or {}
    for item in ocr.get("items", []):
        text = str(item.get("text", "")).strip()
        lowered = text.lower()
        if "download" in lowered:
            return True
        if text.endswith("%") and any(char.isdigit() for char in text):
            return True
    return False


def _matches(ctx: RunContext) -> list[dict]:
    """刷新截图后返回弹窗模板的全部命中。"""
    ctx.action("observe.capture_screen")
    return list(ctx.action("observe.match_asset", asset=POPUP_ASSET) or [])


def detect(ctx: RunContext) -> bool:
    """只观察弹窗模板是否存在，不在检测阶段点击。"""
    found = bool(_matches(ctx))
    ctx.log(f"检测 {POPUP_NAME} 弹窗：{found}")
    return found


def recover(ctx: RunContext) -> None:
    """点击 Confirm 让游戏开始下载；确认下载中状态出现后交给下载中的恢复规则。"""
    for attempt in range(1, MAX_RETRIES + 1):
        matches = _matches(ctx)

        if not matches:
            ctx.log(f"{POPUP_NAME} 弹窗已消失，开始确认下载中状态")
            for _ in range(START_POLLS):
                if _download_started(ctx):
                    ctx.log("已观察到下载中特征，剩余的下载等待交给下载中的恢复规则")
                    return
                ctx.action("observe.wait", seconds=POLL_SECONDS)
            ctx.log("弹窗已消失，但暂未观察到下载中特征，下载中的恢复规则会继续观察", level="warning")
            return

        if len(matches) > 1:
            ctx.log(f"{POPUP_NAME} 命中{len(matches)}个，存在歧义，仍按固定坐标点击 Confirm", level="warning")

        ctx.log(f"{POPUP_NAME} 弹窗存在，点击 Confirm 开始下载（第{attempt}次）")
        ctx.action("control.click", x=CONFIRM_X, y=CONFIRM_Y)
        ctx.action("observe.wait", seconds=POLL_SECONDS)

    ctx.log(
        f"{POPUP_NAME} 弹窗 {MAX_RETRIES} 次点击 Confirm 后仍未消失，交还主流程继续观察",
        level="error",
        screenshot=True,
    )
