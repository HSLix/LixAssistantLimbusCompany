"""镜牢商店购买循环：先补完技能替换，再一次性处理饰品商品；商品都处理完、需要刷新时，Cost 高于阈值才刷新，不高于阈值就不再刷新并停止（全部买下同样停止）交回上层离开商店；买商品不受阈值限制。
另外「停止刷新的剩余饰品栏位」（默认 1）限制刷新：刷新只为了饰品、而未买下的饰品栏位只剩不多于设置值个时，即使 Cost 高于阈值也不再刷新。
刷新方式按技能替换的状态选择：技能替换还有未买下的位置时用右上角普通 Refresh；
技能替换已经买完（没有位置了）而饰品还有未买下的位置时，改用在普通 Refresh 右边的 Keyword Refresh
（step.mirror_shop_keyword_refresh 一次调用走完 打开弹窗 → 按本队流派选关键词 → 点弹窗 Refresh，弹窗一出现就立即处理）。
技能替换不再只靠弹窗识别：step.mirror_shop_skill_replace 先从商品卡名字读出罪人，本场队伍没勾选就不开弹窗。
饰品不再点开详情确认：step.mirror_shop_gift_pick 用一次商品区 OCR 就把所有饰品分成买与不买——
名字与图鉴里的饰品目录名（mirror/gift/<流派>/<名字> 的最后一段）完全相等按图鉴判断，
没有完全相等时取字符修改不超过两次的最近一条目录名并记 warning；
镜牢设置页「饰品配置」里设为「优先获取」的饰品不受流派限制，流派不在本队购买流派里也照买；
镜牢设置页「商店设置」里打开「优先购买未记录饰品」后，名字不在图鉴里的商品也照买（默认关闭）；
购买后商品会移到最后，同一行／同列里被买走位置后面的卡片会整体前移（Run 487 实测右侧卡片左移一格），
同一帧预计算的下一个坐标因此可能落到已买过的卡片上，所以饰品 Step 每次调用只确认一件购买就返回，
由本循环重新 OCR 商品区后再买下一件。已买过的卡片被再点一次时游戏弹出的只读 E.G.O Gift Info 弹窗
（只有 Confirm）盖住商店页、使商店判据全部失效，本循环先识别它并交饰品 Step 关掉，不当作已离开商店。
饰品 Step 点过 Purchase 后不再自己等待并确认 E.G.O Gift GET! 到手弹窗：它只做一段固定等待就交回，
到手弹窗统一由本循环下一轮的“到手弹窗”分支重新观察并交同一步确认，购买与到手确认各占一轮。
商品被买走／重掷后商品区位置会变，所以本次处理完重新 OCR 商品区。
已处理记录按名字核对，而本循环整屏 OCR 与 step.mirror_shop_gift_pick 的商品区局部 OCR 是两次独立识别，
同一张卡的名字可能差一两个字母（Run 626：整屏读成 'Little and To-be-Naughty Plushle'、
局部 OCR 读成 'Plushie'）：完全相等匹配不上时，本循环允许与记录名字最多差两次字符修改，
按同一件已决定过的商品跳过；若饰品 Step 对本轮待处理商品买入、不买、待买都为 0
（说明这些位置上一次调用已经决定过，只是两次 OCR 名字不同），本循环按已处理处理、继续刷新决策，
不再重复派发同一批位置。
商品区的商品名与 Purchased 标签由一次区域 OCR 同时读出，刷新之前复用；Server Error 交给 step.detect_normal_transition 统一拦截。"""
import re

from lalc import ExecutionFailure, RunContext, sub_workflow

# 商店页标识（三条判据取或，任一成立就算商店页）：
# ① 右上角普通 Refresh 按钮模板命中；② 右上角 Keyword Refresh 按钮模板命中；
# ③ 左上角 Shop 标题文字。单个按钮模板在遮挡／动画帧下可能只命中一个，短标题 OCR 也会偶发漏识别，
# 取或之后任一条成立即可继续购买，不会被误判成「已离开商店」提前返回。
# 不再要求右下角 Leave 文字：Run 415 里同一帧 Shop 标题读到、Leave 区域却返回空条目。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 当前持有 Cost：Shop 标题右侧硬币图标后面的数字
COST_REGION = {"x": 540, "y": 100, "width": 120, "height": 60}
# 技能替换弹窗标题：弹窗会盖住 Cost 区域，先处理弹窗再看 Cost。
# 窄区域做局部 OCR 会把长标题断成两段并漏掉两端，因此按整条标题横幅取区域。
SKILL_POPUP_REGION = {"x": 175, "y": 95, "width": 570, "height": 78}
SKILL_POPUP_KEYWORDS = ("replace", "skill")
# 标题 OCR 偶发漏字时的后备判据：弹窗底部的 Cancel／Confirm 按钮在商店页不会同时出现
SKILL_POPUP_ACTION_REGION = {"x": 400, "y": 505, "width": 520, "height": 70}
SKILL_POPUP_ACTION_KEYWORDS = ("cancel", "confirm")
# 技能替换商品的价格图标与商品区（自 step.mirror_shop_skill_replace 复制，用于观察未购买商品）
SKILL_ITEM_ASSET = "mirror/shop/question_mark_price"
SHOP_ITEM_REGION = {"x": 505, "y": 175, "width": 700, "height": 390}
# 已买过的商品卡上方会显示 Purchased：价格图标仍在但点不开弹窗。
# 标签位置不再逐张卡做局部 OCR，只按几何关系判断；饰品名字行与技能替换价格图标中心共用一套区间。
# 实测 1280x720：名字行 y≈341、价格图标中心 y≈317、Purchased 标签中心 y≈228，
# 即标签比名字行高约 113 像素、比价格图标高约 89 像素；商品卡行距约 153 像素。
# 因此取 -150~-60：技能替换原来的 -140~-90 正好漏掉 -89，把已买过的技能替换商品当成未处理；
# 相邻一行的标签相对本行是约 +64 或 -243 像素，落不进这个区间，不会被算到别的卡片头上。
PURCHASED_TOLERANCE_X = 90
PURCHASED_TOP = -150
PURCHASED_BOTTOM = -60
# Cost 阈值来自镜牢设置页「商店设置」，键名与页面保持一致；阈值只限制刷新，不影响购买：
# 只有「商品都处理完、需要刷新」时才看它——当前 Cost 不高于阈值就不再刷新，直接退出购买循环
# 交回上层离开商店；属于本队且买得起的商品照常在退出前买完（Run 474：刷新后 Cost 太低就退出，
# 把还剩的可买商品一并丢了）。页面把下限抬到 MIN_SHOP_COST（300），所以缺失、非法或低于下限时
# 按 300 处理（旧配置里的 0 等更小值在运行时抬到 300），高于上限时也按 300 处理。
SETTINGS_PAGE_ID = "mirror.settings"
SHOP_COST_KEY = "shop_cost_threshold"
MIN_SHOP_COST = 300
DEFAULT_SHOP_COST = MIN_SHOP_COST
MAX_SHOP_COST = 99999
# 商店自动动作开关：由镜牢设置页「商店设置」保存（默认开启）。
# 技能替换关闭时不再购买技能替换商品、也不为它普通 Refresh；购买饰品关闭时不再点开饰品商品、
# 也不为找饰品刷新或使用 Keyword Refresh；两者都已关闭时商店只交回上层做离开前的事务。
SHOP_SKILL_REPLACE_KEY = "shop_skill_replace"
SHOP_BUY_GIFTS_KEY = "shop_buy_gifts"
# 「停止刷新的剩余饰品栏位」：商店里未买下的饰品栏位只剩不多于这个数时，即使 Cost 高于阈值也不再刷新，
# 直接退出购买循环交回上层离开商店（镜牢设置页「商店设置」保存，默认 1）。
# 0 表示不按这条规则提前停止，仍只由 Cost 阈值决定是否刷新。
# 只在刷新不再是为了技能替换时生效：技能替换还有未买下的栏位时，刷新是为了买技能，照旧进行。
SHOP_STOP_GIFT_SLOTS_KEY = "shop_stop_gift_slots"
MIN_STOP_GIFT_SLOTS = 0
DEFAULT_STOP_GIFT_SLOTS = 1
MAX_STOP_GIFT_SLOTS = 8
# 购买循环轮数上限：每轮至少推进一个动作（处理一个弹窗、打开一个商品详情或刷新一次）；
# 每次普通 Refresh 后要重新逐件查看商品（每个饰品占“打开详情 + 判断”两轮），
# 按 Cost 从高位花到阈值需要二十多次刷新估算，留足余量
MAX_ROUNDS = 600
# 同一分支的重复命中上限：技能替换弹窗、Keyword Refresh 弹窗、刷新决策与饰品商品停滞
# 四个分支各自计数，连续命中超过这个次数仍然是同一分支时，在该次动作执行之前抛
# workflow_branch_limit（即允许连续命中 15 次、第 16 次报错）。
# 按开发者要求由原来的 3（连续三次允许、第四次报错）放宽到 15，给现场多留推进余量。
MAX_REPEAT_HITS = 15
# 商店饰品商品：名字行 OCR 的最低分与最短长度
GIFT_NAME_MIN_SCORE = 0.85
GIFT_NAME_MIN_LENGTH = 3
# 技能替换商品的名字形如 Replace X's Skill，饰品商品据此排除
GIFT_SKILL_NAME_KEYWORD = "replace"
# Super Shop 的 ID Skill Search 也是商品卡（同样带 ?? 价格图标），由 step.mirror_shop_skill_replace 处理：
# 它的名字里没有 replace，只能按 skillsearch 片段排除，否则会被当成饰品名字行交给购买饰品，
# 点开后弹出的是底部署人自选而不是 E.G.O Gift 详情
GIFT_SKILL_SEARCH_KEYWORD = "skillsearch"
# Purchased 标签本身也在商品列表区域里且能通过名字行过滤，不能把它当成一件商品
GIFT_PURCHASED_LABEL_KEYWORD = "purchased"
# 买不起的商品卡不再显示商品名，而是在同一行（卡片上方）显示 Not Enough Cost 状态标签。
# Run 487 把这个标签当成饰品商品名字行：把它当成未记录饰品反复点开详情，卡片根本点不开、
# 已处理记录也不增加，最后撞上饰品分支的停滞保护。OCR 会读成 Not-Enough-Cost／Not EnoughaCost／
# Not Enough Cost 等变体，因此只按稳定的 notenough 片段识别，并单独记成「买不起」的位置。
GIFT_UNAFFORDABLE_KEYWORDS = ("notenough", "enoughcost")
# 同一张卡片的名字较长时 OCR 会拆成上下两行：横向／纵向都在这个范围内算同一张卡
SAME_CARD_TOLERANCE_X = 60
SAME_CARD_TOLERANCE_Y = 25
# 已处理记录：技能替换与饰品商品各一份，普通 Refresh 后一起清空。
# 技能替换按坐标记录；饰品商品按名字记录（商品被买走后下方商品会上移，名字不变、位置会变），
# 名字为空的旧记录只能按半径判断位置。
RUNTIME_KEY = "mirror.runtime"
SKILL_HANDLED_KEY = "shop_skill_handled"
GIFT_HANDLED_KEY = "shop_gift_handled"
SAME_ITEM_RADIUS = 40
# 已处理记录按名字核对：本循环读的是整屏 OCR、step.mirror_shop_gift_pick 读的是商品区局部 OCR，
# 两次独立识别对同一张卡可能只差一两个字母（Run 626：'Plushle' 与 'Plushie'）。记录里存的是
# Step 的写法，本循环的名字永远对不上，同一张已决定不买的卡被反复当成待处理，连续 16 次没有进展后
# 撞上停滞保护。完全相等匹配不上时，允许与记录名字最多差 MAX_NAME_EDITS 次字符修改
# （与 Step 匹配图鉴名字同一档）；太短的名字只按完全相等匹配，避免同名误配。
MAX_NAME_EDITS = 2
MIN_NEAR_NAME_LENGTH = 5
# 饰品商品详情弹窗：标题 Purchase E.G.O Gifts 用素材 mirror/shop/purchase_ego_gifts（351x25）匹配，
# 不再检测底部 Cancel／Purchase 按钮（购买按钮改为固定坐标，见 step.mirror_shop_gift_pick）
DETAIL_TITLE_ASSET = "mirror/shop/purchase_ego_gifts"
DETAIL_TITLE_REGION = {"x": 340, "y": 140, "width": 420, "height": 60}
DETAIL_TITLE_THRESHOLD = 0.85
# 购买后的到手弹窗 E.G.O Gift GET!：用素材 mirror/ego_gift_get（430x34 的标题横幅）做原尺寸模板匹配，
# 不再读标题文字（也不再整屏 OCR 兜底）；区域与阈值跟 task.mirror 的 gift_get 判定保持一致
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
# 已买过（Purchased）的商品卡被再点一次时，游戏弹的是只读的 E.G.O Gift Info 弹窗（只有 Confirm）：
# 它压暗商店页，刷新按钮模板与 Shop 标题都会失效，旧实现直接返回「已不是商店页」（Run 487），
# task.mirror 却每轮仍判为商店，连续 4 次后撞上分支上限。标题区与按钮区与
# step.mirror_shop_gift_pick 保持一致：按钮区只覆盖 y>=500 的 Confirm，
# 购买弹窗的 Cancel／Purchase 在 y≈468~497，不会被误判。
GIFT_INFO_TITLE_REGION = {"x": 520, "y": 160, "width": 240, "height": 46}
GIFT_INFO_TITLE_KEYWORD = "egogiftinfo"
GIFT_INFO_BUTTON_REGION = {"x": 430, "y": 500, "width": 400, "height": 70}
GIFT_INFO_CONFIRM_LABEL = "confirm"
# Keyword Refresh 弹窗：标题横幅 Shop - Keyword Refresh（与技能替换弹窗一样盖住 Shop 标题、Cost 与商品区），
# 只用素材 mirror/shop/shop_keyword_refresh（388x37）做模板匹配，不再读标题文字、也不检测底部按钮
KEYWORD_POPUP_TITLE_ASSET = "mirror/shop/shop_keyword_refresh"
KEYWORD_POPUP_TITLE_REGION = {"x": 300, "y": 100, "width": 620, "height": 52}
KEYWORD_POPUP_TITLE_THRESHOLD = 0.85
# Server Error 弹窗与右上角 Connecting 等加载过渡都不在这里单独识别：
# step.detect_normal_transition 已按同一区域判定，错误交恢复规则 recovery.popup_server_error，
# 加载过渡交 step.wait_normal_transition 等待；循环里不再维护第二份特征表。


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _in_region(item: dict, region: dict[str, int]) -> bool:
    """该 OCR 条目的中心是否落在给定区域。"""
    center = item.get("centerxy") or (0, 0)
    x, y = int(center[0]), int(center[1])
    return (
        int(region["x"]) <= x <= int(region["x"]) + int(region["width"])
        and int(region["y"]) <= y <= int(region["y"]) + int(region["height"])
    )


def _items_text(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回规范化小写文本。"""
    texts = [str(item.get("text", "")) for item in items if _in_region(item, region)]
    return _norm(" ".join(text for text in texts if text))


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """兼容旧调用：没有整屏结果时自己识别当前帧一次；循环里统一改用 _items_text。"""
    return _items_text(_screen_items(ctx), region)


def _in_shop(ctx: RunContext, items: list[dict]) -> bool:
    """
    当前帧是否为镜牢商店页：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题。
    三条判据取或：任一成立即可，避免单个按钮模板漏匹配或标题 OCR 漏字时被误判成已离开商店。
    """
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _items_text(items, SHOP_TITLE_REGION)


def _popup_open(items: list[dict]) -> bool:
    """当前帧是否已打开技能替换弹窗（它会盖住 Cost 显示与刷新按钮）。"""
    text = _items_text(items, SKILL_POPUP_REGION)
    if all(word in text for word in SKILL_POPUP_KEYWORDS):
        return True
    actions = _items_text(items, SKILL_POPUP_ACTION_REGION)
    return all(word in actions for word in SKILL_POPUP_ACTION_KEYWORDS)


def _keyword_popup_open(ctx: RunContext) -> bool:
    """当前帧是否已打开 Shop - Keyword Refresh 弹窗：只用标题素材 mirror/shop/shop_keyword_refresh 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=KEYWORD_POPUP_TITLE_ASSET,
            region=KEYWORD_POPUP_TITLE_REGION,
            threshold=KEYWORD_POPUP_TITLE_THRESHOLD,
        )
    )


def _cost(items: list[dict]) -> int | None:
    """从本轮整屏 OCR 结果里读当前持有的 Cost：把硬币右侧的数字按横向顺序拼起来；读不到返回 None。"""
    parts: list[tuple[int, str]] = []
    for item in items:
        if not _in_region(item, COST_REGION):
            continue
        digits = re.sub(r"[^0-9]", "", str(item.get("text", "")))
        if digits:
            parts.append((int(item["centerxy"][0]), digits))
    if not parts:
        return None
    parts.sort()
    text = "".join(digits for _, digits in parts)
    return int(text) if text.isdigit() else None


def _threshold(ctx: RunContext) -> int:
    """读取镜牢设置页「商店设置」里的 Cost 阈值；它只限制刷新，不限制买商品。
    需要刷新而当前 Cost 不高于它时就不再刷新、退出购买循环；
    页面下限是 MIN_SHOP_COST（300）：缺失、非法或低于 300 时按 300 处理，高于上限时也按 300 处理。
    """
    page = (ctx.run_state.settings or {}).get(SETTINGS_PAGE_ID)
    raw = page.get(SHOP_COST_KEY) if isinstance(page, dict) else None
    text = str(raw if raw is not None else DEFAULT_SHOP_COST).strip()
    if not text.isdigit():
        ctx.log(
            f"商店设置的 Cost 阈值 {raw!r} 不是非负整数，按 {DEFAULT_SHOP_COST} 处理",
            level="warning",
        )
        return DEFAULT_SHOP_COST
    value = int(text)
    if value < MIN_SHOP_COST:
        ctx.log(
            f"商店设置的 Cost 阈值 {value} 低于下限 {MIN_SHOP_COST}，按 {MIN_SHOP_COST} 处理",
            level="warning",
        )
        return MIN_SHOP_COST
    if value > MAX_SHOP_COST:
        ctx.log(
            f"商店设置的 Cost 阈值 {value} 超出上限 {MAX_SHOP_COST}，按 {DEFAULT_SHOP_COST} 处理",
            level="warning",
        )
        return DEFAULT_SHOP_COST
    return value


def _switch(ctx: RunContext, key: str) -> bool:
    """读取镜牢设置页「商店设置」的自动动作开关；缺失或非布尔值时按开启处理（保持原有行为）。"""
    page = (ctx.run_state.settings or {}).get(SETTINGS_PAGE_ID)
    raw = page.get(key) if isinstance(page, dict) else None
    return raw if isinstance(raw, bool) else True


def _stop_gift_slots(ctx: RunContext) -> int:
    """读取镜牢设置页「商店设置」的「停止刷新的剩余饰品栏位」。

    缺失、非法、低于下限（0）或超过上限时按默认值 1 处理（下限 0 合法，表示不提前停止）。
    """
    page = (ctx.run_state.settings or {}).get(SETTINGS_PAGE_ID)
    raw = page.get(SHOP_STOP_GIFT_SLOTS_KEY) if isinstance(page, dict) else None
    text = str(raw if raw is not None else DEFAULT_STOP_GIFT_SLOTS).strip()
    if not text.isdigit():
        ctx.log(
            f"商店设置的停止刷新剩余饰品栏位 {raw!r} 不是非负整数，"
            f"按 {DEFAULT_STOP_GIFT_SLOTS} 处理",
            level="warning",
        )
        return DEFAULT_STOP_GIFT_SLOTS
    value = int(text)
    if value > MAX_STOP_GIFT_SLOTS:
        ctx.log(
            f"商店设置的停止刷新剩余饰品栏位 {value} 超出上限 {MAX_STOP_GIFT_SLOTS}，"
            f"按 {DEFAULT_STOP_GIFT_SLOTS} 处理",
            level="warning",
        )
        return DEFAULT_STOP_GIFT_SLOTS
    return value


def _labeled(labels: list[tuple[int, int]], center) -> bool:
    """
    参照点（商品名字行或技能替换价格图标中心）上方是否读到 Purchased 标签。
    labels 是商品区那一次 OCR 读到的全部 Purchased 标签中心，这里只做几何比对、不再单独 OCR；
    两种参照点共用 PURCHASED_TOLERANCE_X／PURCHASED_TOP／PURCHASED_BOTTOM 一套区间；
    参照点缺失时按已买过处理，避免对未知位置重复输入。
    """
    if not center:
        return True
    x, y = int(center[0]), int(center[1])
    return any(
        abs(label_x - x) <= PURCHASED_TOLERANCE_X
        and PURCHASED_TOP <= label_y - y <= PURCHASED_BOTTOM
        for label_x, label_y in labels
    )


def _gift_info_open(items: list[dict]) -> bool:
    """
    当前帧是否叠着只读的 E.G.O Gift Info 弹窗（点已买过的商品卡会弹出）。
    标题 E.G.O Gift Info 为主；标题漏识别时用按钮区的 Confirm 兜底。该按钮区只覆盖 y>=500，
    购买弹窗的 Cancel／Purchase 在 y≈468~497，且详情弹窗不再检测按钮，因此不会再被误判成这个弹窗。
    """
    if GIFT_INFO_TITLE_KEYWORD in _items_text(items, GIFT_INFO_TITLE_REGION):
        return True
    labels = {
        _norm(item.get("text", "")) for item in items if _in_region(item, GIFT_INFO_BUTTON_REGION)
    }
    return GIFT_INFO_CONFIRM_LABEL in labels


def _record(ctx: RunContext, key: str) -> list:
    """读取镜牢运行时状态里的一类已处理位置记录；缺失时返回空列表。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        return []
    record = runtime.get(key)
    return record if isinstance(record, list) else []


def _recorded(record: list, center) -> bool:
    """该位置是否已在记录里：商品被消费后下方商品会上移，因此按坐标半径判断。"""
    if not center:
        return True
    for item in record:
        if not isinstance(item, dict) or item.get("x") is None or item.get("y") is None:
            continue
        if (
            abs(int(center[0]) - int(item["x"])) <= SAME_ITEM_RADIUS
            and abs(int(center[1]) - int(item["y"])) <= SAME_ITEM_RADIUS
        ):
            return True
    return False


def _count(value) -> int:
    """把 Step 返回的计数字符串（'0'、'2'）解析成整数；缺失或不是整数字符串时按 0 处理。"""
    text = str(value if value is not None else "").strip()
    if not text.lstrip("-").isdigit():
        return 0
    return int(text)


def _edit_distance(left: str, right: str, limit: int) -> int | None:
    """有界编辑距离：返回把 left 改成 right 需要的最少字符增删改次数，超过 limit 时返回 None。"""
    if abs(len(left) - len(right)) > limit:
        return None
    previous = list(range(len(right) + 1))
    for row, left_char in enumerate(left, start=1):
        current = [row]
        for column, right_char in enumerate(right, start=1):
            cost = 0 if left_char == right_char else 1
            current.append(
                min(previous[column] + 1, current[column - 1] + 1, previous[column - 1] + cost)
            )
        previous = current
        if min(previous) > limit:
            # 这一行已经全部超过阈值，往下只会更差
            return None
    best = previous[-1]
    return best if best <= limit else None


def _near_record_name(names: dict[str, int], name: str) -> tuple[str, int] | None:
    """
    在已处理记录里找同一件商品的另一种 OCR 写法，返回 (记录里的名字, 字符修改次数) 或 None。
    本循环整屏 OCR 与 Step 的商品区局部 OCR 是两次独立识别，同一张卡可能差一两个字母
    （Run 626：'Little and To-be-Naughty Plushle' 对记录里的 '...Plushie'），完全相等匹配不上
    就会把已经决定过的卡片反复当成待处理。名字太短时只按完全相等匹配，避免误配。
    """
    if len(name) < MIN_NEAR_NAME_LENGTH:
        return None
    best: tuple[int, str] | None = None
    for candidate, count in names.items():
        if count <= 0 or len(candidate) < MIN_NEAR_NAME_LENGTH:
            continue
        distance = _edit_distance(candidate, name, MAX_NAME_EDITS)
        if distance is None:
            continue
        if best is None or distance < best[0]:
            best = (distance, candidate)
    return (best[1], best[0]) if best else None


def _pending_gifts(
    ctx: RunContext, cards: list[tuple[int, int, str, bool]]
) -> list[tuple[int, int, str, bool]]:
    """
    本次商店还没处理过的饰品商品。饰品商品按名字核对已处理记录：商品被买走后下方商品会上移，
    名字不变、位置会变；同名商品各算一次，避免一件买走后同名的另一件被跳过；
    名字为空的旧记录只能按坐标核对；完全相等匹配不上时再按 OCR 变体（最多差 MAX_NAME_EDITS
    次字符修改）核对，避免两次 OCR 的写法差异让同一张卡被反复当成待处理。
    返回的卡片保持商品区的从上到下、从左到右顺序。
    """
    names: dict[str, int] = {}
    legacy: list[dict] = []
    for item in _record(ctx, GIFT_HANDLED_KEY):
        if not isinstance(item, dict):
            continue
        name = _norm(item.get("name") or "")
        if name:
            names[name] = names.get(name, 0) + 1
        else:
            legacy.append(item)
    pending: list[tuple[int, int, str, bool]] = []
    for x, y, text, purchased in cards:
        name = _norm(text)
        if name and names.get(name, 0) > 0:
            names[name] = names[name] - 1
            continue
        if name:
            near = _near_record_name(names, name)
            if near is not None:
                names[near[0]] = names[near[0]] - 1
                # 两次 OCR 的写法差异属正常识别细节，按 debug 记录（开发者要求）
                ctx.log(
                    f"饰品商品 {text!r} 与已处理记录里的 {near[0]!r} 只差 {near[1]} 次字符修改，"
                    "按同一件已决定过的商品跳过（整屏 OCR 与商品区局部 OCR 的写法不同）",
                    level="debug",
                )
                continue
        if not name and _recorded(legacy, (x, y)):
            continue
        pending.append((x, y, text, purchased))
    return pending


def _scan_shelf(
    ctx: RunContext, items: list[dict]
) -> tuple[list[tuple[int, int, str, bool]], list[tuple[int, int]], list[tuple[int, int]]]:
    """
    对当前帧商品区做一次局部 OCR，同时读出饰品商品名字行与卡片上方的状态标签：
    - 名字行只保留有字母且长度、分数达标的文字，价格数字与单字符噪声因此被过滤；
      Replace … Skill 属于技能替换商品，Purchased 标签本身也不能当成一件商品，两者都排除；
      Super Shop 的 ID Skill Search 也是技能替换类商品（点开是底部署人自选），同样排除；
    - Purchased 标签只记中心坐标，用来判断某张卡或某个价格图标是否已买过；
    - Not Enough Cost 标签买不起的商品卡名字行常被状态标签挡住，读不出商品名、也点不开详情，
      单独记成「买不起」的位置，既不当作商品名，也不当作待处理商品；
      名字行仍然读得出来时（标签就在名字行正上方，与 Purchased 同一套几何关系）也按买不起处理，
      否则子流程会反复派它去购买，每次只弹只读的 E.G.O Gift Info（Run 487）；
    - 名字行与 Purchased 标签按几何位置配对，不再对每张卡各做一次局部 OCR。
    返回 ([(名字行中心 x, 名字行中心 y, 文字, 是否已买过)], [Purchased 标签中心 ...],
    [买不起标签中心 ...])，都按坐标排序。
    """
    cards: list[tuple[int, int, str]] = []
    labels: list[tuple[int, int]] = []
    blocked: list[tuple[int, int]] = []
    for item in items:
        if not _in_region(item, SHOP_ITEM_REGION):
            continue
        text = str(item.get("text", "")).strip()
        if not text:
            continue
        flat = _norm(text)
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if GIFT_PURCHASED_LABEL_KEYWORD in flat:
            labels.append((x, y))
            continue
        if any(keyword in flat for keyword in GIFT_UNAFFORDABLE_KEYWORDS):
            # 买不起的商品卡：名字行被 Not Enough Cost 状态标签取代，不能当成商品名
            blocked.append((x, y))
            continue
        if len(flat) < GIFT_NAME_MIN_LENGTH:
            continue
        if float(item.get("score") or 0.0) < GIFT_NAME_MIN_SCORE:
            continue
        if not any(char.isalpha() for char in text):
            continue
        if GIFT_SKILL_NAME_KEYWORD in flat:
            continue
        if GIFT_SKILL_SEARCH_KEYWORD in flat:
            # ID Skill Search 是技能替换类商品（由 step.mirror_shop_skill_replace 处理），不能当饰品买
            continue
        if any(
            abs(x - kept[0]) <= SAME_CARD_TOLERANCE_X and abs(y - kept[1]) <= SAME_CARD_TOLERANCE_Y
            for kept in cards
        ):
            # 同一张卡的名字被 OCR 拆成上下两行：拼成一条，锚点保留最上面那一行
            for index, kept in enumerate(cards):
                if (
                    abs(x - kept[0]) <= SAME_CARD_TOLERANCE_X
                    and abs(y - kept[1]) <= SAME_CARD_TOLERANCE_Y
                ):
                    if y < kept[1]:
                        cards[index] = (x, y, f"{text} {kept[2]}")
                    else:
                        cards[index] = (kept[0], kept[1], f"{kept[2]} {text}")
                    break
            continue
        cards.append((x, y, text))
    labels.sort()
    blocked.sort()
    # 买不起的商品卡：状态标签就在名字行正上方，与 Purchased 同一套几何关系。
    # 这类卡的名字行仍读得出来时（Run 487 的 Thunderbranch）不能当成待买饰品，
    # 否则本循环每轮都派它去购买，点开只弹只读的 E.G.O Gift Info，已处理记录不增加。
    # 它们仍保留在 blocked 里：既不算待处理饰品，也不算「全部买下」，刷新决策照旧考虑买不起的位置。
    unaffordable = [(x, y, text) for x, y, text in cards if _labeled(blocked, (x, y))]
    if unaffordable:
        # 买不起的商品卡属正常识别细节，按 debug 记录（开发者要求）
        ctx.log(
            "商品区这些名字行上方是 Not Enough Cost（Cost 不够买），按买不起处理、不派购买："
            + "; ".join(f"{text!r}@({x},{y})" for x, y, text in unaffordable),
            level="debug",
        )
        cards = [(x, y, text) for x, y, text in cards if not _labeled(blocked, (x, y))]
    paired = [(x, y, text, _labeled(labels, (x, y))) for x, y, text in cards]
    paired.sort(key=lambda entry: (entry[1], entry[0]))
    return paired, labels, blocked


def _detail_open(ctx: RunContext) -> bool:
    """当前帧是否已打开饰品商品详情：标题用素材 mirror/shop/purchase_ego_gifts 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=DETAIL_TITLE_ASSET,
            region=DETAIL_TITLE_REGION,
            threshold=DETAIL_TITLE_THRESHOLD,
        )
    )


def _gift_get(ctx: RunContext) -> bool:
    """当前帧是否叠着购买后的 E.G.O Gift GET! 到手弹窗：只用素材 mirror/ego_gift_get 匹配标题横幅。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=GIFT_GET_ASSET,
            region=GIFT_GET_REGION,
            threshold=GIFT_GET_THRESHOLD,
        )
    )


def _gift_round(ctx: RunContext, state: dict[str, int]) -> None:
    """
    饰品商品分支的停滞保护：已处理商品数没有增加、连续命中超过 MAX_REPEAT_HITS 次时在执行前报错。
    每件饰品本来就各占一轮（完全符合的直接买或排除，模糊命中的多一轮详情复核），
    所以不能只用分支计数，要看已处理商品数是否真的增加了。
    """
    current = len(_record(ctx, GIFT_HANDLED_KEY)) + len(_record(ctx, SKILL_HANDLED_KEY))
    if current == state.get("progress"):
        state["hits"] = int(state.get("hits", 0)) + 1
    else:
        state["hits"] = 1
    state["progress"] = current
    if state["hits"] > MAX_REPEAT_HITS:
        raise ExecutionFailure(
            "workflow_branch_limit",
            f"饰品商品连续 {MAX_REPEAT_HITS + 1} 次命中但已处理位置没有增加",
        )


def _detail_branch(ctx: RunContext, round_index: int, state: dict[str, int]) -> None:
    """
    详情页残留分支：买不买已经在商品区按名字决定过（本步不再用详情复核名字），
    所以这里只让 Step 按一次 Enter 退出详情。
    """
    _gift_round(ctx, state)
    ctx.log(
        f"第{round_index}轮：饰品商品详情还开着（本次调用没有待处理的商品），"
        "交给 Step 按一次 Enter 退出"
    )
    ctx.call("step.mirror_shop_gift_pick")


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    观察驱动的商店购买循环：每轮先截图，再按当前画面选一个动作，动作后重新观察。
    顺序上先补完技能替换，再一次性处理饰品商品：技能替换由 step.mirror_shop_skill_replace
    先从商品卡名字读出罪人，本场队伍没勾选就不开弹窗；饰品由 step.mirror_shop_gift_pick
    用一次商品区 OCR 决定全部买与不买（没有完全相等时取字符修改不超过两次的最近一条并记 warning），
    只按从后往前的顺序点一次 Purchase 就返回（买走后商品区会重排，其余交回本循环重新 OCR）；
    点过 Purchase 后不再由该步检测 E.G.O Gift GET! 到手弹窗，弹窗统一由本循环下一轮识别并交同一步确认。
    - Server Error 弹窗由 step.detect_normal_transition 统一识别并抛错，本循环不重复识别；
    - 不在商店页且没有技能替换弹窗、饰品详情 → completed=False（商店页缺失）；
    - 购买后的 E.G.O Gift GET! 到账弹窗、饰品详情残留开着 → 调一次 shop_gift_pick
      （确认到账弹窗，或按一次 Enter 退出没有待处理目标的详情）；
      饰品 Step 点过 Purchase 后不再自行检测到手弹窗，弹窗只会由本分支在下一轮观察后确认；
    - 只读的 E.G.O Gift Info 弹窗开着（点已买过的商品卡会弹出，会压暗商店页）→
      同样调一次 shop_gift_pick 点一次 Confirm 关掉，不当作已离开商店；
    - 技能替换弹窗开着（上一次调用没走完）→ 调一次 skill_replace 继续推进到成交；
    - Keyword Refresh 弹窗开着（上一次调用没走完）→ 调一次 keyword_refresh：按本队流派选关键词、
      再点一次弹窗里的 Refresh（已点过就不再点，避免重复扣 Cost）；该步一次调用也会走完
      「打开弹窗 → 选关键词 → 提交」，正常不会把弹窗留到下一轮；
    - Cost 读不到 → 停止（cost_unreadable）；刷新是否生效不用 Cost 验收，重掷后由下一轮重新观察商品区，
      过渡状态交通用等待处理；
    - 商品都处理完、需要刷新时先看阈值：Cost 不高于阈值 → 不再刷新，停止（threshold）并交回上层离开商店；
      Cost 阈值只限制刷新，不影响继续购买商品（买得起且属于本队的商品会在退出前买完）；
    - 刷新只为了饰品（技能替换没有未买下的栏位）时，未买下的饰品栏位只剩不多于设置值
      （镜牢设置页「商店设置」的「停止刷新的剩余饰品栏位」，默认 1；0 表示不启用）个 →
      即使 Cost 高于阈值也不再刷新，停止（gift_slots）并交回上层离开商店；
    - 商品区一次 OCR 同时给出饰品名字行、全部 Purchased 标签与技能替换价格图标，
      只在进入本 Subworkflow 的第一次、普通 Refresh 之后、买入商品（Cost 下降或到手弹窗）之后
      与饰品批次处理完之后重新识别（商品位置会随购买与重掷变化）；
    - 商品区还有未处理的技能替换商品 → 调一次 skill_replace（先按商品名判断要不要买，需要买才开弹窗）；
      还有未处理的饰品商品 → 调一次 shop_gift_pick：一次调用决定全部买与不买并买完要买的；
    - 当前商店的商品都处理过且还有未买下的位置时，按技能替换状态选刷新方式：
      还有未买下的技能替换位置 → 普通 Refresh 重掷；技能替换已买完、饰品还有未买下的位置 →
      Keyword Refresh（打开弹窗 → 按本队流派选关键词 → 点弹窗 Refresh），弹窗打不开或没配流派时退回普通 Refresh；
      一个都不剩（全部 Purchased）→ 停止（all_purchased）。
    所有停止原因都返回 completed=True 交回 task.mirror 执行离开商店；保留 MAX_ROUNDS 轮上限。
    同一分支（技能替换弹窗、Keyword Refresh 弹窗、刷新决策、饰品商品停滞）连续命中超过
    MAX_REPEAT_HITS（15）次时，在该次动作执行之前抛 workflow_branch_limit 交恢复规则处理。
    """
    threshold = _threshold(ctx)
    stop_gift_slots = _stop_gift_slots(ctx)
    buy_skills = _switch(ctx, SHOP_SKILL_REPLACE_KEY)
    buy_gifts = _switch(ctx, SHOP_BUY_GIFTS_KEY)
    ctx.log(
        f"镜牢商店购买循环开始：技能替换开关 {buy_skills}、购买饰品开关 {buy_gifts}；"
        f"Cost 阈值 {threshold} 只限制刷新——商品都处理完需要刷新时，"
        "Cost 不高于它就不再刷新并退出购买循环；买商品不受它限制；"
        f"停止刷新的剩余饰品栏位 {stop_gift_slots}（未买下的饰品栏位只剩不多于该值且刷新只为了饰品时，"
        "即使 Cost 高于阈值也不再刷新）"
    )
    refreshed = 0
    # 技能替换弹窗分支的连续命中数：合并成一次调用后弹窗正常应当一轮就关掉
    skill_popup_hits = 0
    # Keyword Refresh 弹窗分支的连续命中数：选关键词到提交正常两轮内关闭
    keyword_popup_hits = 0
    # 刷新决策分支的连续命中数：真正重掷后商品会变化，连续超过 MAX_REPEAT_HITS 次没有变化说明刷新没生效
    refresh_hits = 0
    # 只读 E.G.O Gift Info 弹窗分支的连续命中数：饰品 Step 一次调用就会点 Confirm 关掉
    gift_info_hits = 0
    # 饰品商品分支的停滞计数：每件饰品各占一轮，靠已处理商品数判断是否真没进展
    gift_state: dict[str, int] = {}
    # 本循环当成待处理、但饰品 Step 买入／不买／待买都为 0 的商品名：说明这些位置上一次调用
    # 已经决定过，只是两次 OCR 读出的名字不同（Run 626）。本次商店内一直保留，换掉商品区时清空，
    # 避免同一批位置被反复派发、最后撞上停滞保护。
    gift_decided_elsewhere: set[str] = set()
    # 商品区识别结果（名字行 / Purchased 标签 / 技能替换价格图标命中）：进入本 Subworkflow 后只在
    # 第一次、普通 Refresh 之后、买入商品之后与每处理完一件饰品之后重新识别；
    # 只关闭残留详情、等待过渡等不改变商品区的动作都复用这份结果
    shelf: (
        tuple[
            list[tuple[int, int, str, bool]], list[tuple[int, int]], list, list[tuple[int, int]]
        ]
        | None
    ) = None
    # 做这份商品区识别时的 Cost：之后读到更小的 Cost 就说明期间买入过东西，商品区要重新识别
    shelf_cost: int | None = None
    for round_index in range(1, MAX_ROUNDS + 1):
        meta = ctx.action("observe.capture_screen")
        # 每轮只做一次整屏 OCR：Server Error、弹窗、Cost 与商品区的文字判据都从这份结果里按区域过滤
        items = _screen_items(ctx)

        # 购买后的到手弹窗与饰品详情都盖在商店页之上，必须先处理，
        # 否则会把被盖住的商品卡或按钮当成可点目标
        if _gift_get(ctx):
            ctx.log(f"第{round_index}轮：购买后出现 E.G.O Gift GET! 弹窗，确认一次")
            ctx.call("step.mirror_shop_gift_pick")
            # 到手弹窗是本次商店刚买入一件饰品的直接证据，商品区的 Purchased 状态已变
            shelf = None
            continue

        # Keyword Refresh 弹窗盖住 Shop 标题与商品区：必须先按弹窗标题识别并推进（选流派 → 提交 Refresh），
        # 否则 _in_shop 不成立，会把正在提交的弹窗当成「已离开商店」
        if _keyword_popup_open(ctx):
            keyword_popup_hits += 1
            if keyword_popup_hits > MAX_REPEAT_HITS:
                ctx.log(
                    f"Keyword Refresh 弹窗连续 {MAX_REPEAT_HITS + 1} 次命中仍未关闭，"
                    "报错交恢复规则处理",
                    level="error",
                    screenshot=True,
                )
                raise ExecutionFailure(
                    "workflow_branch_limit",
                    f"Keyword Refresh 弹窗连续 {MAX_REPEAT_HITS + 1} 次命中仍未关闭",
                )
            ctx.log(
                f"第{round_index}轮：Keyword Refresh 弹窗仍开着，本次按本队流派选关键词并提交一次"
            )
            ctx.call("step.mirror_shop_keyword_refresh")
            continue
        keyword_popup_hits = 0

        # 只读的 E.G.O Gift Info 弹窗（点已买过的商品卡会弹出）会压暗商店页，使上面的商店判据全部失效：
        # 先交给饰品 Step 点一次 Confirm 关掉，再由下一轮重新观察商店页，不当作「已离开商店」返回
        if _gift_info_open(items):
            gift_info_hits += 1
            if gift_info_hits > MAX_REPEAT_HITS:
                ctx.log(
                    f"E.G.O Gift Info 弹窗连续 {MAX_REPEAT_HITS + 1} 次命中仍未关闭，"
                    "报错交恢复规则处理",
                    level="error",
                    screenshot=True,
                )
                raise ExecutionFailure(
                    "workflow_branch_limit",
                    f"E.G.O Gift Info 弹窗连续 {MAX_REPEAT_HITS + 1} 次命中仍未关闭",
                )
            ctx.log(
                f"第{round_index}轮：只读的 E.G.O Gift Info 弹窗还开着（点已买过的商品卡会弹出），"
                "本次交饰品 Step 点一次 Confirm 关闭，不做购买输入"
            )
            ctx.call("step.mirror_shop_gift_pick")
            continue
        gift_info_hits = 0

        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            # 通用过渡是本轮最后一个判定：复用本轮整屏 OCR（文字＋中心点），不再让检测 Step 重复识别；
            # 等待 Step 在预算内自行复查，这里不累计任何分支的连续命中，
            # 并把业务分支的连续计数复位到 1 起点，避免长时间加载被误判成分支卡死
            skill_popup_hits = 0
            keyword_popup_hits = 0
            refresh_hits = 0
            gift_info_hits = 0
            gift_state = {}
            ctx.call("step.wait_normal_transition")
            continue
        popup = _popup_open(items)
        detail = _detail_open(ctx)
        if not popup and not detail and not _in_shop(ctx, items):
            ctx.log("当前已不是镜牢商店页，购买循环无法继续", level="warning", screenshot=True)
            return {
                "completed": False,
                "reason": "mirror_shop_page_missing",
                "refreshed": str(refreshed),
            }

        if popup:
            skill_popup_hits += 1
            if skill_popup_hits > MAX_REPEAT_HITS:
                ctx.log(
                    f"技能替换弹窗连续 {MAX_REPEAT_HITS + 1} 次命中仍未关闭，报错交恢复规则处理",
                    level="error",
                    screenshot=True,
                )
                raise ExecutionFailure(
                    "workflow_branch_limit",
                    f"技能替换弹窗连续 {MAX_REPEAT_HITS + 1} 次命中仍未关闭",
                )
            ctx.log(
                f"第{round_index}轮：技能替换弹窗仍在（上一次调用没有走完），本次继续推进到成交"
            )
            ctx.call("step.mirror_shop_skill_replace")
            # 成交会扣 Cost，下一次读到更小的 Cost 时再重新识别商品区；没成交就继续复用它
            continue
        skill_popup_hits = 0

        if detail:
            _detail_branch(ctx, round_index, gift_state)
            # 只是关闭残留详情不改变商品区，继续复用这份识别结果
            continue

        if not buy_skills and not buy_gifts:
            # 两个自动购买开关都关闭：不处理商品也不刷新，直接交回上层做离开前的事务
            ctx.log(
                "商店设置的技能替换与购买饰品都已关闭：本次商店不处理商品、也不刷新，"
                "直接交回上层做饰品自维护并离开商店"
            )
            return {
                "completed": True,
                "reason": "商店购买已按设置关闭",
                "stop": "purchases_disabled",
                "refreshed": str(refreshed),
            }

        cost = _cost(items)
        if cost is None:
            ctx.log(
                "没有读到当前持有的 Cost，停止购买并交回上层，避免继续消耗",
                level="warning",
                screenshot=True,
            )
            return {
                "completed": True,
                "reason": "商店 Cost 读不到，已停止购买",
                "stop": "cost_unreadable",
                "refreshed": str(refreshed),
            }
        ctx.log(f"第{round_index}轮：当前 Cost {cost}，阈值 {threshold}（只限制刷新），继续处理商品")

        # 买入商品（技能替换或饰品）一定扣 Cost：比做这次商品区识别时更低就重新识别一次；
        # 只是打开/关闭详情、取消替换、等待过渡等不改变商品区的轮次继续复用这份结果
        if shelf is not None and shelf_cost is not None and cost < shelf_cost:
            ctx.log(
                f"第{round_index}轮：当前 Cost {cost} 低于上次识别商品区时的 {shelf_cost}，"
                "期间买入过商品，重新识别商品区"
            )
            shelf = None

        # 商品区一次 OCR 同时拿到饰品名字行与其 Purchased 标签，技能替换价格图标也用同一批标签判断；
        # 只在进入本 Subworkflow 的第一次、普通 Refresh 之后、买入商品之后、饰品批次处理完之后重新识别
        if shelf is None:
            cards, labels, blocked = _scan_shelf(ctx, items)
            skill_hits = [
                hit
                for hit in (
                    ctx.action("observe.match_asset", asset=SKILL_ITEM_ASSET, region=SHOP_ITEM_REGION)
                    or []
                )
                if hit.get("centerxy")
            ]
            shelf = (cards, labels, skill_hits, blocked)
            shelf_cost = cost
            ctx.log(
                f"第{round_index}轮：商品区一次 OCR 读出 {len(cards)} 张商品卡、"
                f"{len(labels)} 个 Purchased 标签、{len(blocked)} 个 Not Enough Cost 标签、"
                f"{len(skill_hits)} 个技能替换价格图标，"
                "Refresh 或买入商品之前复用这份结果"
            )
            if blocked:
                # 买不起的位置每帧都可能出现，属于正常识别细节，按 debug 记录（开发者要求）
                ctx.log(
                    f"商品区有 {len(blocked)} 个位置显示 Not Enough Cost（Cost 不够买），"
                    "这些卡读不出商品名、也点不开详情，本次不当作待处理商品",
                    level="debug",
                )
        cards, labels, skill_hits, blocked = shelf

        # 未买下的技能替换位置（不管是否处理过）是自动刷新的依据之一；开关关闭时不再看它
        unbought_skill = (
            [hit for hit in skill_hits if not _labeled(labels, hit["centerxy"])]
            if buy_skills
            else []
        )
        skill_record = _record(ctx, SKILL_HANDLED_KEY)
        pending_skill = [
            hit for hit in unbought_skill if not _recorded(skill_record, hit["centerxy"])
        ]
        if pending_skill:
            refresh_hits = 0
            ctx.log(
                f"第{round_index}轮：商品区还有 {len(pending_skill)} 个未处理的技能替换商品，"
                "本次调用先从商品名读出罪人：本队没勾选就跳过，需要买才开弹窗并走完选择页→成交确认页"
            )
            ctx.call("step.mirror_shop_skill_replace")
            # 成交会扣 Cost，下一次读到更小的 Cost 时再重新识别商品区；没成交就继续复用它
            continue

        unbought_gift = [card for card in cards if buy_gifts and not card[3]]
        pending_gift = _pending_gifts(ctx, unbought_gift)
        if gift_decided_elsewhere:
            pending_gift = [
                entry for entry in pending_gift if _norm(entry[2]) not in gift_decided_elsewhere
            ]
        if pending_gift:
            refresh_hits = 0
            _gift_round(ctx, gift_state)
            ctx.log(
                f"第{round_index}轮：商品区还有 {len(pending_gift)} 个未处理的饰品商品，"
                "本次用这一次 OCR 一次决定买与不买，只点一次 Purchase；到手弹窗留到下一轮重新观察"
            )
            result = ctx.call("step.mirror_shop_gift_pick") or {}
            ctx.log(
                f"第{round_index}轮：饰品商品 Step 返回 {result.get('action')}"
                f"（买入 {result.get('bought')}、不买 {result.get('excluded')}、"
                f"待买 {result.get('pending')}）"
            )
            if (
                _count(result.get("bought")) == 0
                and _count(result.get("excluded")) == 0
                and _count(result.get("pending")) == 0
            ):
                # Step 对整排商品一个决定都没做（买入、不买、待买都是 0）：这些位置它那边已经处理过，
                # 只是两次 OCR 读出的名字不同。按已处理记下来，继续刷新决策，不重复派发同一批位置。
                drifted = [entry[2] for entry in pending_gift]
                gift_decided_elsewhere.update(_norm(text) for text in drifted if _norm(text))
                ctx.log(
                    "本次待处理的饰品商品 "
                    + "; ".join(repr(text) for text in drifted)
                    + " 在饰品 Step 那边没有任何新的买／不买决定（买入 0、不买 0、待买 0）："
                    "这些位置上一次调用已经决定过，只是整屏 OCR 与商品区局部 OCR 读出的名字不同；"
                    "本次不再把它们当作待处理，继续刷新决策",
                    level="warning",
                    screenshot=True,
                )
            # 买走的饰品会移到最后、其余商品前移：这一帧的坐标不再完整可信，下一轮重新 OCR 商品区
            shelf = None
            continue

        # 当前商店的商品都处理过：一个都不剩（全部 Purchased）时不必再花 Cost 刷新；
        # 只剩买不起（Not Enough Cost）的位置没有买下时也不能算全部买下，继续走刷新决策
        if not unbought_skill and not unbought_gift and not blocked:
            ctx.log(
                f"当前商店没有需要继续处理的商品（技能替换 {len(skill_hits)} 个、饰品 {len(cards)} 个；"
                f"技能替换开关 {buy_skills}、购买饰品开关 {buy_gifts}），"
                "没有未买下的位置需要刷新，停止购买交回上层"
            )
            return {
                "completed": True,
                "reason": "商店商品已处理完",
                "stop": "all_purchased",
                "refreshed": str(refreshed),
            }

        # 技能替换没有未买下的位置（或开关已关闭），且购买饰品已关闭：没有需要继续购买的商品，不再刷新
        if not unbought_skill and not buy_gifts:
            ctx.log(
                "技能替换没有未买下的位置，且购买饰品已关闭：没有需要继续购买的商品，"
                "不再刷新，停止购买交回上层"
            )
            return {
                "completed": True,
                "reason": "没有需要继续购买的商品（购买饰品已关闭），不再刷新",
                "stop": "purchases_disabled",
                "refreshed": str(refreshed),
            }

        # 只有走到这里才需要花 Cost 刷新：阈值只在这里起作用，Cost 不高于阈值就不再刷新、退出
        if cost <= threshold:
            ctx.log(
                f"第{round_index}轮：当前商店的商品都处理过、需要刷新，但 Cost {cost} 不高于阈值 "
                f"{threshold}，不再刷新，退出购买循环交回上层"
                + (f"（另有 {len(blocked)} 个位置因 Cost 不够显示 Not Enough Cost）" if blocked else ""),
                screenshot=True,
            )
            return {
                "completed": True,
                "reason": "需要刷新但 Cost 不高于阈值，已停止刷新并退出购买循环",
                "stop": "threshold",
                "refreshed": str(refreshed),
            }

        # 「停止刷新的剩余饰品栏位」：刷新只为了饰品（技能替换没有未买下的栏位）时，
        # 未买下的饰品栏位（读得到名字但没买的卡＋Not Enough Cost 的卡）只剩不多于设置值个就停止——
        # 刷新只会重掷这几格，即使 Cost 高于阈值也不再花 Cost 重掷，直接退出购买循环交回上层离开商店。
        remaining_gift_slots = len(unbought_gift) + len(blocked)
        if not unbought_skill and stop_gift_slots > 0 and remaining_gift_slots <= stop_gift_slots:
            ctx.log(
                f"第{round_index}轮：当前商店的商品都处理过、需要刷新，"
                f"但未买下的饰品栏位只剩 {remaining_gift_slots} 个"
                f"（未买 {len(unbought_gift)} 个、Not Enough Cost {len(blocked)} 个），"
                f"不高于设置的停止刷新栏位 {stop_gift_slots}，"
                f"即使 Cost {cost} 高于阈值 {threshold} 也不再刷新，退出购买循环交回上层",
                screenshot=True,
            )
            return {
                "completed": True,
                "reason": "剩余未买下的饰品栏位不高于设置值，已停止刷新并退出购买循环",
                "stop": "gift_slots",
                "refreshed": str(refreshed),
                "remaining_gift_slots": str(remaining_gift_slots),
            }
        refresh_hits += 1
        if refresh_hits > MAX_REPEAT_HITS:
            raise ExecutionFailure(
                "workflow_branch_limit",
                f"连续 {MAX_REPEAT_HITS + 1} 次进入刷新分支，商品仍没有被重掷",
            )
        if unbought_skill:
            # ① 技能替换还有未买下的位置：用便宜的普通 Refresh 重掷
            refreshed += 1
            ctx.log(
                f"第{round_index}轮：当前商店的商品都处理过，还有 {len(unbought_skill)} 个未买下的"
                f"技能替换位置（未买下的饰品 {len(unbought_gift)} 个），Cost {cost} 高于阈值 "
                f"{threshold}，点击一次普通 Refresh 重掷"
            )
            ctx.call("step.mirror_shop_refresh")
            # 商品列表已重掷：清空本次商店已处理的位置记录，避免新商品沿用旧位置被跳过
            ctx.call("step.mirror_refresh_shop_state", in_shop=True)
            # 商品区换了一批：按名字记为「Step 已决定」的旧位置不再适用
            gift_decided_elsewhere.clear()
            # 商品列表已重掷：下一次必须重新做一次商品区 OCR
            shelf = None
            continue

        # ② 技能替换已经买完（没有位置了），饰品还有未买下的位置：用 Keyword Refresh
        # 按本队流派重掷，抬升本流派饰品出现的概率。第一段只打开弹窗，第二段选关键词并提交一次
        result = ctx.call("step.mirror_shop_keyword_refresh") or {}
        action = str(result.get("action") or "")
        if action == "refresh_clicked":
            refreshed += 1
            # 关键词刷新同样重掷整个商品列表：清空已处理位置记录并重新识别商品区，
            # 免费刷新不扣 Cost，因此不按 Cost 变化验收刷新是否生效
            ctx.call("step.mirror_refresh_shop_state", in_shop=True)
            gift_decided_elsewhere.clear()
            shelf = None
            continue
        if action in ("popup_opened", "popup_closed", "refresh_unconfirmed"):
            # 弹窗刚打开但本次没提交、选关键词后弹窗反而关掉、或已经点过弹窗里的 Refresh：
            # 都不再重复输入，下一轮重新观察弹窗与 Cost
            ctx.log(
                f"第{round_index}轮：Keyword Refresh 弹窗状态 {action}，本次不重复输入，下一轮重新观察"
            )
            continue
        # 没有可用流派关键词、弹窗没打开或被别的弹窗挡住：退回普通 Refresh 继续买，不让购买停在这里
        ctx.log(
            f"第{round_index}轮：Keyword Refresh 不可用（{action}），改点一次普通 Refresh 重掷",
            level="warning",
            screenshot=True,
        )
        refreshed += 1
        ctx.call("step.mirror_shop_refresh")
        ctx.call("step.mirror_refresh_shop_state", in_shop=True)
        gift_decided_elsewhere.clear()
        shelf = None
        continue

    ctx.log(
        f"购买循环达到 {MAX_ROUNDS} 轮上限，停止购买交回上层（刷新 {refreshed} 次）",
        level="warning",
        screenshot=True,
    )
    return {
        "completed": True,
        "reason": "购买轮数达上限，已停止购买",
        "stop": "rounds",
        "refreshed": str(refreshed),
    }
