"""Run 开始时确认游戏已离开标题界面，供 plan 最先调用。"""
from lalc import RunContext, task_workflow

TITLE_ASSET = "restart/clear_all_caches"


def _title_hits(ctx: RunContext) -> list[dict]:
    """在当前帧匹配标题界面的 Clear all caches 特征，返回全部命中。"""
    return list(ctx.action("observe.match_asset", asset=TITLE_ASSET) or [])


@task_workflow
def execute(ctx: RunContext) -> dict[str, str]:
    """调用一次就绪检查 Step，再自行重新截图判断是否仍有标题特征或已进入正常过渡。"""
    ctx.call("step.check_game_ready")
    meta = ctx.action("observe.capture_screen")
    if _title_hits(ctx):
        ctx.log("点击后标题特征仍在，游戏尚未离开标题界面", level="warning")
        return {"completed": "false", "reason": "title_still_visible"}
    # 离开标题界面后会进入加载过渡（Connecting／Combat Tips／Now Loading），
    # 交给通用过渡检测统一判定，本 Task 不再维护第二份 Connecting 区域与关键词
    if ctx.call("step.detect_normal_transition", width=meta["width"], height=meta["height"]):
        ctx.log("识别到正常过渡标识，已离开标题界面")
        return {"completed": "true", "reason": "transition"}
    ctx.log("未检测到标题特征，也没有进入正常过渡，按已离开标题界面处理")
    return {"completed": "true", "reason": "title_gone"}
