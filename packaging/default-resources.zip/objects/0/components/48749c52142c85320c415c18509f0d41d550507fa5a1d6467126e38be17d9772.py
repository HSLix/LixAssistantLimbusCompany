"""只读识别当前帧，供 Workflow 在业务分派前选择通用等待。"""

from lalc import ExecutionFailure, RunContext, step

# 区域按 1280×720 设计基准给出，实际客户端分辨率不同时按比例换算
DESIGN_WIDTH = 1280
DESIGN_HEIGHT = 720
# 拦截性网络错误弹窗的居中区域
SERVER_ERROR_BOX = (380, 270, 520, 150)
# 正常加载的三处提示区域与关键词；区域与关键词保持不变，
# 只是把原来的四次局部 OCR 合并为一次全屏 OCR，再按区域筛选内容
LOADING_BOXES = (
    ((1000, 0, 250, 120), ("connecting",)),
    ((780, 120, 500, 480), ("combat", "tips")),
    ((900, 600, 380, 120), ("nowloading",)),
)


def _scaled(box: tuple[int, int, int, int], width: int, height: int) -> dict[str, int]:
    """把 1280×720 设计坐标换算成当前客户端分辨率下的观察区域。"""
    x, y, box_width, box_height = box
    return {
        "x": x * width // DESIGN_WIDTH,
        "y": y * height // DESIGN_HEIGHT,
        "width": max(1, box_width * width // DESIGN_WIDTH),
        "height": max(1, box_height * height // DESIGN_HEIGHT),
    }


def _center(item) -> tuple[float, float]:
    """取一条 OCR 结果的中心坐标：优先用 centerxy，缺省时用 box 推算。"""
    center = item.get("centerxy")
    if center:
        return float(center[0]), float(center[1])
    box = item.get("box") or {}
    return (
        float(box.get("x", 0)) + float(box.get("width", 0)) / 2,
        float(box.get("y", 0)) + float(box.get("height", 0)) / 2,
    )


def _text(items, region: dict[str, int]) -> str:
    """从一次全屏 OCR 结果里筛出中心落在该区域的条目，忽略空白及标点。"""
    left = region["x"]
    top = region["y"]
    right = left + region["width"]
    bottom = top + region["height"]
    texts = []
    for item in items:
        center_x, center_y = _center(item)
        if left <= center_x < right and top <= center_y < bottom:
            texts.append(str(item.get("text", "")))
    return "".join(char for char in "".join(texts).lower() if char.isalnum())


def _own_items(ctx: RunContext) -> list:
    """自己识别一次：observe.ocr 读当前内存帧，本步不换帧。"""
    return (ctx.action("observe.ocr") or {}).get("items") or []


def _items(ctx: RunContext, texts=None, centers=None) -> list:
    """
    取全屏 OCR 的文字项：上层给了（文字, 中心点）两组平行列表就复用，否则自己识别当前帧一次。
    只在两组长度一致时复用；不一致说明上层拼错了，记 warning 后自己识别，避免把错位坐标当结论。
    """
    if texts is None and centers is None:
        return _own_items(ctx)
    if not isinstance(texts, list) or not isinstance(centers, list) or len(texts) != len(centers):
        ctx.log(
            "传入的 OCR 文字与中心点不是等长列表，本步退回自己识别当前帧",
            level="warning",
        )
        return _own_items(ctx)
    ctx.log("复用上层提供的 OCR 文字与中心点，本步不再重复识别", level="debug")
    items = []
    for text, center in zip(texts, centers):
        if isinstance(center, list) and len(center) >= 2:
            items.append({"text": text, "centerxy": [center[0], center[1]]})
    return items


def _waiting(ctx: RunContext, width: int, height: int, texts=None, centers=None) -> bool:
    """一次全屏 OCR 覆盖原文四处局部识别，再按区域与关键词先查错误弹窗、再查正常加载。"""
    items = _items(ctx, texts, centers)
    if "servererror" in _text(items, _scaled(SERVER_ERROR_BOX, width, height)):
        raise ExecutionFailure("server_error_popup", "检测到 Server Error 弹窗")
    for box, words in LOADING_BOXES:
        text = _text(items, _scaled(box, width, height))
        if all(word in text for word in words):
            return True
    return False


@step
def execute(
    ctx: RunContext,
    *,
    width: int,
    height: int,
    ocr_texts: list[str] | None = None,
    ocr_centers: list[list[int]] | None = None,
) -> bool:
    """读取 Workflow 本轮截图（不换帧），用一次全屏 OCR 按区域筛选判断加载与错误。

    ocr_texts／ocr_centers 可选：上层把本轮整屏 observe.ocr 的 items 拆成两组平行列表传入
    （文字列表与中心点列表，下标一一对应），本步就不再自己识别，直接按 SERVER_ERROR_BOX 与
    LOADING_BOXES 筛选这份结果；两者缺省时自己调用一次全屏 observe.ocr。
    拆成两组平行列表是因为 execute 的输入只允许同构 JSON 容器，而 items 每项含 text/score/
    box/polygon/centerxy 等混合类型字段，无法用合法注解表达（Run 604 的
    dict[str, list[dict[str, float]]] 就是被输入校验拒绝）。
    传入时必须与 width/height 来自同一帧（中心点坐标相对完整客户区），否则区域筛选会错位；
    两组列表长度不一致时记 warning 并退回自己识别。
    """
    return _waiting(ctx, width, height, ocr_texts, ocr_centers)

