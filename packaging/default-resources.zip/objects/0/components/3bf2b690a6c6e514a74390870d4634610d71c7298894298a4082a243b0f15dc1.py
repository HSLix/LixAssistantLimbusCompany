"""镜牢饰品选择编排：读镜牢使用队伍的镜牢配置 → 左选流派 → 右侧按顺序点饰品 → Select/Refuse Gift。"""
import re

from lalc import RunContext, sub_workflow, ExecutionFailure

# 镜牢设置页保存本次镜牢使用第几个队伍；队伍配置页保存每个队伍各自的镜牢饰品配置
MIRROR_PAGE_ID = "mirror.settings"
TEAM_PAGE_ID = "sinners.team_presets"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
KEYWORD_KEY = "gift_keyword"
ORDER_KEY = "gift_slot_order"
KEYWORD_NONE = "none"
MAX_SLOTS = 3
GIFT_ASSET = "mirror/gift_select"
# 底部按钮区域：Selected E.G.O Gift 模板失效时用 Refuse Gift 文字兜底识别本页
BOTTOM_REGION = {"x": 760, "y": 550, "width": 480, "height": 80}
# 右侧 Selected E.G.O Gift 标题下方区域：选好流派后这里显示该流派的饰品
RIGHT_REGION = {"x": 770, "y": 220, "width": 470, "height": 290}
# 未选流派时该区域只有暗色空槽位图标，OCR 会吐出 D／0／K 这类低分单字符噪声；
# 真实饰品名与标题的分数量级在 0.9 以上，因此只认高分且成词的文字
RIGHT_TEXT_MIN_SCORE = 0.75
RIGHT_TEXT_MIN_LENGTH = 3
# 底部 Select 右侧的 已选/上限 计数（自 step.mirror_gift_pick 复制）
COUNTER_PATTERN = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s*$")
# 本次饰品选择的逐屏扫描进度与 step.mirror_gift_open_category 共用，记录在 RunState.settings
MIRROR_RUNTIME_KEY = "mirror.runtime"
GIFT_SCAN_EXHAUSTED_KEY = "gift_scan_exhausted"
GIFT_SCAN_STARTED_KEY = "gift_scan_started"
# 本场镜牢实际使用的队伍记在 mirror.runtime.team_used 里（task.mirror 进场时写入，已是游戏队伍槽位号）：
# 镜牢队伍按设置页的循环顺序逐场轮换，设置页的 mirror_team 只是循环里的第一支，不能代表本场队伍
# （Run 417：轮换到第 2 个队伍，饰品流派却按第 1 个队伍读取）
TEAM_USED_KEY = "team_used"
# 流派列表逐屏扫描的步数上限：逐屏推进不是同一分支死循环，用独立上限防止拖动无效时空转
MAX_GIFT_SCAN_STEPS = 12


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响按钮文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _slot_number(value) -> int:
    """把配置里的序号转成整数，非法值返回 0。"""
    text = str(value).strip()
    return int(text) if text.isdigit() else 0


def _team_index(ctx: RunContext) -> int:
    """本场镜牢实际使用的队伍序号：只读 mirror.runtime.team_used；缺失时按第 1 个队伍处理。"""
    runtime = (ctx.run_state.settings or {}).get(MIRROR_RUNTIME_KEY)
    used = runtime.get(TEAM_USED_KEY) if isinstance(runtime, dict) else None
    if type(used) is int and 1 <= used <= MAX_TEAMS:
        return used
    ctx.log(
        f"没有可用的本场队伍记录 {TEAM_USED_KEY}={used!r}，按第{DEFAULT_TEAM}个队伍处理",
        level="warning",
    )
    return DEFAULT_TEAM


def _team_entry(ctx: RunContext, team_index: int) -> dict:
    """取队伍配置页里第 team_index 个队伍保存的镜牢配置，缺失时按未配置处理。"""
    page = (ctx.run_state.settings or {}).get(TEAM_PAGE_ID) or {}
    teams = page.get("teams")
    if not isinstance(teams, list) or not 1 <= team_index <= len(teams):
        ctx.log(f"队伍配置里没有第{team_index}个队伍，本次按未配置饰品处理", level="warning")
        return {}
    entry = teams[team_index - 1]
    return entry if isinstance(entry, dict) else {}


def _config(ctx: RunContext) -> tuple[int, str, list[int]]:
    """读取镜牢使用队伍的饰品流派与点击顺序，非法值按未配置处理。"""
    team_index = _team_index(ctx)
    entry = _team_entry(ctx, team_index)
    keyword = str(entry.get(KEYWORD_KEY) or KEYWORD_NONE).strip().lower()
    order: list[int] = []
    raw = entry.get(ORDER_KEY)
    if isinstance(raw, list):
        for value in raw:
            slot = _slot_number(value)
            if 1 <= slot <= MAX_SLOTS and slot not in order:
                order.append(slot)
    return team_index, keyword, order[:MAX_SLOTS]


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _in_region(item: dict, region: dict[str, int]) -> bool:
    """该 OCR 条目的中心是否落在给定区域。"""
    center = item.get("centerxy") or (0, 0)
    x, y = int(center[0]), int(center[1])
    return (
        int(region["x"]) <= x <= int(region["x"]) + int(region["width"])
        and int(region["y"]) <= y <= int(region["y"]) + int(region["height"])
    )


def _region_texts(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回规范化小写文本；不刷新截图。"""
    texts = [_norm(item.get("text", "")) for item in items if _in_region(item, region)]
    return " ".join(text for text in texts if text)


def _on_gift_page(ctx: RunContext, items: list[dict]) -> bool:
    """当前是否仍在饰品选择页：优先 Selected E.G.O Gift 模板，其次 Refuse Gift 文字。"""
    if ctx.action("observe.match_asset", asset=GIFT_ASSET):
        return True
    return "refusegift" in _region_texts(items, BOTTOM_REGION)



def _reset_gift_scan(ctx: RunContext) -> None:
    """每次进入饰品选择时复位逐屏扫描进度：从顶部重新起步，允许重新判断是否到底。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法复位流派列表扫描进度", level="warning")
        return
    runtime = settings.get(MIRROR_RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[GIFT_SCAN_STARTED_KEY] = False
    runtime[GIFT_SCAN_EXHAUSTED_KEY] = False
    settings[MIRROR_RUNTIME_KEY] = runtime


def _gift_scan_exhausted(ctx: RunContext) -> bool:
    """本次饰品选择的流派列表是否已被判定滚到底部且仍未找到配置的流派。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        return False
    runtime = settings.get(MIRROR_RUNTIME_KEY)
    if not isinstance(runtime, dict):
        return False
    return bool(runtime.get(GIFT_SCAN_EXHAUSTED_KEY))


def _right_text(items: list[dict]) -> tuple[str, float]:
    """
    从本轮整屏 OCR 结果里筛出右侧饰品区域，返回（可用文字合并结果, 全部条目的最高分），不刷新截图。
    只保留分数不低于 RIGHT_TEXT_MIN_SCORE 且规范化后不少于 RIGHT_TEXT_MIN_LENGTH 个字符的条目，
    避免把未选流派时空槽位图标的单字符噪声当成饰品内容。
    """
    texts: list[str] = []
    best_score = 0.0
    for item in items:
        if not _in_region(item, RIGHT_REGION):
            continue
        text = _norm(item.get("text", ""))
        score = float(item.get("score") or 0.0)
        best_score = max(best_score, score)
        if score < RIGHT_TEXT_MIN_SCORE or len(text) < RIGHT_TEXT_MIN_LENGTH:
            continue
        texts.append(text)
    return " ".join(texts), best_score


def _category_selected(ctx: RunContext, items: list[dict]) -> bool:
    """
    右侧是否已显示流派饰品内容：只认高分成词文字，有内容才算流派已选中。
    未选流派时右侧是暗色空槽位，OCR 噪声不得当成内容，否则会跳过 step.mirror_gift_open_category。
    """
    text, best_score = _right_text(items)
    if text:
        return True
    ctx.log(
        f"右侧饰品区没有可用的高分文字（最高分 {best_score:.2f}，阈值 {RIGHT_TEXT_MIN_SCORE}），"
        "判定流派尚未选中",
        level="info",
    )
    return False


def _counter(items: list[dict]) -> tuple[int, int] | None:
    """从本轮整屏 OCR 结果里筛出底部按钮区域，解析 Select 右侧的 已选/上限；读不到时返回 None。"""
    for item in items:
        if not _in_region(item, BOTTOM_REGION):
            continue
        match = COUNTER_PATTERN.match(str(item.get("text") or ""))
        if match:
            return int(match.group(1)), int(match.group(2))
    return None


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    观察驱动的饰品选择编排：每轮先截图，再按当前画面选一个推进动作，动作后回到顶部重新观察。
    不在饰品页 → 返回 left；未配置流派或顺序 → 调 gift_submit(selected=0) 放弃；
    右侧还没有流派饰品内容 → 调 gift_open_category 选一次流派（从顶部起步后只向下逐屏推进，
    到底仍未找到则按 mirror_gift_category_not_found 失败）；
    读不到 Select 计数 → 按已选满提交一次（避免反复点击把已选取消）；
    已选未满 → 调 gift_pick 按配置点一次饰品；已选已满 → 调 gift_submit(已选数) 提交。
    各动作 Step 不返回结果，所有判断都来自本轮截图与 OCR；保留 30 轮与 hit()。
    """
    team_index, keyword, order = _config(ctx)
    ctx.log(f"饰品选择开始：第{team_index}个队伍，流派 {keyword}，顺序 {order}")
    # 每次进入饰品选择都是新的一份列表，复位逐屏扫描进度后由 step 从顶部重新起步
    _reset_gift_scan(ctx)
    unconfigured = not order or keyword in ("", KEYWORD_NONE)
    scan_index = 0
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, 30 + 1):
        meta = ctx.action("observe.capture_screen")
        # 每轮只做一次整屏 OCR：底部按钮区与右侧饰品区的文字都从这份结果里过滤
        items = _screen_items(ctx)
        if not _on_gift_page(ctx, items):
            return {"completed": True, "reason": "已离开饰品选择页", "page": "left"}

        if unconfigured:
            hit("skip-gifts")
            ctx.log(f"第{round_index}轮：未配置流派或顺序，提交一次放弃饰品")
            ctx.call("step.mirror_gift_submit", selected=0)
            continue

        if not _category_selected(ctx, items):
            if _gift_scan_exhausted(ctx):
                raise ExecutionFailure(
                    "mirror_gift_category_not_found",
                    f"流派列表已从顶部逐屏滚到最底部仍未找到配置的流派 {keyword}",
                )
            scan_index += 1
            if scan_index > MAX_GIFT_SCAN_STEPS:
                raise ExecutionFailure(
                    "workflow_rounds_exhausted",
                    f"流派列表连续 {MAX_GIFT_SCAN_STEPS} 次逐屏扫描仍未找到配置的流派 {keyword}",
                )
            # 逐屏扫描不是同一分支死循环，按屏序号计数，由总轮次与到底判定兜底
            hit(f"gift_scan_{scan_index}")
            ctx.log(f"第{round_index}轮：右侧还没有流派饰品内容，选一次流派 {keyword}")
            ctx.call("step.mirror_gift_open_category", keyword=keyword)
            continue

        counter = _counter(items)
        if counter is None:
            hit("submit-gifts")
            ctx.log(f"第{round_index}轮：读不到 Select 计数，按已选满提交一次")
            ctx.call("step.mirror_gift_submit", selected=len(order))
            continue
        selected, limit = counter
        if selected < limit:
            hit("step.mirror_gift_pick")
            ctx.log(f"第{round_index}轮：已选 {selected}/{limit} 未满，按配置点一次饰品")
            ctx.call("step.mirror_gift_pick", slots=order)
            continue
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            # 通用等待是循环最后一个分支：复用本轮整屏 OCR（文字＋中心点），不再让检测 Step 重复识别一次
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        hit("submit-gifts")
        ctx.log(f"第{round_index}轮：已选 {selected}/{limit} 已满，提交一次")
        ctx.call("step.mirror_gift_submit", selected=selected)
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
