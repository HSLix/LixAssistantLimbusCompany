"""镜牢入口编排：识别 Drive／入口页／中央弹窗，每轮只调一次动作 Step，落点重新观察。"""
from lalc import ExecutionFailure, RunContext, sub_workflow

DRIVE_ASSET = "drive/inferno"
ENTRY_ASSET = "mirror/entry"
TEAM_ASSET = "mirror/team_select"
PATH_ASSET = "mirror/train_head"
STAR_ASSET = "mirror/star"
GIFT_ASSET = "mirror/gift_select"
# 战斗结算页（Defeat / Victory）：从主界面经 Drive → 入口 → Dungeon Progress 回到一场进行中的镜牢时，
# 可能直接落在结算页上（Run 490：确认 Dungeon Progress 后停在 Defeat 结算页，本子流程没有这个分支，
# 连续四轮 unknown 直接失败）。两个结算页都属于镜牢内，识别到就交回 task.mirror 分派。
DEFEAT_ASSET = "battle/defeat"
VICTORY_ASSET = "battle/victory"

BEFORE_TEXT = "before entry"
EXPLORING_TEXT = "exploring"
CONFIRM_TEXT = "will you enter"
PROGRESS_TEXT = "dungeon progress"
# 镜牢内的商店页（Run 642 现场 642/254~642/256）：从主界面经 Drive → 入口 → Dungeon Progress
# 回到一场进行中的镜牢时可能直接落在商店页上，本子流程原来没有这个页面，连续四轮 unknown 撞分支上限。
# 标识按开发者要求用左下角三个页签 Enhance Gifts／Fuse Gifts／Sell Gifts：
# 三者中心分别为 (177,385)/(296,386)/(414,385)，命中两颗以上即算商店页；
# 识别到就交回 task.mirror，由它的商店分支处理购买／自维护／离开。
SHOP_TABS_REGION = {"x": 130, "y": 360, "width": 330, "height": 60}
SHOP_TAB_KEYWORDS = ("enhance", "fuse", "sell")
MIN_SHOP_TABS = 2

# 客户区固定 1280x720：入口页右上角 Exploring 信息栏、中央弹窗区域、主题包页标题
INFO_REGION = {"x": 890, "y": 130, "width": 320, "height": 55}
POPUP_REGION = {"x": 420, "y": 175, "width": 440, "height": 365}
# 主题包选择页标题 SELECT FLOOR n THEME PACK
PACK_HEADER_REGION = {"x": 470, "y": 92, "width": 340, "height": 56}
# 镜牢内的事件叙述页（REC 黑底画面 + 右下角 SKIP）：既没有入口页右上角信息栏，也没有寻路火车头模板，
# 只用右下角按钮区的 SKIP 文字兜底，说明已经进入镜牢，交回 task.mirror 由事件子流程推进（Run 341）
BUTTON_STRIP = {"x": 860, "y": 420, "width": 420, "height": 300}
SKIP_KEYWORD = "skip"
# 上一次探索结束时留在镜牢入口页上的 Exploration Reward 结算弹窗（Run 639 现场：每周记录重置结束后，
# 入口页中央盖着 Exploration Reward 弹窗，抱 Give Up Rewards / To List / Claim 三个按钮，背景的
# Enter 与入口模板都被遮住）。本子流程只负责进副本，但这个弹窗不处理就永远进不去，连续四轮 unknown 失败。
# 识别到就交 step.mirror_exploration_reward 按 reward_rules 推进一步（last_result=unknown 时为 give_up，
# 不消费刚重置的周常加成），弹窗关闭后继续正常的入口页流程。
REWARD_POPUP_REGION = {"x": 210, "y": 90, "width": 850, "height": 520}
REWARD_TITLE_KEYWORD = "explorationreward"
REWARD_GIVE_UP_LABEL = "giveuprewards"
REWARD_CLAIM_LABEL = "claim"
# 点 Give Up Rewards 后的二次确认弹窗（End expedition without claiming rewards）也在这个区域里
REWARD_END_KEYWORD = "endexpeditionwithoutclaimingrewards"


def _theme_page(items: list[dict]) -> bool:
    """主题包选择页特征：标题区域同时出现 SELECT FLOOR 与 THEME PACK。"""
    compact = _region_texts(items, PACK_HEADER_REGION).replace(" ", "")
    return "selectfloor" in compact and "themepack" in compact


def _reward_dialog(items: list[dict]) -> bool:
    """
    入口页上是否盖着 Exploration Reward 结算弹窗（或其二次确认弹窗）：
    标题 Exploration Reward、Give Up Rewards + Claim 两个按钮，或 End expedition without claiming rewards 任一命中。
    """
    text = _region_texts(items, REWARD_POPUP_REGION).replace(" ", "")
    if REWARD_END_KEYWORD in text:
        return True
    if REWARD_TITLE_KEYWORD in text:
        return True
    return REWARD_GIVE_UP_LABEL in text and REWARD_CLAIM_LABEL in text


def _page(ctx: RunContext, items: list[dict]) -> str:
    """
    判断当前页面：reward（入口页上的 Exploration Reward 结算弹窗）、drive、entry、team、path、star、gift、
    left（已离开饰品选择页）、shop（镜牢内的商店页）、defeat、victory（战斗结算页）、
    event（镜牢内的节点叙述页）或 unknown。
    以模板为主；饰品选择页、主题包页、商店页用模板加区域文字确认；
    入口页被弹窗遮挡或变暗时，用右上角信息栏文字兜底。
    """
    # 【优先级】上一次探索留下的 Exploration Reward 结算弹窗盖住入口页：不先识别就会一直落到 unknown，
    # 本子流程永远进不了副本（Run 639：第 6~8 轮连续 unknown 后撞分支上限）
    if _reward_dialog(items):
        return "reward"
    if ctx.action("observe.match_asset", asset=ENTRY_ASSET):
        return "entry"
    # 入口页的 Rental 按钮与 Drive 页右上角 Inferno 横幅同处一个区域，先认入口页再认 Drive，
    # 避免已到入口页却被判回 drive 而反复点同一个按钮（Run 352）
    if ctx.action("observe.match_asset", asset=DRIVE_ASSET):
        return "drive"
    if ctx.action("observe.match_asset", asset=TEAM_ASSET):
        return "team"
    if ctx.action("observe.match_asset", asset=PATH_ASSET):
        return "path"
    if ctx.action("observe.match_asset", asset=STAR_ASSET):
        return "star"
    if ctx.action("observe.match_asset", asset=GIFT_ASSET):
        return "gift"
    # 结算页同样属于镜牢内：这里是刚回到一场进行中的镜牢时最先可能看到的页面
    if ctx.action("observe.match_asset", asset=DEFEAT_ASSET):
        return "defeat"
    if ctx.action("observe.match_asset", asset=VICTORY_ASSET):
        return "victory"
    # 镜牢内的商店页：左下角三个页签命中两颗以上就交回 task.mirror（标识说明见 SHOP_TABS_REGION）
    shop_tabs = sum(
        1 for keyword in SHOP_TAB_KEYWORDS if keyword in _region_texts(items, SHOP_TABS_REGION)
    )
    if shop_tabs >= MIN_SHOP_TABS:
        return "shop"
    if _theme_page(items):
        return "left"
    info = _region_texts(items, INFO_REGION)
    if EXPLORING_TEXT in info or "rental" in info:
        return "entry"
    # 进入镜牢后的节点叙述页：只认右下角 SKIP，命中即算已在镜牢内，不再累计无效轮
    if SKIP_KEYWORD in _region_texts(items, BUTTON_STRIP):
        return "event"
    return "unknown"


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _in_region(item: dict, region: dict[str, int]) -> bool:
    """该 OCR 条目的中心是否落在给定区域。"""
    center = item.get("centerxy") or (0, 0)
    x, y = int(center[0]), int(center[1])
    return (
        int(region["x"]) <= x <= int(region["x"]) + int(region["width"])
        and int(region["y"]) <= y <= int(region["y"]) + int(region["height"])
    )


def _region_texts(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回合并后的小写文本；不刷新截图。"""
    texts = [str(item.get("text", "")) for item in items if _in_region(item, region)]
    return " ".join(text for text in texts if text).lower()


def _popup_items(items: list[dict]) -> list[dict]:
    """从本轮整屏 OCR 结果里筛出中央弹窗区域的条目。"""
    return [item for item in items if _in_region(item, POPUP_REGION)]


def _popup_kind(items: list[dict]) -> str:
    """判断中央弹窗类型：progress（进度弹窗）、confirm（进入确认）或 none。"""
    text = " ".join(str(item.get("text", "")) for item in _popup_items(items)).lower()
    if PROGRESS_TEXT in text:
        return "progress"
    if CONFIRM_TEXT in text:
        return "confirm"
    return "none"


# 点击 Drive 导航后，客户端切到 Drive 页可能比下一轮观察更慢（Run 625：仍停在 Window 主界面约 6 秒，
# 三次点击后第 4 次命中分支直接判失败，故障后现场已经是 Drive 页），因此点击后在分支内做一次有界等待：
# 只有看到 Drive 页／入口页特征才提前结束，等待预算用完就交回循环顶部重新观察，不叠加上一次点击。
DRIVE_WAIT_ROUNDS = 5
DRIVE_WAIT_SECONDS = 1.0


def _wait_drive_page(ctx: RunContext) -> bool:
    """点击 Drive 导航后短等观察：出现 Drive 页或入口页特征返回 True，等待预算用完返回 False。"""
    for _ in range(DRIVE_WAIT_ROUNDS):
        ctx.action("observe.capture_screen")
        if ctx.action("observe.match_asset", asset=DRIVE_ASSET) or ctx.action(
            "observe.match_asset", asset=ENTRY_ASSET
        ):
            return True
        ctx.action("observe.wait", seconds=DRIVE_WAIT_SECONDS)
    return False


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """优先等待正常过渡，再有界分派；同一分支连续第四次命中或总预算耗尽时失败。"""
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, 20 + 1):
        meta = ctx.action("observe.capture_screen")
        # 每轮只做一次整屏 OCR：中央弹窗、入口信息栏、右下角按钮区的文字都从这份结果里过滤
        items = _screen_items(ctx)
        popup = _popup_kind(items)
        if popup in ("progress", "confirm"):
            hit(popup)
            ctx.log(f"第{round_index}轮：中央已有 {popup} 弹窗，只执行一次确认点击")
            ctx.call("step.mirror_confirm_entry")
            continue
        # 正常加载／联网过渡必须先于页面分支处理：Run 637 里确认 Enter 后客户端进入 CONNECTING，
        # 但入口页模板与右上角信息栏仍在，页面分支每轮都命中 entry 并往中央点了四次，
        # 第 4 次在输入前触发分支上限失败；通用等待因此不能只在最后兜底。
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            # 复用本轮整屏 OCR（文字＋中心点），只清零同一分支的连续计数，不重置总预算
            previous_branch = ""
            consecutive_hits = 0
            ctx.log(f"第{round_index}轮：仍处于正常加载／联网过渡，先等待再看页面")
            ctx.call("step.wait_normal_transition")
            continue
        page = _page(ctx, items)
        if page == "reward":
            # 入口页上盖着 Exploration Reward 结算弹窗：每轮只调一次，弹窗关闭就回到入口页流程
            hit("step.mirror_exploration_reward")
            ctx.log(f"第{round_index}轮：入口页上有 Exploration Reward 结算弹窗，按 reward_rules 推进一步")
            ctx.call("step.mirror_exploration_reward")
            continue
        if page == "drive":
            hit("step.mirror_enter_from_drive")
            ctx.log(f"第{round_index}轮：在 Drive 页，只点一次镜牢入口")
            ctx.call("step.mirror_enter_from_drive")
            continue
        if page == "entry":
            hit("step.mirror_open_entry")
            ctx.log(f"第{round_index}轮：在入口页，只点一次入口按钮")
            ctx.call("step.mirror_open_entry")
            continue
        if page in ("team", "star", "gift", "left", "path", "event", "defeat", "victory", "shop"):
            return {"completed": True, "reason": "已在镜牢内", "page": page}
        if any(ctx.action("observe.match_asset", asset=asset) for asset in ("main_navigate/drive", "main_navigate/window", "main_navigate/window_selected")):
            hit("main_navigate/drive")
            ctx.log(f"第{round_index}轮：在主界面，点一次 Drive 导航")
            ctx.call("step.click_asset_until", click_asset="main_navigate/drive", success_assets=["drive/inferno"])
            if _wait_drive_page(ctx):
                ctx.log(f"第{round_index}轮：点击后已看到 Drive 页特征，回到循环顶部重新分派")
            else:
                ctx.log(
                    f"第{round_index}轮：点击后有界等待未出现 Drive 页特征，回到循环顶部重新观察",
                    level="warning",
                )
            continue
        hit("unknown")
        # 附上本轮截图：下次再有未识别页面时能直接看到现场，不用只靠重跑复现
        ctx.log(f"第{round_index}轮：未识别到可推进的镜牢页面，等待后重新观察", screenshot=True)
        ctx.action("observe.wait", seconds=1.0)
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
