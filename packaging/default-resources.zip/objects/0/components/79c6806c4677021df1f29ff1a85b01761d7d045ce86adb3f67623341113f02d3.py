"""对已分派的正常加载执行有界复查等待，不输入游戏，也不返回完成标记。"""
import time

from lalc import ExecutionFailure, RunContext, step

# 单次调用的等待预算：预算内每秒新截一帧复查，提示消失或预算到期都正常返回
WAIT_BUDGET_SECONDS = 30.0
# 每次复查之间的等待秒数；截图与识别耗时也计入预算，剩余不足一次整秒等待时不再开始新的等待
POLL_SECONDS = 1.0


def _text(ctx: RunContext, width: int, height: int, box: tuple[int, int, int, int]) -> str:
    """读取缩放后的当前帧区域，忽略 OCR 空白及标点。"""
    x, y, box_width, box_height = box
    region = {"x": x * width // 1280, "y": y * height // 720,
              "width": max(1, box_width * width // 1280), "height": max(1, box_height * height // 720)}
    items = ctx.action("observe.ocr", region=region)["items"]
    return "".join(char for item in items for char in item["text"].lower() if char.isalnum())


def _waiting(ctx: RunContext, width: int, height: int) -> bool:
    """先识别拦截性的网络错误，再识别正常加载。"""
    if "servererror" in _text(ctx, width, height, (380, 270, 520, 150)):
        raise ExecutionFailure("server_error_popup", "检测到 Server Error 弹窗")
    for box, words in (
        ((1000, 0, 250, 120), ("connecting",)),
        ((780, 120, 500, 480), ("combat", "tips")),
        ((900, 600, 380, 120), ("nowloading",)),
    ):
        text = _text(ctx, width, height, box)
        if all(word in text for word in words):
            return True
    return False


@step
def execute(ctx: RunContext) -> None:
    """
    预算内每秒新截图复查错误弹窗与加载标识：
    - 先复查当前帧，提示已消失就立即返回，不做无意义等待；
    - 仍在加载且剩余预算够一次整秒等待时 observe.wait 一秒后继续复查；
    - 提示消失、预算到期或剩余不足一次整秒等待都正常返回，不抛失败，
      由上层重新截图分派（等待是否结束不由本步的返回值证明）；
    - 等待期间识别到 Server Error 立即抛错交恢复规则，不继续等待。
    """
    started = time.monotonic()
    while True:
        meta = ctx.action("observe.capture_screen")
        if not _waiting(ctx, meta["width"], meta["height"]):
            return
        elapsed = time.monotonic() - started
        remaining = WAIT_BUDGET_SECONDS - elapsed
        if remaining < POLL_SECONDS:
            ctx.log(
                f"正常加载已等待约 {elapsed:.1f} 秒，达到 {WAIT_BUDGET_SECONDS:.0f} 秒等待预算，"
                "按预算到期正常交回上层重新截图分派",
                level="warning",
                screenshot=True,
            )
            return
        ctx.action("observe.wait", seconds=POLL_SECONDS)

