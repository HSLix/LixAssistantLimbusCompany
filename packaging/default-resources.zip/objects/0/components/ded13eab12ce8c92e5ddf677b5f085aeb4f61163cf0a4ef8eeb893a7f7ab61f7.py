"""镜牢 E.G.O Gift Search 饰品搜索页：只点一次右下角 Refuse Gift，再对出现的确认弹窗点一次 Confirm 退出。

开发者要求：进到饰品搜索页后不做任何挑选（不点流派、不点饰品、不花 Star），直接放弃退出。
本步只做「点 Refuse Gift → 确认弹窗」这一组固定动作；之后的页面（饰品选择页／主题包页等）
由 task.mirror 下一轮重新识别后分派，本步不猜落点、不轮询业务完成。
页面识别用左上角独有标题 E.G.O Gift Search（1280x720 现场实测文字框 (143,31)~(344,61)）：
饰品选择页同一位置是别的标题，而两页右上都有一模一样的 Selected E.G.O Gift 横幅
（素材 mirror/gift_select 在两页都会命中），搜索页卡片上还有与楼层饰品页相同的手形图标，
因此上层必须靠这句标题把搜索页单独分派出来，不能只靠共享横幅或手形模板。
现场 Run 661 实测：点 Refuse Gift 后弹出标题为 "Forgo E.G.O Gift Search?" 的确认框
（Cancel (529,496)、Confirm (782,496)），点 Confirm 后离开搜索页、进入主题包页（SELECT FLOOR n THEME PACK）。
"""
import re

from lalc import RunContext, step

# 左上角标题 E.G.O Gift Search：现场实测中心 (243,46)，区域只包这句标题，
# 避开右侧 Owned／Star 数字与下方流派图标行
TITLE_REGION = {"x": 130, "y": 20, "width": 260, "height": 55}
TITLE_KEYWORD = "egogiftsearch"
# 底部按钮带：Refuse Gift 中心 (922,575)、Select 与 Select 0/3 计数在同一行（现场实测）
BOTTOM_REGION = {"x": 760, "y": 540, "width": 480, "height": 80}
REFUSE_LABEL = "refusegift"
# 底部读不到 Refuse Gift 文字时的回退落点：饰品搜索页现场实测按钮中心
REFUSE_FALLBACK = (922, 575)
# 确认弹窗区域：与饰品选择页放弃选择同一类确认，区域与 Confirm 回退坐标跟
# step.mirror_gift_submit 保持一致；只在弹窗区域找 Confirm，不把底部 Refuse Gift／Select 当成确认按钮
POPUP_REGION = {"x": 330, "y": 160, "width": 630, "height": 410}
CONFIRM_LABEL = "confirm"
CONFIRM_FALLBACK = (765, 495)
# 放弃选择的确认弹窗标题：饰品搜索页实测是 "Forgo E.G.O Gift Search?"（1280x720 中心 (639,347)）；
# 饰品选择页放弃时是 "Continue without selecting…"，两条文案都认。
# 弹窗文案读不到时仍按弹窗区域里的 Confirm 按钮判定
ABANDON_KEYWORDS = ("forgoegogiftsearch", "continuewithoutselecting", "withoutselecting")
# 固定等待：点 Refuse 后确认弹窗有滑入动画，点 Confirm 后弹窗关闭与页面切换也要时间
OPEN_WAIT_SECONDS = 1.0
CONFIRM_WAIT_SECONDS = 1.0
# 点击 Refuse 后复查弹窗的次数：弹窗滑入需要时间，属于同一次局部尝试
POPUP_ATTEMPTS = 3
POPUP_POLL_SECONDS = 0.7


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响按钮文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本步的区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _in_region(item: dict, region: dict[str, int]) -> bool:
    """该 OCR 条目的中心是否落在给定区域。"""
    center = item.get("centerxy") or (0, 0)
    x, y = int(center[0]), int(center[1])
    return (
        int(region["x"]) <= x <= int(region["x"]) + int(region["width"])
        and int(region["y"]) <= y <= int(region["y"]) + int(region["height"])
    )


def _items_text(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回规范化小写文本；不刷新截图。"""
    texts = [_norm(item.get("text", "")) for item in items if _in_region(item, region)]
    return " ".join(text for text in texts if text)


def _label_center(
    items: list[dict], region: dict[str, int], label: str
) -> tuple[int, int] | None:
    """在指定区域里找文字等于 label 的条目，返回其中心；没有时返回 None。"""
    for item in items:
        if not _in_region(item, region):
            continue
        if _norm(item.get("text", "")) != label:
            continue
        center = item.get("centerxy")
        if center:
            return (int(center[0]), int(center[1]))
    return None


def _popup_kind(items: list[dict]) -> str:
    """
    当前帧的弹窗状态：abandon（读到放弃选择的确认文案）、confirm（弹窗区域里有 Confirm 按钮）、
    none（没有确认弹窗）。两种非空状态都表示本页被确认弹窗遮住，需要点一次 Confirm。
    """
    text = _items_text(items, POPUP_REGION)
    if any(keyword in text for keyword in ABANDON_KEYWORDS):
        return "abandon"
    return "confirm" if _label_center(items, POPUP_REGION, CONFIRM_LABEL) else "none"


POPUP_LABELS = {
    "abandon": "Forgo E.G.O Gift Search?／Continue without selecting… 放弃确认弹窗",
    "confirm": "未读到标题、只看到 Confirm 按钮的确认弹窗",
}


def _click_confirm(ctx: RunContext, items: list[dict], kind: str, note: str) -> None:
    """确认弹窗开着时点一次 Confirm：优先点识别到的按钮中心，读不到文字才用回退坐标。"""
    label = POPUP_LABELS.get(kind, "确认弹窗")
    center = _label_center(items, POPUP_REGION, CONFIRM_LABEL)
    if center is not None:
        ctx.log(f"{note}：识别到{label}，点击其中的 Confirm @ {center}", screenshot=True)
        ctx.action("control.click", centerxy=center)
    else:
        ctx.log(
            f"{note}：识别到{label}但没有读到 Confirm 文字，点击回退坐标 {CONFIRM_FALLBACK}",
            level="warning",
            screenshot=True,
        )
        ctx.action("control.click", x=CONFIRM_FALLBACK[0], y=CONFIRM_FALLBACK[1])
    ctx.action("observe.wait", seconds=CONFIRM_WAIT_SECONDS)


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    饰品搜索页放弃退出，一次调用最多点一次 Refuse Gift 和一次 Confirm：
    - 确认弹窗已经开着（上一次调用点了 Refuse 还没确认完）→ 只点一次 Confirm，不再点 Refuse；
    - 不在饰品搜索页（标题 E.G.O Gift Search 不成立）→ 零输入返回 skipped；
    - 在搜索页 → 点一次右下角 Refuse Gift（优先用 OCR 到的按钮中心，读不到文字才用现场回退落点），
      等 1 秒让确认弹窗滑入，再在本步内有界复查：看到弹窗就点一次 Confirm 后返回；
      整段复查都没看到弹窗时只记 warning 交回上层，不盲点回退坐标、不重放 Refuse。
    后续页面由 task.mirror 下一轮重新识别分派，本步不猜落点，也不在这里轮询业务完成。
    """
    ctx.action("observe.capture_screen")
    items = _screen_items(ctx)
    kind = _popup_kind(items)
    if kind != "none":
        _click_confirm(ctx, items, kind, "饰品搜索页的放弃确认弹窗已经开着")
        return {"action": "popup_confirmed", "popup": kind}

    if TITLE_KEYWORD not in _items_text(items, TITLE_REGION):
        ctx.log(
            "当前不是镜牢 E.G.O Gift Search 饰品搜索页，本步不做任何点击",
            level="warning",
            screenshot=True,
        )
        return {"action": "skipped"}

    center = _label_center(items, BOTTOM_REGION, REFUSE_LABEL)
    if center is None:
        center = REFUSE_FALLBACK
        ctx.log(
            f"底部没有读到 Refuse Gift 文字，按饰品搜索页现场回退落点 {center} 点击",
            level="warning",
        )
    ctx.log(f"饰品搜索页只点一次右下角 Refuse Gift {center}，不做任何挑选、不消耗 Star")
    ctx.action("control.click", centerxy=center)
    ctx.action("observe.wait", seconds=OPEN_WAIT_SECONDS)

    for attempt in range(1, POPUP_ATTEMPTS + 1):
        ctx.action("observe.capture_screen")
        items = _screen_items(ctx)
        kind = _popup_kind(items)
        if kind != "none":
            _click_confirm(ctx, items, kind, f"点击 Refuse Gift 后第{attempt}次复查")
            return {"action": "refuse_confirmed", "popup": kind}
        if attempt < POPUP_ATTEMPTS:
            ctx.action("observe.wait", seconds=POPUP_POLL_SECONDS)
    ctx.log(
        "点击 Refuse Gift 后没有在弹窗区域识别到确认弹窗，交回上层重新观察",
        level="warning",
        screenshot=True,
    )
    return {"action": "refuse_unconfirmed"}
