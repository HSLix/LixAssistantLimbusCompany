"""镜牢商店融合：每次调用按当前融合页推进一轮，优先做「现成融合」，否则点融合耗材。

现场（1280x720，Run 503~512）实测：
- Fusion Available 标签在右侧列表顶端（实测 y≈218~242）；标签下方这一行是「现成配方」卡，最多五张，
  与下方 E.G.O Gifts Owned 网格同列（列距约 90、左对齐面板内容左边 x≈645）。点中可融合的那张会自动
  把配方材料放进融合格并显示结果预测，此时 Fusion Available 消失、列表上移。
  2026-11-24 现场（Run 614 卡住的那一帧）实测：第一张卡上方显示红色 Cannot Fuse，点它没有任何反应，
  第二张卡点中才有 100% 预测；旧逻辑「只点标签下方第一张」因此会一轮轮空转。
  本步改为开发者要求的固定落点方案：不判断哪张能融合，从左往右依次点这一行的五个固定落点。
- 融合页左侧环形区域里还有一个空的「最后融合格」，素材 mirror/shop/fuse/final_fuse_place
  在它还在时空位命中（实测中心 (200,349)、分数 1.0）；点满材料后该空位消失。
- 右侧 Gifts Owned 列表里的礼物卡与售出弹窗的 mirror/gift/* 模板同尺寸（实测 68x73），
  mirror/gift 整组匹配在 0.85 阈值能命中当前屏的礼物卡（0.874~0.932）。
- 右侧网格实测为 3 行 x 5 列：卡片 68x73，列距 95（首列 x≈640），行距 91（首行 y≈220、
  第二行 311、第三行 402）。Run 524 原匹配区域从 y=240 起，首行整行被切掉（模板高 73，
  顶部被裁掉就无法对齐），首行礼物永远匹配不到；区域改为 y=205..575。
- 点过礼物卡后鼠标停在卡上会弹出 E.G.O GIFT 详情浮窗，盖住网格右半边：Run 524 同一页
  没有浮窗时整组命中 8 张（含 venomous_skin 0.908），浮窗出现后只剩左两列 3 张。
  因此每点完一张就点标题栏空点把光标移开、收起浮窗，再截屏复查左侧融合格。
- 右侧耗材只匹配一次（开发者要求）：调用开始时那一帧截图上把本帧所有耗材的坐标一次记下来，
  之后按坐标逐个点击；点完后的截图只用于看 final_fuse_place 是否消失（融合格是否塞满），
  不再重新匹配右侧列表，避免浮窗／选中高亮让第二帧漏识别。
- 点一张礼物卡会把它放进融合格，但礼物卡仍留在原位（只是加高亮），列表不会重排，
  所以同一帧预计算的多张卡坐标可以依次点击；每点一次都在左侧区域复查 final_fuse_place。
- 融合页底部 Fuse (804,586) 会打开确认弹窗，确认按钮文案为 Confirm。
  耗材路径沿用「Confirm 优先、读不到按一次 Enter 兜底」；Fusion Available 固定落点路径不按 Enter，
  因为要用「有没有确认弹窗」决定换下一个落点，读不到就按这个落点没有可融合配方处理。
- 点掉融合确认弹窗后游戏会弹出 E.G.O Gift GET! 到手弹窗，它盖住融合页：
  耗材路径沿用原来的交接方式（点完 Confirm 就清空耗材位置记录并交回融合循环，由
  sub_workflow.mirror_shop_fuse 识别到手弹窗后再确认）；
  Fusion Available 固定落点路径要在这里用同一素材 mirror/ego_gift_get 复查到手弹窗，
  因为它要靠「有没有真的融合」决定换落点、记 warning 还是返回成功。
- 右侧滚动条滑块与售出弹窗同一模板 mirror/shop/sell_gift_scroll_end（实测 0.983）。

Fusion Available 一行最多五个固定落点，每点一个落点就点一次 Fuse，出现融合确认弹窗才算这张可融合；
五个落点都不行就记一条带截图的 warning，并在本次会话跳过这一行，继续处理下方耗材。
耗材路径一次调用最多点 5 张耗材卡（Super Shop 上限），提前点满、final_fuse_place 消失时立即
点 Fuse 并确认融合；否则把已点的材料记录进运行时，交回上层继续匹配或滚动。
"""
import re

from lalc import RunContext, step

# 融合页标识：标题横幅用素材 mirror/shop/fuse/fuse_ego_gift（425x44）做原尺寸模板匹配，
# 不再读标题文字，也不再读右上角 Fusion Guide 文字（与 step.mirror_shop_fuse_open 一致）。
FUSE_TITLE_ASSET = "mirror/shop/fuse/fuse_ego_gift"
FUSE_TITLE_REGION = {"x": 390, "y": 55, "width": 500, "height": 90}
FUSE_TITLE_THRESHOLD = 0.85
# 关键词弹窗 / Select a Keyword 提示：出现时说明本次会话还没选流派，本步不做任何点击
FUSE_KEYWORD_TITLE_REGION = {"x": 380, "y": 70, "width": 520, "height": 60}
FUSE_KEYWORD_TITLE_KEYWORD = "fusionkeywordselection"
FUSE_KEYWORD_PROMPT_REGION = {"x": 730, "y": 350, "width": 250, "height": 60}
FUSE_KEYWORD_PROMPT = "selectakeyword"
# 右侧 Fusion Available 标签只在列表顶端出现；限定区域可避开下方 E.G.O Gifts Owned 的相似横幅
# （实测同一模板在 Gifts Owned 上还会给 0.809 的误命中）
FUSE_AVAILABLE_ASSET = "mirror/shop/fuse/fusion_available"
FUSE_AVAILABLE_REGION = {"x": 620, "y": 200, "width": 510, "height": 75}
FUSE_AVAILABLE_THRESHOLD = 0.9
# Fusion Available 这一行最多五张配方卡（开发者要求：不判断哪张能融合，五个固定落点从左往右点）。
# 2026-11-24 16:23 现场（1280x720）实测：标签 (637,218,153x25)；这一行卡片与下方 E.G.O Gifts Owned
# 同列（列距约 90、左对齐内容左边 x≈645），卡片中心 y≈300；第一张卡上方会显示红色 Cannot Fuse，
# 点它没有任何反应（Run 614 就是在这里空转），第二张卡点中才装填配方。旧逻辑「只点第一张」已废弃。
FUSE_ROW_POINTS = (
    (679, 300),
    (769, 300),
    (859, 300),
    (949, 300),
    (1039, 300),
)
# 融合确认后的 E.G.O Gift GET! 到手弹窗（与 sub_workflow.mirror_shop_fuse 同一素材、区域和阈值）：
# 固定落点路径用它确认「这一次融合确实发生了」，没看到就不算成功。
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
# 本次会话是否已经判定 Fusion Available 一行都不可融合（由 step.mirror_shop_fuse_open 开新会话时清空）
RECIPE_BLOCKED_KEY = "fuse_recipe_blocked"
# 左侧环形区域与最后融合格空位
LEFT_PANEL_REGION = {"x": 140, "y": 150, "width": 430, "height": 420}
FINAL_FUSE_ASSET = "mirror/shop/fuse/final_fuse_place"
FINAL_FUSE_THRESHOLD = 0.85
# 右侧 Gifts Owned 网格（避开滚动条）。上边界必须高于首行卡片 y≈220，否则 73px 高的模板
# 会被区域裁掉顶部而全部匹配失败；下边界覆盖到第三行卡片底部（402+73=475）。
RIGHT_LIST_REGION = {"x": 630, "y": 205, "width": 500, "height": 370}
LIST_TOP = 205
# 点完一张卡后收起详情浮窗用的标题栏空点（与 step.mirror_shop_fuse_scroll 的刷新点一致，
# 位于 Recipes 与 Fusion Guide 之间；点它只把光标移开，不会触发任何按钮、不改融合状态）
TIP_DISMISS_POINT = (800, 160)
TIP_DISMISS_WAIT_SECONDS = 0.4
GIFT_GROUP = "mirror/gift"
CONSUMABLE_THRESHOLD = 0.85
# 同一帧最多点几张耗材卡：Super Shop 最多五个融合格，普通商店只会有三个
MAX_MATERIALS_PER_CALL = 5
# 已点过的耗材记录：按位置（半径 30）判断，列表不重排时不会重复点同一张卡
RUNTIME_KEY = "mirror.runtime"
USED_KEY = "fuse_used"
USED_RADIUS = 30
# 底部 Fuse 按钮：OCR 为主，兜底落点与现场实测一致
FUSE_BUTTON_REGION = {"x": 640, "y": 555, "width": 300, "height": 60}
FUSE_FALLBACK = (804, 586)
# 融合确认弹窗的 Confirm：居中区域 OCR，读不到时按 Enter
CONFIRM_REGION = {"x": 300, "y": 300, "width": 680, "height": 300}
# 动作后的固定等待
RECIPE_WAIT_SECONDS = 1.2
CLICK_WAIT_SECONDS = 1.2
FUSE_WAIT_SECONDS = 1.2
CONFIRM_WAIT_SECONDS = 1.5


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _fuse_popup_open(ctx: RunContext) -> bool:
    """当前帧是否在 Fuse E.G.O Gift 弹窗上：只用标题横幅素材 mirror/shop/fuse/fuse_ego_gift 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=FUSE_TITLE_ASSET,
            region=FUSE_TITLE_REGION,
            threshold=FUSE_TITLE_THRESHOLD,
        )
    )


def _keyword_popup_open(ctx: RunContext) -> bool:
    """当前帧是否叠着 Fusion - Keyword Selection 弹窗。"""
    return FUSE_KEYWORD_TITLE_KEYWORD in _region_text(ctx, FUSE_KEYWORD_TITLE_REGION)


def _keyword_prompt(ctx: RunContext) -> bool:
    """融合页右侧是否还显示 Select a Keyword。"""
    return FUSE_KEYWORD_PROMPT in _region_text(ctx, FUSE_KEYWORD_PROMPT_REGION)


def _settings(ctx: RunContext) -> dict:
    """RunState.settings；不可用时按空字典处理。"""
    settings = ctx.run_state.settings
    return settings if isinstance(settings, dict) else {}


def _used(ctx: RunContext) -> list:
    """读取本次融合会话已点过的耗材位置记录。"""
    runtime = _settings(ctx).get(RUNTIME_KEY)
    record = runtime.get(USED_KEY) if isinstance(runtime, dict) else None
    return record if isinstance(record, list) else []


def _write_runtime(ctx: RunContext, key: str, value) -> None:
    """写一条本次融合会话的运行时记录；写不进去只记 warning。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录融合耗材位置", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[key] = value
    settings[RUNTIME_KEY] = runtime


def _mark_used(ctx: RunContext, name: str, center) -> None:
    """点之前先记下这张卡的位置，重入时不会对同一张卡重复点击。"""
    record = _used(ctx)
    record.append({"name": str(name), "x": int(center[0]), "y": int(center[1])})
    _write_runtime(ctx, USED_KEY, record)


def _is_used(record: list, center) -> bool:
    """该位置是否已经在本次会话点过：列表不重排，按半径判断即可。"""
    x, y = int(center[0]), int(center[1])
    for item in record:
        if not isinstance(item, dict):
            continue
        if abs(x - int(item.get("x", 0))) <= USED_RADIUS and abs(y - int(item.get("y", 0))) <= USED_RADIUS:
            return True
    return False


def _button_point(ctx: RunContext, region: dict[str, int], keyword: str):
    """在指定区域找按钮文字中心；找不到返回 None。"""
    result = ctx.action("observe.ocr", region=region) or {}
    for item in result.get("items") or []:
        if keyword in _norm(item.get("text", "")):
            center = item.get("centerxy")
            if center:
                return (int(center[0]), int(center[1]))
    return None


def _confirm_point(ctx: RunContext):
    """在融合确认弹窗区域找 Confirm 按钮中心；找不到返回 None。"""
    result = ctx.action("observe.ocr", region=CONFIRM_REGION) or {}
    for item in result.get("items") or []:
        if "confirm" in _norm(item.get("text", "")):
            center = item.get("centerxy")
            if center:
                return (int(center[0]), int(center[1]))
    return None


def _gift_get_popup(ctx: RunContext) -> bool:
    """当前帧是否叠着融合确认后的 E.G.O Gift GET! 到手弹窗（与上层同一素材、区域和阈值）。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=GIFT_GET_ASSET,
            region=GIFT_GET_REGION,
            threshold=GIFT_GET_THRESHOLD,
        )
    )


def _recipe_blocked(ctx: RunContext) -> bool:
    """本次融合会话是否已经判定 Fusion Available 一行都点不出融合确认弹窗。"""
    runtime = _settings(ctx).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(RECIPE_BLOCKED_KEY) is True


def _set_recipe_blocked(ctx: RunContext) -> None:
    """记录「本次会话不再处理 Fusion Available」，由 step.mirror_shop_fuse_open 开新会话时清空。"""
    _write_runtime(ctx, RECIPE_BLOCKED_KEY, True)


def _try_recipe_row(ctx: RunContext) -> dict[str, str] | None:
    """
    按开发者要求处理 Fusion Available 这一行：五个固定落点从左往右依次尝试。
    每点一个落点就点一次 Fuse：出现融合确认弹窗就点 Confirm 并用 mirror/ego_gift_get 复查到手弹窗，
    返回 fused；没有确认弹窗说明这个落点上没有可融合的配方，收起浮窗后点下一个固定落点。
    五个落点都没有确认弹窗时记一条带截图的 warning、写会话标记并返回 None，
    由调用方继续处理下方耗材（本次会话不再处理 Fusion Available）。
    确认弹窗出现但确认后没有到手弹窗时返回 fuse_unconfirmed，交上层停止本次融合，避免原地重试。
    """
    for index, point in enumerate(FUSE_ROW_POINTS, 1):
        ctx.log(
            f"尝试 Fusion Available 第{index}/{len(FUSE_ROW_POINTS)}个固定落点 {point}"
            "（不看配方是否可用，点完就试着融合）"
        )
        ctx.action("control.click", x=point[0], y=point[1])
        ctx.action("observe.wait", seconds=RECIPE_WAIT_SECONDS)
        ctx.action("observe.capture_screen")
        fuse = _button_point(ctx, FUSE_BUTTON_REGION, "fuse") or FUSE_FALLBACK
        ctx.log(f"第{index}个落点已点击，尝试融合：点击 Fuse {fuse}")
        ctx.action("control.click", x=fuse[0], y=fuse[1])
        ctx.action("observe.wait", seconds=FUSE_WAIT_SECONDS)
        ctx.action("observe.capture_screen")
        confirm = _confirm_point(ctx)
        if not confirm:
            ctx.log(
                f"第{index}个落点点击后没有出现融合确认弹窗，"
                "按这个落点没有可融合配方处理，改点下一个固定落点",
                level="info",
            )
            # 移开光标收起礼物详情浮窗，避免浮窗盖住后面要点的卡片（这一下只移光标，不改融合状态）
            ctx.action("control.click", x=TIP_DISMISS_POINT[0], y=TIP_DISMISS_POINT[1])
            ctx.action("observe.wait", seconds=TIP_DISMISS_WAIT_SECONDS)
            continue
        ctx.log(f"第{index}个落点出现融合确认弹窗，点击 Confirm {confirm}")
        ctx.action("control.click", x=confirm[0], y=confirm[1])
        ctx.action("observe.wait", seconds=CONFIRM_WAIT_SECONDS)
        ctx.action("observe.capture_screen")
        if _gift_get_popup(ctx):
            ctx.log(f"第{index}个固定落点融合成功：已出现 E.G.O Gift GET! 到手弹窗")
            return {"action": "fused", "reason": f"recipe_row_{index}", "materials": "0"}
        ctx.log(
            f"第{index}个落点已点 Confirm，但没有看到 E.G.O Gift GET! 到手弹窗，停止本次融合",
            level="warning",
            screenshot=True,
        )
        return {"action": "fuse_unconfirmed", "reason": f"recipe_row_{index}"}
    ctx.action("observe.capture_screen")
    ctx.log(
        f"Fusion Available 一行 {len(FUSE_ROW_POINTS)} 个固定落点都点过、也各点过一次 Fuse，"
        "都没有出现融合确认弹窗：这一行当前没有可融合的配方。"
        "本次会话不再处理 Fusion Available，继续处理下方耗材",
        level="warning",
        screenshot=True,
    )
    _set_recipe_blocked(ctx)
    return None


def _fuse_and_confirm(ctx: RunContext, reason: str, materials: int) -> dict[str, str]:
    """点一次 Fuse 并确认融合：Confirm 优先、Enter 兜底，点完只把控制权交回融合循环。

    点掉确认弹窗后游戏会弹出 E.G.O Gift GET! 到手弹窗，它盖住融合页、也盖住右侧礼物列表，
    所以这里不再复查 Confirm、不再补按 Enter，也不再检查已点卡片是否还留在列表原位：
    融合成功时融合格里的材料已被消耗、列表随后会重排，直接清空本次会话的耗材位置记录，
    由融合循环的下一轮用模板 mirror/ego_gift_get 识别并确认到手弹窗。
    """
    point = _button_point(ctx, FUSE_BUTTON_REGION, "fuse") or FUSE_FALLBACK
    ctx.log(f"点击融合按钮 Fuse {point}（{reason}，本次已点 {materials} 张耗材）")
    ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=FUSE_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    confirm = _confirm_point(ctx)
    if confirm:
        ctx.log(f"融合确认弹窗已出现，点击 Confirm {confirm}")
        ctx.action("control.click", x=confirm[0], y=confirm[1])
    else:
        ctx.log("没有在确认区域读到 Confirm，按一次 Enter 确认融合")
        ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=CONFIRM_WAIT_SECONDS)
    # 确认后游戏弹出 E.G.O Gift GET! 到手弹窗：融合格已被清空、右侧列表会重排，
    # 本次会话点过的位置记录不再有效，直接清空后交回融合循环处理到手弹窗。
    _write_runtime(ctx, USED_KEY, [])
    ctx.log(
        f"融合已确认（{reason}），本次会话的耗材位置记录已清空，交回融合循环确认 E.G.O Gift GET! 到手弹窗"
    )
    return {"action": "fused", "reason": reason, "materials": str(materials)}


@step
def execute(ctx: RunContext, *, consumables: str = "") -> dict[str, str]:
    """
    按当前融合页推进一轮：
    - 关键词弹窗或 Select a Keyword 提示还在 → 零输入返回，交上层先选流派；
    - 有 Fusion Available 且本次会话还没判定这一行不可融合 → 按 FUSE_ROW_POINTS 五个固定落点
      从左往右逐个点击，每点一个就点一次 Fuse；出现融合确认弹窗才点 Confirm 并用
      mirror/ego_gift_get 复查到手弹窗，成功即返回 fused（上层下一轮仍会从头五个落点重来）；
      五个落点都没有确认弹窗 → 记带截图的 warning、本次会话不再处理这一行，继续下面耗材；
    - 没有最后融合格空位（材料已点满）→ 直接 Fuse＋确认；
    - 否则把本帧右侧列表里属于「融合耗材名单」的礼物卡一次匹配出来，
      从左上到右下最多点 MAX_MATERIALS_PER_CALL 张；每点一张都在左侧复查 final_fuse_place，
      空位消失就立即 Fuse＋确认；
    - 右侧耗材只在这一帧上匹配一次、坐标一次记全；之后的截图只用于复查左侧空位，不重新匹配；
    - 本帧没有可点的耗材 → 零输入返回 no_consumable，由上层决定滚动右侧列表。
    consumables 是上层算出的融合耗材素材逻辑名，多个用 | 分隔。
    """
    ctx.action("observe.capture_screen")
    if _keyword_popup_open(ctx):
        return {"action": "keyword_popup"}
    if not _fuse_popup_open(ctx):
        ctx.log("当前不在 Fuse E.G.O Gift 弹窗上，本步不做输入", level="warning", screenshot=True)
        return {"action": "not_fuse_popup"}
    if _keyword_prompt(ctx):
        ctx.log("融合页仍显示 Select a Keyword，本步先不做输入，交上层选择流派")
        return {"action": "keyword_required"}

    available = (
        ctx.action(
            "observe.match_asset",
            asset=FUSE_AVAILABLE_ASSET,
            region=FUSE_AVAILABLE_REGION,
            threshold=FUSE_AVAILABLE_THRESHOLD,
        )
        or []
    )
    available = [hit for hit in available if hit.get("centerxy")]
    if available and not _recipe_blocked(ctx):
        hit = sorted(available, key=lambda item: (item["centerxy"][1], item["centerxy"][0]))[0]
        ctx.log(
            f"命中 Fusion Available（分数 {round(float(hit.get('score', 0.0)), 3)}，"
            f"标签 ({int(hit['x'])},{int(hit['y'])})），按五个固定落点尝试这一行的配方"
        )
        recipe = _try_recipe_row(ctx)
        if recipe is not None:
            return recipe
        # 五个固定落点都没有确认弹窗：warning 与跳过标记已在 _try_recipe_row 里记录，
        # 这里继续走下面的耗材路径，本次会话不再回到 Fusion Available
    elif available:
        ctx.log("本次融合会话已判定 Fusion Available 一行不可融合，跳过这一行直接处理下方耗材")

    places = (
        ctx.action(
            "observe.match_asset",
            asset=FINAL_FUSE_ASSET,
            region=LEFT_PANEL_REGION,
            threshold=FINAL_FUSE_THRESHOLD,
        )
        or []
    )
    if not places:
        ctx.log("左侧已没有 final_fuse_place 空位，说明融合格已点满，直接点击 Fuse")
        return _fuse_and_confirm(ctx, "full", 0)

    # 右侧耗材只匹配这一帧：把本帧所有命中耗材的坐标一次记下来，之后只按坐标点击，不再重新匹配
    hits = (
        ctx.action(
            "observe.match_asset_group",
            group=GIFT_GROUP,
            region=RIGHT_LIST_REGION,
            threshold=CONSUMABLE_THRESHOLD,
        )
        or []
    )
    allowed = {name for name in str(consumables or "").split("|") if name}
    used = _used(ctx)
    candidates: list = []
    rejected: list[str] = []
    for hit in hits:
        name = str(hit.get("logical_name") or "")
        center = hit.get("centerxy")
        if not name or not center:
            continue
        if name not in allowed:
            rejected.append(name)
            continue
        if int(center[1]) < LIST_TOP:
            continue
        if _is_used(used, center):
            continue
        candidates.append((int(center[1]), int(center[0]), name, center, float(hit.get("score", 0.0))))
    if rejected:
        # 识别到了但不点：这些是名单外的礼物（商店购买流派里未设为「优先消耗」的、或「优先获取」的），
        # 属于每帧都会出现的正常跳过，按 debug 记录（开发者要求），便于区分「没识别到」和「被名单过滤掉」
        ctx.log(
            "本帧已识别但不在融合耗材名单、因此不点的礼物："
            + ", ".join(sorted(set(rejected)))
            + "（名单已按商店购买流派与「优先获取」排除，并加回「优先消耗」的饰品）",
            level="debug",
        )
    if not candidates:
        ctx.log(
            f"本帧右侧列表没有匹配到融合耗材（整组命中 {len(hits)} 张礼物卡，"
            f"耗材名单 {len(allowed)} 条），交上层滚动列表",
            screenshot=True,
        )
        return {"action": "no_consumable"}

    candidates.sort()
    ctx.log(
        f"本帧一次匹配到 {len(candidates)} 张融合耗材卡（坐标已全部记下），按从上到下、从左到右最多点 "
        f"{MAX_MATERIALS_PER_CALL} 张；每点一张只复查左侧 final_fuse_place，不再重新匹配右侧列表："
        + "; ".join(
            f"{name}@({int(center[0])},{int(center[1])})" for _, _, name, center, _ in candidates
        )
    )
    clicked = 0
    for _, _, name, center, _score in candidates[:MAX_MATERIALS_PER_CALL]:
        # 点击前先记录位置：购买/融合材料不可安全重放，重入时不再点同一张卡
        _mark_used(ctx, name, center)
        ctx.action("control.click", x=int(center[0]), y=int(center[1]))
        clicked += 1
        ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
        # 点完立刻把光标移到标题栏空点收起详情浮窗：浮窗会盖住网格右半边，
        # 不收起来的话后面按已记录坐标点卡会点在浮窗上（这一下只移光标，不改融合状态）
        ctx.action("control.click", x=TIP_DISMISS_POINT[0], y=TIP_DISMISS_POINT[1])
        ctx.action("observe.wait", seconds=TIP_DISMISS_WAIT_SECONDS)
        # 这张截图只用于判断左侧融合格是否已塞满，不再按新帧重新匹配右侧耗材
        ctx.action("observe.capture_screen")
        places = (
            ctx.action(
                "observe.match_asset",
                asset=FINAL_FUSE_ASSET,
                region=LEFT_PANEL_REGION,
                threshold=FINAL_FUSE_THRESHOLD,
            )
            or []
        )
        if not places:
            ctx.log(f"点入第 {clicked} 张耗材后 final_fuse_place 消失，融合格已满")
            return _fuse_and_confirm(ctx, "filled", clicked)
        ctx.log(f"点入第 {clicked} 张耗材（{name}），final_fuse_place 仍在，继续点下一张")
    return {"action": "materials_added", "count": str(clicked)}
