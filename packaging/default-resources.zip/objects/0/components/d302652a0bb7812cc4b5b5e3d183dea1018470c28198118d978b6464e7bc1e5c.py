"""镜牢商店：从商店页打开 Fuse E.G.O Gift 弹窗，并按本队流派完成 Fusion - Keyword Selection。

现场（1280x720，Run 503~512）实测：
- 商店左侧 Fuse Gifts 按钮中心 (296,396)，点开后弹窗标题 Fuse E.G.O Gift；
- 弹窗右侧礼物列表中央 (880,355) 是「Select a Keyword.」提示，点一下就会打开
  Fusion - Keyword Selection 弹窗；
- 关键词弹窗与商店 Keyword Refresh 弹窗的十张流派卡坐标完全一致（两行五列），
  底部 Confirm 中心 (804,567)，点 Confirm 后回到融合页并显示所选流派图标。

本步一次调用走完「打开融合弹窗 → 打开关键词弹窗 → 选本队流派 → Confirm」，
关键词弹窗已开着时只做「选流派 → Confirm」；每次都只提交一次，不重复点击。
本队流派与 step.mirror_shop_keyword_refresh 同一来源（mirror.runtime.team_used 优先，
其次设置页 mirror_team），sink 归一成弹窗里的 sinking；没有可用的流派关键词时零输入返回，
由上层决定跳过融合并关闭弹窗。
"""
import re

from lalc import RunContext, step

# 商店页标识（三条判据取或，任一成立就算商店页），与购买/刷新 Step 保持一致
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 左侧 Fuse Gifts 按钮（1280x720 实测：按钮中心与 Fuse/Gifts 两行文字中心重合）
FUSE_GIFTS_POINT = (296, 396)
# Fuse E.G.O Gift 弹窗标题横幅：用素材 mirror/shop/fuse/fuse_ego_gift（425x44）做原尺寸模板匹配，
# 不再读标题文字，也不再读右上角 Fusion Guide 文字；搜索区域放宽到能完整容纳模板。
FUSE_TITLE_ASSET = "mirror/shop/fuse/fuse_ego_gift"
FUSE_TITLE_REGION = {"x": 390, "y": 55, "width": 500, "height": 90}
FUSE_TITLE_THRESHOLD = 0.85
# 右侧列表中央的 Select a Keyword 提示：出现时说明还没有选流派，点它才会弹关键词弹窗
FUSE_RIGHT_PANEL_POINT = (880, 355)
FUSE_KEYWORD_PROMPT_REGION = {"x": 730, "y": 350, "width": 250, "height": 60}
FUSE_KEYWORD_PROMPT = "selectakeyword"
# Fusion - Keyword Selection 弹窗：标题为主，底部 Cancel／Confirm 为后备
FUSE_KEYWORD_TITLE_REGION = {"x": 380, "y": 70, "width": 520, "height": 60}
FUSE_KEYWORD_TITLE_KEYWORD = "fusionkeywordselection"
FUSE_KEYWORD_BUTTON_REGION = {"x": 420, "y": 535, "width": 460, "height": 65}
FUSE_KEYWORD_BUTTON_KEYWORDS = ("cancel", "confirm")
# 十张流派卡片的固定点击落点（与 step.mirror_shop_keyword_refresh 的 KEYWORD_CELLS 同一套现场坐标）：
# 行 1 BURN／BLEED／TREMOR／RUPTURE／SINKING，行 2 POISE／CHARGE／SLASH／PIERCE／BLUNT
KEYWORD_CELLS = {
    "burn": (334, 335),
    "bleed": (487, 336),
    "tremor": (641, 336),
    "rupture": (795, 335),
    "sinking": (948, 336),
    "poise": (334, 474),
    "charge": (488, 474),
    "slash": (640, 475),
    "pierce": (795, 474),
    "blunt": (949, 474),
}
# 关键词弹窗底部 Confirm 的固定落点（1280x720 实测中心）
KEYWORD_CONFIRM_POINT = (804, 567)
# 本队流派：队伍配置页按队伍保存的初始饰品类别（gift_keyword）
MIRROR_PAGE_ID = "mirror.settings"
TEAM_PAGE_ID = "sinners.team_presets"
TEAMS_KEY = "teams"
KEYWORD_KEY = "gift_keyword"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
KEYWORD_NONE = "none"
# 融合关键词弹窗里沉沦写作 SINKING，而队伍配置里可能存 sink，统一成弹窗的键
KEYWORD_ALIASES = {"sink": "sinking"}
# 本场镜牢实际使用的队伍（task.mirror 进场时写入）与本次融合会话的运行时记录
RUNTIME_KEY = "mirror.runtime"
TEAM_USED_KEY = "team_used"
KEYWORD_SELECTED_KEY = "fuse_keyword_selected"
USED_KEY = "fuse_used"
# Fusion Available 一行被判定都不可融合的会话标记（固定落点全试过仍无确认弹窗时由 pick 写入）
RECIPE_BLOCKED_KEY = "fuse_recipe_blocked"
# 动作后的固定等待：打开弹窗、打开关键词弹窗、选卡片、提交各等一次，由上层重新观察
OPEN_WAIT_SECONDS = 1.2
POPUP_WAIT_SECONDS = 0.6
POPUP_WAIT_ATTEMPTS = 4
SELECT_WAIT_SECONDS = 0.6
CONFIRM_WAIT_SECONDS = 1.5


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _in_shop(ctx: RunContext) -> bool:
    """当前帧是否为镜牢商店页：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题。"""
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


def _fuse_popup_open(ctx: RunContext) -> bool:
    """当前帧是否已打开 Fuse E.G.O Gift 弹窗：只用标题横幅素材 mirror/shop/fuse/fuse_ego_gift 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=FUSE_TITLE_ASSET,
            region=FUSE_TITLE_REGION,
            threshold=FUSE_TITLE_THRESHOLD,
        )
    )


def _keyword_popup_open(ctx: RunContext) -> bool:
    """当前帧是否已打开 Fusion - Keyword Selection 弹窗：标题为主，底部两个按钮为后备。"""
    if FUSE_KEYWORD_TITLE_KEYWORD in _region_text(ctx, FUSE_KEYWORD_TITLE_REGION):
        return True
    buttons = _region_text(ctx, FUSE_KEYWORD_BUTTON_REGION)
    return all(word in buttons for word in FUSE_KEYWORD_BUTTON_KEYWORDS)


def _keyword_prompt(ctx: RunContext) -> bool:
    """融合页右侧是否还显示 Select a Keyword 提示（说明本次会话还没选流派）。"""
    return FUSE_KEYWORD_PROMPT in _region_text(ctx, FUSE_KEYWORD_PROMPT_REGION)


def _settings(ctx: RunContext) -> dict:
    """RunState.settings；不可用时按空字典处理。"""
    settings = ctx.run_state.settings
    return settings if isinstance(settings, dict) else {}


def _team_index(ctx: RunContext) -> int:
    """本场镜牢实际使用的队伍序号：只读 mirror.runtime.team_used；缺失时按第 1 个队伍处理。"""
    runtime = _settings(ctx).get(RUNTIME_KEY)
    used = runtime.get(TEAM_USED_KEY) if isinstance(runtime, dict) else None
    if type(used) is int and 1 <= used <= MAX_TEAMS:
        return used
    ctx.log(
        f"没有可用的本场队伍记录 {TEAM_USED_KEY}={used!r}，按第{DEFAULT_TEAM}个队伍处理",
        level="warning",
    )
    return DEFAULT_TEAM


def _keyword(ctx: RunContext) -> str:
    """读取本场队伍配置的初始饰品流派，归一成融合关键词弹窗里的键；不可用时返回空串。"""
    settings = _settings(ctx)
    team_index = _team_index(ctx)
    teams_page = settings.get(TEAM_PAGE_ID) or {}
    teams = teams_page.get(TEAMS_KEY) if isinstance(teams_page, dict) else None
    if not isinstance(teams, list) or not 1 <= team_index <= len(teams):
        ctx.log(f"队伍配置里没有第{team_index}个队伍，无法选择融合流派", level="warning")
        return ""
    entry = teams[team_index - 1]
    keyword = str(entry.get(KEYWORD_KEY) or "").strip() if isinstance(entry, dict) else ""
    key = _norm(keyword)
    if not key or key == KEYWORD_NONE:
        return ""
    return KEYWORD_ALIASES.get(key, key)


def _runtime_write(ctx: RunContext, key: str, value) -> None:
    """把本次融合会话的运行时状态写进 mirror.runtime；写不进去只记 warning。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录融合会话状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[key] = value
    settings[RUNTIME_KEY] = runtime


def _confirm_keyword(ctx: RunContext) -> dict[str, str]:
    """关键词弹窗已开着：按本队流派点固定坐标选卡片，再点一次 Confirm。"""
    keyword = _keyword(ctx)
    if keyword not in KEYWORD_CELLS:
        ctx.log(
            f"本队没有可用的融合流派关键词（读到 {keyword!r}），本次不选卡片也不提交",
            level="warning",
            screenshot=True,
        )
        return {"action": "no_keyword", "keyword": keyword}
    center = KEYWORD_CELLS[keyword]
    ctx.log(f"在 Fusion - Keyword Selection 弹窗里按固定坐标选择流派 {keyword} @ {center}")
    ctx.action("control.click", x=center[0], y=center[1])
    ctx.action("observe.wait", seconds=SELECT_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    if not _keyword_popup_open(ctx):
        ctx.log(
            "选择流派后关键词弹窗已经不在了，本次不再点 Confirm",
            level="warning",
            screenshot=True,
        )
        return {"action": "popup_closed", "keyword": keyword}
    ctx.log(f"点击关键词弹窗底部 Confirm {KEYWORD_CONFIRM_POINT} 提交本次流派")
    ctx.action("control.click", x=KEYWORD_CONFIRM_POINT[0], y=KEYWORD_CONFIRM_POINT[1])
    ctx.action("observe.wait", seconds=CONFIRM_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    if _keyword_popup_open(ctx):
        ctx.log(
            "点击 Confirm 后关键词弹窗仍在，本次不再重复提交，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return {"action": "confirm_unconfirmed", "keyword": keyword}
    _runtime_write(ctx, KEYWORD_SELECTED_KEY, True)
    ctx.log(f"融合流派已确认：{keyword}")
    return {"action": "keyword_confirmed", "keyword": keyword}


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    按当前画面推进一次「打开融合弹窗并选流派」，最多提交一次关键词：
    - 关键词弹窗已开着 → 直接选本队流派卡片并点 Confirm；
    - 融合弹窗已开着 → 右侧仍显示 Select a Keyword 时点右侧中央打开关键词弹窗并提交；
      已选过流派（运行时标记为真且没有提示）就零输入返回 already_open；
    - 仍在商店页 → 点一次左侧 Fuse Gifts，有界等待弹窗滑入，再点右侧中央打开关键词弹窗并提交；
    - 不在商店页、打不开弹窗、没有可用流派 → 零输入返回对应动作名，由上层决定关闭或跳过。
    """
    ctx.action("observe.capture_screen")
    if _keyword_popup_open(ctx):
        return _confirm_keyword(ctx)

    if _fuse_popup_open(ctx):
        runtime = _settings(ctx).get(RUNTIME_KEY)
        selected = isinstance(runtime, dict) and runtime.get(KEYWORD_SELECTED_KEY) is True
        if selected and not _keyword_prompt(ctx):
            return {"action": "already_open"}
        ctx.log("融合弹窗已打开，点击右侧列表中央打开 Fusion - Keyword Selection 弹窗")
        ctx.action("control.click", x=FUSE_RIGHT_PANEL_POINT[0], y=FUSE_RIGHT_PANEL_POINT[1])
        ctx.action("observe.wait", seconds=OPEN_WAIT_SECONDS)
        ctx.action("observe.capture_screen")
        for attempt in range(1, POPUP_WAIT_ATTEMPTS + 1):
            if _keyword_popup_open(ctx):
                return _confirm_keyword(ctx)
            if not _keyword_prompt(ctx):
                break
            if attempt < POPUP_WAIT_ATTEMPTS:
                ctx.action("observe.wait", seconds=POPUP_WAIT_SECONDS)
                ctx.action("observe.capture_screen")
        if _keyword_popup_open(ctx):
            return _confirm_keyword(ctx)
        if not _keyword_prompt(ctx):
            # 右侧提示已经消失：按已经选过流派处理，避免反复点列表中央误选礼物
            _runtime_write(ctx, KEYWORD_SELECTED_KEY, True)
            ctx.log("点击右侧中央后没有出现关键词弹窗，但 Select a Keyword 提示已消失，按已选流派处理")
            return {"action": "keyword_assumed"}
        ctx.log(
            "点击右侧中央后仍显示 Select a Keyword，关键词弹窗没有出现，交回上层重试",
            level="warning",
            screenshot=True,
        )
        return {"action": "keyword_unconfirmed"}

    if not _in_shop(ctx):
        ctx.log("当前不是镜牢商店页，不打开 Fuse E.G.O Gift 弹窗", level="warning", screenshot=True)
        return {"action": "not_in_shop"}

    # 新的一次融合会话从商店页开始：清掉上一次会话的流派/耗材/配方行记录
    _runtime_write(ctx, KEYWORD_SELECTED_KEY, False)
    _runtime_write(ctx, USED_KEY, [])
    _runtime_write(ctx, RECIPE_BLOCKED_KEY, False)
    ctx.log(f"点击商店左侧 Fuse Gifts {FUSE_GIFTS_POINT} 打开融合弹窗")
    ctx.action("control.click", x=FUSE_GIFTS_POINT[0], y=FUSE_GIFTS_POINT[1])
    ctx.action("observe.wait", seconds=OPEN_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    for attempt in range(1, POPUP_WAIT_ATTEMPTS + 1):
        if _keyword_popup_open(ctx):
            return _confirm_keyword(ctx)
        if _fuse_popup_open(ctx):
            ctx.log(f"融合弹窗已打开（点击后第{attempt}次复查命中），点击右侧中央选择流派")
            ctx.action("control.click", x=FUSE_RIGHT_PANEL_POINT[0], y=FUSE_RIGHT_PANEL_POINT[1])
            ctx.action("observe.wait", seconds=SELECT_WAIT_SECONDS)
            ctx.action("observe.capture_screen")
            for attempt in range(1, POPUP_WAIT_ATTEMPTS + 1):
                if _keyword_popup_open(ctx):
                    return _confirm_keyword(ctx)
                if attempt < POPUP_WAIT_ATTEMPTS:
                    ctx.action("observe.wait", seconds=POPUP_WAIT_SECONDS)
                    ctx.action("observe.capture_screen")
            ctx.log(
                "点击右侧中央后没有出现关键词弹窗，交回上层重新观察",
                level="warning",
                screenshot=True,
            )
            return {"action": "keyword_unconfirmed"}
        if attempt < POPUP_WAIT_ATTEMPTS:
            ctx.action("observe.wait", seconds=POPUP_WAIT_SECONDS)
            ctx.action("observe.capture_screen")
    ctx.log(
        "点击 Fuse Gifts 后没有出现 Fuse E.G.O Gift 弹窗，交回上层重新观察",
        level="warning",
        screenshot=True,
    )
    return {"action": "open_failed"}
