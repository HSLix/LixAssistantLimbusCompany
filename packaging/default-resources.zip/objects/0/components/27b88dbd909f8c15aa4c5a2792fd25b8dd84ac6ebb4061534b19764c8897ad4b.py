"""事件选项阶段：复查入口后最多执行一次动作（点命中选项／滚轮下滚一次／到底后拖回顶部做保底扫描），退出信号是 result 页。"""
import random
import re

from lalc import ExecutionFailure, RunContext, step

CHOICES_ASSET = "event/choices"
RESULT_ASSET = "event/result"
SCROLL_BLOCK_ASSET = "event/scroll_block"
# 右侧选项卡片可视区（1280x720 客户区），避开左上剧情文本、右下 SKIP 与右侧滚动条
OPTIONS_REGION = {"x": 690, "y": 165, "width": 470, "height": 345}
# 滚动条整列：在这里模板匹配滚动条方块，没有命中说明当前列表没有滚动条，不需要滚动
SCROLL_COLUMN_REGION = {"x": 1185, "y": 160, "width": 45, "height": 365}
# 配置页 PAGE_ID 与字段名：关键词在「通用事件选项」设置页维护；
# PAGE_ID 保持 mirror.choices 只为兼容已保存的配置，配置本身对所有事件共用
SETTINGS_PAGE_ID = "mirror.choices"
KEYWORDS_KEY = "preferred_keywords"
DEFAULT_KEYWORDS = ("select to gain", "pass to gain")
# 同一行文字片段的 y 中心允许偏差，以及不同选项段落之间的最小垂直间隔
LINE_Y_TOLERANCE = 12
BLOCK_GAP = 45
# 保底策略要跳过的纯推进按钮：把 Continue/Skip/Proceed 当普通选项点掉会白白放弃事件收益
NAVIGATION_KEYWORDS = ("continue", "skip", "proceed", "commencebattle")
# 一次下滚：在选项卡片区用鼠标滚轮向下滚固定格数，列表内容随之上移。
# 这里不能用 control.drag：Run 420 在同一个选项页连续拖动 7 次，选项区内容始终没有露出新选项，
# 第 8 轮撞上 sub_workflow.event 的分支上限；项目内其他列表（如队伍列表）同样只用滚轮滚动
SCROLL_POINT = (930, 340)
SCROLL_STEPS = 3
SCROLL_WAIT_SECONDS = 0.6
# 保底策略的随机点击范围
CLICK_POINT_X = (760, 1100)
CLICK_POINT_Y = (200, 480)
# 保底清屏扫描：滚动块到底且没命中优先关键词时，先把滚动条方块拖回顶部，
# 然后不再匹配优先关键词，按选项列的四个固定卡片位置从上到下逐个点击
CHOICES_SLOT_X = 915
CHOICES_SLOT_YS = (185, 315, 445, 575)
# 扫描轮次上限：每轮点完四个候选点后下滚一次，滚回底部（文本不再变化）或轮次用完就报错
MAX_SWEEP_ROUNDS = 6
# 动作后只做一次固定等待
ACTION_WAIT_SECONDS = 0.9


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或标点影响关键字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _choices_page(ctx: RunContext) -> bool:
    """用 event/choices 标题模板判断当前帧是否还在事件选项阶段。"""
    return bool(ctx.action("observe.match_asset", asset=CHOICES_ASSET))


def _lines(ctx: RunContext) -> list[dict]:
    """OCR 右侧选项区，把 y 中心接近的文字片段按出现顺序合成一行，并从上到下排序。"""
    result = ctx.action("observe.ocr", region=OPTIONS_REGION) or {}
    items = [item for item in (result.get("items") or []) if _norm(str(item.get("text") or ""))]
    items.sort(
        key=lambda item: (
            int((item.get("centerxy") or [0, 0])[1]),
            int((item.get("centerxy") or [0, 0])[0]),
        )
    )

    lines: list[dict] = []
    for item in items:
        center = item.get("centerxy") or [0, 0]
        box = item.get("box") or {}
        center_y = int(center[1])
        top = int(box.get("y", center_y))
        bottom = top + int(box.get("height", 0))
        left = int(box.get("x", center[0]))
        right = left + int(box.get("width", 0))

        if lines and abs(center_y - lines[-1]["y"]) <= LINE_Y_TOLERANCE:
            line = lines[-1]
            line["text"] = f"{line['text']} {item['text']}"
            line["y"] = (line["y"] + center_y) // 2
            line["top"] = min(line["top"], top)
            line["bottom"] = max(line["bottom"], bottom)
            line["left"] = min(line["left"], left)
            line["right"] = max(line["right"], right)
            continue

        lines.append(
            {
                "text": str(item["text"]),
                "y": center_y,
                "top": top,
                "bottom": bottom,
                "left": left,
                "right": right,
            }
        )
    return lines


def _blocks(lines: list[dict]) -> list[dict]:
    """把相邻的行按垂直间隔合并成选项段落；间隔超过 BLOCK_GAP 视为下一个选项。"""
    blocks: list[dict] = []
    for line in lines:
        if blocks and line["top"] - blocks[-1]["bottom"] <= BLOCK_GAP:
            block = blocks[-1]
            block["text"] = f"{block['text']} {line['text']}"
            block["top"] = min(block["top"], line["top"])
            block["bottom"] = max(block["bottom"], line["bottom"])
            block["left"] = min(block["left"], line["left"])
            block["right"] = max(block["right"], line["right"])
            continue
        blocks.append(dict(line))
    return blocks


def _center(block: dict) -> list[int]:
    """取选项段落的包围框中心，作为点击坐标。"""
    return [(block["left"] + block["right"]) // 2, (block["top"] + block["bottom"]) // 2]


def _options_text(blocks: list[dict]) -> str:
    """选项区文本指纹：把各选项段落的规范化文本拼起来，用于比较滚动前后内容是否变化。"""
    return "|".join(_norm(block["text"]) for block in blocks)


def _result_page(ctx: RunContext) -> bool:
    """用 event/result 模板判断是否已进入结果页，这是本步的退出信号。"""
    return bool(ctx.action("observe.match_asset", asset=RESULT_ASSET))


def _keywords(ctx: RunContext) -> list[str]:
    """读取设置页的优先关键词：按行或逗号拆分，逐个去空白并转小写去重；未配置时用默认关键词。"""
    page = (ctx.run_state.settings or {}).get(SETTINGS_PAGE_ID) or {}
    raw = page.get(KEYWORDS_KEY)
    if isinstance(raw, str):
        candidates = re.split(r"[\n,，;；]+", raw)
    elif isinstance(raw, list):
        candidates = [str(value) for value in raw]
    else:
        candidates = []

    keywords: list[str] = []
    for candidate in candidates:
        keyword = str(candidate).strip().lower()
        if keyword and keyword not in keywords:
            keywords.append(keyword)
    if not keywords:
        ctx.log(f"设置页没有可用的优先关键词，退回内置默认关键词 {DEFAULT_KEYWORDS}", level="warning")
        keywords = list(DEFAULT_KEYWORDS)
    return keywords


def _preferred(blocks: list[dict], keywords: list[str]) -> tuple[dict | None, str]:
    """按从上到下的顺序找第一个命中任意优先关键词的选项段落，返回该段落与命中的关键词。"""
    for block in blocks:
        text = str(block["text"]).lower()
        for keyword in keywords:
            if keyword in text:
                return block, keyword
    return None, ""


def _scroll_block(ctx: RunContext) -> dict | None:
    """在滚动条整列里模板匹配滚动条方块；没有命中说明当前列表没有滚动条，不需要滚动。"""
    matches = (
        ctx.action("observe.match_asset", asset=SCROLL_BLOCK_ASSET, region=SCROLL_COLUMN_REGION) or []
    )
    if not matches:
        return None
    if len(matches) > 1:
        ctx.log(
            f"滚动条方块命中{len(matches)}处：{[item.get('centerxy') for item in matches]}，取分数最高的一处",
            level="warning",
        )
    return max(matches, key=lambda item: float(item.get("score", 0.0)))


def _scroll_once(ctx: RunContext) -> None:
    """在选项卡片区用鼠标滚轮向下滚 SCROLL_STEPS 格一次，让列表露出下方选项。"""
    x, y = SCROLL_POINT
    ctx.action("control.scroll", direction="down", steps=SCROLL_STEPS, x=x, y=y)
    ctx.action("observe.wait", seconds=SCROLL_WAIT_SECONDS)


def _fallback_blocks(blocks: list[dict]) -> list[dict]:
    """保底策略的候选段落：排除只写着 Continue/Skip/Proceed/CommenceBattle 的推进按钮。"""
    candidates = [block for block in blocks if _norm(block["text"]) not in NAVIGATION_KEYWORDS]
    return candidates or list(blocks)


def _random_point(block: dict | None) -> tuple[int, int]:
    """在候选段落内部（避开边缘）随机取一点；没有任何段落时在选项区域里随机取点。"""
    if block is None:
        return (
            random.randint(CLICK_POINT_X[0], CLICK_POINT_X[1]),
            random.randint(CLICK_POINT_Y[0], CLICK_POINT_Y[1]),
        )
    left = int(block["left"]) + 8
    right = max(left, int(block["right"]) - 8)
    top = int(block["top"]) + 6
    bottom = max(top, int(block["bottom"]) - 6)
    return random.randint(left, right), random.randint(top, bottom)


def _fallback_click(ctx: RunContext, blocks: list[dict], keywords: list[str]) -> None:
    """保底策略：在排除纯推进按钮后的段落里随机点一处，一次后交回上层重新观察。"""
    candidates = _fallback_blocks(blocks)
    chosen = candidates[random.randrange(len(candidates))] if candidates else None
    x, y = _random_point(chosen)
    text = str(chosen["text"])[:40] if chosen is not None else "选项区没有识别到段落"
    ctx.log(
        f"当前屏没有命中优先关键词 {keywords}，也没有可继续滚动的内容，"
        f"保底点击 ({x}, {y}) 一次（候选 {len(candidates)} 处：{text}）后交回上层重新观察",
        level="warning",
    )
    ctx.action("control.click", x=x, y=y)
    ctx.action("observe.wait", seconds=ACTION_WAIT_SECONDS)


def _block_to_top(ctx: RunContext) -> None:
    """
    把滑动块拖回滚动条整列的最上方，让选项列表回到最开始的位置。
    拖拽的是滚动条方块本身（不是卡片区，拖卡片会被当成拖拽而不是滚动）；
    找不到方块时退回滚轮向上，避免没有可拖目标时直接卡在底部。
    """
    block = _scroll_block(ctx)
    if block is None:
        ctx.log("滚动条整列没有可拖的方块，改用滚轮向上把选项列表滚回顶部", level="warning")
        for _ in range(2):
            ctx.action(
                "control.scroll",
                direction="up",
                steps=10,
                x=SCROLL_POINT[0],
                y=SCROLL_POINT[1],
            )
            ctx.action("observe.wait", seconds=SCROLL_WAIT_SECONDS)
        return

    center = block.get("centerxy") or (SCROLL_COLUMN_REGION["x"] + 20, 300)
    start_x = int(center[0])
    start_y = int(center[1])
    target_y = SCROLL_COLUMN_REGION["y"] + max(1, int(block.get("height", 0)) // 2)
    ctx.log(
        f"把滑动块从 ({start_x}, {start_y}) 拖到顶部 ({start_x}, {target_y})，"
        "让选项列表回到最开始的位置"
    )
    ctx.action("control.drag", x=start_x, y=start_y, end_x=start_x, end_y=target_y, seconds=0.6)
    ctx.action("observe.wait", seconds=SCROLL_WAIT_SECONDS)


def _sweep_choices(ctx: RunContext) -> None:
    """
    保底清屏扫描：滑动块已经到底、优先关键词又没命中时使用。
    1. 先把滑动块拖回顶部；拖完已不在选项页就零点击返回。
    2. 不再匹配优先关键词，按 CHOICES_SLOT_YS 的四个候选位置逐个点击（x 固定取卡片区中部）；
       每点一处都重新截图，发现已离开选项页立即返回，不再继续点后面的位置。
    3. 四个点都没离开选项页就下滚一次继续扫；下滚后发现已离开选项页同样返回。
    4. 滚动块再次到底（滚轮已经不能让选项区文本变化）仍没离开选项页，或扫描轮次用完，
       抛 workflow_choices_exhausted：本层不再重复同一组输入，也不返回当作已完成。
    """
    _block_to_top(ctx)
    ctx.action("observe.capture_screen")
    if not _choices_page(ctx):
        ctx.log(
            "拖回顶部后已不在事件选项页，保底扫描不点击任何位置，交回上层按页面状态处理",
            level="warning",
            screenshot=True,
        )
        return

    for sweep_round in range(1, MAX_SWEEP_ROUNDS + 1):
        for slot_index, slot_y in enumerate(CHOICES_SLOT_YS, start=1):
            ctx.log(
                f"保底扫描第{sweep_round}/{MAX_SWEEP_ROUNDS}轮：不再匹配优先关键词，"
                f"点击第{slot_index}/{len(CHOICES_SLOT_YS)}个候选位置 ({CHOICES_SLOT_X}, {slot_y})"
            )
            ctx.action("control.click", x=CHOICES_SLOT_X, y=slot_y)
            ctx.action("observe.wait", seconds=ACTION_WAIT_SECONDS)
            ctx.action("observe.capture_screen")
            if not _choices_page(ctx):
                ctx.log(f"点击候选位置 ({CHOICES_SLOT_X}, {slot_y}) 后已离开选项页，保底扫描结束")
                return

        before = _options_text(_blocks(_lines(ctx)))
        ctx.log(
            f"保底扫描第{sweep_round}轮四个候选位置都没有离开选项页，"
            f"下滚 {SCROLL_STEPS} 格后继续扫描"
        )
        _scroll_once(ctx)
        ctx.action("observe.capture_screen")
        if not _choices_page(ctx):
            ctx.log("下滚后已离开选项页，保底扫描结束", screenshot=True)
            return
        if _options_text(_blocks(_lines(ctx))) == before:
            raise ExecutionFailure(
                "workflow_choices_exhausted",
                f"保底扫描第{sweep_round}轮后已重新滚到底部（选项区文本不再变化），"
                "四个候选位置仍未离开选项页",
            )

    raise ExecutionFailure(
        "workflow_choices_exhausted",
        f"保底扫描 {MAX_SWEEP_ROUNDS} 轮共 {MAX_SWEEP_ROUNDS * len(CHOICES_SLOT_YS)} 次候选点击"
        "仍未离开选项页",
    )


@step
def execute(ctx: RunContext) -> None:
    """
    事件选项阶段的一次局部尝试，进入后最多执行一次点击，不承诺选项阶段已经结束：
    1. 先重新截图：命中 event/result，或已不在选项页（event/choices 模板不命中）时零输入返回，
       交回上层按页面状态继续，不在这里盲点或盲滚。
    2. 当前屏按设置页的优先关键词（小写包含匹配）命中选项段落时，点击该段落一次，
       等 ACTION_WAIT_SECONDS 秒后返回。
    3. 没有命中时：存在滚动条方块就用滚轮向下滚 SCROLL_STEPS 格一次，并重新截图比较选项区文本；
       文本变了说明列表确实滚动，交回上层下一轮重新判断关键词；
       文本没变说明列表已到底或不响应滚轮：此时把滑动块拖回顶部，再按保底清屏扫描调用
       _sweep_choices——不再匹配优先关键词，按四个候选位置逐个点击并逐次确认是否已离开选项页，
       没离开才下滚一次继续扫；滚回底部仍没离开（或扫描轮次用完）则抛 workflow_choices_exhausted。
       没有滚动条方块说明当前列表不需要滚动，直接按保底策略点击一次。
    选项是否生效、是否已进入结果页，都由上层下一轮重新截图判定：本步不轮询、不重放同一输入，
    也不返回任何局部结果。OCR 不支持韩文，韩文关键词不会命中。
    """
    ctx.action("observe.capture_screen")
    if _result_page(ctx):
        ctx.log("匹配到 result 标识，选项阶段已结束，本步不点击也不滚动")
        return
    if not _choices_page(ctx):
        ctx.log(
            "已不在事件选项页，本步不点击也不滚动，交回上层按页面状态处理",
            level="warning",
            screenshot=True,
        )
        return

    keywords = _keywords(ctx)
    blocks = _blocks(_lines(ctx))
    hit, keyword = _preferred(blocks, keywords)
    if hit is not None:
        point = _center(hit)
        ctx.log(f"当前屏命中优先关键词「{keyword}」，点击 ({point[0]}, {point[1]}) 一次：{hit['text']}")
        ctx.action("control.click", x=point[0], y=point[1])
        ctx.action("observe.wait", seconds=ACTION_WAIT_SECONDS)
        return

    if _scroll_block(ctx) is None:
        _fallback_click(ctx, blocks, keywords)
        return

    before = _options_text(blocks)
    ctx.log(f"当前屏没有命中优先关键词 {keywords}，用滚轮向下滚 {SCROLL_STEPS} 格一次后重新观察")
    _scroll_once(ctx)
    ctx.action("observe.capture_screen")
    if not _choices_page(ctx):
        ctx.log(
            "滚轮滚动后已不在事件选项页，本步不再点击，交回上层按页面状态处理",
            level="warning",
            screenshot=True,
        )
        return
    after = _blocks(_lines(ctx))
    if _options_text(after) != before:
        return
    # 滚轮完全没有推动列表（已到底或该列表不响应滚轮）时再滚一次只会重复同一动作：
    # Run 420 就是这样连续 7 轮滚同一屏，第 8 轮撞上 sub_workflow.event 的分支上限而中断整场镜牢
    ctx.log(
        "滚轮滚动后选项区文本完全没变，说明列表已到底或不响应滚轮，"
        "改为拖回顶部后做保底扫描（不再匹配优先关键词）",
        level="warning",
        screenshot=True,
    )
    _sweep_choices(ctx)
