"""镜牢 Select Encounter Reward Card 页面识别：只判断状态与已知卡片图标，不做任何点击。"""
import re

from lalc import RunContext, sub_workflow, ExecutionFailure

# 页面标题条（1280x720 客户区）：Select Encounter Reward Card
TITLE_REGION = {"x": 270, "y": 100, "width": 540, "height": 70}
TITLE_KEYWORD = "encounterrewardcard"
# 未选择奖励时的确认弹窗文案区域：
# You have not selected a reward yet. / Continue without choosing a reward?
POPUP_REGION = {"x": 340, "y": 180, "width": 600, "height": 350}
POPUP_KEYWORDS = ("notselectedareward", "withoutchoosingareward")
# E.G.O Gift GET! 弹窗：选卡提交后拿到饰品时的正常结果页，会盖在奖励卡页上方（Run 292）。
# 用素材 mirror/ego_gift_get（430x34 的标题横幅）做原尺寸模板匹配，不再读标题文字；
# 区域与阈值跟 task.mirror 的 gift_get 判定保持一致
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
# 卡片图标所在区域：卡片上部的图标行，不含卡片下方的说明文字
CARD_REGION = {"x": 330, "y": 175, "width": 640, "height": 290}
# 右上角 Selectable 右侧的数字区域：只取 已选/上限，带上左侧标签时 OCR 会丢掉数字
COUNTER_REGION = {"x": 985, "y": 112, "width": 60, "height": 45}
COUNTER_PATTERN = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s*$")
# 卡片优先级：靠前的先选；以后新增卡类只要按优先级往这个元组里加素材逻辑名
# coin（镜牢局内 Coin 货币）与选卡 Step 的说明文字关键词排序保持一致，排在 starlight 之后
# cost_and_gift_chance（Cost 与 E.G.O 礼品概率）卡片图标在卡面上有缩放与形变，
# 因此与其它卡类一样走特征匹配；优先级低于 coin、高于 random_gift
CARD_PRIORITY = (
    "mirror/reward_card/starlight",
    "mirror/reward_card/coin",
    "mirror/reward_card/cost_and_gift_chance",
    "mirror/reward_card/random_gift",
)


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _in_region(item: dict, region: dict[str, int]) -> bool:
    """该 OCR 条目的中心是否落在给定区域。"""
    center = item.get("centerxy") or (0, 0)
    x, y = int(center[0]), int(center[1])
    return (
        int(region["x"]) <= x <= int(region["x"]) + int(region["width"])
        and int(region["y"]) <= y <= int(region["y"]) + int(region["height"])
    )


def _region_text(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回规范化小写文本；不刷新截图。"""
    texts = [str(item.get("text", "")) for item in items if _in_region(item, region)]
    return _norm(" ".join(text for text in texts if text))


def _state(ctx: RunContext, items: list[dict]) -> tuple[str, str]:
    """
    按当前帧判定状态，返回 (状态, 判定依据)。
    gift_get：拿到饰品的 E.G.O Gift GET! 弹窗，属于奖励卡流程的正常退出信号（会盖在奖励卡页上方，所以先判）；
    popup：未选择奖励的确认弹窗（会压暗整页，所以先判）；reward_card：可选卡片页；
    left：不在本页。后两者都只在命中各自独特文案时才算，避免把其它页面误判成本页。
    """
    if ctx.action(
        "observe.match_asset",
        asset=GIFT_GET_ASSET,
        region=GIFT_GET_REGION,
        threshold=GIFT_GET_THRESHOLD,
    ):
        return "gift_get", GIFT_GET_ASSET
    popup = _region_text(items, POPUP_REGION)
    if any(keyword in popup for keyword in POPUP_KEYWORDS):
        return "popup", popup
    title = _region_text(items, TITLE_REGION)
    if TITLE_KEYWORD in title:
        return "reward_card", title
    return "left", title


def _counter(ctx: RunContext) -> tuple[int, int] | None:
    """
    对当前帧的计数数字区域单独做一次局部 OCR，解析 Selectable 的 已选/上限，读不到时返回 None。
    Selectable 右侧的这行金色小字在整屏 OCR 里会被整条漏掉（Run 606 整屏结果只有 Selectable 标签、
    没有 0/1），所以这一小块仍用局部 OCR；不重新截图，只识别当前帧。
    """
    result = ctx.action("observe.ocr", region=COUNTER_REGION) or {}
    for item in result.get("items") or []:
        match = COUNTER_PATTERN.match(str(item.get("text") or ""))
        if match:
            return int(match.group(1)), int(match.group(2))
    return None






@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """优先等待正常过渡，再有界分派；同一分支连续第四次命中或总预算耗尽时失败。"""
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, 30 + 1):
        meta = ctx.action("observe.capture_screen")
        # 每轮对同一帧只做一次整屏 OCR：弹窗与标题都从这份结果里按区域过滤；
        # Selectable 右侧的小字计数在整屏 OCR 里会漏检，改由 _counter 对这一小块补做局部 OCR
        items = _screen_items(ctx)
        page, evidence = _state(ctx, items)
        ctx.log(f"第{round_index}轮奖励卡状态 {page}：{evidence}")
        if page == "gift_get":
            # 拿到饰品后的 E.G.O Gift GET! 弹窗是奖励卡流程的正常结束：直接交回上层，
            # 由 task.mirror 的 gift_get 分支按 Enter 确认，不在这里重复按 Enter，也不计未达成
            return {
                "completed": True,
                "reason": "已出现 E.G.O Gift GET! 弹窗，奖励卡已提交完成",
                "page": "gift_get",
            }
        if page == "left":
            return {"completed": True, "reason": "已离开奖励卡页", "page": "left"}
        if page == "popup":
            hit("step.mirror_reward_card_decline")
            ctx.log("未选择奖励弹窗在，只按一次 ESC")
            ctx.call("step.mirror_reward_card_decline")
            continue
        counter = _counter(ctx)
        if counter is None:
            ctx.log("Selectable 右侧计数没读到，本轮按未选满处理", level="warning")
        if counter and counter[0] >= counter[1]:
            hit("step.mirror_reward_card_enter")
            ctx.log(f"计数 {counter[0]}/{counter[1]} 已选满，只按一次 Enter")
            ctx.call("step.mirror_reward_card_enter")
            continue
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            # 通用等待是循环最后一个分支：复用本轮整屏 OCR（文字＋中心点），不再让检测 Step 重复识别一次
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        hit("step.mirror_reward_card_pick")
        ctx.log(f"计数 {counter} 未满，只选一次卡片")
        ctx.call("step.mirror_reward_card_pick")
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
