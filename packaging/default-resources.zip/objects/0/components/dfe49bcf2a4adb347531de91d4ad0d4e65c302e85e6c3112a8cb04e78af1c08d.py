"""镜牢收尾判定：本场镜牢领奖完成后，一旦检测到主界面标识就交回任务结束。

状态来源：step.mirror_exploration_complete 在结算页领取流程成功后把
RunState.settings["mirror.runtime"]["exploration_complete"] 写成 True，
表示本场镜牢刚完成；task.mirror 每轮最先调用本 Step 做收尾判定。
"""
import re

from lalc import RunContext, step

# 主界面标识：底部导航的 Drive / Window 图标（含选中态）；与 task.mirror 的主界面判定一致
MAIN_ASSETS = (
    "main_navigate/drive",
    "main_navigate/drive_selected",
    "main_navigate/window",
    "main_navigate/window_selected",
)
# 主界面可能被充值／提示弹窗压暗，模板分数会明显下降，因此主界面判定除模板外再用底部导航文字兜底
MAIN_THRESHOLD = 0.8
# 底部导航区域与文案：Window / Sinners / Drive / Theater / Extract / Dispense，命中两个以上即算主界面
MAIN_NAV_REGION = {"x": 770, "y": 620, "width": 510, "height": 90}
MAIN_NAV_KEYWORDS = ("window", "sinners", "drive", "theater", "extract", "dispense")
MIN_MAIN_NAV_LABELS = 2
# 镜牢刚完成状态在 RunState.settings 中的位置
RUNTIME_KEY = "mirror.runtime"
EXPLORATION_COMPLETE_KEY = "exploration_complete"


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _main_nav_labels(ctx: RunContext) -> list[str]:
    """对当前帧底部导航区域做 OCR，返回命中的导航文案列表；不刷新截图。"""
    text = _region_text(ctx, MAIN_NAV_REGION)
    return [label for label in MAIN_NAV_KEYWORDS if label in text]


def _completed(ctx: RunContext) -> bool:
    """读取本场镜牢是否已领奖完成；没有记录时按未完成处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(EXPLORATION_COMPLETE_KEY) is True


@step
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    镜牢收尾判定：刚完成状态为 True 时再检测主界面标识，命中即返回 completed=True 交回任务结束；
    状态未置位则不做截图直接交回未完成，避免每轮多一次截图。
    """
    if not _completed(ctx):
        return {"page": "not_completed", "evidence": "", "completed": False, "reason": "本场镜牢还没有领奖完成"}

    ctx.action("observe.capture_screen")
    for asset in MAIN_ASSETS:
        matches = ctx.action("observe.match_asset", asset=asset, threshold=MAIN_THRESHOLD)
        if matches:
            best = max(matches, key=lambda item: item["score"])
            ctx.log(f"镜牢已完成并检测到主界面标识 {asset}（score={float(best['score']):.3f}），交回任务结束")
            return {"page": "main", "evidence": asset, "completed": True, "reason": "局部目标已确认"}
    # 主界面被弹窗压暗时模板可能都不过阈，用底部导航文字兜底
    labels = _main_nav_labels(ctx)
    if len(labels) >= MIN_MAIN_NAV_LABELS:
        ctx.log(f"镜牢已完成并检测到底部导航 {labels}，交回任务结束")
        return {"page": "main", "evidence": "nav:" + ",".join(labels), "completed": True, "reason": "局部目标已确认"}
    return {"page": "waiting_main", "evidence": "", "completed": False, "reason": "镜牢已完成但还没回到主界面"}
