"""event 循环的兜底推进：没有命中任何业务 Step 时按一次 Enter，让文本或动画继续。"""
from lalc import RunContext, step


@step
def execute(ctx: RunContext, *, note: str = "") -> None:
    """
    在 event 子流程中按一下 Enter 键推进一次，然后等待一小段时间让页面响应。
    note 只用于把调用方的分支语义写进日志（例如未知页面的兑底推进），
    不影响按键行为；本步不判断当前页面状态，也不声明事件已经推进，
    页面是否变化由调用方重新截图观察；不向调用方返回任何局部结果。
    """
    # TODO: 事件 Enter 推进尚无入口保护；遇到对应叙述或判定动画情景时，尝试提取独特特征并补入口与已完成检查。
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=0.9)
    ctx.log(note or "没有命中任何 event Step，按 Enter 兜底推进")
