"""处理追加数据下载提示（A new download has been added.）：重启游戏，让启动器重新拉取并下载追加数据。

现场（1280x720，Run 654/1128）：
主界面／标题界面上弹出 A new download has been added. / The game will be closed; please restart the game
to download the update.，下方一个居中 Confirm（实测文字中心 (656,498)）。只点掉提示不会下载追加数据，
因此本规则改为 control.restart_game，由启动器完成下载；重启后最多等 10 分钟，以标题界面特征
（restart/clear_all_caches）且没有新的阻挡弹窗作为就绪证据。
等待按 10 秒分片执行（单次 observe.wait 上限 60 秒），暂停与取消仍由 observe.wait 响应；预算耗尽只记录后交回。
判定用弹窗正文文案，与 recovery.popup_download_notice（标题界面下载询问模板）和 recovery.downloading
（含 download 的下载中文字特征）互斥，避免同一现场多条规则同时命中。
"""
import re

from lalc import RunContext

POPUP_NAME = "追加下载提示"
# 正文第一行，最独特的识别特征；Run 653/654 现场连续多帧稳定识别。
# 关键字按 _norm 规则预先去空格，与规范化后的整屏 OCR 文字直接比较
TITLE_KEYWORD = "newdownloadhasbeenadded"
# 正文第二行，OCR 会断成两句；合并整屏文字后命中任一段即可佐证
BODY_KEYWORDS = ("restartthegame", "downloadtheupdate")
# 重启后最多观察 10 分钟
RESTART_WAIT_SECONDS = 600
POLL_SECONDS = 10
# 就绪证据：标题界面左下角 Clear all caches（与 recovery.title_to_main 同一素材）
READY_ASSET = "restart/clear_all_caches"
# 仍压着这些弹窗就不算就绪，交由对应规则或下一轮检测处理
BLOCKING_KEYWORDS = (
    TITLE_KEYWORD,
    "scheduledmaintenance",
    "cannotoperatethegame",
    "gameclientisnotuptodate",
)


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断字、断行和标点差异影响匹配。

    关键字常量也按本规则书写（如 newdownloadhasbeenadded），避免出现文字已去空格、
    关键字仍带空格而永远匹配不到的情况（Run 654 的假阴性原因）。
    """
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_text(ctx: RunContext) -> str:
    """刷新截图并返回整屏 OCR 合并后的规范化文本。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    items = result.get("items") or []
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _current_text(ctx: RunContext) -> str:
    """对当前已捕获帧整屏 OCR，返回规范化文本；不刷新截图。"""
    result = ctx.action("observe.ocr") or {}
    items = result.get("items") or []
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _evidence(text: str) -> str:
    """返回命中的关键字清单，便于日志区分是哪一个提示。"""
    return "、".join(keyword for keyword in (TITLE_KEYWORD, *BODY_KEYWORDS) if keyword in text)


def _ready(ctx: RunContext) -> bool:
    """当前帧是否已回到标题界面且没有挡住流程的弹窗。"""
    if not ctx.action("observe.match_asset", asset=READY_ASSET):
        return False
    text = _current_text(ctx)
    return not any(keyword in text for keyword in BLOCKING_KEYWORDS)


def detect(ctx: RunContext) -> bool:
    """只观察弹窗正文文案，不在检测阶段重启或点击。"""
    text = _screen_text(ctx)
    found = TITLE_KEYWORD in text and any(keyword in text for keyword in BODY_KEYWORDS)
    ctx.log(f"检测 {POPUP_NAME}：命中证据 [{_evidence(text)}]，判定 {found}")
    return found


def recover(ctx: RunContext) -> None:
    """重启游戏让启动器下载追加数据，重启后最多等 10 分钟观察是否回到可识别界面。"""
    text = _screen_text(ctx)
    if TITLE_KEYWORD not in text:
        ctx.log(f"{POPUP_NAME} 已消失，本次不重启")
        return

    ctx.log(f"检测到 {POPUP_NAME}，重启游戏让启动器下载追加数据（不点击弹窗里的 Confirm）")
    ctx.action("control.restart_game")
    waited = 0
    while waited < RESTART_WAIT_SECONDS:
        ctx.action("observe.wait", seconds=POLL_SECONDS)
        waited += POLL_SECONDS
        ctx.action("observe.capture_screen")
        if _ready(ctx):
            ctx.log(f"重启后约{waited}秒已回到标题界面，追加数据交由启动器下载，交回主流程重新观察")
            return
    ctx.log(
        f"重启后等到 {RESTART_WAIT_SECONDS // 60} 分钟仍未回到可识别界面，交回主流程重新观察",
        level="warning",
        screenshot=True,
    )
