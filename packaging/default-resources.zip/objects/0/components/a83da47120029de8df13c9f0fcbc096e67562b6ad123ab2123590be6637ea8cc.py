"""复查事件叙述页后，按右下角固定坐标点击一次。"""
import re

from lalc import RunContext, step

CHOICES_ASSET = "event/choices"
RESULT_ASSET = "event/result"
# 叙述页 SKIP 按钮改用模板匹配，不再读右下角 OCR 文案
SKIP_ASSET = "event/skip"
# 判定选择阶段的成功率档次标签：任意一档命中就说明已经进入判定页，作为叙述阶段的退出信号
PASS_TIER_ASSETS = (
    "event/pass/veryhigh",
    "event/pass/high",
    "event/pass/normal",
    "event/pass/low",
    "event/pass/verylow",
)
# 五档成功率标签统一使用 0.8 的模板匹配阈值（observe.match_asset 默认 0.9，更严格）
PASS_TIER_THRESHOLD = 0.8
# 右下角 SKIP 按钮与右上 Choices 标题所在区域（1280x720 客户区）
SKIP_REGION = {"x": 1020, "y": 590, "width": 240, "height": 120}
CHOICES_REGION = {"x": 640, "y": 85, "width": 320, "height": 80}
CHOICES_KEYWORD = "choices"
# 右下角推进按钮的固定点击坐标：与 step.event_result_proceed 保持一致，
# 叙述阶段的 SKIP 与结果页的 Proceed／Continue 在不同阶段共用同一位置
CLICK_POINT = (1140, 650)
# 点击后等待页面响应，再确认是否已离开叙述阶段


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _texts(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做 OCR，返回合并后的规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _choices_page(ctx: RunContext) -> bool:
    """判断当前帧是否已到事件选项阶段：优先 Choices 标题模板，其次右上角 OCR 文本。"""
    if ctx.action("observe.match_asset", asset=CHOICES_ASSET):
        return True
    return CHOICES_KEYWORD in _texts(ctx, CHOICES_REGION)


def _result_page(ctx: RunContext) -> bool:
    """判断当前帧是否已经到事件结果阶段，避免在结果页继续点 SKIP。"""
    return bool(ctx.action("observe.match_asset", asset=RESULT_ASSET))


def _skip_button(ctx: RunContext) -> bool:
    """当前帧右下角是否命中 event/skip 模板（叙述阶段 SKIP 按钮可用）。"""
    return bool(ctx.action("observe.match_asset", asset=SKIP_ASSET, region=SKIP_REGION))


def _check_page(ctx: RunContext) -> bool:
    """当前帧是否已进入判定选择页：成功率档次标签任意一档命中即算，不读 OCR 文案。"""
    return any(
        ctx.action("observe.match_asset", asset=asset, threshold=PASS_TIER_THRESHOLD)
        for asset in PASS_TIER_ASSETS
    )


@step
def execute(ctx: RunContext) -> None:
    """复查当前操作入口，适用时仅点击一次。"""
    ctx.action("observe.capture_screen")
    if _choices_page(ctx):
        ctx.log("当前已在事件选项阶段，无需跳过叙述")
        return
    if _result_page(ctx):
        ctx.log("当前已在事件结果阶段，无需跳过叙述")
        return
    if _check_page(ctx):
        ctx.log("当前已在事件判定选择页，无需跳过叙述")
        return

    if not _skip_button(ctx):
        ctx.log(
            "右下角没有命中 event/skip 模板，当前不在事件叙述页，也未命中选项／结果／判定页，未点击",
            level="warning",
            screenshot=True,
        )
        return

    point = f"{CLICK_POINT[0]},{CLICK_POINT[1]}"
    ctx.log(f"命中叙述页 event/skip 模板，点击右下角固定坐标 ({CLICK_POINT[0]}, {CLICK_POINT[1]}) 跳过叙述")
    ctx.action("control.click", centerxy=CLICK_POINT)
