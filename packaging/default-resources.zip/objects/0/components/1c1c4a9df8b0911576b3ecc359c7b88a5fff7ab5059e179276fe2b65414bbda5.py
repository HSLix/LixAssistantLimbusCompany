"""主界面体力条点击：打开 Charge Enkephalin 兑换弹窗，只点一次，落点由上层重新观察。"""
import re

from lalc import RunContext, step

# 弹窗打开标志：标题 Charge Enkephalin（1280x720 实测文字位于 x532~747、y104~136）
POPUP_TITLE_REGION = {"x": 500, "y": 95, "width": 280, "height": 55}
POPUP_TITLE_KEYWORD = "chargeenkephalin"
# 体力读数区域（与 step.check_stamina_overflow 一致），用读数框中心作为点击点
STAMINA_REGION = {"x": 290, "y": 600, "width": 190, "height": 100}
STAMINA_PATTERN = re.compile(r"(\d{1,4})[/\\|](\d{1,4})")
# 读不到读数时的回退点击点：1280x720 实测体力条 "159/159" 中心附近
FALLBACK_POINT = (390, 672)
AFTER_CLICK_SECONDS = 1.2


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_items(ctx: RunContext, region: dict[str, int]) -> list[dict]:
    """对当前帧指定区域做一次 OCR，返回条目列表；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    return list(result.get("items") or [])


@step
def execute(ctx: RunContext) -> None:
    """弹窗已打开时零输入返回；否则点一次体力读数打开弹窗，等固定秒数后交回。"""
    ctx.action("observe.capture_screen")
    title = "".join(str(item.get("text", "")) for item in _region_items(ctx, POPUP_TITLE_REGION))
    if POPUP_TITLE_KEYWORD in _norm(title):
        ctx.log("Charge Enkephalin 弹窗已经打开，无需再点体力条")
        return

    point = FALLBACK_POINT
    for item in _region_items(ctx, STAMINA_REGION):
        text = re.sub(r"\s+", "", str(item.get("text", "")))
        box = item.get("box") or {}
        if box and STAMINA_PATTERN.search(text):
            point = (int(box["x"] + box["width"] // 2), int(box["y"] + box["height"] // 2))
            break

    ctx.log(f"点击体力读数 {point} 打开 Charge Enkephalin 弹窗，等 {AFTER_CLICK_SECONDS} 秒后交回")
    ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
