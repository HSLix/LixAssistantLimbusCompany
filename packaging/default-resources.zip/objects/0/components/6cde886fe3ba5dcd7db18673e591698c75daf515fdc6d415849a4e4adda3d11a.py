"""灰化 SKIP 的叙述页：复查 event/grey_skip 后连续按 3 次 Enter，每次间隔 1 秒推进。"""
from lalc import RunContext, step

# 灰化 SKIP 模板的匹配区域（1280x720 客户区），与 sub_workflow.event 的 SKIP 匹配区域一致。
# 模板是整颗按钮的裁剪（240x95），宽度与原来的按钮区域相同；区域没有横向余量时模板只有唯一位置可放，
# 按钮偏移几个像素就永远匹配不到，这里用带余量的右下角区域让模板按实际位置滑动。
BUTTON_REGION = {"x": 980, "y": 560, "width": 300, "height": 160}
GREY_SKIP_ASSET = "event/grey_skip"
# 推进次数与间隔：灰化 SKIP 点不动，按 Enter 仍能推进文本，因此连续 3 次、每次间隔 1 秒
PRESS_COUNT = 3
PRESS_INTERVAL_SECONDS = 1.0


def _grey_skip(ctx: RunContext) -> bool:
    """当前帧右下角是否命中灰化的 event/grey_skip 模板；只匹配按钮区域，不读 OCR 文案。"""
    return bool(ctx.action("observe.match_asset", asset=GREY_SKIP_ASSET, region=BUTTON_REGION))


@step
def execute(ctx: RunContext) -> None:
    """
    事件叙述页「灰化 SKIP」的一次局部尝试：
    1. 先重新截图复查入口：右下角没有命中 event/grey_skip 时零输入返回，不按任何键；
    2. 命中时连续按 PRESS_COUNT 次 Enter，每次之间等待 PRESS_INTERVAL_SECONDS 秒。
    本步不判断页面是否已推进、不轮询、也不返回局部结果；是否离开灰化叙述页
    由 sub_workflow.event 下一轮重新截图验收（可点击的 event/skip 由叙述页点击分支处理）。
    """
    ctx.action("observe.capture_screen")
    if not _grey_skip(ctx):
        ctx.log(
            "右下角没有命中 event/grey_skip 模板，本步不按 Enter",
            level="warning",
            screenshot=True,
        )
        return

    ctx.log(
        f"命中灰化 SKIP（event/grey_skip），连续按 {PRESS_COUNT} 次 Enter，间隔 {PRESS_INTERVAL_SECONDS} 秒推进"
    )
    for index in range(1, PRESS_COUNT + 1):
        ctx.action("control.key_press", key="enter")
        if index < PRESS_COUNT:
            ctx.action("observe.wait", seconds=PRESS_INTERVAL_SECONDS)
