"""镜牢主题包选择页：按设置页选择的难度核对右上角 ///NORMAL 标签，不一致时点一次箭头切换。

按钮形态（1280x720 现场实测，左右镜像只在两种难度间变化）：
- 普通：`///NORMAL [◀ ▶]`，标签在左（828~910），左右箭头胶囊在右（约 918 / 973）；
- 困难：`[◀ ▶] HARD ///`，标签在右（908~990），左右箭头胶囊在左（约 848 / 898）。
两个箭头本质是同一个切换按钮的不同方向，点一次就在普通与困难之间切换。
本 Step 每场镜牢最多点一次箭头（记录在 RunState.settings 的 mirror.runtime.difficulty_switched，
由 plan 在每场开始时复位）：先截图，用素材模板确认当前难度，与配置不一致才点一次箭头，
点完固定等 2 秒再重新截图复验。箭头点过之后再进来只观察并记日志，无论难度是否符合都不再点；
真正落在哪一页由上层 task.mirror 重新观察，本层不猜。
返回 status：already（已经是目标难度）、switched（已切换并复验确认）、
not_confirmed（切换后复验仍与目标不一致）、switch_skipped（本场已经点过箭头，按当前画面继续）、
ambiguous（两个模板同时命中）、not_identified（两个模板都没命中，例如页面还在动画，不点任何按钮）、
not_page（已出现火车头，不在主题包选择页）。
"""
from lalc import RunContext, step

# 与镜牢设置页同一份配置：settings.mirror.settings.difficulty，取值 normal／hard
MIRROR_PAGE_ID = "mirror.settings"
DIFFICULTY_KEY = "difficulty"
DIFFICULTY_NORMAL = "normal"
DIFFICULTY_HARD = "hard"
# 两种难度状态的标签模板（各 82x34，同一块区域裁出）：普通裁自 (828,30)，困难裁自 (908,30)
NORMAL_ASSET = "mirror/theme_pack_difficulty_normal"
HARD_ASSET = "mirror/theme_pack_difficulty_hard"
# 模板匹配阈值：普通标签画面稳定，沿用默认 0.9；困难标签会周期发光，亮度变化会把
# 分数压到 0.9 以下，按开发者要求单独降到 0.8
NORMAL_THRESHOLD = 0.9
HARD_THRESHOLD = 0.8
# 本场镜牢是否已经点过一次难度箭头：开发者要求难度切换只管点一次，点过之后无论难度是否
# 符合都不再点；plan 在每场镜牢开始时把这个记录复位
RUNTIME_KEY = "mirror.runtime"
DIFFICULTY_SWITCHED_KEY = "difficulty_switched"
# 只在右上角这一条按钮带里匹配，避开画面中间同样写着 NORMAL／HARD 的金色横幅
DIFFICULTY_REGION = {"x": 815, "y": 18, "width": 190, "height": 62}
# 箭头胶囊相对标签命中框的水平偏移（实测）：
# 普通标签右侧 63px 是右箭头中心，困难标签左侧 60px 是左箭头中心；两种状态都点「远离标签」的那一侧
ARROW_OFFSET_FROM_NORMAL = 63
ARROW_OFFSET_FROM_HARD = 60
# 点击难度箭头后的固定等待（开发者要求等 2 秒）：难度切换会重新加载本层可选主题包，
# 等满 2 秒再截图复验，避免在重绘／动画帧上误判；复验后仍交给上层 4 秒稳定等待
SWITCH_SETTLE_SECONDS = 2.0
# 主题包已选好、进入寻路页的标识：这时不核对难度，也不点任何按钮
TRAIN_HEAD_ASSET = "mirror/train_head"


def _configured(ctx: RunContext) -> str:
    """读取设置页选择的难度；缺失或非法值按普通处理（与页面默认值一致）。"""
    page = (ctx.run_state.settings or {}).get(MIRROR_PAGE_ID)
    raw = page.get(DIFFICULTY_KEY) if isinstance(page, dict) else None
    return DIFFICULTY_HARD if str(raw).strip().lower() == DIFFICULTY_HARD else DIFFICULTY_NORMAL


def _hits(ctx: RunContext, asset: str, threshold: float) -> list:
    """对当前帧在右上角按钮带里按各自阈值匹配一个难度标签模板；不刷新截图。"""
    return list(
        ctx.action(
            "observe.match_asset",
            asset=asset,
            region=DIFFICULTY_REGION,
            threshold=threshold,
        )
        or []
    )


def _switch_used(ctx: RunContext) -> bool:
    """本场镜牢是否已经点过一次难度箭头；没有记录时按还没点过处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(DIFFICULTY_SWITCHED_KEY) is True


def _set_switch_used(ctx: RunContext, used: bool) -> None:
    """
    记录本场镜牢已经点过难度箭头；每场开始时由 plan 复位。
    写入前 RunState 里可能还没有这个记录，拿到的是空 dict，必须写回 settings 才会生效。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录难度箭头已点状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[DIFFICULTY_SWITCHED_KEY] = used
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢难度切换状态 {DIFFICULTY_SWITCHED_KEY}={used}")


def _state(ctx: RunContext) -> tuple[str, dict | None, int, int]:
    """
    判定当前帧的难度状态，返回 (状态, 标签命中, 普通命中数, 困难命中数)。
    两个模板都命中时状态为 ambiguous，都不命中时为 not_identified：这两种情况都不点按钮。
    """
    normal_hits = _hits(ctx, NORMAL_ASSET, NORMAL_THRESHOLD)
    hard_hits = _hits(ctx, HARD_ASSET, HARD_THRESHOLD)
    if normal_hits and hard_hits:
        return "ambiguous", None, len(normal_hits), len(hard_hits)
    if normal_hits:
        return DIFFICULTY_NORMAL, normal_hits[0], len(normal_hits), 0
    if hard_hits:
        return DIFFICULTY_HARD, hard_hits[0], 0, len(hard_hits)
    return "not_identified", None, 0, 0


def _arrow_center(state: str, hit: dict) -> tuple[int, int]:
    """
    按标签命中框推算切换箭头的位置：普通状态点标签右侧的右箭头，困难状态点标签左侧的左箭头
    （两种画面左右镜像，箭头总在标签的外侧）。
    """
    x = int(hit.get("x") or 0)
    width = int(hit.get("width") or 0)
    center = hit.get("centerxy") or (0, 0)
    y = int(center[1])
    if state == DIFFICULTY_NORMAL:
        return x + width + ARROW_OFFSET_FROM_NORMAL, y
    return x - ARROW_OFFSET_FROM_HARD, y


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """核对一次难度：已是目标难度或本场已经点过箭头就零输入返回，否则点一次箭头并复验后交回上层。"""
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=TRAIN_HEAD_ASSET):
        ctx.log("已出现火车头，说明主题包已选好，不核对难度")
        return {"status": "not_page"}
    wanted = _configured(ctx)
    current, hit, normal_count, hard_count = _state(ctx)
    ctx.log(
        f"难度核对：设置页选择 {wanted}；当前画面 {NORMAL_ASSET}（阈值 {NORMAL_THRESHOLD}）"
        f"命中 {normal_count} 个、{HARD_ASSET}（阈值 {HARD_THRESHOLD}）命中 {hard_count} 个"
        f"（按 {current} 处理）"
    )
    if current == "ambiguous":
        ctx.log(
            "两种难度标签模板同时命中，无法判断当前难度，不点箭头，交上层重新观察",
            level="warning",
            screenshot=True,
        )
        return {"status": "ambiguous"}
    if current == "not_identified":
        ctx.log(
            "右上角两个难度标签模板都没命中（可能页面还在动画或不在主题包选择页），"
            "不点箭头，交上层重新观察",
            level="warning",
            screenshot=True,
        )
        return {"status": "not_identified"}
    if current == wanted:
        return {"status": "already"}
    if _switch_used(ctx):
        ctx.log(
            f"本场镜牢已经点过一次难度箭头（按开发者要求不再重复点）：当前 {current}、目标 {wanted}，"
            "本次按当前画面的难度继续选择主题包",
            level="warning",
            screenshot=True,
        )
        return {"status": "switch_skipped"}
    arrow = _arrow_center(current, hit or {})
    ctx.log(
        f"难度不一致（{current} → {wanted}），点一次难度胶囊箭头 ({arrow[0]}, {arrow[1]})"
        f"（箭头位置按 {current} 标签命中框推算）"
    )
    ctx.action("control.click", x=arrow[0], y=arrow[1])
    # 点下就先记下本场唯一的一次切换机会已经用掉：复验失败或上层重入都不再点
    _set_switch_used(ctx, True)
    # 开发者要求：点完难度箭头先自动等 2 秒，等页面重绘／重新加载后再截图检测
    ctx.log(f"已点下难度箭头，先等 {SWITCH_SETTLE_SECONDS} 秒再截图复验难度")
    ctx.action("observe.wait", seconds=SWITCH_SETTLE_SECONDS)
    ctx.action("observe.capture_screen")
    now, _hit, normal_count, hard_count = _state(ctx)
    if now == wanted:
        ctx.log(
            f"切换后复验通过：右上角现在按 {now} 处理"
            f"（NORMAL {normal_count} 个、HARD {hard_count} 个），附稳定后的截图",
            screenshot=True,
        )
        return {"status": "switched"}
    ctx.log(
        f"切换后复验未通过：右上角按 {now} 处理（目标 {wanted}；"
        f"NORMAL {normal_count} 个、HARD {hard_count} 个），"
        "可能是切换没生效或模板在动画帧上没命中，交上层重新观察",
        level="warning",
        screenshot=True,
    )
    return {"status": "not_confirmed"}
