"""镜牢商店：把右侧商品列表整体向下或向上滚动（超级商店一屏加载不完时使用）。

子流程不直接调用鼠标滚动这类控制动作，滚动集中放在这个 Step 里：先截图复查入口仍是商店页，
再在商品列表中间按 direction 滚 steps 格，最后等固定时间让列表停稳。
滚动只移动列表位置，不点击任何商品；滚到第几屏、是否已经到底由上层重新截图后的观察判断。
"""
import re

from lalc import RunContext, step

# 商店页标识（与购买循环一致的三条取或）：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题。
# 超级商店的左上角是 Super Shop，规范化后包含 shop，因此不需要为此再写一条判据。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 商品列表中间的滚动位置（1280x720 实测商品区 x 505~1205、y 175~565）：
# 落在两行商品卡片之间，滚轮只滚动列表、不会触发点击
SCROLL_POINT = (1150, 420)
# 滚动后等待列表停稳
SCROLL_SETTLE_SECONDS = 0.8
# control.scroll 单次最多 10 格（Trusted Action 契约）：本步要滚更多格时按 10 格一批连续发送
MAX_SCROLL_ACTION_STEPS = 10
# 本步一次调用最多滚动 20 格（超级商店看第二屏与回顶都按 20 格）：20 格分两批发送
MAX_SCROLL_STEPS = 20


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _in_shop(ctx: RunContext) -> bool:
    """当前帧是否为镜牢商店页：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题。"""
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    result = ctx.action("observe.ocr", region=SHOP_TITLE_REGION) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return SHOP_TITLE_KEYWORD in _norm(joined)


@step
def execute(ctx: RunContext, *, direction: str = "down", steps: int = 20) -> dict[str, str]:
    """
    在商店商品列表中间按 direction（down／up）滚动 steps 格（1~MAX_SCROLL_STEPS，默认 20）并等待列表停稳。
    control.scroll 单次最多 10 格，超过 10 格时按 10 格一批连续发送，批间与最后都等待列表停稳。
    先截图复查入口：当前不是商店页、或技能替换弹窗等遮住画面时不做盲滚——这里只按商店页判据
    拦一次，弹窗类遮挡由上层在调用前处理；返回 action（scrolled／not_in_shop）、方向与格数。
    滚动不点击商品，也不判断列表是否到底，滚动后看到的内容由上层重新截图后的商品区 OCR 决定。
    """
    if direction not in ("down", "up"):
        raise ValueError("direction 只能是 down 或 up")
    if not isinstance(steps, int) or not 1 <= steps <= MAX_SCROLL_STEPS:
        raise ValueError(f"steps 必须是 1~{MAX_SCROLL_STEPS} 的整数")
    ctx.action("observe.capture_screen")
    if not _in_shop(ctx):
        ctx.log("当前不是镜牢商店页，不滚动商品列表", level="warning", screenshot=True)
        return {"action": "not_in_shop", "direction": direction, "steps": str(steps)}
    ctx.log(
        f"把商店商品列表往{'下' if direction == 'down' else '上'}滚动 {steps} 格"
        f"（位置 {SCROLL_POINT}，按单次最多 {MAX_SCROLL_ACTION_STEPS} 格分批发送），"
        f"等 {SCROLL_SETTLE_SECONDS} 秒后交回"
    )
    remaining = steps
    while remaining > 0:
        chunk = min(remaining, MAX_SCROLL_ACTION_STEPS)
        ctx.action("control.scroll", direction=direction, steps=chunk, centerxy=SCROLL_POINT)
        remaining -= chunk
        if remaining > 0:
            # 批与批之间留出列表停稳时间，避免连续滚轮被合并或漏格
            ctx.action("observe.wait", seconds=SCROLL_SETTLE_SECONDS)
    ctx.action("observe.wait", seconds=SCROLL_SETTLE_SECONDS)
    return {"action": "scrolled", "direction": direction, "steps": str(steps)}
