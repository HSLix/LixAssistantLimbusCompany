"""镜牢商店「自维护饰品」入口一步：点开 Sell E.G.O Gift 弹窗并确认标题出现。

弹窗已经开着（上一次没关掉）时零输入返回 already_open，避免同一次运行里重复点按钮。
本步只点商店页的 Sell Gifts 按钮，不点弹窗里的 Sell 按钮：那个会真的把饰品卖掉，且不可撤回。
"""
import re

from lalc import RunContext, step

# 商店页底部中间的 Sell Gifts 按钮（1280x720 实测中心 (414,385)；弹窗打开后这里被弹窗盖住）
SELL_GIFTS_BUTTON = (414, 385)
# 弹窗标题横幅：实测标题文字 "Sell E.G.O Gift" 中心 (641,102)
POPUP_TITLE_REGION = {"x": 500, "y": 76, "width": 300, "height": 54}
POPUP_TITLE_WORDS = ("sell", "gift")
# 标题 OCR 漏识别时的后备判据：弹窗左下角的 Close 按钮，商店页没有这段文字
POPUP_CLOSE_REGION = {"x": 438, "y": 560, "width": 116, "height": 48}
POPUP_CLOSE_WORD = "close"
# 点完按钮到弹窗滑入完成的固定等待，交回后仍以本次截图为准
POPUP_SETTLE_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响按钮文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _popup_open(ctx: RunContext) -> bool:
    """当前帧是否已经打开 Sell E.G.O Gift 弹窗：标题为主，左下角 Close 按钮为后备。"""
    text = _region_text(ctx, POPUP_TITLE_REGION)
    if all(word in text for word in POPUP_TITLE_WORDS):
        return True
    return POPUP_CLOSE_WORD in _region_text(ctx, POPUP_CLOSE_REGION)


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    先截一帧判断弹窗是否已经开着：开着就零输入返回 already_open；
    否则点一次商店页的 Sell Gifts 按钮，等 POPUP_SETTLE_SECONDS 后重新截图确认标题。
    返回 status=already_open/opened/not_opened，打开失败只记 warning，由上层决定是否继续。
    """
    ctx.action("observe.capture_screen")
    if _popup_open(ctx):
        ctx.log("Sell E.G.O Gift 弹窗已经开着，本次不再点 Sell Gifts 按钮")
        return {"status": "already_open"}
    ctx.log(f"点击商店页的 Sell Gifts 按钮 {SELL_GIFTS_BUTTON}，打开 Sell E.G.O Gift 弹窗")
    ctx.action("control.click", x=SELL_GIFTS_BUTTON[0], y=SELL_GIFTS_BUTTON[1])
    ctx.action("observe.wait", seconds=POPUP_SETTLE_SECONDS)
    ctx.action("observe.capture_screen")
    if _popup_open(ctx):
        ctx.log("Sell E.G.O Gift 弹窗已打开")
        return {"status": "opened"}
    ctx.log(
        "点过 Sell Gifts 按钮后仍未读到弹窗标题与 Close 按钮，饰品自维护本次无法进行",
        level="warning",
        screenshot=True,
    )
    return {"status": "not_opened"}
