"""镜牢战斗胜利结算页：点一次右下角 Confirm，结果由上层重新观察。"""
from lalc import RunContext, step

# Victory 结算页标识：右上角 Victory 文字模板
VICTORY_ASSET = "battle/victory"
# 结算页右下角 Confirm 按钮（含左侧对勾）在 1280x720 客户区中的固定坐标
CONFIRM_POINT = (1147, 570)
# 点击后的固定等待：先让结算页切换，避免在过渡动画里重复输入
SETTLE_SECONDS = 1.5
# 本场镜牢刚结算结果在 RunState.settings 中的位置；结算规则据此决定是否领取奖励
RUNTIME_KEY = "mirror.runtime"
LAST_RESULT_KEY = "last_result"
RESULT_VICTORY = "victory"


def _mark_last_result(ctx: RunContext, value: str) -> None:
    """把本场镜牢刚结算结果写进 RunState.settings，供结算规则决定是否领取奖励。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录本场镜牢刚结算结果", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[LAST_RESULT_KEY] = value
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录本场镜牢刚结算结果 {LAST_RESULT_KEY}={value}")


def _victory_here(ctx: RunContext) -> bool:
    """对当前帧匹配 Victory 标识，判断是否仍停在胜利结算页；不刷新截图。"""
    return bool(ctx.action("observe.match_asset", asset=VICTORY_ASSET))


@step
def execute(ctx: RunContext) -> None:
    """
    先截图复查入口：看不到 Victory 标识（当前不在胜利结算页）时零输入返回；
    确在胜利结算页才点一次右下角固定坐标的 Confirm，等固定 1.5 秒后交回。
    同时把本场刚结算结果写进 RunState（不是返回值），供结算规则决定是否领取奖励；
    Victory 是否已消失、是否已回到下一页面由 task.mirror 下一轮重新观察，本步不轮询。
    """
    ctx.action("observe.capture_screen")
    if not _victory_here(ctx):
        ctx.log("当前不是 Victory 结算页，不点击 Confirm")
        return

    _mark_last_result(ctx, RESULT_VICTORY)
    ctx.log(f"点击一次 Victory 结算页右下角 Confirm {CONFIRM_POINT}，等 {SETTLE_SECONDS} 秒后交回")
    ctx.action("control.click", x=CONFIRM_POINT[0], y=CONFIRM_POINT[1])
    ctx.action("observe.wait", seconds=SETTLE_SECONDS)
