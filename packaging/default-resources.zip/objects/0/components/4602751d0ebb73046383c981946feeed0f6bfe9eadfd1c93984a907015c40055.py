"""镜牢商店：遍历技能替换商品，一次调用把一件商品的弹窗推进到成交，再交回上层验收。

点开弹窗前先从商品卡名字（Replace <罪人>'s Skill）读出罪人，本场队伍没有勾选这个罪人的技能替换时
不打开弹窗直接跳过；名字有 OCR 误差时允许最多 MAX_SINNER_EDITS 个字符的模糊匹配（商品一定属于十二罪人之一），
并记 warning。只有需要买时才点开商品卡，用弹窗标题校验罪人后一路推进到成交。
"""
import re
import unicodedata

from lalc import RunContext, step

# 技能替换商品的价格图标：命中后点击它正上方的商品卡进入技能替换弹窗
SKILL_ITEM_ASSET = "mirror/shop/question_mark_price"
# 只在商店右侧商品列表里找价格图标，避开左侧 Enhance Gifts 等同样可能显示 ?? 价格的面板
SHOP_ITEM_REGION = {"x": 505, "y": 175, "width": 700, "height": 390}
# 商店页标识（三条判据取或，任一成立就算商店页）：
# ① 右上角普通 Refresh 按钮模板命中；② Keyword Refresh 按钮模板命中；③ 左上角 Shop 标题文字。
# 单个按钮模板在遮挡／动画帧下可能只命中一个，短标题 OCR 也会偶发漏识别，取或后不再要求两个同时命中。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 技能替换弹窗标题 Replace <罪人名>'s Skill：弹窗会盖住商店页，标题是它的唯一入口特征。
# 区域只框住标题铭牌本身（x 175~600）。右边界停在 600：再往右是弹窗框上的 Skills Owned
# 和中间那排 SKILL 1x2／SKILL 2x3／SKILL 3x1 标签（实测起点 x=612、y=129，与标题同一条横幅高度），
# 它们都含 skill 字样，混进标题会让罪人解析读到无关文字。
# 之前用 430x60 的窄区域，实测标题偏长时局部 OCR 会把两端丢掉（只读到 Don + n Quixote's），
# 因此横向按整条铭牌取足够宽度、纵向保留整行高度，让 OCR 有足够上下文识别完整标题。
POPUP_TITLE_REGION = {"x": 175, "y": 95, "width": 425, "height": 80}
POPUP_TITLE_KEYWORDS = ("replace", "skill")
# 标题 OCR 仍漏字时的后备判据：弹窗底部的 Cancel／Confirm 按钮在商店页不会同时出现
POPUP_ACTION_REGION = {"x": 400, "y": 505, "width": 520, "height": 70}
POPUP_ACTION_KEYWORDS = ("cancel", "confirm")
# 局部标题 OCR 不完整时，用整屏 OCR 只取标题铭牌范围内的文本补全标题；
# 右边界同样停在 600，避免把右侧 Skills Owned 与 SKILL nxm 标签所在的 X 区间算进来
FULL_TITLE_X = (175, 600)
FULL_TITLE_Y = (95, 175)
# 宽松解析罪人名的最小长度：太短的名字按字符顺序匹配容易误配
MIN_LOOSE_ALIAS_LENGTH = 5
# 弹窗底部 Cancel／Confirm 按钮的固定坐标
CANCEL_POINT = (523, 542)
CONFIRM_POINT = (814, 542)
# 弹窗里三个替换选项的固定坐标，从左到右依次是 1→2、2→3、1→3，编号与队伍配置页一致
OPTION_POINTS = {1: (315, 340), 2: (637, 340), 3: (970, 340)}
MAX_OPTIONS = 3
# 成交确认页的提示：Spend <价格> Cost to replace this Skill?
# 实测 en 1.119.0 是两阶段：选择页点选项只改当前选择，点选择页的 Confirm 才进入这个提示页，
# 再点一次 Confirm 才真正扣 Cost 完成替换。
# 确认页用素材 mirror/shop/cost_to_replace_this_skill（216x17）做模板匹配，不再读提示文字
PROMPT_ASSET = "mirror/shop/cost_to_replace_this_skill"
PROMPT_REGION = {"x": 300, "y": 450, "width": 700, "height": 90}
PROMPT_THRESHOLD = 0.85
# 弹窗的三个状态：不在、选择页（三张技能卡 + Cancel／Confirm）、成交确认页（Spend … Cost + Cancel／Confirm）
PAGE_NONE = "none"
PAGE_SELECT = "select"
PAGE_PROMPT = "prompt"
# 确认提示里左右两张技能卡上方的 SKILL n 标签：左边是原技能、右边是替换后的技能
PAIR_REGION = {"x": 490, "y": 195, "width": 620, "height": 60}
PAIR_LABEL = re.compile(r"skill([123])")
# 选中的技能对与选项编号的对应：1→2、2→3、1→3
OPTION_BY_PAIR = {(1, 2): 1, (2, 3): 2, (1, 3): 3}
# 依次点击多个勾选项之间的间隔，以及点 Confirm 前让按钮动画落定的等待
OPTION_CLICK_SECONDS = 0.8
CONFIRM_SETTLE_SECONDS = 1.0
# 选择页 Confirm 之后等成交确认页滑入的时间：同一次调用要在这之后复核确认页
PROMPT_WAIT_SECONDS = 1.5
# 价格图标到商品卡的距离：点图标正上方这么高就是这张商品卡
ITEM_CLICK_HEIGHT = 60
# 商品卡名字行（Replace <罪人>'s Skill）在价格行下方：以价格图标中心为基准取一块窄区域，
# 实测 1280x720 名字行中心 y≈341、价格图标中心 y≈317（行距≈154），卡宽≈153，所以只取±90 像素
CARD_NAME_HALF_WIDTH = 90
CARD_NAME_TOP_OFFSET = 8
CARD_NAME_HEIGHT = 55
# 罪人名模糊匹配允许的最大字符修改次数：商品一定属于十二罪人之一，允许 OCR 的小幅误差
MAX_SINNER_EDITS = 2
# 同一商品的位置判定半径：商品行高约 100 像素，用 40 像素区分相邻商品
SAME_ITEM_RADIUS = 40
# 已买过的商品卡上方会显示 Purchased：价格图标仍在但点不开弹窗，需要跳过
PURCHASED_KEYWORD = "purchased"
PURCHASED_REGION_SIZE = (150, 45)
PURCHASED_REGION_OFFSET = (75, 115)
# 点击商品卡片后等待弹窗滑入的固定时间，以及每次弹窗内动作后的固定等待
CLICK_WAIT_SECONDS = 1.5
AFTER_ACTION_SECONDS = 1.0
# 成交确认页点 Confirm 后游戏要联网提交：失败会在确认页上叠一个 Server Error 弹窗。
# 本步不再单独检测 Server Error，交上层每轮的通用过渡检测（step.detect_normal_transition）
# 识别并抛给恢复规则处理。
# 本次镜牢使用的队伍来自镜牢设置页，技能替换配置按队伍保存在队伍配置页
MIRROR_PAGE_ID = "mirror.settings"
# 镜牢设置页「商店设置」的技能替换开关（默认开启）：关闭时本步不再购买，
# 遇到已打开的技能替换弹窗只点一次 Cancel 关掉。
SKILL_REPLACE_SWITCH_KEY = "shop_skill_replace"
TEAM_PAGE_ID = "sinners.team_presets"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
TEAMS_KEY = "teams"
SKILL_KEY = "skill_replacements"
# 本次商店已处理的商品记录在 RunState.settings 的镜牢运行时状态里，重入时不重复点击
RUNTIME_KEY = "mirror.runtime"
HANDLED_KEY = "shop_skill_handled"
# 本场镜牢实际使用的队伍记在 mirror.runtime.team_used 里（task.mirror 进场时写入，已是游戏队伍槽位号）：
# 镜牢队伍按设置页的循环顺序逐场轮换，设置页的 mirror_team 只是循环里的第一支，不能代表本场队伍
# （Run 417：轮换到第 2 个队伍，技能替换却按第 1 个队伍读取，误把 yi_sang 的 1→2 换成第 2 队）
TEAM_USED_KEY = "team_used"
# 弹窗标题里的罪人英文名（规范化后为小写纯字母）到队伍配置键的映射
SINNER_ALIASES = (
    ("yi_sang", ("yisang",)),
    ("faust", ("faust",)),
    ("don_quixote", ("donquixote",)),
    ("ryoshu", ("ryoshu",)),
    ("meursault", ("meursault",)),
    ("hong_lu", ("honglu",)),
    ("heathcliff", ("heathcliff",)),
    ("ishmael", ("ishmael",)),
    ("rodion", ("rodion",)),
    ("sinclair", ("sinclair",)),
    ("outis", ("outis",)),
    ("gregor", ("gregor",)),
)


def _norm(text: str) -> str:
    """去掉音标、空白和符号并转小写，避免 OCR 断行与 Ryōshū 之类字符影响名字匹配。"""
    decomposed = unicodedata.normalize("NFKD", str(text))
    ascii_only = "".join(char for char in decomposed if ord(char) < 128)
    return re.sub(r"[^a-z0-9]", "", ascii_only.lower())


def _title_part(text: str) -> str:
    """
    只保留界面上的 Replace <罪人名>'s Skill 这一段，丢掉同一横幅里混进来的其他标签。
    弹窗右侧的 Skills Owned 与中间的 SKILL 1x2／SKILL 2x3／SKILL 3x1 也含 skill 字样，
    区域裁切仍可能带进少量残字，因此取第一个 replace 到其后第一个 skill 为止。
    """
    start = text.find("replace")
    if start < 0:
        return text
    end = text.find("skill", start + len("replace"))
    if end < 0:
        return text[start:]
    return text[start : end + len("skill")]


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _action_buttons(ctx: RunContext) -> bool:
    """当前帧底部是否同时出现 Cancel 与 Confirm：技能替换弹窗的固定按钮，商店页没有。"""
    text = _region_text(ctx, POPUP_ACTION_REGION)
    return all(word in text for word in POPUP_ACTION_KEYWORDS)


def _full_title(ctx: RunContext) -> str:
    """整屏 OCR 后只取标题横幅范围内的文本；局部裁切 OCR 漏字时用来补全标题。"""
    result = ctx.action("observe.ocr") or {}
    left, right = FULL_TITLE_X
    top, bottom = FULL_TITLE_Y
    parts: list[str] = []
    for item in result.get("items") or []:
        center = item.get("centerxy") or [0, 0]
        if left <= int(center[0]) <= right and top <= int(center[1]) <= bottom:
            parts.append(str(item.get("text", "")))
    return _title_part(_norm(" ".join(parts)))


def _popup_state(ctx: RunContext) -> tuple[bool, str]:
    """
    判断当前帧是否停在技能替换弹窗，并返回标题区文本供解析罪人。
    标题关键词是主判据；标题局部 OCR 漏字时用底部 Cancel／Confirm 按钮确认弹窗已打开，
    再用整屏 OCR 的同一铭牌范围补全标题，避免读不到罪人而误点 Cancel。
    标题文本一律经 _title_part 截到 Replace … Skill 为止，不掺入右侧 Skills Owned
    与中间那排 SKILL nxm 标签的文字。
    """
    text = _title_part(_region_text(ctx, POPUP_TITLE_REGION))
    if all(word in text for word in POPUP_TITLE_KEYWORDS):
        return True, text
    if not _action_buttons(ctx):
        return False, ""
    return True, _title_part(_norm(f"{_full_title(ctx)} {text}"))


def _in_shop(ctx: RunContext) -> bool:
    """当前帧是否为镜牢商店页：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题（技能替换弹窗已由 _popup_state 先判）。"""
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


def _ordered_contains(text: str, alias: str) -> bool:
    """alias 的字符是否按顺序全部出现在 text 中；允许 OCR 多识别出重复字符。"""
    if len(alias) < MIN_LOOSE_ALIAS_LENGTH:
        return False
    position = 0
    for char in text:
        if position < len(alias) and char == alias[position]:
            position += 1
    return position == len(alias)


def _sinner_of(title: str) -> tuple[str, bool]:
    """
    从弹窗标题里解析罪人配置键，返回 (罪人键, 是否使用了宽松匹配)。
    先要求名字完整出现；OCR 把 Don Quixote 读成 DonnQuixotes 这类多字情形再按字符顺序兜底。
    """
    for sinner, aliases in SINNER_ALIASES:
        if any(alias in title for alias in aliases):
            return sinner, False
    for sinner, aliases in SINNER_ALIASES:
        if any(_ordered_contains(title, alias) for alias in aliases):
            return sinner, True
    return "", False


def _bounded_distance(left: str, right: str, limit: int) -> int | None:
    """有界编辑距离：返回把 left 改成 right 需要的最少字符增删改次数，超过 limit 时返回 None。"""
    if abs(len(left) - len(right)) > limit:
        return None
    previous = list(range(len(right) + 1))
    for row, left_char in enumerate(left, start=1):
        current = [row]
        for column, right_char in enumerate(right, start=1):
            cost = 0 if left_char == right_char else 1
            current.append(
                min(previous[column] + 1, current[column - 1] + 1, previous[column - 1] + cost)
            )
        previous = current
        if min(previous) > limit:
            return None
    best = previous[-1]
    return best if best <= limit else None


def _card_name(ctx: RunContext, center) -> str:
    """
    对价格图标下方的名字行做一次局部 OCR，按从上到下、从左到右拼成商品名；不刷新截图。
    名字过长时 OCR 会拆成上下两行，拼起来后才能读到完整的 Replace … Skill。
    """
    icon_x, icon_y = int(center[0]), int(center[1])
    region = {
        "x": max(0, icon_x - CARD_NAME_HALF_WIDTH),
        "y": icon_y + CARD_NAME_TOP_OFFSET,
        "width": CARD_NAME_HALF_WIDTH * 2,
        "height": CARD_NAME_HEIGHT,
    }
    result = ctx.action("observe.ocr", region=region) or {}
    lines: list[tuple[int, int, str]] = []
    for item in result.get("items") or []:
        text = str(item.get("text", "")).strip()
        if not text:
            continue
        point = item.get("centerxy") or (0, 0)
        lines.append((int(point[1]), int(point[0]), text))
    lines.sort()
    return " ".join(text for _, _, text in lines)


def _sinner_from_card(ctx: RunContext, text: str) -> tuple[str, bool]:
    """
    从商品卡名字（形如 Replace Yi Sang's Skill）解析罪人，返回 (罪人键, 是否用了模糊匹配)。
    商品一定属于十二罪人之一，所以完整名字读不到时允许最多 MAX_SINNER_EDITS 次字符修改；
    最近距离并列时返回空串，交回弹窗标题判断，避免按错误罪人跳过了需要买的商品。
    """
    flat = _norm(text)
    start = flat.find("replace")
    if start >= 0:
        flat = flat[start + len("replace") :]
    end = flat.rfind("skill")
    if end >= 0:
        flat = flat[:end]
    if not flat:
        return "", False
    for sinner, aliases in SINNER_ALIASES:
        if any(alias in flat for alias in aliases):
            return sinner, False
    candidates = [flat]
    if flat.endswith("s"):
        candidates.append(flat[:-1])
    hits: list[tuple[int, str]] = []
    for sinner, aliases in SINNER_ALIASES:
        for alias in aliases:
            for candidate in candidates:
                distance = _bounded_distance(alias, candidate, MAX_SINNER_EDITS)
                if distance is not None:
                    hits.append((distance, sinner))
    if not hits:
        return "", False
    lowest = min(distance for distance, _ in hits)
    winners = sorted({sinner for distance, sinner in hits if distance == lowest})
    if len(winners) > 1:
        ctx.log(
            f"商品名字 {text!r} 同时接近罪人 {winners}（都差 {lowest} 个字符），"
            "不按商品名跳过，交回弹窗标题判断",
            level="warning",
        )
        return "", False
    return winners[0], True


def _team_index(ctx: RunContext) -> int:
    """本场镜牢实际使用的队伍序号：只读 mirror.runtime.team_used；缺失时按第 1 个队伍处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    used = runtime.get(TEAM_USED_KEY) if isinstance(runtime, dict) else None
    if type(used) is int and 1 <= used <= MAX_TEAMS:
        return used
    ctx.log(
        f"没有可用的本场队伍记录 {TEAM_USED_KEY}={used!r}，按第{DEFAULT_TEAM}个队伍处理",
        level="warning",
    )
    return DEFAULT_TEAM


def _switch_enabled(ctx: RunContext) -> bool:
    """读取镜牢设置页「商店设置」的技能替换开关；缺失或非布尔值时按开启处理。"""
    page = (ctx.run_state.settings or {}).get(MIRROR_PAGE_ID)
    raw = page.get(SKILL_REPLACE_SWITCH_KEY) if isinstance(page, dict) else None
    return raw if isinstance(raw, bool) else True


def _skill_options(ctx: RunContext, sinner: str) -> list[int]:
    """读取当前镜牢队伍里该罪人勾选的技能替换编号（1→2、2→3、1→3）；未配置返回空列表。"""
    if not sinner:
        return []
    team_index = _team_index(ctx)
    page = (ctx.run_state.settings or {}).get(TEAM_PAGE_ID) or {}
    teams = page.get(TEAMS_KEY)
    if not isinstance(teams, list) or not 1 <= team_index <= len(teams):
        ctx.log(f"队伍配置里没有第{team_index}个队伍，本次按没有技能替换处理", level="warning")
        return []
    entry = teams[team_index - 1]
    raw = entry.get(SKILL_KEY) if isinstance(entry, dict) else None
    values = raw.get(sinner) if isinstance(raw, dict) else None
    options: list[int] = []
    for value in values if isinstance(values, list) else []:
        text = str(value).strip()
        if not text.isdigit():
            continue
        option = int(text)
        if 1 <= option <= MAX_OPTIONS and option not in options:
            options.append(option)
    ctx.log(
        f"技能替换配置取自本场第{team_index}个队伍（{TEAMS_KEY}[{team_index - 1}]）："
        f"罪人 {sinner} → {sorted(options)}"
    )
    return sorted(options)


def _handled(ctx: RunContext) -> list:
    """返回本次商店已处理过的技能替换商品记录。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        return []
    record = runtime.get(HANDLED_KEY)
    return record if isinstance(record, list) else []


def _mark_handled(ctx: RunContext, sinner: str, center) -> None:
    """记录本次商店已处理的商品；拿不到商品坐标时只按罪人记录。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录商店技能替换处理结果", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    record = runtime.get(HANDLED_KEY)
    if not isinstance(record, list):
        record = []
    x = y = None
    if center is not None:
        x, y = int(center[0]), int(center[1])
    record.append({"sinner": sinner, "x": x, "y": y})
    runtime[HANDLED_KEY] = record
    settings[RUNTIME_KEY] = runtime


def _already_handled(record: list, center) -> bool:
    """该价格图标位置是否已处理过：商品被消费后下方商品会上移，因此按坐标判断。"""
    if not center:
        return False
    for item in record:
        if not isinstance(item, dict) or item.get("x") is None or item.get("y") is None:
            continue
        if (
            abs(int(center[0]) - int(item["x"])) <= SAME_ITEM_RADIUS
            and abs(int(center[1]) - int(item["y"])) <= SAME_ITEM_RADIUS
        ):
            return True
    return False


def _purchased(ctx: RunContext, center) -> bool:
    """该价格图标对应的商品卡是否已买过：卡片上方的 Purchased 标签是重入时的跳过依据。"""
    width, height = PURCHASED_REGION_SIZE
    offset_x, offset_y = PURCHASED_REGION_OFFSET
    region = {
        "x": max(0, int(center[0]) - offset_x),
        "y": max(0, int(center[1]) - offset_y),
        "width": width,
        "height": height,
    }
    return PURCHASED_KEYWORD in _region_text(ctx, region)


def _popup_page(ctx: RunContext) -> str:
    """
    判断当前帧技能替换弹窗处于哪一页，返回 PAGE_PROMPT／PAGE_SELECT／PAGE_NONE。
    成交确认页有 Spend … Cost 提示；选择页只有标题和三张技能卡，两页底部都有 Cancel／Confirm。
    """
    if _confirm_prompt(ctx):
        return PAGE_PROMPT
    if _popup_state(ctx)[0]:
        return PAGE_SELECT
    return PAGE_NONE


def _click_cancel(ctx: RunContext) -> None:
    """点击一次弹窗底部的 Cancel，关闭技能替换弹窗（不扣 Cost）。"""
    ctx.log(f"点击弹窗 Cancel {CANCEL_POINT}")
    ctx.action("control.click", x=CANCEL_POINT[0], y=CANCEL_POINT[1])


def _confirm_prompt(ctx: RunContext) -> bool:
    """当前帧是否已进入「Spend <价格> Cost to replace this Skill?」确认步骤：用提示横幅模板匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=PROMPT_ASSET,
            region=PROMPT_REGION,
            threshold=PROMPT_THRESHOLD,
        )
    )


def _selected_pair(ctx: RunContext) -> tuple[int, int] | None:
    """读确认步骤里两张技能卡上的 SKILL n 标签，返回 (原技能, 替换后的技能)；读不到返回 None。"""
    result = ctx.action("observe.ocr", region=PAIR_REGION) or {}
    labels: list[tuple[int, int]] = []
    for item in result.get("items") or []:
        match = PAIR_LABEL.fullmatch(_norm(item.get("text", "")))
        if match:
            labels.append((int(item["centerxy"][0]), int(match.group(1))))
    if len(labels) < 2:
        return None
    labels.sort()
    return labels[0][1], labels[-1][1]


def _confirm_step_option(ctx: RunContext, options: list[int]) -> int | None:
    """
    在 Spend … Cost 二次确认步骤核对选中的技能对，返回要成交的选项编号。
    选中项不在配置里时返回 None（调用方点 Cancel 放弃），读不到时按配置回退。
    """
    pair = _selected_pair(ctx)
    selected = OPTION_BY_PAIR.get(pair) if pair else None
    if selected is None:
        ctx.log("没有读到确认步骤里选中的技能编号，按配置直接点 Confirm", level="warning", screenshot=True)
        return options[-1]
    if selected not in options:
        ctx.log(
            f"确认步骤选中的技能对 {pair}（第 {selected} 项）不在配置 {options} 里，点击 Cancel 放弃本次替换",
            level="warning",
            screenshot=True,
        )
        return None
    ctx.log(f"确认步骤选中的技能对 {pair}（第 {selected} 项）在配置 {options} 里")
    return selected


def _confirm_purchase(ctx: RunContext, options: list[int]) -> None:
    """
    在 Spend … Cost 成交确认页核对选中的技能对，然后点一次 Confirm 真正扣 Cost 完成替换。
    选中项不在配置里时点一次 Cancel 放弃；读不到选中项时按配置最后一项成交。
    这次 Confirm 是唯一会联网提交的输入，点完只固定等 1 秒就交回，
    成交是否生效、Cost 是否下降都由上层下一轮重新观察。
    """
    selected = _confirm_step_option(ctx, options)
    if selected is None:
        _click_cancel(ctx)
        return
    ctx.action("observe.wait", seconds=CONFIRM_SETTLE_SECONDS)
    ctx.log(f"点击成交确认页的 Confirm {CONFIRM_POINT} 完成第 {selected} 项替换，交回上层重新观察")
    ctx.action("control.click", x=CONFIRM_POINT[0], y=CONFIRM_POINT[1])
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)


def _drive_popup(ctx: RunContext, title: str) -> None:
    """
    把已打开的技能替换弹窗在本次调用里推进到底：
    - 成交确认页：核对选中的技能对后点一次 Confirm 成交（或点 Cancel 放弃）；
    - 选择页：先按罪人配置依次点选项（只改当前选择，不成交），再点选择页的 Confirm
      进入成交确认页——选择页这一步不涉及网络；复核确认页后再立刻成交。
    任何一步没有达到预期状态都只记录 warning 并返回，由 sub_workflow.mirror_shop
    重新观察后再次调用本步；真正提交的 Confirm 在一次调用里只点一次。
    """
    sinner, loose = _sinner_of(title)
    if loose:
        ctx.log(f"弹窗标题 OCR 不完整（{title}），按字符顺序宽松匹配到罪人 {sinner}", level="warning")
    if not sinner:
        ctx.log(f"无法从弹窗标题识别罪人（{title}），按没有技能替换处理", level="warning", screenshot=True)
    options = _skill_options(ctx, sinner)
    # 商品位置已被弹窗盖住，这里只能先按罪人记录本次处理
    _mark_handled(ctx, sinner, None)

    page = _popup_page(ctx)
    if page == PAGE_PROMPT:
        if not options:
            ctx.log(f"罪人 {sinner or '未知'} 没有配置技能替换，点击 Cancel 放弃本次替换")
            _click_cancel(ctx)
            return
        _confirm_purchase(ctx, options)
        return
    if page != PAGE_SELECT:
        ctx.log(
            "技能替换弹窗既不是选择页也不是成交确认页，本次不做输入，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return
    if not options:
        ctx.log(f"罪人 {sinner or '未知'} 没有配置技能替换，点击 Cancel 放弃本次替换")
        _click_cancel(ctx)
        return

    ctx.log(
        f"罪人 {sinner} 勾选的技能替换 {options}，按从左到右各点一次"
        "（后面的点击只覆盖前面的选择，不会各成交一次）"
    )
    for option in options:
        point = OPTION_POINTS[option]
        ctx.action("control.click", x=point[0], y=point[1])
        ctx.log(f"点击第 {option} 项 {point}")
        ctx.action("observe.wait", seconds=OPTION_CLICK_SECONDS)
    ctx.action("observe.wait", seconds=CONFIRM_SETTLE_SECONDS)
    ctx.log(f"点击选择页的 Confirm {CONFIRM_POINT} 进入 Spend … Cost 成交确认页（不扣 Cost）")
    ctx.action("control.click", x=CONFIRM_POINT[0], y=CONFIRM_POINT[1])
    ctx.action("observe.wait", seconds=PROMPT_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    if _popup_page(ctx) != PAGE_PROMPT:
        ctx.log(
            "点击选择页的 Confirm 后没有确认到 Spend … Cost 成交确认页，本次不成交，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return
    _confirm_purchase(ctx, options)





@step
def execute(ctx: RunContext) -> None:
    """
    处理镜牢商店的技能替换商品，一次调用完整走完一件商品：
    - 弹窗已打开（上一轮没走完或上次中断）时，直接从弹窗当前状态推进到成交；
    - 既不是商店页也没有弹窗时零输入返回；
    - 在商店页时找第一个未处理的技能替换商品，不急着点开：先 OCR 价格图标下方的商品名字读出罪人，
      本场队伍没有勾选这个罪人的技能替换时不开弹窗、只记一笔就交回，省掉打开／取消弹窗的时间；
      名字有 OCR 误差时允许最多 MAX_SINNER_EDITS 个字符的模糊匹配并记 warning，识别不出或并列时仍按标题判断；
    - 需要买时才点一次商品卡，等弹窗滑入后在同一次调用里继续推进选择页与成交确认页；
      已买过（Purchased）的商品只记记录跳过、不做输入；没有未处理商品时零输入返回。
    选择页点选项与选择页 Confirm 都不涉及网络，所以合并进同一次调用；
    只有成交确认页那次 Confirm 会联网提交，点完固定等 1 秒立即交回，
    只用成交确认页的提示素材判断当前在哪个步骤；成交是否生效、Cost 是否下降由
    sub_workflow.mirror_shop 下一轮重新观察。
    本次商店处理过的商品位置与罪人记进 RunState，重入不重复点击（购买不可安全重放）。
    """
    ctx.action("observe.capture_screen")

    opened, title = _popup_state(ctx)
    if not _switch_enabled(ctx):
        # 开关关闭后不再购买技能替换：弹窗已打开时只点一次 Cancel 关掉，下一轮重新观察商店
        if opened:
            ctx.log(
                "商店设置的技能替换已关闭：点击一次 Cancel 关闭残留的技能替换弹窗，不做购买输入",
                level="warning",
            )
            _click_cancel(ctx)
            return
        ctx.log("商店设置的技能替换已关闭，本步不做任何动作")
        return
    if opened:
        ctx.log(f"技能替换弹窗已打开（{title}），本次调用从弹窗当前状态一路推进到成交")
        _drive_popup(ctx, title)
        return

    if not _in_shop(ctx):
        ctx.log("当前既不是镜牢商店页也没有技能替换弹窗，本步不做动作", level="warning", screenshot=True)
        return

    matches = ctx.action("observe.match_asset", asset=SKILL_ITEM_ASSET, region=SHOP_ITEM_REGION) or []
    record = _handled(ctx)
    pending = [
        hit
        for hit in matches
        if hit.get("centerxy") and not _already_handled(record, hit["centerxy"])
    ]
    if not pending:
        ctx.log(f"当前帧命中 {len(matches)} 个技能替换价格图标，没有未处理的新商品，本步不点击")
        return

    pending.sort(key=lambda hit: (int(hit["centerxy"][1]), int(hit["centerxy"][0])))
    if len(pending) > 1:
        ctx.log(
            f"当前帧有 {len(pending)} 个未处理技能替换商品，按从上到下、从左到右先处理第一个",
            level="warning",
        )
    center = pending[0]["centerxy"]
    if _purchased(ctx, center):
        ctx.log(f"技能替换商品已买过（Purchased），只记录跳过价格图标 {center}", level="warning")
        _mark_handled(ctx, "", (int(center[0]), int(center[1])))
        return

    # 点开弹窗之前先从商品名字读出罪人：本场队伍没有勾选这个罪人的技能替换就不打开弹窗
    name = _card_name(ctx, center)
    sinner, fuzzy = _sinner_from_card(ctx, name)
    if sinner:
        if fuzzy:
            ctx.log(
                f"技能替换商品名 OCR 为 {name!r}，按最多 {MAX_SINNER_EDITS} 个字符的误差匹配到罪人 {sinner}",
                level="warning",
            )
        options = _skill_options(ctx, sinner)
        if not options:
            ctx.log(
                f"技能替换商品 {name!r} 的罪人 {sinner} 在本场队伍没有勾选技能替换，"
                "不打开弹窗，只记录位置后跳过"
            )
            _mark_handled(ctx, sinner, (int(center[0]), int(center[1])))
            return
    else:
        ctx.log(
            f"没有从商品名字 {name!r} 识别出罪人，仍点开弹窗按标题判断",
            level="warning",
        )

    click_x, click_y = int(center[0]), int(center[1]) - ITEM_CLICK_HEIGHT
    ctx.log(f"点击一次技能替换商品：价格图标 {center} 正上方 ({click_x}, {click_y})")
    ctx.action("control.click", x=click_x, y=click_y)
    # 先记位置再等弹窗：同一商品不会因未确认而重复点击
    _mark_handled(ctx, "", (int(center[0]), int(center[1])))
    ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    opened, title = _popup_state(ctx)
    if not opened:
        ctx.log(
            "点击技能替换商品后没有看到 Replace … Skill 弹窗，本次不继续输入，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return
    _drive_popup(ctx, title)
