"""处理标题界面开始下载数据后的下载中状态，等待数据下载结束。"""
import re

from lalc import RunContext

STATE_NAME = "下载中"
# 下载询问弹窗属于 recovery.popup_download_notice 的职责，本规则必须与其互斥
POPUP_ASSET = "popup/download_data_notice"
# 下载询问弹窗里的下载体积行，不能当成下载中状态
NOTICE_TEXT = re.compile(r"\d+(?:\.\d+)?\s*(?:mb|gb)\s+of\s+data", re.IGNORECASE)
POLL_SECONDS = 10
# 本次开发者指定下载等待上限十分钟；耗尽后交还主流程
MAX_SECONDS = 10 * 60
ABSENT_POLLS_TO_FINISH = 3
# 百分比文字只认下半屏，避免和其它界面的百分比混淆
PERCENT_MIN_Y = 400

PERCENT_ONLY = re.compile(r"^\s*\d{1,3}(?:\.\d+)?\s*%\s*$")
SIZE_PROGRESS = re.compile(
    r"\d+(?:\.\d+)?\s*(?:mb|gb)\s*(?:/|of)\s*\d+(?:\.\d+)?\s*(?:mb|gb)",
    re.IGNORECASE,
)


def _ocr_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回整屏 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    return list(result.get("items") or [])


def _popup_visible(ctx: RunContext) -> bool:
    """下载询问弹窗还在时归弹窗恢复规则处理，本规则不参与。"""
    return bool(ctx.action("observe.match_asset", asset=POPUP_ASSET))


def _download_hints(items: list[dict]) -> list[str]:
    """收集能说明仍在下载的文字：Download 字样、x MB / y MB 进度或下半屏独立百分比。"""
    hints: list[str] = []
    for item in items:
        text = str(item.get("text", "")).strip()
        if not text or NOTICE_TEXT.search(text):
            continue
        if "download" in text.lower() or SIZE_PROGRESS.search(text):
            hints.append(text)
            continue
        box = item.get("box") or {}
        if PERCENT_ONLY.match(text) and int(box.get("y", 0) or 0) >= PERCENT_MIN_Y:
            hints.append(text)
    return hints


def detect(ctx: RunContext) -> bool:
    """只观察下载中的特征文字；下载询问弹窗仍在时不参与，避免规则歧义。"""
    ctx.action("observe.capture_screen")
    if _popup_visible(ctx):
        ctx.log(f"下载询问弹窗仍在，不属于{STATE_NAME}状态")
        return False
    hints = _download_hints(_ocr_items(ctx))
    ctx.log(f"检测 {STATE_NAME} 状态，命中特征文字：{hints}")
    return bool(hints)


def recover(ctx: RunContext) -> None:
    """下载可能持续数分钟：轮询观察下载进度文字，特征连续多次消失后才认为下载结束。"""
    max_polls = int(MAX_SECONDS / POLL_SECONDS)
    absent_polls = 0
    last_hint = ""
    for poll in range(max_polls):
        waited = int(poll * POLL_SECONDS)
        ctx.action("observe.capture_screen")
        if _popup_visible(ctx):
            ctx.log("下载询问弹窗重新出现，交回弹窗恢复规则处理", level="warning")
            return
        hints = _download_hints(_ocr_items(ctx))

        if hints:
            absent_polls = 0
            current = next((hint for hint in hints if "%" in hint or "/" in hint), hints[0])
            if current != last_hint:
                ctx.log(f"下载进行中，当前进度文字：{current}（已等待约{waited}秒）")
                last_hint = current
        else:
            absent_polls += 1
            if absent_polls >= ABSENT_POLLS_TO_FINISH:
                ctx.log(
                    f"下载中特征文字连续{absent_polls}次未出现（已等待约{waited}秒），"
                    "认为下载结束，交还主流程"
                )
                return
            ctx.log(f"下载中特征文字暂未出现（第{absent_polls}次），继续观察确认")

        ctx.action("observe.wait", seconds=POLL_SECONDS)

    ctx.log(
        f"下载中状态已等待超过{MAX_SECONDS // 60}分钟仍未结束，交还主流程按当前画面处理",
        level="error",
        screenshot=True,
    )
