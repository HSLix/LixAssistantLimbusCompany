"""队伍列表编排：连续拖拽把左侧 TEAMS 列表拉回顶部，每次拖拽后等 1 秒再做一次全屏 OCR。

与「点击选择队伍」分开：本子流程只做拖拽上拉与检测，不点击任何队伍行；
点击由上层随后调用 step.select_team_by_index 完成，中间再做一次通用等待检测。
原因是滚轮遇到突发弹窗会失效（Run 630 的 TEAMS 行点击就撞上 Could Not Load Notice），
所以改为拖拽上拉，并且每拖一次都确认当前帧没有加载／弹窗干扰，再继续下一次拖拽。

【重要】队伍名字不固定：TEAMS 列表里的行文字是玩家可以随意改名的队伍名，
不能用 TEAMS #1 之类的固定文案判断是否到顶。本子流程只用「这一拖有没有让可检测的队伍名变化」：
拖完等 1 秒，重新截图后做一次全屏 OCR，把同一份结果先交给 step.detect_normal_transition 做通用检测，
再按列表区域筛出可见队伍名与上一次比较——变了就继续拖，没变就认为列表已夹在顶部，停止。
第一次拖拽无条件执行（否则列表停在中间时永远拿不到「上一次」可比）。
"""
import re

from lalc import RunContext, sub_workflow

# 【开发者要求】最多六次拖拽；第一次无条件执行，之后按「可见队伍名是否变化」决定是否继续
DRAG_COUNT = 6
# 每次拖拽后先等 1 秒（等列表惯性收尾），再截图并全屏 OCR
AFTER_DRAG_WAIT_SECONDS = 1.0
# 队伍行名字所在的实测区域（1280x720）：只包左侧列表的行，避开上方的 TEAMS 标题与右侧其他文字。
# 【重要】队伍名不固定（玩家可随意改名），这里只按区域取「可检测到的名字」，不匹配任何固定队伍文案
ROWS_REGION = {"x": 80, "y": 292, "width": 116, "height": 252}


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断字影响比较；队伍名本身不做任何固定匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _in_region(center, region: dict[str, int]) -> bool:
    """OCR 条目的中心是否落在给定区域。"""
    x, y = int(center[0]), int(center[1])
    return (
        int(region["x"]) <= x <= int(region["x"]) + int(region["width"])
        and int(region["y"]) <= y <= int(region["y"]) + int(region["height"])
    )


def _row_names(items: list[dict]) -> tuple[str, ...]:
    """
    从一次全屏 OCR 结果里筛出左侧列表区域内的队伍行名字，返回规范小写、按名字排序的元组。
    队伍名可被玩家随意修改，所以不做任何固定文案匹配，只把「当前能检测到的名字集合」作为比较依据。
    """
    names = []
    for item in items:
        center = item.get("centerxy") or (0, 0)
        if not _in_region(center, ROWS_REGION):
            continue
        name = _norm(item.get("text", ""))
        if name:
            names.append(name)
    return tuple(sorted(names))


def _observe(ctx: RunContext) -> tuple[dict, list[dict]]:
    """新截一帧并做一次全屏 OCR，返回 (截图元数据, OCR 条目)。"""
    meta = ctx.action("observe.capture_screen")
    items = list((ctx.action("observe.ocr") or {}).get("items") or [])
    return meta, items


def _transition(ctx: RunContext, meta: dict, items: list[dict]) -> bool:
    """把同一帧的全屏 OCR 结果拆成文字／中心点两组平行列表交给通用检测，不重复识别。"""
    texts = [str(item.get("text") or "") for item in items]
    centers = [
        [int((item.get("centerxy") or [0, 0])[0]), int((item.get("centerxy") or [0, 0])[1])]
        for item in items
    ]
    return bool(
        ctx.call(
            "step.detect_normal_transition",
            width=int(meta["width"]),
            height=int(meta["height"]),
            ocr_texts=texts,
            ocr_centers=centers,
        )
    )


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str]:
    """
    有界上划：最多 DRAG_COUNT 次，第一次无条件拖拽；每次拖拽后等 1 秒，
    重新截图并做一次全屏 OCR，用同一份结果先做通用等待检测（命中加载／Could Not Load Notice
    就交 step.wait_normal_transition 处理），再按列表区域筛出可检测的队伍名：
    - 与上一次相同：列表没有再动，认为已夹在顶部，停止；
    - 有变化：继续下一次拖拽。
    不按 TEAMS #1 之类的固定文案判断（队伍名由玩家随意命名，不固定）。
    六次拖完仍在变化时记 warning 并按次数停止，交上层重新截图分派；本子流程不点击队伍行。
    """
    previous = None
    drags = 0
    for index in range(1, DRAG_COUNT + 1):
        outcome = ctx.call("step.team_list_drag_once") or {}
        if str(outcome.get("completed")) != "true":
            reason = str(outcome.get("reason") or "no_team_list")
            ctx.log(
                f"队伍列表第{index}次拖拽没有执行（{reason}），停止上划，交回上层重新截图分派",
                level="warning",
                screenshot=True,
            )
            return {"completed": "false", "drag_count": str(drags), "reason": reason}
        drags = index

        ctx.action("observe.wait", seconds=AFTER_DRAG_WAIT_SECONDS)
        meta, items = _observe(ctx)
        if _transition(ctx, meta, items):
            ctx.log(
                f"第{index}次拖拽后检测到加载／弹窗，交给通用等待处理后再比较队伍名",
                level="warning",
                screenshot=True,
            )
            ctx.call("step.wait_normal_transition")
            # 等待后重新截图识别：不用弹窗前的旧帧比较队伍名
            meta, items = _observe(ctx)
            if _transition(ctx, meta, items):
                ctx.log(
                    f"第{index}次拖拽后的等待结束时仍有加载／弹窗，停止本次上划，交回上层",
                    level="warning",
                    screenshot=True,
                )
                return {
                    "completed": "false",
                    "drag_count": str(index),
                    "reason": "transition_not_cleared",
                }

        names = _row_names(items)
        ctx.log(f"第{index}次拖拽后可见队伍名（{len(names)} 条）：{list(names)}")
        if previous is not None and names == previous:
            ctx.log(f"第{index}次拖拽后可见队伍名与上次相同，列表没有再动，按已到顶停止")
            return {"completed": "true", "drag_count": str(index), "reason": "no_change"}
        previous = names

    ctx.log(
        f"已拖拽 {DRAG_COUNT} 次，每次可见队伍名都还在变化，按次数停止（未用固定队伍名判断顶部）",
        level="warning",
        screenshot=True,
    )
    return {"completed": "true", "drag_count": str(DRAG_COUNT), "reason": "drag_count_done"}
