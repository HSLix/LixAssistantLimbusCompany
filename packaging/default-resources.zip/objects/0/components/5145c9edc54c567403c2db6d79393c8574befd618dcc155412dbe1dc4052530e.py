"""战斗页面中，按下一次 Enter 推进本回合战斗开始的单次动作步骤。"""
from lalc import RunContext, step


def _hit(ctx: RunContext, assets: list[str]) -> list[str]:
    """按同一截图统计命中素材，返回命中名称。"""
    return [asset for asset in assets if ctx.action("observe.match_asset", asset=asset)]


@step
def execute(ctx: RunContext, *, continue_battle_assets: list[str], battleing_signal_assets: list[str]) -> None:
    """截图复查入口条件后按一次 Enter 推进战斗，只做一次动作，是否开战由上层用新画面验收。

    battleing_signal_assets 仅为兼容现有调用方保留，本步不再用它判定战斗是否已经开始。
    """

    ctx.action("observe.capture_screen")

    if not _hit(ctx, continue_battle_assets):
        ctx.log("未在 可推进战斗的 页面，本轮不操作", level="warning", screenshot=True)
        return

    if not ctx.action("observe.match_asset", asset="battle/win_rate_selected"):
        ctx.log("未选中 win rate，本轮不推进战斗", level="warning", screenshot=True)
        return
        
    ctx.log("可推进战斗且 win rate 已选中，按一次 Enter")
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=0.5)
