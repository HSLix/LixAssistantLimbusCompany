"""镜牢 Exploration Complete 结算页：点右下角 Claim Rewards 打开 Exploration Reward 结算弹窗。"""
import re

from lalc import RunContext, step

# Exploration Complete 标题（左上角两行文字）与右下角 Claim Rewards 按钮的区域（1280x720 客户区）
TITLE_REGION = {"x": 140, "y": 80, "width": 200, "height": 95}
TITLE_KEYWORD = "explorationcomplete"
BUTTON_REGION = {"x": 1030, "y": 555, "width": 210, "height": 90}
BUTTON_KEYWORDS = ("claim", "rewards")
# 结算弹窗标题：弹窗已打开的证据，也是本 Step 的退出信号
POPUP_TITLE_REGION = {"x": 500, "y": 90, "width": 300, "height": 60}
POPUP_TITLE_KEYWORD = "explorationreward"
# 右下角 Claim Rewards 按钮（含左侧对勾）的固定坐标
CLAIM_REWARDS_POINT = (1148, 598)
# 点击后的固定等待秒数；弹窗是否出现由上层下一轮重新观察
AFTER_CLICK_SECONDS = 0.6


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _page_here(ctx: RunContext) -> bool:
    """当前帧是否为 Exploration Complete 结算页：左侧标题与右下角 Claim Rewards 按钮都要命中。"""
    if TITLE_KEYWORD not in _region_text(ctx, TITLE_REGION):
        return False
    button = _region_text(ctx, BUTTON_REGION)
    return all(word in button for word in BUTTON_KEYWORDS)


def _popup_here(ctx: RunContext) -> bool:
    """当前帧是否已出现 Exploration Reward 结算弹窗。"""
    return POPUP_TITLE_KEYWORD in _region_text(ctx, POPUP_TITLE_REGION)


@step
def execute(ctx: RunContext) -> None:
    """
    只负责打开结算弹窗，只做一次局部尝试：
    Exploration Reward 弹窗已打开时零动作返回；
    不在 Exploration Complete 结算页时不做任何点击；
    在结算页才点一次右下角固定坐标的 Claim Rewards，等固定 0.6 秒后交回。
    弹窗是否出现由 sub_workflow.mirror_reward_settlement 下一轮重新观察，本步不轮询。
    """
    ctx.action("observe.capture_screen")
    if _popup_here(ctx):
        ctx.log("Exploration Reward 结算弹窗已打开，无需再点 Claim Rewards")
        return
    if not _page_here(ctx):
        ctx.log("当前不是 Exploration Complete 结算页，不点击 Claim Rewards", level="warning", screenshot=True)
        return

    ctx.log(f"Exploration Complete 结算页：点击右下角 Claim Rewards {CLAIM_REWARDS_POINT}")
    ctx.action("control.click", x=CLAIM_REWARDS_POINT[0], y=CLAIM_REWARDS_POINT[1])
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
