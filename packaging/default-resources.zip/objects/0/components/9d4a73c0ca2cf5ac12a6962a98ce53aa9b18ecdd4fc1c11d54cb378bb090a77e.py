"""处理 Failed to login via Steam 弹窗：用 OCR 文字特征识别，重启游戏后确认弹窗不再出现。

该弹窗出现在标题界面，与 recovery.title_to_main 的 Clear all caches 特征重叠，
因此 title_to_main 的 detect 会主动跳过本弹窗，保证同一现场只有本规则匹配。
"""
import re

from lalc import RunContext

POPUP_NAME = "Failed to login via Steam"
# 弹窗文案：Failed to login via Steam. Please check your Steam login status and try again at a later time.
POPUP_KEYWORD = "failedtologinviasteam"
# 3 次重启；单次等待取决于游戏启动与 Steam 登录耗时，不能按 2 秒轮询
MAX_RETRIES = 3
STARTUP_WAIT_SECONDS = 60


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _popup_visible(ctx: RunContext) -> bool:
    """刷新截图后整屏 OCR，命中弹窗文案即认为弹窗存在。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return POPUP_KEYWORD in _norm(joined)


def detect(ctx: RunContext) -> bool:
    """只观察弹窗文字，不在检测阶段点击或重启。"""
    found = _popup_visible(ctx)
    ctx.log(f"检测 {POPUP_NAME} 弹窗：{found}")
    return found


def recover(ctx: RunContext) -> None:
    """最多重启 3 次，每次启动后确认弹窗不再出现；次数耗尽后交还主流程。"""
    for attempt in range(1, MAX_RETRIES + 1):
        ctx.log(f"第{attempt}/{MAX_RETRIES}次处理 {POPUP_NAME} 弹窗，重启游戏")
        ctx.action("control.restart_game")
        ctx.log(f"等待游戏启动 {STARTUP_WAIT_SECONDS} 秒")
        ctx.action("observe.wait", seconds=STARTUP_WAIT_SECONDS)
        if not _popup_visible(ctx):
            ctx.log(f"第{attempt}次重启后未再出现 {POPUP_NAME} 弹窗，交还主流程处理")
            return
        ctx.log(
            f"第{attempt}/{MAX_RETRIES}次重启后仍出现 {POPUP_NAME} 弹窗，Steam 登录可能仍未恢复",
            level="warning",
            screenshot=True,
        )

    ctx.log(
        f"{POPUP_NAME} 弹窗 {MAX_RETRIES} 次重启后仍存在，交还主流程继续观察",
        level="error",
        screenshot=True,
    )
