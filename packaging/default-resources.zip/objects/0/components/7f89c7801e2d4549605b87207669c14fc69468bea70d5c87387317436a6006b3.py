"""镜牢主题包页面：点一次右上角 Refresh，重掷本层可选的主题包。

按开发者要求不再做 OCR 检测：跳过页面标题与 Refresh 文案识别，直接点右上角按钮的固定坐标，
点下后立即交回，刷新后 4 秒的淡入等待与 info 级稳定截图由上层 sub_workflow.mirror_theme_pack 负责。
唯一保留的入口判断是模板 mirror/train_head：
画面上已经出现火车头说明主题包已选好、进了寻路页，这时不点，避免在寻路页上乱点。
返回 status：refreshed（已点下）、not_page（已出现火车头，不需要刷新）。
"""
from lalc import RunContext, step

TRAIN_HEAD_ASSET = "mirror/train_head"
# 右上角 Refresh 按钮的固定点击坐标（1280x720 实测按钮约 x=990~1160、y=22~66，中心 (1075, 44)）
REFRESH_CENTER = (1075, 44)


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """已在寻路页时不点；否则直接点右上角 Refresh 的固定坐标后立即交回，
    刷新后 4 秒的淡入等待与稳定截图交给上层，不轮询刷新结果。
    """
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=TRAIN_HEAD_ASSET):
        ctx.log("已出现火车头，说明主题包已选好，不点 Refresh")
        return {"status": "not_page"}
    ctx.log(
        f"直接点击右上角 Refresh 固定坐标 ({REFRESH_CENTER[0]}, {REFRESH_CENTER[1]})"
        "（不做文字检测），点完立即交回，由上层统一等 4 秒让新主题包淡入并截稳定截图"
    )
    ctx.action("control.click", x=REFRESH_CENTER[0], y=REFRESH_CENTER[1])
    return {"status": "refreshed"}
