"""镜牢寻路保底：按上层给出的下标点击第一列三个固定坐标中的一个，点完交回上层检测 Enter。"""
from lalc import RunContext, step

# 火车头归位到 (140, 330)±40 后，第一列节点的 x 固定为 380，上/中/下三个 y 坐标固定为 350、130、560；
# PROBE_POINTS 只表示三个坐标的固定清单，不代表点击顺序：上层 sub_workflow.mirror_pathfind
# 每轮用随机打乱的下标顺序通过 point 传入，一次只点一个固定点，点完就交回检测 Enter，
# 没有出现 Enter 才点本轮顺序里的下一个固定点
PROBE_POINTS = [(380, 350), (380, 130), (380, 560)]
# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上才算寻路界面
PATH_ICON_ASSETS = ("mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects")
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2
# 单击一个固定点后的固定等待：等确认弹窗动画出来再交回，
# 交回后由 sub_workflow.mirror_pathfind 立刻重新截图检测 Enter；没出现才点下一个固定点
AFTER_CLICK_SECONDS = 1.0


@step
def execute(ctx: RunContext, *, attempt: int = 1, point: int | None = None) -> None:
    """
    先截图复查入口：右上角寻路界面按钮不足两个（不在寻路页）时零输入返回。
    确在寻路页才点击一个保底固定点：point 是 PROBE_POINTS 的 1 起下标
    （1=(380,350)、2=(380,130)、3=(380,560)），为空时退回旧行为，即下标与 attempt 相同。
    上层 sub_workflow.mirror_pathfind 每轮把下标顺序随机打乱后逐个传入 point，attempt 只表示
    本轮第几次试探，用于日志。点完固定等 1 秒让确认弹窗动画出来再交回；本步只点一个坐标，
    不在这里确认是否弹出了节点确认界面，也不在内部重试后续固定点。
    下标超出固定点数量时不点击，只记 warning 交回。
    坐标以火车头已归位到 (130,330) 为前提；交回后由 sub_workflow.mirror_pathfind 立刻重新截图
    检测 Enter（命中就直接调用进入 Step），未命中才继续调用本步点下一个固定点。
    """
    ctx.action("observe.capture_screen")
    icons = sum(
        1
        for asset in PATH_ICON_ASSETS
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )
    if icons < MIN_PATH_ICONS:
        ctx.log(
            f"右上角寻路界面按钮只命中 {icons}/{len(PATH_ICON_ASSETS)} 个，不在寻路页，本步不试探",
            level="warning",
            screenshot=True,
        )
        return

    index = attempt if point is None else point
    if index < 1 or index > len(PROBE_POINTS):
        ctx.log(
            f"保底试探第 {attempt} 次要点的固定点下标 {index} 不在 1~{len(PROBE_POINTS)} 范围内，"
            "本步不点击",
            level="warning",
            screenshot=True,
        )
        return

    point_x, point_y = PROBE_POINTS[index - 1]
    ctx.log(
        f"保底试探第{attempt}/{len(PROBE_POINTS)}次：点击固定点下标 {index} ({point_x}, {point_y})"
    )
    ctx.action("control.click", x=point_x, y=point_y)
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
