"""在 EXP／Thread 的胜负结算页尝试按一次 Enter。"""

from lalc import RunContext, step


@step
def execute(ctx: RunContext) -> None:
    """复查仍有胜负标识才输入；结算验收由调用方负责。"""
    ctx.action("observe.capture_screen")
    if any(ctx.action("observe.match_asset", asset=asset) for asset in ("battle/defeat", "battle/victory")):
        ctx.action("control.key_press", key="enter")
