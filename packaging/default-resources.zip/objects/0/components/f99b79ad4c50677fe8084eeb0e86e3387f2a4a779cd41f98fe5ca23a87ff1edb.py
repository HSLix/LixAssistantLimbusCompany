"""镜牢入口页：点一次入口按钮打开弹窗，弹窗按钮由后续 Step 处理。"""
from lalc import RunContext, step

# 点击入口按钮后的固定等待秒数；只留给弹窗滑入，不用来判定弹窗是否已开
AFTER_CLICK_SECONDS = 1.0

DRIVE_ASSET = "drive/inferno"
ENTRY_ASSET = "mirror/entry"
TEAM_ASSET = "mirror/team_select"
PATH_ASSET = "mirror/train_head"
STAR_ASSET = "mirror/star"
GIFT_ASSET = "mirror/gift_select"

BEFORE_TEXT = "before entry"
EXPLORING_TEXT = "exploring"
CONFIRM_TEXT = "will you enter"
PROGRESS_TEXT = "dungeon progress"

# 客户区固定 1280x720：入口页右上角 Exploring 信息栏、中央弹窗区域、主题包页标题
INFO_REGION = {"x": 890, "y": 130, "width": 320, "height": 55}
POPUP_REGION = {"x": 420, "y": 175, "width": 440, "height": 365}
# 主题包选择页标题 SELECT FLOOR n THEME PACK
PACK_HEADER_REGION = {"x": 470, "y": 92, "width": 340, "height": 56}


def _theme_page(ctx: RunContext) -> bool:
    """主题包选择页特征：标题区域同时出现 SELECT FLOOR 与 THEME PACK。"""
    compact = _region_texts(ctx, PACK_HEADER_REGION).replace(" ", "")
    return "selectfloor" in compact and "themepack" in compact


def _page(ctx: RunContext) -> str:
    """
    判断当前页面：drive、entry、team、path、star、gift、left（已离开饰品选择页）或 unknown。
    以模板为主；饰品选择页、主题包页用模板加区域文字确认；
    入口页被弹窗遮挡或变暗时，用右上角信息栏文字兜底。
    """
    if ctx.action("observe.match_asset", asset=DRIVE_ASSET):
        return "drive"
    if ctx.action("observe.match_asset", asset=ENTRY_ASSET):
        return "entry"
    if ctx.action("observe.match_asset", asset=TEAM_ASSET):
        return "team"
    if ctx.action("observe.match_asset", asset=PATH_ASSET):
        return "path"
    if ctx.action("observe.match_asset", asset=STAR_ASSET):
        return "star"
    if ctx.action("observe.match_asset", asset=GIFT_ASSET):
        return "gift"
    ctx.action("observe.capture_screen")
    if _theme_page(ctx):
        return "left"
    info = _region_texts(ctx, INFO_REGION)
    if EXPLORING_TEXT in info or "rental" in info:
        return "entry"
    return "unknown"


def _region_texts(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做 OCR，返回合并后的小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    return " ".join(str(item.get("text", "")) for item in items if item.get("text")).lower()


def _popup_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回中央弹窗区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=POPUP_REGION) or {}
    return list(result.get("items") or [])


def _popup_kind(ctx: RunContext) -> str:
    """判断中央弹窗类型：progress（进度弹窗）、confirm（进入确认）或 none。"""
    text = " ".join(str(item.get("text", "")) for item in _popup_items(ctx)).lower()
    if PROGRESS_TEXT in text:
        return "progress"
    if CONFIRM_TEXT in text:
        return "confirm"
    return "none"


@step
def execute(ctx: RunContext, *, dungeon_x: int = 640, dungeon_y: int = 380, entry_x: int = 1108, entry_y: int = 493) -> None:
    """
    先截图复查入口：弹窗已经打开、已经进入镜牢（队伍／寻路／star／饰品页）或不在入口页时零输入返回；
    确在入口页才根据右上角信息栏选一个入口点一下（Exploring 点右下入口，Before Entry 点中央入口），
    等固定 1 秒后交回。弹窗是否打开由上层下一轮重新观察，本步不轮询。
    """
    popup = _popup_kind(ctx)
    if popup != "none":
        ctx.log(f"中央已有 {popup} 弹窗，无需再点入口")
        return
    page = _page(ctx)
    if page in ("team", "path", "star", "gift", "left"):
        ctx.log(f"当前已在镜牢内（{page}），无需再点入口")
        return
    if page != "entry":
        ctx.log("当前不是镜牢入口页，不点击入口", level="warning", screenshot=True)
        return
    info = _region_texts(ctx, INFO_REGION)
    if EXPLORING_TEXT in info and BEFORE_TEXT not in info:
        point, how = (entry_x, entry_y), "继续探索入口"
    elif BEFORE_TEXT in info:
        point, how = (dungeon_x, dungeon_y), "开始确认入口"
    else:
        ctx.log("入口页右上角既没有 Exploring 也没有 Before Entry，不盲点", level="warning", screenshot=True)
        return
    ctx.action("control.click", centerxy=point)
    ctx.log(f"点击镜牢入口页{how} {point}，等 {AFTER_CLICK_SECONDS} 秒后交回")
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
