"""镜牢队伍轮换：领取奖励后把队伍顺序真实轮换一格，直接写回唯一的一份顺序配置。

队伍顺序只有一份：镜牢设置页的 JSON 资源 team_order（{"teams": [...]}）。页面显示、页面保存、
每场运行与轮换写回都只用这一份；不再维护 rotation／next_team 指针，也不保存「轮换中」标记，
也不再往页面 settings 写第二份 mirror_teams／mirror_team。
"""
from lalc import RunContext, step

# 队伍顺序唯一存储的页面与资源名（与页面 mirror.py 一致）
MIRROR_PAGE_ID = "mirror.settings"
MAX_TEAMS = 40
# 唯一的队伍顺序存储：页面资源 team_order.teams（页面显示、运行选队、轮换写回都用这一份）
ORDER_RESOURCE = "team_order"
ORDER_TEAMS_KEY = "teams"
# 资源读取状态：整份缺失（读到 None，通常是页面资源被删除或清空）与内容非法分开记日志
ORDER_STATE_OK = "ok"
ORDER_STATE_MISSING = "missing"
ORDER_STATE_INVALID = "invalid"
# RunState 里 task.mirror 记录的本场实际使用队伍，用于核对轮换对象
RUNTIME_KEY = "mirror.runtime"
TEAM_USED_KEY = "team_used"


def _sanitize(values) -> list[int]:
    """把配置里的队伍号转成 1~MAX_TEAMS 的整数列表，去重并保持顺序，非法值丢弃。"""
    teams: list[int] = []
    if isinstance(values, list):
        for value in values:
            text = str(value).strip()
            if not text.isdigit():
                continue
            team = int(text)
            if 1 <= team <= MAX_TEAMS and team not in teams:
                teams.append(team)
    return teams


def _saved_order(ctx: RunContext) -> tuple[list[int], str]:
    """
    读取页面 team_order 资源里保存的队伍顺序，返回 (队伍顺序, 状态)。
    状态 ok／missing（资源整份不存在，读到 None）／invalid（内容不合形状），供调用方区分缺失与写坏。
    """
    value = ctx.action("page_resource.read_json", page_id=MIRROR_PAGE_ID, name=ORDER_RESOURCE)
    raw = value.get(ORDER_TEAMS_KEY) if isinstance(value, dict) else None
    teams = _sanitize(raw)
    if teams:
        return teams, ORDER_STATE_OK
    return [], ORDER_STATE_MISSING if value is None else ORDER_STATE_INVALID


@step
def execute(ctx: RunContext) -> None:
    """
    领取奖励后把队伍顺序真实轮换一格：第一支移到末尾，并把轮换后的完整顺序写回唯一那份配置——
    页面 JSON 资源 team_order（页面读它显示，页面保存也写它，下一场镜牢读它取第一支）。
    不保存 next_team 指针，也不保存「轮换中」标记；同一场重复执行会再轮换一格，
    因此仍由调用方在领取完成时只调用一次（放弃奖励不调用）。
    本 Step 不点游戏、不截图。
    """
    teams, state = _saved_order(ctx)
    if not teams:
        reason = (
            f"页面资源 {ORDER_RESOURCE} 不存在（读到 None：可能是页面资源被删除或清空）"
            if state == ORDER_STATE_MISSING
            else f"页面资源 {ORDER_RESOURCE}.{ORDER_TEAMS_KEY} 内容非法"
        )
        ctx.log(
            f"{reason}，无法推进镜牢队伍轮换（请在镜牢设置页重新选择队伍顺序并点「确定」）",
            level="warning",
        )
        return
    settings = ctx.run_state.settings
    runtime = settings.get(RUNTIME_KEY) if isinstance(settings, dict) else None
    used = runtime.get(TEAM_USED_KEY) if isinstance(runtime, dict) else None
    if type(used) is int and 1 <= used <= MAX_TEAMS and used != teams[0]:
        ctx.log(
            f"本场记录的队伍 {used} 与当前顺序第一支 {teams[0]} 不一致，仍按当前顺序轮换",
            level="warning",
        )
    rotated = teams[1:] + teams[:1]
    ctx.log(
        f"镜牢队伍轮换：本场第{teams[0]}个队伍 → 下一场第{rotated[0]}个队伍"
        f"（共 {len(teams)} 个队伍，轮换后顺序 {rotated}）"
    )
    # 唯一一份配置：页面读同一份资源显示，下一场运行也取它的第一支
    ctx.action(
        "page_resource.write_json",
        page_id=MIRROR_PAGE_ID,
        name=ORDER_RESOURCE,
        value={ORDER_TEAMS_KEY: rotated},
    )
    ctx.log(
        f"已保存轮换后的队伍顺序：{ORDER_RESOURCE}.{ORDER_TEAMS_KEY}={rotated}，"
        f"下一场使用第{rotated[0]}个队伍"
    )
