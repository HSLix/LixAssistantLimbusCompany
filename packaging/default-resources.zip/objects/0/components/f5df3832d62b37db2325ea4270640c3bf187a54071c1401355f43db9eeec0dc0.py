"""镜牢 Select Encounter Reward Card 页面选卡：优先按卡片说明文字 OCR 选卡，特征匹配作为保底。"""
import re

from lalc import RunContext, step

# 页面标题条：Select Encounter Reward Card
TITLE_REGION = {"x": 270, "y": 100, "width": 540, "height": 70}
TITLE_KEYWORD = "encounterrewardcard"
# 卡片图标所在区域：卡片上部的图标行
CARD_REGION = {"x": 330, "y": 175, "width": 640, "height": 290}
# 卡片优先级：靠前的先选；以后新增卡类只要按优先级往这个元组里加素材逻辑名
# coin（镜牢局内 Coin 货币）排在 starlight 之后，与下面文字 OCR 的关键词优先级一致
# cost_and_gift_chance（Cost 与 E.G.O 礼品概率）卡片图标在卡面上有缩放与形变，
# 因此与其它卡类一样走特征匹配；优先级低于 coin、高于 random_gift
CARD_PRIORITY = (
    "mirror/reward_card/starlight",
    "mirror/reward_card/coin",
    "mirror/reward_card/cost_and_gift_chance",
    "mirror/reward_card/random_gift",
)
# 卡片说明文字所在区域：从 (120, 300) 到 (1200, 500)；优先在这里用 OCR 读卡片效果文案
CARD_TEXT_REGION = {"x": 120, "y": 300, "width": 1080, "height": 200}
# 卡片文案的关键词优先级（全部小写匹配）：
# starlight → coin / cost（且不含 gift）→ gift → resource
# 镜牢局内 Coin 货币卡的英文文案写作 "Gain x~y Cost"，没有 coin 字样，
# 所以 cost 与 coin 视为同一档（Run 292 里只认 coin 时这张卡不参与排名，结果选了 gift）
KEYWORD_STARLIGHT = "starlight"
KEYWORD_COIN = "coin"
KEYWORD_COST = "cost"
KEYWORD_GIFT = "gift"
KEYWORD_RESOURCE = "resource"
# 同一张卡片文字块的判定：包围框水平间隙不超过这个像素数算同一块；
# 同一行文字判定：包围框中心 y 相差不超过这个像素数算同一行
BLOCK_GAP_X = 40
LINE_TOLERANCE_Y = 12
# 点完卡片后的固定等待秒数；是否选满由 sub_workflow.mirror_reward_card 下一轮重新观察
AFTER_CLICK_SECONDS = 0.5


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_items(ctx: RunContext, region: dict[str, int]) -> list[dict]:
    """刷新截图并返回指定区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=region) or {}
    return list(result.get("items") or [])


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _title_text(ctx: RunContext) -> str:
    """对当前帧的标题条做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=TITLE_REGION) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _box(item: dict) -> tuple[int, int, int, int]:
    """取 OCR 条目的包围框 (x, y, width, height)；缺字段时按 0 处理。"""
    box = item.get("box") or {}
    return (
        int(box.get("x", 0)),
        int(box.get("y", 0)),
        int(box.get("width", 0)),
        int(box.get("height", 0)),
    )


def _gap_x(first: tuple[int, int, int, int], second: tuple[int, int, int, int]) -> int:
    """两个包围框的水平间隙，重叠时返回 0。"""
    ax, _, aw, _ = first
    bx, _, bw, _ = second
    return max(0, bx - (ax + aw), ax - (bx + bw))


def _blocks(items: list[dict]) -> list[list[dict]]:
    """
    把 OCR 条目聚成每张卡片一个文字块：水平间隙不超过 BLOCK_GAP_X 的条目属于同一张卡片。
    不同卡片的说明文字之间间隙明显更大，因此不会被并到同一块里。
    """
    blocks: list[list[dict]] = []
    for item in sorted(items, key=lambda entry: _box(entry)[0]):
        if not str(item.get("text") or "").strip():
            continue
        item_box = _box(item)
        for block in blocks:
            if any(_gap_x(item_box, _box(member)) <= BLOCK_GAP_X for member in block):
                block.append(item)
                break
        else:
            blocks.append([item])
    return blocks


def _block_text(block: list[dict]) -> tuple[str, tuple[int, int, int, int]]:
    """
    把一个卡片文字块按 y 相近合并成行，行内按 x 顺序拼接，返回整块小写文案与合并后的包围框。
    """
    lines: list[dict] = []
    for item in sorted(block, key=lambda entry: _box(entry)[1] + _box(entry)[3] / 2):
        center = _box(item)[1] + _box(item)[3] / 2
        for line in lines:
            if abs(line["center"] - center) <= LINE_TOLERANCE_Y:
                line["items"].append(item)
                break
        else:
            lines.append({"center": center, "items": [item]})

    lines.sort(key=lambda line: line["center"])
    texts = [
        " ".join(str(entry.get("text") or "") for entry in sorted(line["items"], key=lambda it: _box(it)[0]))
        for line in lines
    ]
    boxes = [_box(entry) for entry in block]
    left = min(box[0] for box in boxes)
    top = min(box[1] for box in boxes)
    right = max(box[0] + box[2] for box in boxes)
    bottom = max(box[1] + box[3] for box in boxes)
    return " ".join(texts).strip(), (left, top, right - left, bottom - top)


def _rank(text: str) -> tuple[int, str] | None:
    """
    按卡片文案关键词排名（小写匹配）：starlight 最优，其次是 Coin 货币卡
    （含 coin，或文案为 "Gain x~y Cost" 而含 cost，且不含 gift），再次是含 gift 的，
    最后是含 resource 的；都不含时返回 None，表示不参与选择。
    """
    lowered = str(text).lower()
    if KEYWORD_STARLIGHT in lowered:
        return 0, KEYWORD_STARLIGHT
    if KEYWORD_GIFT not in lowered:
        if KEYWORD_COIN in lowered:
            return 1, KEYWORD_COIN
        if KEYWORD_COST in lowered:
            return 1, KEYWORD_COST
    if KEYWORD_GIFT in lowered:
        return 2, KEYWORD_GIFT
    if KEYWORD_RESOURCE in lowered:
        return 3, KEYWORD_RESOURCE
    return None


def _ocr_candidate(ctx: RunContext) -> dict | None:
    """
    刷新截图，对卡片说明文字区做 OCR，聚成每张卡片一块后按关键词优先级挑出要点的卡片。
    返回 {"keyword", "point", "text", "candidates"}；区域里没有命中关键词的卡片时返回 None。
    """
    items = _region_items(ctx, CARD_TEXT_REGION)
    blocks = _blocks(items)
    ranked: list[dict] = []
    for block in blocks:
        text, box = _block_text(block)
        rank = _rank(text)
        if rank is None:
            continue
        ranked.append({"rank": rank[0], "keyword": rank[1], "text": text, "box": box})

    if not ranked:
        ctx.log(f"卡片说明文字区 OCR 共 {len(blocks)} 块，没有命中 starlight / coin / cost / gift / resource 关键词")
        return None

    ranked.sort(key=lambda entry: (entry["rank"], entry["box"][0], entry["box"][1]))
    best = ranked[0]
    same = [entry for entry in ranked if entry["rank"] == best["rank"]]
    if len(same) > 1:
        ctx.log(
            f"OCR 有 {len(same)} 张卡片同为最高优先级 {best['keyword']}，按从左到右取最左侧一张",
            level="warning",
        )
    left, top, width, height = best["box"]
    return {
        "keyword": best["keyword"],
        "point": (left + width // 2, top + height // 2),
        "text": best["text"],
        "candidates": len(ranked),
    }


@step
def execute(ctx: RunContext) -> None:
    """
    在镜牢 Select Encounter Reward Card 页面选一张卡，只做一次局部尝试：
    - 不在本页（标题条读不到 Encounter Reward Card）时零输入返回；
    - 先对卡片说明文字区 OCR，按 starlight → coin／cost（不含 gift）→ gift → resource 优先级挑一张，点一次；
    - OCR 没命中可选卡时退回特征匹配 CARD_PRIORITY，命中就点一次；两者都没命中时不点击。
    点完只等固定 0.5 秒交回；是否选满、是否需要按 Enter 或先按 ESC 由
    sub_workflow.mirror_reward_card 下一轮重新观察，本步不读计数、不轮询。
    """
    ctx.action("observe.capture_screen")
    if TITLE_KEYWORD not in _title_text(ctx):
        ctx.log("当前不是 reward card 可选卡片页，本步不点击")
        return

    candidate = _ocr_candidate(ctx)
    if candidate:
        ctx.log(
            f"OCR 选中 {candidate['keyword']} 卡片（文案：{candidate['text']}），点击 {candidate['point']}"
        )
        ctx.action("control.click", centerxy=candidate["point"])
        ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
        return

    for asset in CARD_PRIORITY:
        ctx.action("observe.capture_screen")
        hits = ctx.action("observe.match_feature", asset=asset, region=CARD_REGION) or []
        if not hits:
            continue
        if len(hits) > 1:
            ctx.log(f"{asset} 特征匹配命中 {len(hits)} 处，按内点数最高的一处点击", level="warning")
        center = hits[0].get("centerxy") or (0, 0)
        point = (int(center[0]), int(center[1]))
        ctx.log(f"OCR 没有选出卡片，按 CARD_PRIORITY 点击 {asset} 卡片图标 {point}")
        ctx.action("control.click", centerxy=point)
        ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
        return

    ctx.log(
        "OCR 与特征匹配都没有选出已知奖励卡片，本步不点击；"
        "新卡类需要先在素材库补充 mirror/reward_card/ 下的图标",
        level="warning",
        screenshot=True,
    )
