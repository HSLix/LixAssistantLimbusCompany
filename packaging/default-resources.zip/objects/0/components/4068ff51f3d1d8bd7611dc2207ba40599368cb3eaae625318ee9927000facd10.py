"""镜牢商店运行时状态：按调度点一次性刷新本楼层的商店相关记录（技能替换处理记录与已进过商店标记）。"""
import re

from lalc import RunContext, step

# 商店相关的运行时记录都放在 RunState.settings 的镜牢运行时状态里，由本步统一管理：
# shop_skill_handled 是本次商店已处理的技能替换商品，shop_visited 是本楼层是否已进过商店并做完离开前事务。
RUNTIME_KEY = "mirror.runtime"
SHOP_SKILL_HANDLED_KEY = "shop_skill_handled"
# 本次商店已经做过技能替换（固定商品成交、ID Skill Search 成交）或点过头像的罪人：
# 后续 ID Skill Search 选人按队伍编排顺序往后取下一个；商品一重掷，那张卡就换了一批选项，
# 已替换／已选记录也必须同步清空
SHOP_ID_SKILL_SEARCH_TRIED_KEY = "shop_id_skill_search_tried"
# 本次商店已处理（打开过详情）的饰品商品位置，与技能替换记录同时清空
SHOP_GIFT_HANDLED_KEY = "shop_gift_handled"
SHOP_VISITED_KEY = "shop_visited"
# 本次商店是否已跑过饰品自维护（打开 Sell E.G.O Gift 弹窗存新饰品）：新楼层开始时要复位。
SELL_GIFT_MAINTAINED_KEY = "sell_gift_maintained"
# 本次商店是否已跑过融合（Fuse Gifts）：新楼层开始时要复位，否则新楼层的融合会被跳过。
SHOP_FUSED_KEY = "shop_fused"
# 商店页标识（三条判据取或，任一成立就算商店页）：
# ① 右上角普通 Refresh 按钮模板命中；② Keyword Refresh 按钮模板命中；③ 左上角 Shop 标题文字。
# 单个按钮模板在遮挡／动画帧下可能只命中一个，短标题 OCR 也会偶发漏识别，取或后不再要求两个同时命中。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 商店的 Fuse E.G.O Gift 融合页同样盖住商店页：停在融合页时也不能清空商店记录。
# 标题横幅用素材 mirror/shop/fuse/fuse_ego_gift（425x44）做原尺寸模板匹配，
# 不再读标题文字，也不再读右上角 Fusion Guide 文字。
FUSE_POPUP_TITLE_ASSET = "mirror/shop/fuse/fuse_ego_gift"
FUSE_POPUP_TITLE_REGION = {"x": 390, "y": 55, "width": 500, "height": 90}
FUSE_POPUP_TITLE_THRESHOLD = 0.85
# 商店的技能替换弹窗盖住商店页（Shop 标题被挡住），用弹窗标题 Replace <罪人>'s Skill 单独识别。
# 窄区域做局部 OCR 会把长标题断成两段并漏掉两端，因此按整条标题横幅取区域。
SKILL_POPUP_REGION = {"x": 175, "y": 95, "width": 570, "height": 78}
SKILL_POPUP_KEYWORDS = ("replace", "skill")
# 标题 OCR 偶发漏字时的后备判据：弹窗底部的 Cancel／Confirm 按钮在商店页不会同时出现
SKILL_POPUP_ACTION_REGION = {"x": 400, "y": 505, "width": 520, "height": 70}
SKILL_POPUP_ACTION_KEYWORDS = ("cancel", "confirm")


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _popup_open(ctx: RunContext) -> bool:
    """当前帧是否停在技能替换弹窗：标题关键词为主，底部 Cancel／Confirm 按钮为后备。"""
    text = _region_text(ctx, SKILL_POPUP_REGION)
    if all(word in text for word in SKILL_POPUP_KEYWORDS):
        return True
    actions = _region_text(ctx, SKILL_POPUP_ACTION_REGION)
    return all(word in actions for word in SKILL_POPUP_ACTION_KEYWORDS)


def _in_shop(ctx: RunContext) -> bool:
    """当前帧是否已停在商店页、技能替换弹窗或融合页：这些状态里清空处理记录会导致重复购买。"""
    if _popup_open(ctx):
        return True
    if ctx.action(
        "observe.match_asset",
        asset=FUSE_POPUP_TITLE_ASSET,
        region=FUSE_POPUP_TITLE_REGION,
        threshold=FUSE_POPUP_TITLE_THRESHOLD,
    ):
        return True
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


@step
def execute(ctx: RunContext, *, in_shop: bool = False) -> None:
    """
    管理同一楼层商店的运行时记录（只写 RunState，不点击、不返回数据）：
    - 默认（in_shop=False）：主题包选择成功后由 task.mirror 调度一次，清空 shop_skill_handled
      与 shop_gift_handled（本楼层商店已处理的位置），并把 shop_visited 复位为 False（本楼层还没进过商店）。
    - in_shop=True：在商店里普通 Refresh 重掷商品后调度，只清空 shop_skill_handled、shop_gift_handled
      与 shop_id_skill_search_tried（商品列表已换，新商品要重新评估），shop_visited 保持不变。
    in_shop=False 时若当前帧仍停在商店页或技能替换弹窗（属于商店内），则零写入直接返回：
    在商店里清空记录会导致重复购买，交给 task.mirror 的商店分支处理。
    """
    if not in_shop:
        ctx.action("observe.capture_screen")
        if _in_shop(ctx):
            ctx.log(
                "当前仍停在镜牢商店页或技能替换弹窗，不在商店里按新楼层刷新商店状态"
                "（清空记录会重复购买），交给上层商店分支处理",
                level="warning",
                screenshot=True,
            )
            return

    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法刷新商店运行时记录", level="error")
        return

    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    previous_handled = runtime.get(SHOP_SKILL_HANDLED_KEY)
    previous_gift = runtime.get(SHOP_GIFT_HANDLED_KEY)
    previous_id_search = runtime.get(SHOP_ID_SKILL_SEARCH_TRIED_KEY)
    runtime[SHOP_SKILL_HANDLED_KEY] = []
    runtime[SHOP_GIFT_HANDLED_KEY] = []
    runtime[SHOP_ID_SKILL_SEARCH_TRIED_KEY] = []
    if in_shop:
        ctx.log(
            f"商品已重掷：清空本次商店的技能替换与饰品商品处理记录"
            f"（原技能替换 {previous_handled}、原饰品 {previous_gift}、"
            f"原 ID Skill Search 已选罪人 {previous_id_search}），"            f"{SHOP_VISITED_KEY} 保持 {runtime.get(SHOP_VISITED_KEY)}"
        )
    else:
        previous_visited = runtime.get(SHOP_VISITED_KEY)
        previous_fused = runtime.get(SHOP_FUSED_KEY)
        runtime[SHOP_VISITED_KEY] = False
        runtime[SELL_GIFT_MAINTAINED_KEY] = False
        runtime[SHOP_FUSED_KEY] = False
        ctx.log(
            f"已刷新新楼层的商店运行时记录：技能替换记录由 {previous_handled} 清空、"
            f"饰品商品记录由 {previous_gift} 清空，"
            f"ID Skill Search 已选／已替换罪人由 {previous_id_search} 清空，"
            f"{SHOP_VISITED_KEY} 由 {previous_visited} 复位为 False，"
            f"{SELL_GIFT_MAINTAINED_KEY} 复位为 False，{SHOP_FUSED_KEY} 由 {previous_fused} 复位为 False"
        )
    settings[RUNTIME_KEY] = runtime
