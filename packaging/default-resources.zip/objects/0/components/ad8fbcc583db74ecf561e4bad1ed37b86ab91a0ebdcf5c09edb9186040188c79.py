"""镜牢商店「自维护饰品」核心一步：处理 Sell E.G.O Gift 弹窗右侧饰品格里的一个格子。

整卡矩形由开发者指定的角标倒推：卡片框左下角贴着一块角标（素材 mirror/shop/ego_corner，
现场已收敛为单一 16x16 模板，匹配阈值 CORNER_THRESHOLD = 0.8）。
角标模板的左边／底边与卡片框有固定内缩，先按命中模板的宽高查 CORNER_TEMPLATE_INSETS 归一化，
再按「卡片左边 = 角标左边 + 左内缩、卡片底边 = 角标底边 − 底内缩、卡片顶边 = 底边 − 卡高」
算出整卡矩形；卡片宽高全场统一（都是 68x73），不按格子区分。
现场实测（1280x720）：卡片宽 68、高 73，第 1 列左边 645、列距 92、行距 107。
上层按价格行反推的卡片顶边会随滚动漂 1~2 像素、列距也不是整百，所以角标只在标称矩形周围
放宽 CORNER_SEARCH_PAD 的窗口里匹配，命中即用角标位置、匹配不到才退回固定网格几何。
（Run 437/438 结论仍然成立：拿角标在整片格区做 0.5 阈值聚类是噪声灾难，且卡片被选中后
边框高亮会破坏角标；这里只在单格窗口内、点击之前用高阈值匹配，不受那两条限制。）
空格子本来就没有卡片、也就没有角标，属于正常分支：角标没命中先按 info 记录并退回标称网格，
只有点开该格后真的读到饰品名时，才升级成 warning（说明角标检测在真的有卡片时失效了，
Run 471 的两次命中失败都在空格子上，原先直接记 warning 会让人误以为角标模板坏了）。

一步只处理一个格子，顺序固定：
1) 先截一帧，用角标倒推该格整卡矩形，再把整张卡片暂存成裁剪（正常情况下此时还没点选，模板里不带
   选中高亮），并读一次左侧名字横幅记下「点击前的选中项」——弹窗会保留上一次点选的饰品，上一轮留下
   的选中高亮会同时破坏这一格的模板匹配与角标，这个记录是第 3 步判据的依据；
2) 点一次倒推出来的卡片中心——弹窗里的选中状态无法靠重复点击撤回，所以一格在一次运行里只点一次；
   这里绝不点弹窗的 Sell 按钮（那会真的卖出饰品）；
3) 重新截图，OCR 左侧名字横幅读出饰品名（检测器 thresh 按开发者要求下放到 0.15，
   让偏暗或笔画细的标题字更容易被分框），过滤掉纯数字（价格数字也会被读进来）
   与名字区右上角 (x > 510 且 y < 210) 的 coin 图标、"+N" 数字；
   读不到名字（未选中时横幅只有 "???"）、读到的是已经处理过的名字、或读到的是与点击前完全相同的名字
   ——点空格子不会改变选中项，本来就处于选中态的卡片也一样——都按空格子处理，丢弃暂存裁剪；
   其中「名字没变」这条判据来自 Run 472：上一轮（Run 471）把 Perversion 留在选中态后取消，本轮打开
   弹窗时它仍带选中高亮，干净模板 d8b268… 因此 0.85 整组没命中（改为默认阈值 0.9、并取消放宽阈值复核的效果），
   该格被当成新饰品把带高亮的裁剪存成同名第二张图（4e5fb3…）；加上这条判据后同类格子不再写素材库；
4) 识别流派：先用 mirror/gift_keyword_icon 图鉴在左侧大图右下角做一次模板匹配，覆盖图鉴下全部 11 个
   流派类（bleed／blunt／burn／charge／keywordless／pierce／poise／rupture／sink／slash／tremor，
   同一逻辑名下可以同时存在多种尺寸的模板）；多类同时命中时以准确度最高（分数最高）的那一类
   为准，最高分与次高分的差距只用于记 warning、不改判；只有一类都没命中时才读饰品说明文字里的
   流派词（状态词优先，其次伤害类型词，一个都没有就按 keywordless）；图标与说明都拿不到流派时
   只有「图鉴里已有同名目录」才继续按已有目录补图，新饰品无法确定目录才跳过并记 warning；
5) 用第 1 步的暂存裁剪保存成 mirror/gift/<流派>/<名字>，名字转小写、非字母数字转下划线。
   上层只在 mirror/gift 整组匹配达不到默认阈值 0.9 时才点这一格，所以这里无论新饰品还是已入库的饰品都要收录：
   已有同名目录时一律在原逻辑名下追加一张裁剪（本次流派识别结果与已有目录不同也只记 warning，不新建
   第二条同名记录），新饰品才按本次识别流派建目录；这样图鉴下次就能按默认阈值命中同一件饰品。
   配置镜像（「饰品配置」）里还没有的饰品，保存成功后同时记进 mirror.runtime.new_gifts 临时字典：
   那是本次 Run 刚收录、页面配置还没重建的饰品，融合耗材名单等后续步骤会把它并入计算（只在本次 Run 内有效）。
dry_run=True 时只走完识别与日志、丢弃裁剪，不写共享素材库（也不累计临时字典）。
素材库镜像：镜牢设置页「饰品配置」的键就是素材逻辑名 mirror/gift/<流派>/<名字>，页面每次显示／保存都按
素材目录重建（手工直接加进素材库的饰品也在里面，偏好为 default）；工作流不能直接枚举素材库，
也不再维护单独的饰品图鉴资源，这里用这份配置判断同名饰品已存在的目录。
"""
import hashlib
from pathlib import PureWindowsPath
import re
import unicodedata

from lalc import RunContext, step

MIRROR_PAGE_ID = "mirror.settings"
SHOP_GIFTS_KEY = "shop_gifts"
GIFT_PREFERENCE_KEY = "preferences"
# 本次 Run 的临时新增饰品字典：{饰品逻辑名: 收录来源}，只在 RunState 内存里累计。
# 收录的是「保存成功但配置镜像里还没有」的饰品（页面还没按素材目录重建），供融合耗材名单并入计算。
RUNTIME_KEY = "mirror.runtime"
NEW_GIFTS_KEY = "new_gifts"

# 整卡尺寸（1280x720 现场实测 68x73）与「卡片中心 → 整卡裁剪左上角」的偏移（半个卡片尺寸）：
# 卡片框左边 645、列距 92、行距 107；第 1 行卡片顶边 215 时价格数字中心在 304。
CARD_WIDTH = 68
CARD_HEIGHT = 73
CROP_LEFT_DELTA = -34
CROP_TOP_DELTA = -36
# 卡片框左下角的角标：素材 mirror/shop/ego_corner（现场已收敛为单一 16x16 模板）
CORNER_ASSET = "mirror/shop/ego_corner"
CORNER_THRESHOLD = 0.8
# 角标搜索窗口：标称整卡矩形四周各放宽这么多像素
CORNER_SEARCH_PAD = 16
# 角标模板的裁剪边距与卡片框不是零距离，按命中模板的宽高查表归一化（单位像素，(左内缩, 底内缩)）：
# 卡片左边 = 角标左边 + 左内缩；卡片底边 = 角标底边 − 底内缩；卡片顶边 = 底边 − 卡高。
# 卡片宽高全场统一（68x73），不需要按格子区分。
# 内缩取自 Run 464 现场标定：命中 (736,279,16x16) score=0.963 时卡片框左边应在 737、底边应在 288。
CORNER_TEMPLATE_INSETS = {
    (16, 16): (1, 7),
}
# 角标倒推位置与标称位置相差超过这么多像素就按噪声丢弃，避免把裁剪拉走
MAX_CORNER_SHIFT = 12
# 点完格子到左侧详情面板刷新完成的固定等待
CLICK_SETTLE_SECONDS = 0.7
# 左侧名字横幅：按开发者要求放大到 (300,160)~(560,280)，即宽 260、高 120。
# 上沿不再压在横幅本体上（实测饰品名 "Rags" 中心 (430,221)、横幅约 y 200~245），
# 多读进来的卡片右上角 coin 图标与 "+N" 数字改由下面的坐标过滤剔除，
# 不再靠裁掉整条上边来避开它们（Run 467 曾把它们读成名字前缀 "Bgg"）。
NAME_REGION = {"x": 300, "y": 160, "width": 260, "height": 120}
# 名字区的 OCR 检测参数：开发者要求标题 OCR 用 thresh=0.15（默认 0.3），
# 降低文字像素阈值让暗底上的细笔画也参与找轮廓，减少标题被切碎／漏字；
# 只作用于名字区这一次局部 OCR，不影响其它区域的全默认识别。
NAME_DET_OPTIONS = {"thresh": 0.15}
# 名字区里要忽略的右上角：中心 x 大于该值且 y 小于该值的条目（coin 图标、"+N" 数字）不算饰品名
NAME_IGNORE_X = 510
NAME_IGNORE_Y = 210
# 未选中饰品时这里只有 "???"，没有字母，天然被过滤；这个短语出现在下方说明区，用于确认确实没选中
NAME_PLACEHOLDER = "selecttheegogift"
# 拼接后整条名字的最短长度：只在整体上校验，单个条目不再单独按长度过滤，
# 否则 "Ashes to Ashes" 里只有两个字母的 "to" 会被当成短噪声丢掉（Run 467 现象）。
NAME_MIN_LENGTH = 3
# 左侧饰品说明文字：流派词（Sinking、Bleed…）也写在说明里，作为图标匹配失败时的后备
DESCRIPTION_REGION = {"x": 158, "y": 335, "width": 392, "height": 180}
# 左侧大图右下角的流派图标区域：按开发者要求改为 (230,260)~(300,330)，即宽 70、高 70（原为
# (205,255) 起的 80x60）。图标模板本身约 20x22（sink 约在 (232,282)~(252,302)），区域放大只影响
# 搜索范围，图标命中判定仍按 KEYWORD_THRESHOLD 与各流派类归并后取最高分。
KEYWORD_REGION = {"x": 230, "y": 260, "width": 70, "height": 70}
KEYWORD_GROUP = "mirror/gift_keyword_icon"
# mirror/gift_keyword_icon 下的全部流派类目录（与素材库一一对应，共 11 类）：
# 图标检测按这些类归并命中，说明文字后备也只映射到这 11 类；素材库新增类目录时必须同步这里。
KEYWORD_CLASSES = (
    "bleed",
    "blunt",
    "burn",
    "charge",
    "keywordless",
    "pierce",
    "poise",
    "rupture",
    "sink",
    "slash",
    "tremor",
)
KEYWORD_THRESHOLD = 0.8
# 多个流派类同时命中时以准确度最高者为准（开发者要求）；最高分与次高分相差小于这个值时
# 额外记一条 warning 说明判定有歧义，但仍然采用最高分，不改判、不退回说明文字
KEYWORD_AMBIGUOUS_MARGIN = 0.03
# 图标逻辑名叶子／说明文字里的词 → 素材库流派目录名（只接受 KEYWORD_CLASSES 里的类）
KEYWORD_ALIASES = {
    "sink": "sink",
    "sinking": "sink",
    "bleed": "bleed",
    "burn": "burn",
    "burning": "burn",
    "tremor": "tremor",
    "rupture": "rupture",
    "poise": "poise",
    "charge": "charge",
    "slash": "slash",
    "pierce": "pierce",
    "blunt": "blunt",
    "keywordless": "keywordless",
    "keywordlessicon": "keywordless",
    "general": "keywordless",
    "none": "keywordless",
}
GIFT_ROOT = "mirror/gift"
# 图鉴条目 id 与素材引用只接受 mirror/gift/<流派>/<名字>：流派目录名由素材库决定
GIFT_ID_PATTERN = re.compile(r"mirror/gift/[a-zA-Z_][a-zA-Z0-9_-]*/[a-zA-Z_][a-zA-Z0-9_-]*")
# 说明文字里的状态词 → 素材库流派目录名
STATUS_WORDS = {
    "sinking": "sink",
    "sink": "sink",
    "bleed": "bleed",
    "burn": "burn",
    "tremor": "tremor",
    "rupture": "rupture",
    "poise": "poise",
    "charge": "charge",
}
# 说明文字里的伤害类型词 → 素材库流派目录名，只在没有任何状态词时才采用
DAMAGE_WORDS = {"slash": "slash", "pierce": "pierce", "blunt": "blunt"}


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，便于文字匹配。"""
    return "".join(c for c in unicodedata.normalize("NFKC", str(text)).casefold() if c.isalnum())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _fmt(region: dict[str, int]) -> str:
    """把矩形格式化成 (x,y,WxH)，便于日志核对。"""
    return f"({region['x']},{region['y']},{region['width']}x{region['height']})"


def _nominal_card(cx: int, cy: int) -> dict[str, int]:
    """由上层给的卡片中心换算标称整卡矩形：既是角标搜索的基准，也是匹配不到角标时的后备。"""
    return {
        "x": cx + CROP_LEFT_DELTA,
        "y": cy + CROP_TOP_DELTA,
        "width": CARD_WIDTH,
        "height": CARD_HEIGHT,
    }


def _search_region(nominal: dict[str, int]) -> dict[str, int]:
    """角标搜索窗口：标称整卡矩形四周各放宽 CORNER_SEARCH_PAD 像素。"""
    pad = CORNER_SEARCH_PAD
    return {
        "x": nominal["x"] - pad,
        "y": nominal["y"] - pad,
        "width": nominal["width"] + 2 * pad,
        "height": nominal["height"] + 2 * pad,
    }


def _card_by_corner(ctx: RunContext, nominal: dict[str, int]):
    """
    用卡片框左下角的角标 mirror/shop/ego_corner 倒推整卡矩形。

    角标模板（现只有 16x16 一个模板）的左边、底边与卡片框有固定内缩，所以先按命中模板的宽高查
    CORNER_TEMPLATE_INSETS 归一化，再算卡片左边 = 角标左边 + 左内缩、卡片底边 = 角标底边 − 底内缩、
    卡片顶边 = 卡片底边 − 卡高；卡片宽高全场统一（68x73），不按格子区分。
    在标称矩形周围放宽 CORNER_SEARCH_PAD 的窗口里按 CORNER_THRESHOLD（0.8）匹配一次；多个命中按
    「离标称矩形最近」取一个，与标称位置相差超过 MAX_CORNER_SHIFT 的命中按噪声丢弃；命中模板尺寸
    不在表里时不猜偏移，直接退回标称几何（退回时把每个命中框写进 warning，便于现场补测内缩）。
    返回 (整卡矩形, 说明)；拿不到可用角标时返回 (None, 说明)。
    """
    search = _search_region(nominal)
    hits = (
        ctx.action(
            "observe.match_asset",
            asset=CORNER_ASSET,
            region=search,
            threshold=CORNER_THRESHOLD,
        )
        or []
    )
    if not hits:
        return None, (
            f"标称矩形周围 {CORNER_SEARCH_PAD} 像素内没匹配到角标 {CORNER_ASSET}"
            f"（阈值 {CORNER_THRESHOLD}）"
        )
    best = None
    rejected: list = []
    unknown_sizes: set = set()
    for hit in hits:
        height = int(hit.get("height") or 0)
        size = (int(hit.get("width") or 0), height)
        if not height or size not in CORNER_TEMPLATE_INSETS:
            unknown_sizes.add(size)
            continue
        left_inset, bottom_inset = CORNER_TEMPLATE_INSETS[size]
        left = int(hit.get("x") or 0) + left_inset
        bottom = int(hit.get("y") or 0) + height - bottom_inset
        rect = {
            "x": left,
            "y": bottom - CARD_HEIGHT,
            "width": CARD_WIDTH,
            "height": CARD_HEIGHT,
        }
        dx = abs(rect["x"] - nominal["x"])
        dy = abs(rect["y"] - nominal["y"])
        if dx > MAX_CORNER_SHIFT or dy > MAX_CORNER_SHIFT:
            rejected.append((hit, rect))
            continue
        if best is None or dx + dy < best[0]:
            best = (dx + dy, rect, hit)
    if unknown_sizes:
        ctx.log(
            f"角标命中里有未知模板尺寸 {sorted(unknown_sizes)}，没有对应的对齐偏移，"
            "这些命中不参与倒推（需按现场测量补进 CORNER_TEMPLATE_INSETS）",
            level="warning",
        )
    if best is not None:
        hit = best[2]
        left_inset, bottom_inset = CORNER_TEMPLATE_INSETS[
            (int(hit.get("width") or 0), int(hit.get("height") or 0))
        ]
        note = (
            f"角标 {CORNER_ASSET} 在阈值 {CORNER_THRESHOLD} 命中 "
            f"({hit.get('x')},{hit.get('y')},{hit.get('width')}x{hit.get('height')}) "
            f"score={round(float(hit.get('score', 0.0)), 3)}，按模板内缩 "
            f"({left_inset},{bottom_inset}) 归一化后卡片框左边 {best[1]['x']}、"
            f"底边 {best[1]['y'] + CARD_HEIGHT}"
        )
        if rejected:
            note += (
                f"（另有 {len(rejected)} 个命中离标称位置超过 {MAX_CORNER_SHIFT} 像素，按噪声丢弃："
                + "；".join(
                    f"({hit.get('x')},{hit.get('y')},{hit.get('width')}x{hit.get('height')})"
                    f"→ 整卡 ({rect['x']},{rect['y']})"
                    for hit, rect in rejected
                )
                + "）"
            )
        return best[1], note
    detail = "；".join(
        f"({hit.get('x')},{hit.get('y')},{hit.get('width')}x{hit.get('height')}) "
        f"score={round(float(hit.get('score', 0.0)), 3)} → 整卡 ({rect['x']},{rect['y']})"
        for hit, rect in rejected
    )
    return None, (
        f"角标 {CORNER_ASSET} 在阈值 {CORNER_THRESHOLD} 命中 {len(hits)} 个，但都与标称卡片位置"
        f"相差超过 {MAX_CORNER_SHIFT} 像素，按噪声丢弃：{detail}"
    )


def _gift_name(ctx: RunContext) -> str:
    """
    读左侧名字横幅：只保留含字母、且不是未选中占位的条目，纯数字（价格）与 coin 之类的
    图标噪声都被过滤。名字区右上角（中心 x > NAME_IGNORE_X 且 y < NAME_IGNORE_Y）是卡片上的
    coin 图标与 "+N" 数字，按开发者要求一律忽略、不作为饰品名的一部分。单个条目不再按长度过滤，
    按识别顺序拼成整条名字后才校验最短长度，这样 "Ashes to Ashes" 中间的 "to" 不会被丢掉
    （Run 467 现象）。OCR 检测参数用 NAME_DET_OPTIONS（thresh 0.15）。
    """
    result = ctx.action("observe.ocr", region=NAME_REGION, det_options=NAME_DET_OPTIONS) or {}
    texts = []
    ignored = []
    for item in result.get("items") or []:
        text = str(item.get("text", "")).strip()
        if not text or not any(char.isalpha() for char in text):
            continue
        flat = _norm(text)
        if not flat or NAME_PLACEHOLDER in flat:
            continue
        center = item.get("centerxy")
        if center and int(center[0]) > NAME_IGNORE_X and int(center[1]) < NAME_IGNORE_Y:
            ignored.append(f"{text}@({int(center[0])},{int(center[1])})")
            continue
        texts.append(text)
    if ignored:
        ctx.log(
            f"名字区右上角 x>{NAME_IGNORE_X} 且 y<{NAME_IGNORE_Y} 的条目按图标噪声忽略："
            + "; ".join(ignored)
        )
    name = " ".join(texts).strip()
    return "" if len(_norm(name)) < NAME_MIN_LENGTH else name


def _slug(name: str) -> str:
    """为名称选择安全的素材目录名（匹配用的名字就是它）；非 ASCII 名称只能用哈希目录名，无法按名字匹配。"""
    text = unicodedata.normalize("NFKC", name).strip()
    slug = re.sub(r"[^a-z0-9_-]+", "_", text.lower()).strip("_-")
    if not slug or not text.isascii() or len(slug) > 120 or PureWindowsPath(slug).is_reserved():
        return "gift_" + hashlib.sha256(_norm(name).encode()).hexdigest()[:20]
    return "gift_" + slug if slug[0].isdigit() else slug


def _mirror_gifts(ctx: RunContext) -> dict[str, str]:
    """
    素材库镜像里的饰品逻辑名 → 获取偏好：镜牢设置页「饰品配置」的键就是 mirror/gift/<流派>/<名字>，
    页面每次显示／保存都按素材目录重建，手工直接加进素材库的饰品也在里面。
    工作流不能直接枚举素材库，也不再有单独的饰品图鉴资源；这里只用它判断同名饰品已存在的目录。
    """
    settings = ctx.run_state.settings
    page = settings.get(MIRROR_PAGE_ID) if isinstance(settings, dict) else None
    gifts = page.get(SHOP_GIFTS_KEY) if isinstance(page, dict) else None
    raw = gifts.get(GIFT_PREFERENCE_KEY) if isinstance(gifts, dict) else None
    if not isinstance(raw, dict):
        return {}
    return {
        str(name): str(value) for name, value in raw.items()
        if GIFT_ID_PATTERN.fullmatch(str(name))
    }


def _record_new_gift(ctx: RunContext, asset: str, source: str) -> None:
    """
    把配置镜像里还没有的饰品逻辑名记进本次 Run 的临时新增饰品字典 mirror.runtime.new_gifts。
    字典是「逻辑名 → 收录来源」，同一逻辑名重复收录只留最后一条来源，不会重复累计；
    写不进去（settings 只读）时只记 warning，不回退、不影响本步的素材保存结果。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法累计本次 Run 的临时新增饰品字典", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    record = runtime.get(NEW_GIFTS_KEY)
    if not isinstance(record, dict):
        record = {}
    record[asset] = str(source or "")
    runtime[NEW_GIFTS_KEY] = record
    settings[RUNTIME_KEY] = runtime
    ctx.log(
        f"本次 Run 临时新增饰品字典累计 {len(record)} 件：{asset}（来源 {source}）"
    )


def _archive(asset: str) -> str:
    """取素材逻辑名里的流派目录（mirror/gift/<流派>/<名字> 的第三段）；不是这个形状时返回空串。"""
    parts = str(asset or "").split("/")
    return parts[2] if len(parts) == 4 else ""


def _find_gift(gifts: dict[str, str], name: str, asset: str = "") -> str | None:
    """按素材逻辑名或唯一的饰品目录名解析已有目录；目录名命中多条时返回 None（不认领）。"""
    if asset and asset in gifts:
        return asset
    wanted = _norm(name)
    matches = [
        key for key in gifts
        if wanted and _norm(key.rsplit("/", 1)[-1]) == wanted
    ]
    if len(matches) > 1:
        return None
    return matches[0] if matches else ""


def _keyword_class(text: str) -> str:
    """把图标逻辑名叶子或说明文字里的词归一成素材库流派目录名；不在 KEYWORD_CLASSES 里的类返回空串。"""
    key = _norm(text)
    name = KEYWORD_ALIASES.get(key, key)
    return name if name in KEYWORD_CLASSES else ""


def _keyword_by_icon(ctx: RunContext) -> str:
    """
    用 mirror/gift_keyword_icon 图鉴在左侧大图右下角匹配流派图标，覆盖图鉴下全部 11 个流派类。
    同一逻辑名下可以有多个尺寸的模板，因此预览尺寸的图标只要入过库就能命中。命中按流派类归并、
    各取最高分后判定（开发者要求：多类同时命中时以准确度最高的那一类为准）：
    - 只有一类命中 → 采用该类；
    - 多类命中 → 采用分数最高的一类；最高分与次高分相差小于 KEYWORD_AMBIGUOUS_MARGIN 时
      额外记一条 warning 说明几个图标相似、判定有歧义，但不改判、也不退回说明文字；
    - 一类都没命中 → 返回空串，交给说明文字后备逻辑；
    - 命中类不在 KEYWORD_CLASSES（素材库新增了未登记的类）时跳过并记 warning。
    """
    hits = (
        ctx.action(
            "observe.match_asset_group",
            group=KEYWORD_GROUP,
            region=KEYWORD_REGION,
            threshold=KEYWORD_THRESHOLD,
        )
        or []
    )
    best: dict[str, float] = {}
    unknown: set[str] = set()
    for hit in hits:
        logical = str(hit.get("logical_name") or "")
        leaf = logical.rsplit("/", 1)[-1]
        if not logical or not leaf:
            continue
        name = _keyword_class(leaf)
        if not name:
            unknown.add(logical)
            continue
        score = float(hit.get("score") or 0.0)
        best[name] = max(best.get(name, 0.0), score)
    if unknown:
        ctx.log(
            f"流派图标命中里出现不在 {list(KEYWORD_CLASSES)} 里的逻辑名 {sorted(unknown)}，"
            "这些命中不参与判定（需在本步登记新的流派类）",
            level="warning",
        )
    if not best:
        return ""
    ranked = sorted(best.items(), key=lambda item: item[1], reverse=True)
    top_name, top_score = ranked[0]
    if len(ranked) == 1:
        ctx.log(f"流派图标判为 {top_name}（分数 {round(top_score, 3)}）")
        return top_name
    second_name, second_score = ranked[1]
    # 开发者要求：多类同时命中时以准确度最高者为准，不再因为分数接近就判为不唯一、改读说明文字
    if top_score - second_score < KEYWORD_AMBIGUOUS_MARGIN:
        ctx.log(
            f"流派图标多类命中且最高分很接近：{top_name}={round(top_score, 3)} 与 "
            f"{second_name}={round(second_score, 3)}（差 < {KEYWORD_AMBIGUOUS_MARGIN}），"
            f"按准确度最高取 {top_name}",
            level="warning",
        )
        return top_name
    ctx.log(
        f"流派图标多类命中，按准确度最高取 {top_name}（分数 {round(top_score, 3)}，"
        f"次高 {second_name}={round(second_score, 3)}）"
    )
    return top_name


def _keyword_by_description(ctx: RunContext) -> str:
    """
    说明文字后备：读左侧饰品说明，找流派词。状态词（Sinking／Bleed／Tremor…）优先，
    只有唯一状态词才采用；没有任何状态词时再看伤害类型词（Slash／Pierce／Blunt）。
    多个状态词同时出现（说明里提到别的状态）时判为不唯一，返回空串（不保存）。
    说明读到了、但一个流派词都没有时按 keywordless 处理（素材库里已有 mirror/gift/keywordless/…）：
    游戏里无流派饰品的说明就不再出现任何状态／伤害类型词（Run 439 的 Rusty Commemorative Coin 就是这种）。
    """
    text = _region_text(ctx, DESCRIPTION_REGION)
    if not text or NAME_PLACEHOLDER in text:
        return ""
    status = {value for word, value in STATUS_WORDS.items() if word in text}
    if len(status) == 1:
        return status.pop()
    if status:
        ctx.log(f"说明文字里出现多个状态词 {sorted(status)}，流派不唯一", level="warning")
        return ""
    damage = {value for word, value in DAMAGE_WORDS.items() if word in text}
    if len(damage) == 1:
        return damage.pop()
    if damage:
        ctx.log(f"说明文字里出现多个伤害类型词 {sorted(damage)}，流派不唯一", level="warning")
        return ""
    ctx.log("说明文字里没有任何流派词，按无流派（keywordless）处理")
    return "keywordless"


@step
def execute(
    ctx: RunContext,
    *,
    row: int = 0,
    col: int = 0,
    cx: int = 0,
    cy: int = 0,
    handled: str = "",
    dry_run: bool = False,
) -> dict[str, str]:
    """
    处理一个格子：点击前先暂存整卡裁剪 → 点一次格子中心 → 读名字 → 判流派 → 保存素材。
    row/col 只用于日志（1 起，按行从上到下、行内从左到右）；cx/cy 是上层算出的标称卡片中心，
    实际裁剪矩形与点击中心以角标倒推结果为准（倒推不到时才用标称矩形）。
    handled 是本次自维护已处理过的饰品名，多个名字用 | 分隔；命中即按空格子处理（点空格子不会改变选中项）。
    dry_run=True 时只记录会保存成什么名字，不写素材库（也不再维护任何页面图鉴资源）。
    返回 status 与名称、流派或素材引用。unchanged 表示点选前后标题相同，丢弃可能带高亮的裁剪。
    """
    if not isinstance(cx, int) or not isinstance(cy, int) or cx <= 0 or cy <= 0:
        raise ValueError("cx、cy 必须是卡片点击中心的正整数坐标")
    label = f"第{row}行第{col}列（中心 {cx},{cy}）"
    handled_names = {
        _norm(name) for name in str(handled or "").split("|") if str(name).strip()
    }
    nominal = _nominal_card(cx, cy)

    # ① 点击前先截一帧，用卡片框左下角的角标倒推整卡矩形，再暂存裁剪（正常情况下还没有选中高亮）；
    #    同时读一次左侧名字横幅，记下这一击之前的选中项，用来判断点击是否真的换了选中项
    ctx.action("observe.capture_screen")
    before_name = _gift_name(ctx)
    ctx.log(f"{label}：点击前左侧名字横幅是 {before_name or '(空／未选中)'}")
    card, note = _card_by_corner(ctx, nominal)
    corner_found = card is not None
    if card is None:
        # 没角标既可能是空格子（正常），也可能是角标被高光／遮挡破坏；先按 info 退回标称网格，
        # 点完读到名字再决定是否升级成 warning，避免空槽位把日志刷成告警。
        card = nominal
        ctx.log(
            f"{label}：{note}，先按标称网格整卡裁剪 {_fmt(card)}"
            "（空格子没有角标属正常，点击后再按左侧名字判空）",
            level="info",
        )
    else:
        ctx.log(
            f"{label}：{note} → 整卡裁剪 {_fmt(card)}"
            f"（相对标称 dx={card['x'] - nominal['x']}, dy={card['y'] - nominal['y']}）"
        )
    center = (card["x"] + card["width"] // 2, card["y"] + card["height"] // 2)
    crop_id = ctx.action("observe.stage_asset_crop", region=card)
    ctx.log(f"{label}：暂存点击前的整卡裁剪 {_fmt(card)}，准备点击中心 {center}")

    # ② 点一次倒推出来的卡片中心（只选中，不售卖；弹窗里的选中状态无法撤回，所以一格只点一次）
    ctx.action("control.click", centerxy=center)
    ctx.action("observe.wait", seconds=CLICK_SETTLE_SECONDS)
    ctx.action("observe.capture_screen")

    # ③ 读左侧名字横幅，过滤纯数字价格与未选中状态
    name = _gift_name(ctx)
    if not name:
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(f"{label}：左侧没有读到饰品名（空格子或未选中），丢弃暂存裁剪")
        return {"status": "empty"}
    if before_name and _norm(name) == _norm(before_name):
        # 点击前后名字完全相同：这一击没有换选中项——点空格子不会改变它，本来就处于选中态的卡片也不会。
        # 这类格的裁剪可能是选中高亮态（Run 472 的 Perversion 就是这样存成了同名第二张图），一律不保存。
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(
            f"{label}：点击前后左侧名字都是 {name}，说明这一击没有换选中项"
            "（空格子，或该卡本来就是选中态、裁剪带选中高亮），丢弃暂存裁剪、不写素材库"
        )
        return {"status": "unchanged", "name": name}
    if _norm(name) in handled_names:
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(f"{label}：左侧仍是已处理过的 {name}，按空格子处理，丢弃暂存裁剪")
        return {"status": "duplicate", "name": name}

    # 角标没命中却真的点开了饰品：说明角标在该格失效（选中高光、遮挡或模板漂移），裁剪来自标称网格
    if not corner_found:
        ctx.log(
            f"{label}：角标 {CORNER_ASSET} 在该格没命中，但点开后读到饰品 {name}——"
            "角标检测在这种情形下失效了（可能被选中高光、遮挡或位置漂移破坏），"
            "本次整卡裁剪取自标称网格，需要按现场补测",
            level="warning",
            screenshot=True,
        )

    # ④ 先解析图鉴里已有的同名目录，再判流派：已有目录时不需要流派也能补图
    gifts = _mirror_gifts(ctx)
    match = _find_gift(gifts, name)
    if match is None:
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(f"{label}：名字 {name} 在素材库镜像里命中多个目录，跳过收录", level="warning")
        return {"status": "name_conflict", "name": name}
    gift_id = match
    keyword = _keyword_by_icon(ctx)
    source = "图标"
    if not keyword:
        keyword = _keyword_by_description(ctx)
        source = "说明文字"
    if not keyword and not gift_id:
        # 新饰品必须先知道流派才能建目录；已有同名目录时下面会直接在原目录补图
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(
            f"{label}：饰品 {name} 的流派识别失败（图标与说明文字都没给出唯一流派），"
            "图鉴里也没有同名目录，无法确定保存目录，跳过收录",
            level="warning",
            screenshot=True,
        )
        return {"status": "keyword_unknown", "name": name}
    slug = _slug(name)
    if not name.isascii():
        ctx.log(
            f"{label}：饰品名 {name!r} 不是 ASCII，只能存成哈希目录名 {slug}，"
            "商店无法按名字匹配这件饰品（匹配只认素材目录名）",
            level="warning",
        )
    if gift_id:
        # 已有同名目录：一律在原有逻辑名下追加一张裁剪，无论本次流派识别结果如何都不新建第二条记录，
        # 否则同一件饰品会在「饰品配置」里出现两条，并影响商店按流派判断买不买
        asset = gift_id
        if not keyword:
            ctx.log(
                f"{label}：饰品 {name} 的流派识别失败，但图鉴里已有目录 {gift_id}，"
                "仍按已有目录补一张裁剪（不再因流派识别失败跳过）"
            )
        elif _archive(gift_id) != keyword:
            ctx.log(
                f"{label}：饰品 {name} 已有目录 {gift_id}，本次识别流派 {keyword} 与之不同，"
                f"仍在原目录补图（不新建 {GIFT_ROOT}/{keyword}/{slug}），"
                "避免同名饰品出现两条图鉴记录；需要改流派时请手动调整目录",
                level="warning",
            )
    else:
        # 图鉴里还没有这件饰品：用本次识别到的流派建目录
        asset = f"{GIFT_ROOT}/{keyword}/{slug}"
    # 目录名就是匹配用的名字，不能指向另一条记录。
    leaf = asset.rsplit("/", 1)[-1]
    leaf_owner = [
        key for key in gifts
        if key != asset and key.rsplit("/", 1)[-1] == leaf
    ]
    if leaf_owner:
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(f"{label}：目录名 {leaf} 已被 {leaf_owner} 占用，跳过收录", level="warning")
        return {"status": "name_conflict", "name": name}
    if dry_run:
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(
            f"{label}：饰品 {name} 判为 {keyword or '未识别'}（来源{source}），演练模式不保存"
            f"（正式运行会存成 {asset}）",
            level="info",
            screenshot=True,
        )
        return {"status": "dry_run", "name": name, "keyword": keyword, "asset": asset}

    # ⑤ 用点击前的干净裁剪保存；同名同哈希时复用已有图片
    saved = ctx.action("observe.save_asset_crop", crop_id=crop_id, asset=asset)
    ctx.log(
        f"{label}：饰品 {name} 判为 {keyword or '未识别'}（来源{source}），已保存素材 {asset}"
        f"（sha256 {saved.get('sha256')}）",
        level="info",
    )
    # 配置镜像里还没有这条记录：说明页面还没按素材目录重建，把它记进本次 Run 的临时字典，
    # 让融合耗材名单等后续步骤也能用上（配置里已有的饰品不需要再记）
    if asset not in gifts:
        _record_new_gift(ctx, asset, f"sell_gift_maintain:{source}")
    return {"status": "saved", "name": name, "keyword": keyword, "asset": asset}
