"""镜牢主题包子流程：先等页面动画，做法自维护收录，再按选择偏好的优先级下拉选择主题包。

开发者要求的流程：
1. 一进入主题包页面先等 1 秒，之后每次正式做整组匹配前统一再等 4 秒（第一次进入共 5 秒），
   等待结束后截一张 info 级别的稳定截图，然后才开始识别；刷新后同样由这 4 秒兜住
   新主题包淡入与网络加载，不依赖外层通用等待是否命中，保证至少等满 4 秒。
   这 4 秒之后、整组匹配之前再补一次通用检测（step.detect_normal_transition）：
   加载中先等 step.wait_normal_transition 再回到顶部重新等满 4 秒，
   Server Error 则抛 server_error_popup 交恢复规则，不拿过渡帧做整组匹配。
   每轮的稳定截图都带 info 日志（含刷新后的第 2、3… 轮），
   便于按轮对照刷新前后的实际卡片名单；
2. 先用 mirror/theme_pack_detail（每张卡片右上角的放大镜）找出这一页的卡片，
   再用 mirror/theme_pack 对已收录模板做整组匹配（不传阈值，用默认 0.9）认出已收录的主题包；
   命中中心落在这张卡片的相对窗口内就算同一张卡片（模板就是从详情图标下方裁出来的，
   两者在同一张卡片上的相对位置固定）；
3. 认不出来的卡片就是还没收录的主题包：在开始这次观察的同一帧里，把每张未收录卡片的详情图标
   下方 150x240 封面全部预剪切好（observe.stage_asset_crop），再逐张调
   step.mirror_theme_pack_collect 点详情、读弹窗顶部标题、用预剪好的裁剪存成
   mirror/theme_pack/<名字>（与商店饰品自维护同一套做法：先剪素材，再一个个收录名字）；
   新收录的主题包一律按「默认选择」等级的偏好处理（页面按素材目录派生列表，偏好缺失即默认）；
   收录完不再重新截图观察：特殊交互会让主题包边缘高光常驻，重新匹配达不到默认阈值，
   所以直接用本帧已经识别到的卡片信息继续分类与选择；
4. 只要出现「优先选择」就点它并向下拉完成选择；
   没有「优先选择」时继续刷新：每轮点一次右上角 Refresh 后不再单独等待，直接回到循环顶部，
   由整组匹配前统一的 4 秒覆盖新主题包淡入与网络加载（616 日志：刷新后只等 1 秒就截图，
   那一帧只画出左边一张卡，按这份残缺名单把 avoid 的 the_wedge_in_the_wake_of_dawnbreak
   下拉了，而画全的稳定帧里其实有 prefer 的 Addicting Lust），
   判断 Refresh 是否还可用之前先补一张干净截图（收录步骤留下的当前帧还压着详情弹窗的暗幕，
   灰按钮被压暗后达不到默认阈值，会把「已经不能刷新」误判成「还能刷新」），
   直到模板 mirror/theme_pack_no_refresh 命中（Refresh 已经不可用）才停止刷新，
   然后按 默认选择 → 尽量不选 的顺序挑一个下拉；整页一个主题包都认不出来时退回旧做法
   （直接下拉最左边卡片），保证镜牢还能继续推进，只是这一次不按偏好选；
5. 下拉后固定等待并重新截图：出现火车头或已经不在主题包页就返回 completed，
   真正进了哪一页由 task.mirror 的整屏情景分派重新判定，本层不猜测。
"""
import re

from lalc import ExecutionFailure, RunContext, sub_workflow

TRAIN_HEAD_ASSET = "mirror/train_head"
# 主题包选择页标题 SELECT FLOOR n THEME PACK（1280x720）
HEADER_REGION = {"x": 470, "y": 92, "width": 340, "height": 56}
# 每张卡片右上角的放大镜（详情）图标；按开发者要求整屏匹配，不再限定卡片带区域
DETAIL_ASSET = "mirror/theme_pack_detail"
# 已收录主题包的模板组：模板都放在 mirror/theme_pack/<名字>，整组匹配用默认阈值 0.9
PACK_GROUP = "mirror/theme_pack"
# 主题包封面模板尺寸（开发者要求：详情图标下方 150x240）；预剪切的裁剪几何只在子流程这一处定义
CROP_WIDTH = 150
CROP_HEIGHT = 240
# Refresh 已经不可用的按钮状态模板（灰色 Refresh 按钮，143x28），只在右上角按钮带里匹配
NO_REFRESH_ASSET = "mirror/theme_pack_no_refresh"
NO_REFRESH_REGION = {"x": 960, "y": 10, "width": 240, "height": 80}
# 固定等待（开发者要求：刚进入主题包页先等 1 秒，之后每次正式做整组匹配前统一再等 4 秒：
# 第一次进入共 5 秒；刷新后不做单独等待，同样由这 4 秒覆盖新主题包淡入与网络加载，
# 不管外层通用等待有没有命中，本子流程都保证至少等满 4 秒再截图识别）
ENTRY_SETTLE_SECONDS = 1.0
MATCH_SETTLE_SECONDS = 4.0
# 下拉之后的固定等待：选择行为会开始加载下一层
PULL_SETTLE_SECONDS = 1.5
# 已收录模板命中中心相对详情图标中心的窗口（模板裁自图标下方右对齐，实测 dx≈-56、dy≈+130）：
# 命中中心落在这个窗口里就算同一张卡片
CARD_DX_MIN = -170
CARD_DX_MAX = 60
CARD_DY_MIN = -40
CARD_DY_MAX = 420
# 选择偏好与镜牢设置页「主题包」一致：settings.mirror.settings.theme_packs.preferences
MIRROR_PAGE_ID = "mirror.settings"
THEME_PACKS_KEY = "theme_packs"
PREFERENCES_KEY = "preferences"
PREFERENCE_PREFER = "prefer"
PREFERENCE_DEFAULT = "default"
PREFERENCE_AVOID = "avoid"
PREFERENCE_VALUES = (PREFERENCE_PREFER, PREFERENCE_DEFAULT, PREFERENCE_AVOID)
# 难度选择与镜牢设置页（总览顶部）同一份配置：settings.mirror.settings.difficulty，取值 normal／hard。
# 主题包选择页右上角的难度标签就是当前游戏难度（///NORMAL 或 ///HARD），
# 与这里不一致时先点一次难度胶囊的箭头切换，再按本页流程收录与选择主题包。
DIFFICULTY_KEY = "difficulty"
DIFFICULTY_NORMAL = "normal"
DIFFICULTY_HARD = "hard"
# 难度模板没命中时的重试次数（页面淡入时标签可能还没出现；重试只观察，不点按钮）
DIFFICULTY_ATTEMPTS = 2
DIFFICULTY_RETRY_SECONDS = 1.0
# 有界预算：一页通常三张卡片，收录 + 刷新 + 选择各留余量；
# 刷新不再限一次：没有「优先选择」就继续刷新，直到 mirror/theme_pack_no_refresh 命中，
# MAX_REFRESH 只是模板漏识别时防止无限刷新的兜底上限
MAX_ROUNDS = 18
MAX_COLLECT = 9
MAX_REFRESH = 6
# 同一个详情图标中心在这个像素容差内算同一张卡片（两套模板与动画前后会差几个像素）
HANDLED_TOLERANCE = 14


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _theme_page(ctx: RunContext) -> bool:
    """主题包选择页特征：标题区域同时读到 SELECT FLOOR 与 THEME PACK。"""
    header = _region_text(ctx, HEADER_REGION)
    return "selectfloor" in header and "themepack" in header


def _details(ctx: RunContext) -> list:
    """整屏匹配详情图标（放大镜）命中，按中心 x 从左到右排序。"""
    hits = ctx.action("observe.match_asset", asset=DETAIL_ASSET) or []
    return sorted(hits, key=lambda hit: int((hit.get("centerxy") or (0, 0))[0]))


def _known(ctx: RunContext) -> list:
    """对当前帧做一次 mirror/theme_pack 整组匹配（默认阈值 0.9）。"""
    return ctx.action("observe.match_asset_group", group=PACK_GROUP) or []


def _crop_region(detail: dict) -> dict[str, int]:
    """详情图标下方 150x240 的封面矩形：右边缘对齐图标右边缘，顶边紧贴图标底边。"""
    left = int(detail.get("x") or 0) + int(detail.get("width") or 0) - CROP_WIDTH
    top = int(detail.get("y") or 0) + int(detail.get("height") or 0)
    return {"x": left, "y": top, "width": CROP_WIDTH, "height": CROP_HEIGHT}


def _is_handled(detail: dict, handled: list) -> bool:
    """这张卡片的详情图标中心是否已经点过（容差内算同一张，避免图标漂几像素就重复点）。"""
    center = detail.get("centerxy") or (0, 0)
    x, y = int(center[0]), int(center[1])
    return any(
        abs(x - px) <= HANDLED_TOLERANCE and abs(y - py) <= HANDLED_TOLERANCE
        for px, py in handled
    )


def _remember(detail: dict, handled: list) -> None:
    """记下已经点过的卡片中心，供下一轮跳过。"""
    center = detail.get("centerxy") or (0, 0)
    handled.append((int(center[0]), int(center[1])))


def _matches_card(hit: dict, detail: dict) -> bool:
    """已收录模板的命中中心是否落在这张卡片上（相对详情图标的固定窗口）。"""
    detail_center = detail.get("centerxy") or (0, 0)
    hit_center = hit.get("centerxy") or (0, 0)
    dx = int(hit_center[0]) - int(detail_center[0])
    dy = int(hit_center[1]) - int(detail_center[1])
    return CARD_DX_MIN <= dx <= CARD_DX_MAX and CARD_DY_MIN <= dy <= CARD_DY_MAX


def _preferences(ctx: RunContext) -> dict:
    """页面配置里的主题包偏好：键是素材逻辑名 mirror/theme_pack/<名字>，值 prefer／default／avoid。"""
    settings = ctx.run_state.settings
    page = settings.get(MIRROR_PAGE_ID) if isinstance(settings, dict) else None
    packs = page.get(THEME_PACKS_KEY) if isinstance(page, dict) else None
    raw = packs.get(PREFERENCES_KEY) if isinstance(packs, dict) else None
    if not isinstance(raw, dict):
        return {}
    return {
        str(name): str(value) for name, value in raw.items()
        if str(value) in PREFERENCE_VALUES
    }


def _preference(prefs: dict, asset: str) -> str:
    """素材对应的偏好；配置里没有这个名字（例如刚收录进素材库）时按默认选择处理。"""
    return prefs.get(asset, PREFERENCE_DEFAULT)


def _difficulty(ctx: RunContext) -> str:
    """页面总览顶部选择的镜牢难度；缺失或非法值按普通处理（与页面默认值一致）。"""
    settings = ctx.run_state.settings
    page = settings.get(MIRROR_PAGE_ID) if isinstance(settings, dict) else None
    raw = page.get(DIFFICULTY_KEY) if isinstance(page, dict) else None
    return DIFFICULTY_HARD if str(raw).strip().lower() == DIFFICULTY_HARD else DIFFICULTY_NORMAL


def _ensure_difficulty(ctx: RunContext) -> dict[str, str]:
    """
    确认主题包页右上角的难度与页面选择一致：模板没命中时只重试观察，不重复点箭头；
    切换由 step.mirror_theme_difficulty 自己做一次并复验，结果在这里记日志后交回本流程。
    """
    wanted = _difficulty(ctx)
    result: dict[str, str] = {}
    for attempt in range(1, DIFFICULTY_ATTEMPTS + 1):
        result = ctx.call("step.mirror_theme_difficulty") or {}
        status = str(result.get("status") or "")
        if status in ("already", "switched", "not_page"):
            break
        if attempt < DIFFICULTY_ATTEMPTS:
            ctx.log(
                f"第{attempt}次难度核对没有确认状态（{status}），等 {DIFFICULTY_RETRY_SECONDS} 秒"
                "重新观察后再核对，不重复点箭头"
            )
            ctx.action("observe.wait", seconds=DIFFICULTY_RETRY_SECONDS)
            ctx.action("observe.capture_screen")
    status = str(result.get("status") or "")
    if status == "switched":
        ctx.log(
            f"已按设置页把镜牢难度切换为 {wanted}（点了一次难度胶囊箭头并复验通过）；"
            "切换会重新加载本层可选主题包，仍由循环顶部统一的稳定等待兜住"
        )
    elif status == "already":
        ctx.log(f"镜牢难度已与设置页一致（{wanted}），不点难度箭头")
    else:
        ctx.log(
            f"难度没有确认到设置页选择的 {wanted}（{status}），本次按当前画面继续选择主题包",
            level="warning",
            screenshot=True,
        )
    return result


def _cards(ctx: RunContext, details: list, known: list, prefs: dict) -> list:
    """
    把这一页的卡片配成 [{index, detail, asset, preference, center}]：
    asset 为空串表示还没收录；center 是已收录模板的命中中心（用来算下拉起点）。
    """
    cards = []
    for index, detail in enumerate(details, start=1):
        match = None
        for hit in known:
            if not _matches_card(hit, detail):
                continue
            if match is None or float(hit.get("score") or 0.0) > float(match.get("score") or 0.0):
                match = hit
        if match is None:
            cards.append(
                {"index": index, "detail": detail, "asset": "", "preference": "", "center": None}
            )
            continue
        asset = str(match.get("logical_name") or "")
        cards.append(
            {
                "index": index,
                "detail": detail,
                "asset": asset,
                "preference": _preference(prefs, asset),
                "center": match.get("centerxy"),
            }
        )
    return cards


def _pull(ctx: RunContext, card: dict, reason: str) -> dict[str, str | bool]:
    """
    下拉一张卡片完成选择：起点优先用已收录模板的命中中心（裁出来的封面中心，必然落在卡片主体上），
    没认出来的卡片退回「详情图标左下方」的标称卡片中心。下拉后固定等 1.5 秒再截图：
    出现火车头或已经不在主题包页就算完成；仍停在主题包页则记 warning 交回上层重新处理。
    """
    center = card.get("center")
    if not center:
        detail_center = card["detail"].get("centerxy") or (0, 0)
        center = (int(detail_center[0]) - 40, int(detail_center[1]) + 130)
    ctx.log(
        f"下拉主题包完成选择（{reason}）：{card.get('asset') or '未收录卡片'}，"
        f"偏好 {card.get('preference') or PREFERENCE_DEFAULT}，卡片主体起点 "
        f"({int(center[0])}, {int(center[1])})"
    )
    ctx.call(
        "step.mirror_theme_pack_select",
        pack_x=int(center[0]),
        pack_y=int(center[1]),
    )
    ctx.action("observe.wait", seconds=PULL_SETTLE_SECONDS)
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=TRAIN_HEAD_ASSET):
        return {"completed": True, "reason": f"pulled_{reason}", "page": "path"}
    if not _theme_page(ctx):
        return {"completed": True, "reason": f"pulled_{reason}_loading", "page": "loading"}
    ctx.log(
        "下拉后仍停在主题包页，这一下拉可能没生效，交回上层重新观察后再处理",
        level="warning",
        screenshot=True,
    )
    return {"completed": False, "reason": "pull_not_effective", "page": "themepack"}


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    按开发者要求的顺序推进：进入先等 1 秒 → 整组匹配前统一等 2 秒 → 收录未入库主题包 →
    有优先选择就选它 → 否则点一次 Refresh，刷新后不再单独等待，回到循环顶部再等那 3 秒
    → 按 优先 → 默认 → 尽量不选 选一个下拉。
    每次只做一次动作，动作后回到循环顶部重新截图观察；预算耗尽抛 workflow_rounds_exhausted。
    """
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=TRAIN_HEAD_ASSET):
        ctx.log("已在镜牢寻路页面，无需再选择主题包")
        return {"completed": True, "reason": "already_path", "page": "path"}
    if not _theme_page(ctx):
        ctx.log("当前不是镜牢主题包选择页，不执行主题包选择", level="warning", screenshot=True)
        return {"completed": False, "reason": "not_theme_page", "page": "unknown"}
    ctx.log(
        f"进入镜牢主题包页，先等 {ENTRY_SETTLE_SECONDS} 秒；之后每次正式做整组匹配前统一再等 "
        f"{MATCH_SETTLE_SECONDS} 秒，第一次进入共 "
        f"{ENTRY_SETTLE_SECONDS + MATCH_SETTLE_SECONDS} 秒；刷新后不再单独等待，"
        f"同样由这 {MATCH_SETTLE_SECONDS} 秒兜住新主题包淡入与网络加载"
    )
    ctx.action("observe.wait", seconds=ENTRY_SETTLE_SECONDS)
    # 难度核对排在收录与选择之前：设置页选择 Normal／Hard，画面右上角的 ///NORMAL／///HARD
    # 与之不一致时先点一次难度胶囊箭头切换，后面的整组匹配才是切换后的主题包名单
    _ensure_difficulty(ctx)

    prefs = _preferences(ctx)
    # 本次调用已经点过详情的卡片中心：无论收录成功与否都不再重复点，避免同一张卡片反复收录
    handled: list = []
    collected = 0
    refreshes = 0

    for round_index in range(1, MAX_ROUNDS + 1):
        # 开发者要求：正式做整组匹配前统一等 MATCH_SETTLE_SECONDS（4 秒）再截图。
        # 第一次进入配合 ENTRY_SETTLE_SECONDS 共 5 秒；刷新后不做单独等待，
        # 这一等同样覆盖新主题包淡入与网络加载，不依赖外层通用等待是否命中
        # （616 日志就是刷新后只等 1 秒就截图，把只画出一张卡的过渡帧当成了整页名单）
        ctx.action("observe.wait", seconds=MATCH_SETTLE_SECONDS)
        meta = ctx.action("observe.capture_screen")
        # 开发者要求：每一轮稳定后的截图都打 info 日志，刷新后的第 2、3… 轮也要有，
        # 不能只有第一轮有截图（否则刷新后的实际卡片名单无法按轮对照）
        if round_index == 1:
            ctx.log(
                f"整组匹配前统一等 {MATCH_SETTLE_SECONDS} 秒结束（连同进入时的 "
                f"{ENTRY_SETTLE_SECONDS} 秒共 "
                f"{ENTRY_SETTLE_SECONDS + MATCH_SETTLE_SECONDS} 秒），附稳定后的截图",
                level="info",
                screenshot=True,
            )
        else:
            ctx.log(
                f"第{round_index}轮：整组匹配前统一等 {MATCH_SETTLE_SECONDS} 秒结束"
                "（刷新后不单独等待），附稳定后的截图",
                level="info",
                screenshot=True,
            )
        # 整组匹配前先确认画面不在加载／联网过渡中：4 秒稳定等待保持不变，
        # 这里只补一次通用检测——Server Error 直接抛 server_error_popup 交恢复规则，
        # 加载中则先等待，再回到循环顶部重新等满 4 秒，不拿过渡帧做整组匹配或判定已离开本页。
        if ctx.call("step.detect_normal_transition", width=meta["width"], height=meta["height"]):
            ctx.log(
                f"第{round_index}轮：整组匹配前检测到加载／联网过渡，先通用等待，"
                f"再回到顶部重新等满 {MATCH_SETTLE_SECONDS} 秒后识别"
            )
            ctx.call("step.wait_normal_transition")
            continue
        if ctx.action("observe.match_asset", asset=TRAIN_HEAD_ASSET):
            ctx.log(f"第{round_index}轮：画面里已有火车头，说明主题包已选好、进入寻路页")
            return {"completed": True, "reason": "path_visible", "page": "path"}
        if not _theme_page(ctx):
            ctx.log(f"第{round_index}轮：已不在主题包页（多半正在加载下一层），交回上层重新观察")
            return {"completed": True, "reason": "left_theme_page", "page": "left"}
        details = _details(ctx)
        if not details:
            ctx.log(
                "主题包页里一张卡片的详情图标都没匹配到（可能停在详情弹窗上或页面还在切换），"
                "无法继续收录与选择，交回上层重新观察",
                level="warning",
                screenshot=True,
            )
            return {"completed": False, "reason": "detail_missing", "page": "themepack"}
        cards = _cards(ctx, details, _known(ctx), prefs)
        unknown = [
            card for card in cards
            if not card["asset"] and not _is_handled(card["detail"], handled)
        ]
        remaining = MAX_COLLECT - collected
        if unknown and remaining > 0:
            # 开发者要求：先基于这一帧把没收录的封面全部预剪切好，再逐张点详情看名字收录
            unknown = unknown[:remaining]
            staged = []
            for card in unknown:
                region = _crop_region(card["detail"])
                crop_id = ctx.action("observe.stage_asset_crop", region=region)
                detail_center = card["detail"].get("centerxy") or (0, 0)
                _remember(card["detail"], handled)
                staged.append((card, crop_id, detail_center, region))
            positions = [
                f"第{card['index']}张@({int(center[0])},{int(center[1])}) "
                f"裁剪 ({region['x']},{region['y']},{region['width']}x{region['height']})"
                for card, _crop_id, center, region in staged
            ]
            ctx.log(
                f"第{round_index}轮：本帧有 {len(staged)} 张未收录卡片，先按详情图标下方 "
                f"{CROP_WIDTH}x{CROP_HEIGHT} 预剪切好封面，再逐张点详情读标题收录："
                + "；".join(positions)
            )
            for card, crop_id, detail_center, _region in staged:
                collected += 1
                result = ctx.call(
                    "step.mirror_theme_pack_collect",
                    detail_cx=int(detail_center[0]),
                    detail_cy=int(detail_center[1]),
                    crop_id=str(crop_id),
                    index=int(card["index"]),
                ) or {}
                status = str(result.get("status") or "")
                if status == "collected":
                    # 特殊交互会让主题包边缘高光常驻：收录后不再重新截图匹配，
                    # 直接把本帧这张卡片补成刚收录的素材（新收录按默认选择处理）
                    asset = str(result.get("asset") or "")
                    card["asset"] = asset
                    card["preference"] = _preference(prefs, asset)
                    card["center"] = None
                    ctx.log(
                        f"第{card['index']}张主题包卡片已收录 {result.get('name')} → "
                        f"素材 {asset}（按默认选择等级的偏好处理）"
                    )
                elif status == "missing_detail":
                    ctx.log(
                        f"第{card['index']}张卡片的详情图标复验时没匹配到，跳过",
                        level="warning",
                    )
                else:
                    ctx.log(
                        f"第{card['index']}张卡片的详情弹窗没读到主题包名（{status}），"
                        "本次不收录，已丢弃预剪切的封面",
                        level="warning",
                        screenshot=True,
                    )
            ctx.log(
                f"本轮预剪切的 {len(staged)} 张卡片处理完（累计收录 {collected} 张）；"
                "按开发者要求不再重新观察这一页（主题包边缘高光会常驻），"
                "直接用本帧信息继续按偏好选择"
            )

        known_cards = [card for card in cards if card["asset"]]
        if not known_cards:
            ctx.log(
                "这一页一个已收录的主题包都没认出来（收录都没成功）：退回旧做法，"
                "直接下拉最左边卡片，本次不按偏好选择",
                level="warning",
                screenshot=True,
            )
            return _pull(ctx, cards[0], "leftmost_fallback")

        prefers = [
            card for card in known_cards if card["preference"] == PREFERENCE_PREFER
        ]
        if prefers:
            return _pull(ctx, prefers[0], PREFERENCE_PREFER)
        # 开发者要求：没有「优先选择」时不再限刷一次，就一直刷新，
        # 直到模板 mirror/theme_pack_no_refresh 命中（Refresh 按钮已经不可用）才停止刷新。
        # 判断前必须单独补一张截图：本轮的收录（step.mirror_theme_pack_collect）会点开详情弹窗、
        # 按 Esc 关掉后直接返回，当前帧还停在弹窗压着页面暗幕的那一张，灰掉的 Refresh 按钮被压暗后
        # 达不到默认阈值，就会把「已经不能刷新」误判成「还能刷新」而继续空点 Refresh
        # （550 日志第 2、3 轮就是这样多点了两次无效刷新）。这里只读右上角按钮带，
        # 不重新匹配主题包封面（收录后卡片边缘高光会常驻）。
        ctx.action("observe.capture_screen")
        no_refresh = bool(
            ctx.action(
                "observe.match_asset",
                asset=NO_REFRESH_ASSET,
                region=NO_REFRESH_REGION,
            )
        )
        summary = [(card["asset"], card["preference"]) for card in known_cards]
        if not no_refresh and refreshes < MAX_REFRESH:
            refreshes += 1
            ctx.log(
                f"第{round_index}轮：可选主题包 {summary} 里没有「优先选择」，也没有匹配到 "
                f"{NO_REFRESH_ASSET}：第 {refreshes}/{MAX_REFRESH} 次点右上角 Refresh 重掷本层主题包"
            )
            result = ctx.call("step.mirror_theme_pack_refresh") or {}
            if str(result.get("status") or "") == "refreshed":
                ctx.log(
                    "Refresh 已点下，刷新后不再单独等待：回到循环顶部，由整组匹配前统一的 "
                    f"{MATCH_SETTLE_SECONDS} 秒覆盖新主题包淡入与网络加载，再按 "
                    "优先 → 默认 → 尽量不选 的顺序判断"
                )
                handled.clear()
                collected = 0
                continue
            ctx.log(
                f"Refresh 没能点下去（{result.get('status')}），按刷新结束处理，"
                "直接按 默认 → 尽量不选 选择",
                level="warning",
                screenshot=True,
            )
        elif no_refresh:
            ctx.log(
                f"第{round_index}轮：匹配到 {NO_REFRESH_ASSET}（Refresh 已不可用），"
                "停止刷新，按 默认选择 → 尽量不选 选择"
            )
        else:
            ctx.log(
                f"第{round_index}轮：Refresh 已到本次上限 {MAX_REFRESH} 且没匹配到 "
                f"{NO_REFRESH_ASSET}，按刷新结束处理，按 默认 → 尽量不选 选择",
                level="warning",
                screenshot=True,
            )

        chosen = None
        for level in (PREFERENCE_DEFAULT, PREFERENCE_AVOID):
            candidates = [card for card in known_cards if card["preference"] == level]
            if candidates:
                chosen = candidates[0]
                break
        if chosen is None:
            ctx.log(
                "刷新后既没有默认选择也没有尽量不选的主题包，退回直接下拉最左边卡片",
                level="warning",
                screenshot=True,
            )
            return _pull(ctx, known_cards[0], "no_preference_fallback")
        return _pull(ctx, chosen, chosen["preference"])

    raise ExecutionFailure(
        "workflow_rounds_exhausted",
        "主题包页的收录／选择预算耗尽，仍未完成主题包选择",
    )
