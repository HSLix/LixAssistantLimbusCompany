"""退出镜牢寻路界面回到主界面：齿轮 → Dungeon Progress 弹窗的 To Window → Enter，寻路界面标识消失即完成。"""
import re

from lalc import ExecutionFailure, RunContext, sub_workflow

# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上就算寻路界面
PATH_ICON_ASSETS = ("mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects")
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2
# Dungeon Progress 弹窗：标题是弹窗独有文案；点齿轮与 To Window 的动作都在 Step 里执行
POPUP_REGION = {"x": 350, "y": 165, "width": 580, "height": 400}
POPUP_KEYWORD = "dungeonprogress"
# 主界面标识：底部导航 Drive 图标或 Window 页图标
MAIN_ASSETS = ("main_navigate/drive", "main_navigate/window", "main_navigate/window_selected")
MAX_ROUNDS = 20


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响弹窗标题与按钮文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮区域文字判断都从这份结果里过滤。"""
    return list((ctx.action("observe.ocr") or {}).get("items") or [])


def _texts(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，返回规范化小写文本；不刷新截图。"""
    left = int(region["x"])
    top = int(region["y"])
    right = left + int(region["width"])
    bottom = top + int(region["height"])
    parts: list[str] = []
    for item in items:
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if left <= x <= right and top <= y <= bottom:
            text = str(item.get("text", ""))
            if text:
                parts.append(text)
    return _norm(" ".join(parts))


def _icons(ctx: RunContext) -> int:
    """对当前帧右上角匹配三个按钮素材，返回命中数量；不刷新截图。"""
    return sum(
        1
        for asset in PATH_ICON_ASSETS
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )


def _main_page(ctx: RunContext) -> str:
    """对当前帧检测主界面图标，命中返回 main，否则返回空字符串。"""
    for asset in MAIN_ASSETS:
        if ctx.action("observe.match_asset", asset=asset):
            return "main"
    return ""


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    进入标识：寻路界面标识成立（右上角按钮命中 ≥2 个）且没有火车头，由寻路流程判定寻路失败后交 Task 调用。
    流程：step.mirror_exit_open_settings（点齿轮并确认 Dungeon Progress 弹窗）→
    step.mirror_exit_leave_path（点 To Window 固定坐标、按 Enter、确认离开寻路界面）。
    停止信号：寻路界面标识消失且 Dungeon Progress 弹窗不在，直接返回上层主循环，由 Task 重新分派。
    同一分支连续第四次命中或总轮数耗尽时失败。
    """
    started = False
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, MAX_ROUNDS + 1):
        meta = ctx.action("observe.capture_screen")
        # 每轮只做一次整屏 OCR：弹窗标题等文字判据都从这份结果里按区域过滤，不再逐区域识别
        items = _screen_items(ctx)
        # 正常加载／联网过渡先于业务分派（Run 637）：过渡帧上寻路按钮与弹窗判据都会抖动，
        # 先分派业务会重复点击或提前判定退出完成；等待后业务分支从 1 重新计数。
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        icons = _icons(ctx)
        popup_open = POPUP_KEYWORD in _texts(items, POPUP_REGION)
        if icons < MIN_PATH_ICONS and not popup_open:
            if started:
                ctx.log("寻路界面标识已消失，退出镜牢流程结束")
                return {"completed": True, "reason": "已离开寻路界面", "page": _main_page(ctx) or "main"}
            ctx.log(
                f"右上角按钮只命中 {icons}/{len(PATH_ICON_ASSETS)} 个，当前不是寻路界面，无需退出",
                level="warning",
                screenshot=True,
            )
            return {"completed": False, "reason": "当前不在寻路界面"}
        started = True
        if popup_open:
            hit("step.mirror_exit_leave_path")
            ctx.log(f"第{round_index}轮：Dungeon Progress 弹窗在，只执行一次 To Window + Enter")
            ctx.call("step.mirror_exit_leave_path")
        else:
            hit("step.mirror_exit_open_settings")
            ctx.log(f"第{round_index}轮：寻路界面在，只执行一次点齿轮")
            ctx.call("step.mirror_exit_open_settings")
        continue
    raise ExecutionFailure("workflow_rounds_exhausted", "退出镜牢流程预算耗尽")

