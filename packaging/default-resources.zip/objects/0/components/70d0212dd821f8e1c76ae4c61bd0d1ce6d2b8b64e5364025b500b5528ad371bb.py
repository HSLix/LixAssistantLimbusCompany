"""镜牢寻路页面：点一次火车头（当前位置标记），是否可直接进入由上层观察。"""
import re

from lalc import RunContext, step

TRAIN_ASSET = "mirror/train_head"
# 火车头只用特征匹配（SIFT）：模板匹配回退已移除，失配即视为找不到火车头
# 点击火车头后的固定等待秒数
AFTER_CLICK_SECONDS = 0.8


@step
def execute(ctx: RunContext) -> None:
    """
    先截图识别火车头（当前位置标记）：未命中时零输入返回，交给上层继续观察；
    命中（多处命中记 warning 并取分数最高的一处）才点一次火车头，等固定 0.8 秒后交回。
    右下角是否出现 Enter 按钮由 sub_workflow.mirror_pathfind 下一轮重新观察，
    本步只做点击，不按 Enter、不拖拽、不判断节点类型。
    """
    ctx.action("observe.capture_screen")
    matches = ctx.action("observe.match_feature", asset=TRAIN_ASSET) or []
    if not matches:
        ctx.log(
            "未检测到火车头（特征匹配无命中，已不再退回模板匹配），不点击，交给上层继续观察",
            level="warning",
            screenshot=True,
        )
        return

    if len(matches) > 1:
        centers = [match.get("centerxy") for match in matches]
        ctx.log(
            f"火车头同时命中{len(matches)}处：{centers}，按最高分命中处理",
            level="warning",
            screenshot=True,
        )
    best = max(matches, key=lambda item: float(item.get("score", 0.0)))
    score = float(best.get("score", 0.0))
    center = best.get("centerxy") or (0, 0)
    center_x = int(center[0])
    center_y = int(center[1])
    ctx.log(
        f"点击一次火车头 ({center_x}, {center_y})，特征匹配识别（内点 {int(score)}），"
        f"等 {AFTER_CLICK_SECONDS} 秒后交回"
    )
    ctx.action("control.click", centerxy=(center_x, center_y))
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
