"""镜牢商店：点击右上角的普通 Refresh 重掷商品列表，以当前持有 Cost 减少确认刷新生效。"""
import re

from lalc import RunContext, step

# 商店页标识（三条判据取或，任一成立就算商店页）：
# ① 右上角普通 Refresh 按钮模板命中；② Keyword Refresh 按钮模板命中；③ 左上角 Shop 标题文字。
# 单个按钮模板在遮挡／动画帧下可能只命中一个，短标题 OCR 也会偶发漏识别，取或后不再要求两个同时命中。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 当前持有 Cost：Shop 标题右侧硬币图标后面的数字，避开右上角刷新按钮自己的价格
COST_REGION = {"x": 540, "y": 100, "width": 120, "height": 60}
# 右上角两个刷新按钮所在区域：靠左的是普通 Refresh，靠右的是 Keyword Refresh。
# 普通 Refresh 直接用素材 mirror/shop/refresh 做模板匹配取按钮中心，不再读 Refresh 文字
REFRESH_BUTTON_ASSET = "mirror/shop/refresh"
REFRESH_BUTTON_REGION = {"x": 920, "y": 95, "width": 300, "height": 90}
REFRESH_BUTTON_THRESHOLD = 0.85
# 模板没命中时的兜底落点（普通刷新按钮中心），只在识别失败时点一次
FALLBACK_REFRESH_POINT = (1014, 138)
# 技能替换弹窗标题：弹窗打开时刷新按钮被挡住，不能盲点。
# 窄区域做局部 OCR 会把长标题断成两段并漏掉两端，因此按整条标题横幅取区域。
SKILL_POPUP_REGION = {"x": 175, "y": 95, "width": 570, "height": 78}
SKILL_POPUP_KEYWORDS = ("replace", "skill")
# 标题 OCR 偶发漏字时的后备判据：弹窗底部的 Cancel／Confirm 按钮在商店页不会同时出现
SKILL_POPUP_ACTION_REGION = {"x": 400, "y": 505, "width": 520, "height": 70}
SKILL_POPUP_ACTION_KEYWORDS = ("cancel", "confirm")
# 点击后的固定等待秒数；刷新生效与否由 sub_workflow.mirror_shop 下一轮重新读 Cost 判断
CLICK_WAIT_SECONDS = 1.5


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _in_shop(ctx: RunContext) -> bool:
    """当前帧是否为镜牢商店页：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题。"""
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


def _popup_open(ctx: RunContext) -> bool:
    """当前帧是否已打开技能替换弹窗（它会盖住右上角刷新按钮）。"""
    text = _region_text(ctx, SKILL_POPUP_REGION)
    if all(word in text for word in SKILL_POPUP_KEYWORDS):
        return True
    actions = _region_text(ctx, SKILL_POPUP_ACTION_REGION)
    return all(word in actions for word in SKILL_POPUP_ACTION_KEYWORDS)


def _cost(ctx: RunContext) -> int | None:
    """读当前持有的 Cost：把硬币右侧的数字按横向顺序拼起来；读不到返回 None。"""
    result = ctx.action("observe.ocr", region=COST_REGION) or {}
    parts: list[tuple[int, str]] = []
    for item in result.get("items") or []:
        digits = re.sub(r"[^0-9]", "", str(item.get("text", "")))
        if digits:
            parts.append((int(item["centerxy"][0]), digits))
    if not parts:
        return None
    parts.sort()
    text = "".join(digits for _, digits in parts)
    return int(text) if text.isdigit() else None


def _refresh_point(ctx: RunContext) -> tuple[int, int] | None:
    """用素材 mirror/shop/refresh 在右上角匹配普通刷新按钮，返回按钮中心；没命中返回 None。"""
    hits = (
        ctx.action(
            "observe.match_asset",
            asset=REFRESH_BUTTON_ASSET,
            region=REFRESH_BUTTON_REGION,
            threshold=REFRESH_BUTTON_THRESHOLD,
        )
        or []
    )
    centers = [
        (int(hit["centerxy"][0]), int(hit["centerxy"][1]))
        for hit in hits
        if hit.get("centerxy")
    ]
    if not centers:
        return None
    centers.sort()
    return centers[0]


@step
def execute(ctx: RunContext) -> None:
    """
    在镜牢商店页点一次右上角的普通 Refresh（两个刷新按钮里靠左的那个）重掷商品列表。
    先截图复查入口：技能替换弹窗仍打开、当前不是商店页、读不到当前 Cost 时都零输入返回，
    不做盲点（弹窗会盖住刷新按钮）。
    点击后只固定等 1.5 秒就交回；是否真的刷新生效由 sub_workflow.mirror_shop
    下一轮重新读 Cost 判断，本步不轮询、不重试。
    清空已处理商品记录由 step.mirror_refresh_shop_state 负责。
    """
    ctx.action("observe.capture_screen")
    if _popup_open(ctx):
        ctx.log("技能替换弹窗仍打开，刷新按钮被挡住，本轮不刷新", level="warning", screenshot=True)
        return
    if not _in_shop(ctx):
        ctx.log("当前不是镜牢商店页，不点击普通 Refresh", level="warning", screenshot=True)
        return

    before = _cost(ctx)
    if before is None:
        ctx.log("没有读到当前持有的 Cost，不做盲点刷新", level="warning", screenshot=True)
        return

    point = _refresh_point(ctx)
    if point is None:
        point = FALLBACK_REFRESH_POINT
        ctx.log(
            f"右上角没有匹配到普通刷新按钮模板 {REFRESH_BUTTON_ASSET}，"
            f"按兜底落点 {point} 点击普通 Refresh",
            level="warning",
        )
    ctx.log(
        f"点击一次普通 Refresh {point}（点击前 Cost={before}），等 {CLICK_WAIT_SECONDS} 秒后交回"
    )
    ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
