"""镜牢商店：遍历技能替换商品，一次调用把一件商品的弹窗推进到成交，再交回上层验收。

点开弹窗前先从商品卡名字（Replace <罪人>'s Skill）读出罪人，本场队伍没有勾选这个罪人的技能替换时
不打开弹窗直接跳过；名字有 OCR 误差时允许最多 MAX_SINNER_EDITS 个字符的模糊匹配（商品一定属于十二罪人之一），
并记 warning。只有需要买时才点开商品卡，用弹窗标题校验罪人后一路推进到成交。

技能替换商品原本只靠价格图标（??）定位，而这个图标是动画帧：模板匹配分数会在阈值附近抖动
（Run 692 同一张 ID Skill Search 卡同一位置从 0.995 掉到不足 0.9，本步只应用到两个已买过的价格图标，
报「没有未处理的新商品」，购买循环于是转去买了饰品）。因此本步同时按商品卡名字行
（Replace <罪人>'s Skill 与 ID Skill Search）识别技能替换商品，名字行反推出的位置与模板命中共用
同一套点击、Purchased 与已处理记录几何。

另外处理 Super Shop 的 ID Skill Search 商品：它的名字里没有罪人，点开后要先用本页底部那排十二个罪人头像的
固定坐标选一个配置了技能替换的罪人，随后的 Replace <罪人>'s Skill 弹窗与普通技能替换完全一致。
按开发者要求，ID Skill Search（index 选人）是最后的兜底：同一帧里只要还有未处理的固定
Replace <罪人>'s Skill 商品，就先处理固定商品，没有固定商品可处理时才用它；
用它选人时按「可技能替换罪人」在本场队伍里的编排顺序（战斗准备页的出战顺序）取第一个
本次商店还没点过、本场镜牢也还没用完的罪人。

已买过的商品会在卡片上方显示 Purchased（价格图标与名字行都还在，但点它不会弹出任何窗口）：扫描商品时
先按这个标签区分已购买与未购买，已买过的只记录位置后跳过，不对它做任何输入。

某个罪人的技能替换也有用完的时候：初始 1 技能 3 个、2 技能 2 个、3 技能 1 个，而技能替换只做
1→2、1→3 或 2→3，源技能的份数被换完后再选这个罪人就会卡在选择页（选项点不动、Confirm 也不推进）。
出现这种卡住时本步把该罪人记进 RunState 的「本场技能替换已用完」记录，
再点一次弹窗底部的 Cancel 关掉弹窗：
ID Skill Search 的这张商品卡撤销处理记录，下一轮按本场队伍顺序改选下一个配置了技能替换的罪人；
普通 Replace <罪人>'s Skill 商品则把该罪人当作没有勾选技能替换，后续不再为它打开弹窗。
该记录只对同一场镜牢有效（plan 在每场镜牢开始时复位）。
"""
import re
import unicodedata

from lalc import RunContext, step

# 技能替换商品的价格图标：命中后点击它正上方的商品卡进入技能替换弹窗
SKILL_ITEM_ASSET = "mirror/shop/question_mark_price"
# 只在商店右侧商品列表里找价格图标，避开左侧 Enhance Gifts 等同样可能显示 ?? 价格的面板
SHOP_ITEM_REGION = {"x": 505, "y": 175, "width": 700, "height": 390}
# 商店页标识（三条判据取或，任一成立就算商店页）：
# ① 右上角普通 Refresh 按钮模板命中；② Keyword Refresh 按钮模板命中；③ 左上角 Shop 标题文字。
# 单个按钮模板在遮挡／动画帧下可能只命中一个，短标题 OCR 也会偶发漏识别，取或后不再要求两个同时命中。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 技能替换弹窗标题 Replace <罪人名>'s Skill：弹窗会盖住商店页，标题是它的唯一入口特征。
# 区域只框住标题铭牌本身（x 175~600）。右边界停在 600：再往右是弹窗框上的 Skills Owned
# 和中间那排 SKILL 1x2／SKILL 2x3／SKILL 3x1 标签（实测起点 x=612、y=129，与标题同一条横幅高度），
# 它们都含 skill 字样，混进标题会让罪人解析读到无关文字。
# 之前用 430x60 的窄区域，实测标题偏长时局部 OCR 会把两端丢掉（只读到 Don + n Quixote's），
# 因此横向按整条铭牌取足够宽度、纵向保留整行高度，让 OCR 有足够上下文识别完整标题。
POPUP_TITLE_REGION = {"x": 175, "y": 95, "width": 425, "height": 80}
POPUP_TITLE_KEYWORDS = ("replace", "skill")
# 标题 OCR 仍漏字时的后备判据：弹窗底部的 Cancel／Confirm 按钮在商店页不会同时出现
POPUP_ACTION_REGION = {"x": 400, "y": 505, "width": 520, "height": 70}
POPUP_ACTION_KEYWORDS = ("cancel", "confirm")
# 局部标题 OCR 不完整时，用整屏 OCR 只取标题铭牌范围内的文本补全标题；
# 右边界同样停在 600，避免把右侧 Skills Owned 与 SKILL nxm 标签所在的 X 区间算进来
FULL_TITLE_X = (175, 600)
FULL_TITLE_Y = (95, 175)
# 宽松解析罪人名的最小长度：太短的名字按字符顺序匹配容易误配
MIN_LOOSE_ALIAS_LENGTH = 5
# 弹窗底部 Cancel／Confirm 按钮的固定坐标
CANCEL_POINT = (523, 542)
CONFIRM_POINT = (814, 542)
# 弹窗里三个替换选项的固定坐标，从左到右依次是 1→2、2→3、1→3，编号与队伍配置页一致
OPTION_POINTS = {1: (315, 340), 2: (637, 340), 3: (970, 340)}
MAX_OPTIONS = 3
# Super Shop 的 ID Skill Search：商品卡名字只写 ID Skill Search（没有罪人），也是一张 ?? 价格图标。
# 点开商品卡后要在商店页底部那排十二个罪人头像里自选一个，点完弹窗就是普通的技能替换弹窗。
# OCR 可能把 ID 丢掉，只按 skillsearch 这一段判断。
ID_SKILL_SEARCH_KEYWORD = "skillsearch"
# 底部十二个罪人头像的固定点击坐标（1280x720 实测中心：一行十二个，间距≈76 像素，中心 y≈652）。
# 顺序与配队页的十二个人像框一致：第一行第一列从左到右，再第二行从左到右，即
# Yi Sang → Faust → Don Quixote → Ryoshu → Meursault → Hong Lu →
# Heathcliff → Ishmael → Rodion → Sinclair → Outis → Gregor。
ID_SKILL_SEARCH_AVATARS = {
    "yi_sang": (100, 652),
    "faust": (176, 652),
    "don_quixote": (252, 652),
    "ryoshu": (329, 652),
    "meursault": (405, 652),
    "hong_lu": (481, 652),
    "heathcliff": (557, 652),
    "ishmael": (633, 652),
    "rodion": (709, 652),
    "sinclair": (785, 652),
    "outis": (861, 652),
    "gregor": (937, 652),
}
# 成交确认页的提示：Spend <价格> Cost to replace this Skill?
# 实测 en 1.119.0 是两阶段：选择页点选项只改当前选择，点选择页的 Confirm 才进入这个提示页，
# 再点一次 Confirm 才真正扣 Cost 完成替换。
# 确认页用素材 mirror/shop/cost_to_replace_this_skill（216x17）做模板匹配，不再读提示文字
PROMPT_ASSET = "mirror/shop/cost_to_replace_this_skill"
PROMPT_REGION = {"x": 300, "y": 450, "width": 700, "height": 90}
PROMPT_THRESHOLD = 0.85
# 弹窗的三个状态：不在、选择页（三张技能卡 + Cancel／Confirm）、成交确认页（Spend … Cost + Cancel／Confirm）
PAGE_NONE = "none"
PAGE_SELECT = "select"
PAGE_PROMPT = "prompt"
# 确认提示里左右两张技能卡上方的 SKILL n 标签：左边是原技能、右边是替换后的技能
PAIR_REGION = {"x": 490, "y": 195, "width": 620, "height": 60}
PAIR_LABEL = re.compile(r"skill([123])")
# 选中的技能对与选项编号的对应：1→2、2→3、1→3
OPTION_BY_PAIR = {(1, 2): 1, (2, 3): 2, (1, 3): 3}
# 依次点击多个勾选项之间的间隔，以及点 Confirm 前让按钮动画落定的等待
OPTION_CLICK_SECONDS = 0.8
CONFIRM_SETTLE_SECONDS = 1.0
# 选择页 Confirm 之后等成交确认页滑入的时间：同一次调用要在这之后复核确认页
PROMPT_WAIT_SECONDS = 1.5
# 价格图标到商品卡的距离：点图标正上方这么高就是这张商品卡
ITEM_CLICK_HEIGHT = 60
# 商品卡名字行（Replace <罪人>'s Skill）在价格行下方：以价格图标中心为基准取一块窄区域，
# 实测 1280x720 名字行中心 y≈341、价格图标中心 y≈317（行距≈154），卡宽≈153，所以只取±90 像素
CARD_NAME_HALF_WIDTH = 90
CARD_NAME_TOP_OFFSET = 8
CARD_NAME_HEIGHT = 55
# 罪人名模糊匹配允许的最大字符修改次数：商品一定属于十二罪人之一，允许 OCR 的小幅误差
MAX_SINNER_EDITS = 2
# 同一商品的位置判定半径：商品行高约 100 像素，用 40 像素区分相邻商品
SAME_ITEM_RADIUS = 40
# 技能替换商品卡的名字行比价格图标中心低约 24 像素（1280x720 实测：第一行图标 y≈317、名字 y≈341，
# 第二行 471／495）。价格图标上的 ?? 是动画帧，模板匹配分数会在 0.9 附近抖动（Run 692 同一张
# ID Skill Search 卡同一位置从 0.995 掉到不足 0.9），只靠模板就会把这张卡当成不存在。
# 商品卡名字行（Replace <罪人>'s Skill／ID Skill Search）稳定可读，因此按名字行中心反推价格图标中心，
# 后续点击（图标上方 60 像素）、Purchased 判断与已处理记录都复用同一套几何。
NAME_TO_ICON_DY = 24
# 已买过的商品卡上方会显示 Purchased：价格图标与名字行仍在，但点不开弹窗，必须按标签跳过。
# 标签位置按与价格图标的几何关系取：实测 1280x720 价格图标中心 y≈317、
# Purchased 标签中心 y≈228（约高 89 像素）、标签宽约 86；商品卡行距约 153 像素，
# 因此竖向取 -150~-60、横向 ±90，既能框住本行标签，又不会把相邻一行的标签算到这张卡头上
# （与 sub_workflow.mirror_shop 判断已买过商品的几何区间一致）。
PURCHASED_KEYWORD = "purchased"
PURCHASED_ASSET = "mirror/shop/purchased"
PURCHASED_THRESHOLD = 0.85
PURCHASED_LABEL_HALF_WIDTH = 90
PURCHASED_LABEL_TOP = -150
PURCHASED_LABEL_BOTTOM = -60
# 点击商品卡片后等待弹窗滑入的固定时间，以及每次弹窗内动作后的固定等待
CLICK_WAIT_SECONDS = 1.5
AFTER_ACTION_SECONDS = 1.0
# 成交确认页点 Confirm 后游戏要联网提交：失败会在确认页上叠一个 Server Error 弹窗。
# 本步不再单独检测 Server Error，交上层每轮的通用过渡检测（step.detect_normal_transition）
# 识别并抛给恢复规则处理。
# 本次镜牢使用的队伍来自镜牢设置页，技能替换配置按队伍保存在队伍配置页
MIRROR_PAGE_ID = "mirror.settings"
# 镜牢设置页「商店设置」的技能替换开关（默认开启）：关闭时本步不再购买，
# 遇到已打开的技能替换弹窗只点一次 Cancel 关掉。
SKILL_REPLACE_SWITCH_KEY = "shop_skill_replace"
TEAM_PAGE_ID = "sinners.team_presets"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
TEAMS_KEY = "teams"
# 队伍配置页按队伍保存的罪人出战顺序：ID Skill Search 按这个顺序挑第一个配置了技能替换的罪人
SINNERS_KEY = "sinners"
SKILL_KEY = "skill_replacements"
# 本次商店已处理的商品记录在 RunState.settings 的镜牢运行时状态里，重入时不重复点击
RUNTIME_KEY = "mirror.runtime"
HANDLED_KEY = "shop_skill_handled"
# 本次商店 ID Skill Search 已经点过的罪人：同一张商品卡重入时改选队伍里下一个配置了技能替换的罪人，
# 不重复点同一个头像。商品被重掷后由 step.mirror_refresh_shop_state 与其他商店记录一起清空。
ID_SEARCH_TRIED_KEY = "shop_id_skill_search_tried"
# 本场镜牢实际使用的队伍记在 mirror.runtime.team_used 里（task.mirror 进场时写入，已是游戏队伍槽位号）：
# 镜牢队伍按设置页的循环顺序逐场轮换，设置页的 mirror_team 只是循环里的第一支，不能代表本场队伍
# （Run 417：轮换到第 2 个队伍，技能替换却按第 1 个队伍读取，误把 yi_sang 的 1→2 换成第 2 队）
TEAM_USED_KEY = "team_used"
# 某个罪人本场镜牢的技能替换已用完的记录（写入 mirror.runtime，键名与 plan 每场复位用的常量一致）：
# 初始 1 技能 3 个、2 技能 2 个、3 技能 1 个，技能替换只做 1→2、1→3 或 2→3；
# 源技能的份数换完（例如 1 技能的 3 份都换过）之后，选择页里的选项点不动、点 Confirm 也
# 不会进入 Spend … Cost 成交确认页（Run 686 现场：Skills Owned 显示 SKILL 1x0，
# 配置的 1→2 替换点完没有任何反应，卡在选择页无法推进）。
# 判定只按「卡在选择页不能推进」：点一次选择页 Confirm 没进入 Spend … Cost 成交确认页就算用完
# （按开发者要求不做补点，避免不确定当前是选择页还是确认页时重复点击）；
# 记录后点一次弹窗底部的 Cancel（固定坐标）关掉弹窗；本场镜牢内这些罪人一律按没有技能替换处理。
EXHAUSTED_KEY = "shop_skill_exhausted"
# 弹窗标题里的罪人英文名（规范化后为小写纯字母）到队伍配置键的映射
SINNER_ALIASES = (
    ("yi_sang", ("yisang",)),
    ("faust", ("faust",)),
    ("don_quixote", ("donquixote",)),
    ("ryoshu", ("ryoshu",)),
    ("meursault", ("meursault",)),
    ("hong_lu", ("honglu",)),
    ("heathcliff", ("heathcliff",)),
    ("ishmael", ("ishmael",)),
    ("rodion", ("rodion",)),
    ("sinclair", ("sinclair",)),
    ("outis", ("outis",)),
    ("gregor", ("gregor",)),
)


def _norm(text: str) -> str:
    """去掉音标、空白和符号并转小写，避免 OCR 断行与 Ryōshū 之类字符影响名字匹配。"""
    decomposed = unicodedata.normalize("NFKD", str(text))
    ascii_only = "".join(char for char in decomposed if ord(char) < 128)
    return re.sub(r"[^a-z0-9]", "", ascii_only.lower())


def _title_part(text: str) -> str:
    """
    只保留界面上的 Replace <罪人名>'s Skill 这一段，丢掉同一横幅里混进来的其他标签。
    弹窗右侧的 Skills Owned 与中间的 SKILL 1x2／SKILL 2x3／SKILL 3x1 也含 skill 字样，
    区域裁切仍可能带进少量残字，因此取第一个 replace 到其后第一个 skill 为止。
    """
    start = text.find("replace")
    if start < 0:
        return text
    end = text.find("skill", start + len("replace"))
    if end < 0:
        return text[start:]
    return text[start : end + len("skill")]


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _action_buttons(ctx: RunContext) -> bool:
    """当前帧底部是否同时出现 Cancel 与 Confirm：技能替换弹窗的固定按钮，商店页没有。"""
    text = _region_text(ctx, POPUP_ACTION_REGION)
    return all(word in text for word in POPUP_ACTION_KEYWORDS)


def _full_title(ctx: RunContext) -> str:
    """整屏 OCR 后只取标题横幅范围内的文本；局部裁切 OCR 漏字时用来补全标题。"""
    result = ctx.action("observe.ocr") or {}
    left, right = FULL_TITLE_X
    top, bottom = FULL_TITLE_Y
    parts: list[str] = []
    for item in result.get("items") or []:
        center = item.get("centerxy") or [0, 0]
        if left <= int(center[0]) <= right and top <= int(center[1]) <= bottom:
            parts.append(str(item.get("text", "")))
    return _title_part(_norm(" ".join(parts)))


def _popup_state(ctx: RunContext) -> tuple[bool, str]:
    """
    判断当前帧是否停在技能替换弹窗，并返回标题区文本供解析罪人。
    标题关键词是主判据；标题局部 OCR 漏字时用底部 Cancel／Confirm 按钮确认弹窗已打开，
    再用整屏 OCR 的同一铭牌范围补全标题，避免读不到罪人而误点 Cancel。
    标题文本一律经 _title_part 截到 Replace … Skill 为止，不掺入右侧 Skills Owned
    与中间那排 SKILL nxm 标签的文字。
    """
    text = _title_part(_region_text(ctx, POPUP_TITLE_REGION))
    if all(word in text for word in POPUP_TITLE_KEYWORDS):
        return True, text
    if not _action_buttons(ctx):
        return False, ""
    return True, _title_part(_norm(f"{_full_title(ctx)} {text}"))


def _in_shop(ctx: RunContext) -> bool:
    """当前帧是否为镜牢商店页：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题（技能替换弹窗已由 _popup_state 先判）。"""
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


def _ordered_contains(text: str, alias: str) -> bool:
    """alias 的字符是否按顺序全部出现在 text 中；允许 OCR 多识别出重复字符。"""
    if len(alias) < MIN_LOOSE_ALIAS_LENGTH:
        return False
    position = 0
    for char in text:
        if position < len(alias) and char == alias[position]:
            position += 1
    return position == len(alias)


def _sinner_of(title: str) -> tuple[str, bool]:
    """
    从弹窗标题里解析罪人配置键，返回 (罪人键, 是否使用了宽松匹配)。
    先要求名字完整出现；OCR 把 Don Quixote 读成 DonnQuixotes 这类多字情形再按字符顺序兜底。
    """
    for sinner, aliases in SINNER_ALIASES:
        if any(alias in title for alias in aliases):
            return sinner, False
    for sinner, aliases in SINNER_ALIASES:
        if any(_ordered_contains(title, alias) for alias in aliases):
            return sinner, True
    return "", False


def _bounded_distance(left: str, right: str, limit: int) -> int | None:
    """有界编辑距离：返回把 left 改成 right 需要的最少字符增删改次数，超过 limit 时返回 None。"""
    if abs(len(left) - len(right)) > limit:
        return None
    previous = list(range(len(right) + 1))
    for row, left_char in enumerate(left, start=1):
        current = [row]
        for column, right_char in enumerate(right, start=1):
            cost = 0 if left_char == right_char else 1
            current.append(
                min(previous[column] + 1, current[column - 1] + 1, previous[column - 1] + cost)
            )
        previous = current
        if min(previous) > limit:
            return None
    best = previous[-1]
    return best if best <= limit else None


def _card_name(ctx: RunContext, center) -> str:
    """
    对价格图标下方的名字行做一次局部 OCR，按从上到下、从左到右拼成商品名；不刷新截图。
    名字过长时 OCR 会拆成上下两行，拼起来后才能读到完整的 Replace … Skill。
    """
    icon_x, icon_y = int(center[0]), int(center[1])
    region = {
        "x": max(0, icon_x - CARD_NAME_HALF_WIDTH),
        "y": icon_y + CARD_NAME_TOP_OFFSET,
        "width": CARD_NAME_HALF_WIDTH * 2,
        "height": CARD_NAME_HEIGHT,
    }
    result = ctx.action("observe.ocr", region=region) or {}
    lines: list[tuple[int, int, str]] = []
    for item in result.get("items") or []:
        text = str(item.get("text", "")).strip()
        if not text:
            continue
        point = item.get("centerxy") or (0, 0)
        lines.append((int(point[1]), int(point[0]), text))
    lines.sort()
    return " ".join(text for _, _, text in lines)


def _sinner_from_card(ctx: RunContext, text: str) -> tuple[str, bool]:
    """
    从商品卡名字（形如 Replace Yi Sang's Skill）解析罪人，返回 (罪人键, 是否用了模糊匹配)。
    商品一定属于十二罪人之一，所以完整名字读不到时允许最多 MAX_SINNER_EDITS 次字符修改；
    最近距离并列时返回空串，交回弹窗标题判断，避免按错误罪人跳过了需要买的商品。
    """
    flat = _norm(text)
    start = flat.find("replace")
    if start >= 0:
        flat = flat[start + len("replace") :]
    end = flat.rfind("skill")
    if end >= 0:
        flat = flat[:end]
    if not flat:
        return "", False
    for sinner, aliases in SINNER_ALIASES:
        if any(alias in flat for alias in aliases):
            return sinner, False
    candidates = [flat]
    if flat.endswith("s"):
        candidates.append(flat[:-1])
    hits: list[tuple[int, str]] = []
    for sinner, aliases in SINNER_ALIASES:
        for alias in aliases:
            for candidate in candidates:
                distance = _bounded_distance(alias, candidate, MAX_SINNER_EDITS)
                if distance is not None:
                    hits.append((distance, sinner))
    if not hits:
        return "", False
    lowest = min(distance for distance, _ in hits)
    winners = sorted({sinner for distance, sinner in hits if distance == lowest})
    if len(winners) > 1:
        ctx.log(
            f"商品名字 {text!r} 同时接近罪人 {winners}（都差 {lowest} 个字符），"
            "不按商品名跳过，交回弹窗标题判断",
            level="warning",
        )
        return "", False
    return winners[0], True


def _team_index(ctx: RunContext) -> int:
    """本场镜牢实际使用的队伍序号：只读 mirror.runtime.team_used；缺失时按第 1 个队伍处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    used = runtime.get(TEAM_USED_KEY) if isinstance(runtime, dict) else None
    if type(used) is int and 1 <= used <= MAX_TEAMS:
        return used
    ctx.log(
        f"没有可用的本场队伍记录 {TEAM_USED_KEY}={used!r}，按第{DEFAULT_TEAM}个队伍处理",
        level="warning",
    )
    return DEFAULT_TEAM


def _switch_enabled(ctx: RunContext) -> bool:
    """读取镜牢设置页「商店设置」的技能替换开关；缺失或非布尔值时按开启处理。"""
    page = (ctx.run_state.settings or {}).get(MIRROR_PAGE_ID)
    raw = page.get(SKILL_REPLACE_SWITCH_KEY) if isinstance(page, dict) else None
    return raw if isinstance(raw, bool) else True


def _skill_options(ctx: RunContext, sinner: str) -> list[int]:
    """读取当前镜牢队伍里该罪人勾选的技能替换编号（1→2、2→3、1→3）；未配置返回空列表。"""
    if not sinner:
        return []
    team_index = _team_index(ctx)
    page = (ctx.run_state.settings or {}).get(TEAM_PAGE_ID) or {}
    teams = page.get(TEAMS_KEY)
    if not isinstance(teams, list) or not 1 <= team_index <= len(teams):
        ctx.log(f"队伍配置里没有第{team_index}个队伍，本次按没有技能替换处理", level="warning")
        return []
    entry = teams[team_index - 1]
    raw = entry.get(SKILL_KEY) if isinstance(entry, dict) else None
    values = raw.get(sinner) if isinstance(raw, dict) else None
    options: list[int] = []
    for value in values if isinstance(values, list) else []:
        text = str(value).strip()
        if not text.isdigit():
            continue
        option = int(text)
        if 1 <= option <= MAX_OPTIONS and option not in options:
            options.append(option)
    ctx.log(
        f"技能替换配置取自本场第{team_index}个队伍（{TEAMS_KEY}[{team_index - 1}]）："
        f"罪人 {sinner} → {sorted(options)}"
    )
    return sorted(options)


def _exhausted(ctx: RunContext) -> list[str]:
    """本场镜牢里技能替换已经用完的罪人（源技能份数换完，选择页点 Confirm 无法推进）。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    record = runtime.get(EXHAUSTED_KEY) if isinstance(runtime, dict) else None
    return [str(value) for value in record] if isinstance(record, list) else []


def _mark_exhausted(ctx: RunContext, sinner: str) -> None:
    """
    记录该罪人本场镜牢的技能替换已用完；写不进 RunState 只记 warning。
    取出的记录先复制再追加，避免直接改动 plan 里那份复位的常量列表。
    """
    if not sinner:
        return
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录技能替换已用完的罪人", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    record = runtime.get(EXHAUSTED_KEY)
    values = list(record) if isinstance(record, list) else []
    if sinner in values:
        return
    values.append(sinner)
    runtime[EXHAUSTED_KEY] = values
    settings[RUNTIME_KEY] = runtime
    ctx.log(
        f"记录罪人 {sinner} 本场镜牢的技能替换已用完（源技能份数换完，选择页 Confirm 不再推进）："
        f"本场用完名单 {values}"
    )


def _available_options(ctx: RunContext, sinner: str) -> list[int]:
    """
    该罪人本场镜牢还能用的技能替换编号：本场已用完的罪人按没有技能替换处理，
    不再为它点选项／Confirm，也不打开它的商品卡。
    """
    if not sinner:
        return []
    if sinner in _exhausted(ctx):
        ctx.log(
            f"罪人 {sinner} 本场镜牢的技能替换已用完（源技能份数换完），按没有技能替换处理"
        )
        return []
    return _skill_options(ctx, sinner)


def _is_id_skill_search(name: str) -> bool:
    """商品卡名字是否为 Super Shop 的 ID Skill Search（没有罪人名，只按 skillsearch 片段判断）。"""
    return ID_SKILL_SEARCH_KEYWORD in _norm(name)


def _named_skill_hits(ctx: RunContext) -> list[dict]:
    """
    对当前帧商品区做一次局部 OCR，按商品卡名字找出技能替换商品
    （Replace <罪人>'s Skill 与 ID Skill Search），返回与价格图标模板命中同形状的列表，
    centerxy 是按名字行反推的价格图标中心；不刷新截图。
    名字行是识别技能替换商品的第二判据：价格图标是动画帧，模板匹配会偶发掉到阈值以下（Run 692）。
    """
    result = ctx.action("observe.ocr", region=SHOP_ITEM_REGION) or {}
    hits: list[dict] = []
    for item in result.get("items") or []:
        text = str(item.get("text", "")).strip()
        if not text:
            continue
        flat = _norm(text)
        if not (_is_id_skill_search(text) or ("replace" in flat and "skill" in flat)):
            continue
        center = item.get("centerxy") or (0, 0)
        hits.append({"centerxy": [int(center[0]), int(center[1]) - NAME_TO_ICON_DY]})
    return hits


def _merge_hits(matched: list[dict], named: list[dict]) -> list[dict]:
    """把按名字行反推的命中并入模板命中；同一张卡（半径 SAME_ITEM_RADIUS 内）只保留模板命中。"""
    merged = [hit for hit in matched if hit.get("centerxy")]
    for hit in named:
        if any(
            abs(int(hit["centerxy"][0]) - int(kept["centerxy"][0])) <= SAME_ITEM_RADIUS
            and abs(int(hit["centerxy"][1]) - int(kept["centerxy"][1])) <= SAME_ITEM_RADIUS
            for kept in merged
        ):
            continue
        merged.append(hit)
    return merged


def _team_sinners(ctx: RunContext) -> list[str]:
    """
    本场队伍里罪人的编排顺序：优先用队伍配置页保存的 sinners 列表——它的顺序与游戏配队页
    中间的十二个人像框、战斗准备页的出战顺序一致，也就是开发者要求的「队伍编排顺序」；
    没有配置时退回十二罪人的固定顺序并记 warning（此时反映不了真实编排顺序）；
    只保留已知罪人，重复项只算一次。
    """
    team_index = _team_index(ctx)
    page = (ctx.run_state.settings or {}).get(TEAM_PAGE_ID) or {}
    teams = page.get(TEAMS_KEY)
    entry = None
    if isinstance(teams, list) and 1 <= team_index <= len(teams):
        entry = teams[team_index - 1]
    raw = entry.get(SINNERS_KEY) if isinstance(entry, dict) else None
    order: list[str] = []
    for value in raw if isinstance(raw, list) else []:
        sinner = str(value).strip()
        if sinner in ID_SKILL_SEARCH_AVATARS and sinner not in order:
            order.append(sinner)
    if order:
        return order
    ctx.log(
        f"队伍配置里没有第{team_index}个队伍的罪人编排顺序（{SINNERS_KEY}），"
        "ID Skill Search 只能退回十二罪人的固定顺序选人，无法按战斗准备页的出战顺序排队",
        level="warning",
    )
    return [sinner for sinner, _ in SINNER_ALIASES]


def _id_search_tried(ctx: RunContext) -> list[str]:
    """本次商店已经做过技能替换（ID Skill Search 点头像或固定商品成交）的罪人。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    record = runtime.get(ID_SEARCH_TRIED_KEY) if isinstance(runtime, dict) else None
    return [str(value) for value in record] if isinstance(record, list) else []


def _mark_id_search_tried(ctx: RunContext, sinner: str) -> None:
    """记录本次商店已经做过技能替换（或点过头像）的罪人，重复项不重复记；写不进 RunState 只记 warning。"""
    if not sinner:
        return
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录本次商店已替换的罪人", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    record = runtime.get(ID_SEARCH_TRIED_KEY)
    if not isinstance(record, list):
        record = []
    if sinner in record:
        return
    record.append(sinner)
    runtime[ID_SEARCH_TRIED_KEY] = record
    settings[RUNTIME_KEY] = runtime


def _mark_replaced(ctx: RunContext, sinner: str) -> None:
    """
    记录本次商店已经为这个罪人完成了一次技能替换（固定商品或 ID Skill Search 成交）。
    开发者要求 index 选人最后用、且按队伍编排顺序走：固定商品买完后 index 要取下一个罪人，
    不能又选回刚刚买过的同一个罪人重复花 Cost，所以已替换名单与「已点过头像」共用同一份本次商店记录
    （商品重掷时一起清空）。
    """
    if not sinner:
        return
    _mark_id_search_tried(ctx, sinner)
    ctx.log(
        f"本次商店已为罪人 {sinner} 完成一次技能替换，ID Skill Search 选人按队伍编排顺序往后取下一个"
    )


def _id_search_target(ctx: RunContext) -> str:
    """
    ID Skill Search 要选哪个罪人（开发者要求）：先把「可技能替换罪人」（配置了技能替换、本场镜牢还没用完）
    按本场队伍的编排顺序排好——也就是战斗准备页的出战顺序，再取第一个本次商店还没做过技能替换的罪人；
    没有这样的罪人时返回空串（不打开商品卡）。
    """
    tried = set(_id_search_tried(ctx))
    exhausted = set(_exhausted(ctx))
    candidates: list[str] = []
    for sinner in _team_sinners(ctx):
        if sinner in tried:
            ctx.log(f"ID Skill Search 按队伍编排顺序跳过罪人 {sinner}：本次商店已经为它做过技能替换")
            continue
        if sinner in exhausted:
            continue
        if _skill_options(ctx, sinner):
            candidates.append(sinner)
    if not candidates:
        return ""
    ctx.log(
        "ID Skill Search 按队伍编排顺序（战斗准备页的出战顺序）排出的可替换罪人："
        + " → ".join(candidates)
        + f"，本次选第一个 {candidates[0]}"
    )
    return candidates[0]


def _drive_id_skill_search(ctx: RunContext, center) -> None:
    """
    Super Shop 的 ID Skill Search 商品：点开商品卡后，在本页底部那排十二个罪人头像里按固定坐标
    点中配置了技能替换的罪人；随后的 Replace <罪人>'s Skill 弹窗与普通技能替换完全一样，
    直接交给 _drive_popup 推进到成交。
    选过的罪人记在本次商店内：同一张商品卡重入时不重复点同一个头像；成交后商品卡会显示 Purchased。
    """
    target = _id_search_target(ctx)
    if not target:
        ctx.log(
            "ID Skill Search 商品：本场队伍没有配置技能替换（或配置的罪人都已试过），"
            "不打开商品卡，只记录位置后跳过",
            level="warning",
        )
        _mark_handled(ctx, "", (int(center[0]), int(center[1])))
        return
    click_x, click_y = int(center[0]), int(center[1]) - ITEM_CLICK_HEIGHT
    ctx.log(f"点击一次 ID Skill Search 商品：价格图标 {center} 正上方 ({click_x}, {click_y})")
    ctx.action("control.click", x=click_x, y=click_y)
    ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    point = ID_SKILL_SEARCH_AVATARS[target]
    ctx.log(
        f"在底部十二个罪人头像里点击罪人 {target} 的固定坐标 {point}"
        "（顺序与配队页的十二个人像框一致）选择替换对象"
    )
    ctx.action("control.click", x=point[0], y=point[1])
    # 先记选过的罪人再等弹窗：同一个人不会因弹窗没出现而被重复点击
    _mark_id_search_tried(ctx, target)
    ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    opened, title = _popup_state(ctx)
    if not opened:
        ctx.log(
            f"点击罪人 {target} 后没有看到 Replace … Skill 弹窗，本次不继续输入，"
            "交回上层重新观察（下一轮改选队伍里下一个配置了技能替换的罪人）",
            level="warning",
            screenshot=True,
        )
        return
    sinner, _ = _sinner_of(title)
    if sinner and sinner != target:
        ctx.log(
            f"弹窗标题 {title!r} 解析出的罪人 {sinner} 与刚点的头像 {target} 不一致，按弹窗标题处理",
            level="warning",
            screenshot=True,
        )
    ctx.log(
        f"ID Skill Search 选中罪人 {target} 后弹出的弹窗与普通技能替换一致（{title}），继续推进到成交"
    )
    # 商品卡位置先记一笔：成交通过弹窗完成，重入时不再重复点开同一张卡
    _mark_handled(ctx, target, (int(center[0]), int(center[1])))
    result = _drive_popup(ctx, title, hint=target)
    if result != "confirmed":
        # 这次没有成交（含该罪人技能替换已用完）：这张商品卡只是没买下，不是已处理，
        # 撤销处理记录让下一轮按顺位改选队伍里下一个配置了技能替换的罪人
        ctx.log(
            f"ID Skill Search 商品本次推进结果 {result}（未成交），撤销这张商品卡的处理记录"
        )
        _unmark_handled(ctx, (int(center[0]), int(center[1])))


def _handled(ctx: RunContext) -> list:
    """返回本次商店已处理过的技能替换商品记录。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        return []
    record = runtime.get(HANDLED_KEY)
    return record if isinstance(record, list) else []


def _mark_handled(ctx: RunContext, sinner: str, center) -> None:
    """记录本次商店已处理的商品；拿不到商品坐标时只按罪人记录。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录商店技能替换处理结果", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    record = runtime.get(HANDLED_KEY)
    if not isinstance(record, list):
        record = []
    x = y = None
    if center is not None:
        x, y = int(center[0]), int(center[1])
    record.append({"sinner": sinner, "x": x, "y": y})
    runtime[HANDLED_KEY] = record
    settings[RUNTIME_KEY] = runtime


def _already_handled(record: list, center) -> bool:
    """该价格图标位置是否已处理过：商品被消费后下方商品会上移，因此按坐标判断。"""
    if not center:
        return False
    for item in record:
        if not isinstance(item, dict) or item.get("x") is None or item.get("y") is None:
            continue
        if (
            abs(int(center[0]) - int(item["x"])) <= SAME_ITEM_RADIUS
            and abs(int(center[1]) - int(item["y"])) <= SAME_ITEM_RADIUS
        ):
            return True
    return False


def _unmark_handled(ctx: RunContext, center) -> None:
    """
    从本次商店已处理记录里删掉这个位置：ID Skill Search 的罪人技能替换用完（或这次没成交）时，
    这张商品卡并没有买下，下一轮要按顺位改选队伍里下一个配置了技能替换的罪人重新处理。
    """
    if not center:
        return
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        return
    record = runtime.get(HANDLED_KEY)
    if not isinstance(record, list):
        return
    kept = [
        item
        for item in record
        if not (
            isinstance(item, dict)
            and item.get("x") is not None
            and item.get("y") is not None
            and abs(int(center[0]) - int(item["x"])) <= SAME_ITEM_RADIUS
            and abs(int(center[1]) - int(item["y"])) <= SAME_ITEM_RADIUS
        )
    ]
    if len(kept) == len(record):
        return
    runtime[HANDLED_KEY] = kept
    settings[RUNTIME_KEY] = runtime
    ctx.log(
        f"把 ID Skill Search 商品位置 ({int(center[0])}, {int(center[1])}) 从本次商店已处理记录里移除，"
        "下一轮按顺位改选下一个可替换罪人"
    )


def _purchased(ctx: RunContext, center) -> bool:
    """
    该价格图标对应的商品卡是否已买过：卡片上方的 Purchased 标签是重入时的跳过依据。
    先用素材 mirror/shop/purchased 在价格图标正上方的标签区做模板匹配（不刷新截图），
    模板没命中时再用同一区域 OCR 兜底，避免遮挡／动画帧下单一判据失效。
    """
    if not center:
        return False
    x, y = int(center[0]), int(center[1])
    region = {
        "x": max(0, x - PURCHASED_LABEL_HALF_WIDTH),
        "y": max(0, y + PURCHASED_LABEL_TOP),
        "width": PURCHASED_LABEL_HALF_WIDTH * 2,
        "height": PURCHASED_LABEL_BOTTOM - PURCHASED_LABEL_TOP,
    }
    if ctx.action(
        "observe.match_asset",
        asset=PURCHASED_ASSET,
        region=region,
        threshold=PURCHASED_THRESHOLD,
    ):
        return True
    return PURCHASED_KEYWORD in _region_text(ctx, region)


def _popup_page(ctx: RunContext) -> str:
    """
    判断当前帧技能替换弹窗处于哪一页，返回 PAGE_PROMPT／PAGE_SELECT／PAGE_NONE。
    成交确认页有 Spend … Cost 提示；选择页只有标题和三张技能卡，两页底部都有 Cancel／Confirm。
    """
    if _confirm_prompt(ctx):
        return PAGE_PROMPT
    if _popup_state(ctx)[0]:
        return PAGE_SELECT
    return PAGE_NONE


def _click_cancel(ctx: RunContext) -> None:
    """点击一次弹窗底部的 Cancel，关闭技能替换弹窗（不扣 Cost）。"""
    ctx.log(f"点击弹窗 Cancel {CANCEL_POINT}")
    ctx.action("control.click", x=CANCEL_POINT[0], y=CANCEL_POINT[1])


def _dismiss_popup(ctx: RunContext) -> bool:
    """
    点一次弹窗底部的 Cancel（固定坐标 CANCEL_POINT）关掉技能替换弹窗（不扣 Cost），返回关闭是否得到确认。
    选择页与成交确认页的 Cancel 在同一位置；不用 Esc（Run 687 现场：Esc 后弹窗仍在）。
    点完固定等一小会儿再截图复核：弹窗已不在返回 True；仍在返回 False 交回上层重新观察。
    """
    _click_cancel(ctx)
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
    ctx.action("observe.capture_screen")
    return _popup_page(ctx) == PAGE_NONE


def _confirm_prompt(ctx: RunContext) -> bool:
    """当前帧是否已进入「Spend <价格> Cost to replace this Skill?」确认步骤：用提示横幅模板匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=PROMPT_ASSET,
            region=PROMPT_REGION,
            threshold=PROMPT_THRESHOLD,
        )
    )


def _selected_pair(ctx: RunContext) -> tuple[int, int] | None:
    """读确认步骤里两张技能卡上的 SKILL n 标签，返回 (原技能, 替换后的技能)；读不到返回 None。"""
    result = ctx.action("observe.ocr", region=PAIR_REGION) or {}
    labels: list[tuple[int, int]] = []
    for item in result.get("items") or []:
        match = PAIR_LABEL.fullmatch(_norm(item.get("text", "")))
        if match:
            labels.append((int(item["centerxy"][0]), int(match.group(1))))
    if len(labels) < 2:
        return None
    labels.sort()
    return labels[0][1], labels[-1][1]


def _confirm_step_option(ctx: RunContext, options: list[int]) -> int | None:
    """
    在 Spend … Cost 二次确认步骤核对选中的技能对，返回要成交的选项编号。
    选中项不在配置里时返回 None（调用方点 Cancel 放弃），读不到时按配置回退。
    """
    pair = _selected_pair(ctx)
    selected = OPTION_BY_PAIR.get(pair) if pair else None
    if selected is None:
        ctx.log("没有读到确认步骤里选中的技能编号，按配置直接点 Confirm", level="warning", screenshot=True)
        return options[-1]
    if selected not in options:
        ctx.log(
            f"确认步骤选中的技能对 {pair}（第 {selected} 项）不在配置 {options} 里，点击 Cancel 放弃本次替换",
            level="warning",
            screenshot=True,
        )
        return None
    ctx.log(f"确认步骤选中的技能对 {pair}（第 {selected} 项）在配置 {options} 里")
    return selected


def _confirm_purchase(ctx: RunContext, options: list[int]) -> bool:
    """
    在 Spend … Cost 成交确认页核对选中的技能对，然后点一次 Confirm 真正扣 Cost 完成替换；
    返回是否点了成交的 Confirm（选中项不在配置里时点一次 Cancel 放弃并返回 False）。
    读不到选中项时按配置最后一项成交。
    这次 Confirm 是唯一会联网提交的输入，点完只固定等 1 秒就交回，
    成交是否生效、Cost 是否下降都由上层下一轮重新观察。
    """
    selected = _confirm_step_option(ctx, options)
    if selected is None:
        _click_cancel(ctx)
        return False
    ctx.action("observe.wait", seconds=CONFIRM_SETTLE_SECONDS)
    ctx.log(f"点击成交确认页的 Confirm {CONFIRM_POINT} 完成第 {selected} 项替换，交回上层重新观察")
    ctx.action("control.click", x=CONFIRM_POINT[0], y=CONFIRM_POINT[1])
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
    return True


def _drive_popup(ctx: RunContext, title: str, hint: str = "") -> str:
    """
    把已打开的技能替换弹窗在本次调用里推进到底，返回推进结果：
    confirmed（已成交）／cancelled（主动放弃）／exhausted（技能替换已用完并已点 Cancel 关掉弹窗）／
    closed（弹窗意外消失）／stalled（既没推进也没关掉，交回上层重新观察）。
    - 成交确认页：核对选中的技能对后点一次 Confirm 成交（或点 Cancel 放弃）；
    - 选择页：先按罪人配置依次点选项（只改当前选择，不成交），再点选择页的 Confirm
      进入成交确认页——选择页这一步不涉及网络；复核确认页后再立刻成交。
      选择页的 Confirm 只点一次（按开发者要求不做补点）：没推进到确认页就说明该罪人本场镜牢的
      技能替换已用完（源技能份数换完），记入 RunState 后点一次弹窗底部的 Cancel 关掉弹窗，
      不再卡在无法推进的选择页上。
    任何一步没有达到预期状态都只记录 warning 并返回，由 sub_workflow.mirror_shop
    重新观察后再次调用本步；真正提交的 Confirm 在一次调用里只点一次。
    hint 是打开弹窗时选中的罪人（ID Skill Search 点头像时已知），标题读不到罪人名时用它兜底。
    """
    sinner, loose = _sinner_of(title)
    if loose:
        ctx.log(f"弹窗标题 OCR 不完整（{title}），按字符顺序宽松匹配到罪人 {sinner}", level="warning")
    if not sinner and hint:
        sinner = hint
        ctx.log(
            f"弹窗标题里没有读到罪人名（{title}），按打开弹窗时选中的罪人 {hint} 处理",
            level="warning",
        )
    if not sinner:
        ctx.log(f"无法从弹窗标题识别罪人（{title}），按没有技能替换处理", level="warning", screenshot=True)
    options = _available_options(ctx, sinner)
    # 商品位置已被弹窗盖住，这里只能先按罪人记录本次处理
    _mark_handled(ctx, sinner, None)

    page = _popup_page(ctx)
    if page == PAGE_PROMPT:
        if not options:
            ctx.log(f"罪人 {sinner or '未知'} 没有可用的技能替换，点击 Cancel 放弃本次替换")
            _click_cancel(ctx)
            return "cancelled"
        if _confirm_purchase(ctx, options):
            _mark_replaced(ctx, sinner)
        return "confirmed"
    if page != PAGE_SELECT:
        ctx.log(
            "技能替换弹窗既不是选择页也不是成交确认页，本次不做输入，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return "stalled"
    if not options:
        ctx.log(f"罪人 {sinner or '未知'} 没有可用的技能替换，点击 Cancel 放弃本次替换")
        _click_cancel(ctx)
        return "cancelled"

    ctx.log(
        f"罪人 {sinner} 勾选的技能替换 {options}，按从左到右各点一次"
        "（后面的点击只覆盖前面的选择，不会各成交一次）"
    )
    for option in options:
        point = OPTION_POINTS[option]
        ctx.action("control.click", x=point[0], y=point[1])
        ctx.log(f"点击第 {option} 项 {point}")
        ctx.action("observe.wait", seconds=OPTION_CLICK_SECONDS)

    ctx.action("observe.wait", seconds=CONFIRM_SETTLE_SECONDS)
    ctx.log(
        f"点击选择页的 Confirm {CONFIRM_POINT} 进入 Spend … Cost 成交确认页（不扣 Cost，只点一次）"
    )
    ctx.action("control.click", x=CONFIRM_POINT[0], y=CONFIRM_POINT[1])
    ctx.action("observe.wait", seconds=PROMPT_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    page = _popup_page(ctx)
    if page == PAGE_PROMPT:
        if _confirm_purchase(ctx, options):
            _mark_replaced(ctx, sinner)
        return "confirmed"
    if page != PAGE_SELECT:
        ctx.log(
            "点击选择页的 Confirm 后技能替换弹窗已不在（既不是选择页也不是成交确认页），"
            "本次不成交，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return "closed"

    # 点一次 Confirm 不推进：该罪人本场镜牢的技能替换已用完（源技能份数换完，选项点不动、Confirm 也不推进）
    _mark_exhausted(ctx, sinner)
    if _dismiss_popup(ctx):
        ctx.log(
            f"罪人 {sinner or '未知'} 点选择页 Confirm 没有进入 Spend … Cost 成交确认页："
            "判定该罪人本场镜牢的技能替换已用完，已点击弹窗 Cancel 关闭（本场镜牢内不再为这个罪人做技能替换）",
            level="warning",
            screenshot=True,
        )
        return "exhausted"
    ctx.log(
        f"判定罪人 {sinner or '未知'} 的技能替换已用完，但点击 Cancel 后技能替换弹窗仍在："
        "本次不再输入，交回上层重新观察",
        level="warning",
        screenshot=True,
    )
    return "stalled"





@step
def execute(ctx: RunContext) -> None:
    """
    处理镜牢商店的技能替换商品，一次调用完整走完一件商品：
    - 弹窗已打开（上一轮没走完或上次中断）时，直接从弹窗当前状态推进到成交；
    - 既不是商店页也没有弹窗时零输入返回；
    - 在商店页时先剔除卡片上方显示 Purchased（已买过、点不开弹窗）的商品，只记录位置不点开；
      再找未处理的技能替换商品，按商品卡名字分开处理：
      Super Shop 的 ID Skill Search 同样带 ?? 价格图标，名字里没有罪人，
      点开后要在本页底部那排十二个罪人头像里按固定坐标选人，
      选完出现的 Replace <罪人>'s Skill 弹窗与普通技能替换完全一致，照常推进到成交；
      但它是最后的兜底：同一帧还有未处理的固定 Replace <罪人>'s Skill 商品时先处理固定商品，
      没有固定商品可处理才用它；目标罪人按「可技能替换罪人」在本场队伍里的编排顺序
      （战斗准备页的出战顺序）挑第一个本次商店还没点过、本场镜牢也还没用完的人；
    - 普通商品不急着点开：先 OCR 价格图标下方的商品名字读出罪人，
      本场队伍没有勾选这个罪人的技能替换时不开弹窗、只记一笔就交回，省掉打开／取消弹窗的时间；
      名字有 OCR 误差时允许最多 MAX_SINNER_EDITS 个字符的模糊匹配并记 warning，识别不出或并列时仍按标题判断；
    - 需要买时才点一次商品卡，等弹窗滑入后在同一次调用里继续推进选择页与成交确认页；
      已买过（Purchased）的商品只记记录跳过、不做输入；没有未处理商品时零输入返回；
    - 选好技能却卡在选择页、点 Confirm 也进不去 Spend … Cost 成交确认页时，按该罪人本场镜牢的
      技能替换已用完处理（初始 1 技能 3 个、2 技能 2 个、3 技能 1 个，替换只做 1→2、1→3、2→3，
      源技能份数换完就换不动了）：记入 RunState 的用完名单后点一次弹窗底部的 Cancel 关掉弹窗；
      ID Skill Search 撤销这张商品卡的处理记录，下一轮按顺位改选下一个可替换罪人；
      普通技能替换商品则把该罪人当作没有技能替换，后续不再为它打开弹窗。
    选择页点选项与选择页 Confirm 都不涉及网络，所以合并进同一次调用；
    只有成交确认页那次 Confirm 会联网提交，点完固定等 1 秒立即交回，
    只用成交确认页的提示素材判断当前在哪个步骤；成交是否生效、Cost 是否下降由
    sub_workflow.mirror_shop 下一轮重新观察。
    本次商店处理过的商品位置与罪人记进 RunState，重入不重复点击（购买不可安全重放）。
    """
    ctx.action("observe.capture_screen")

    opened, title = _popup_state(ctx)
    if not _switch_enabled(ctx):
        # 开关关闭后不再购买技能替换：弹窗已打开时只点一次 Cancel 关掉，下一轮重新观察商店
        if opened:
            ctx.log(
                "商店设置的技能替换已关闭：点击一次 Cancel 关闭残留的技能替换弹窗，不做购买输入",
                level="warning",
            )
            _click_cancel(ctx)
            return
        ctx.log("商店设置的技能替换已关闭，本步不做任何动作")
        return
    if opened:
        ctx.log(f"技能替换弹窗已打开（{title}），本次调用从弹窗当前状态一路推进到成交")
        _drive_popup(ctx, title)
        return

    if not _in_shop(ctx):
        ctx.log("当前既不是镜牢商店页也没有技能替换弹窗，本步不做动作", level="warning", screenshot=True)
        return

    matches = ctx.action("observe.match_asset", asset=SKILL_ITEM_ASSET, region=SHOP_ITEM_REGION) or []
    # 价格图标是动画帧、模板匹配会偶发掉到阈值以下；商品卡名字行稳定可读，按它反推图标位置并合并
    matches = _merge_hits(matches, _named_skill_hits(ctx))
    record = _handled(ctx)
    pending = [
        hit
        for hit in matches
        if hit.get("centerxy") and not _already_handled(record, hit["centerxy"])
    ]
    if not pending:
        ctx.log(
            f"当前帧命中 {len(matches)} 个技能替换商品（价格图标或名字行），没有未处理的新商品，本步不点击"
        )
        return

    pending.sort(key=lambda hit: (int(hit["centerxy"][1]), int(hit["centerxy"][0])))
    # 已买过（Purchased）的商品卡价格图标与名字行都还在，但点它不会弹出任何窗口：
    # 先按卡片上方的 Purchased 标签剔除，只记录位置后跳过，不对它做输入。
    # 技能替换在弹窗里成交时商品位置被弹窗盖住，只能按罪人记录，所以重入时这张卡仍会被当成未处理
    # （Run 681：点开已买过的 Replace Ryōshū's Skill 没有出现弹窗，白等一帧还记了 warning）。
    purchased_hits = []
    actionable = []
    for hit in pending:
        (purchased_hits if _purchased(ctx, hit["centerxy"]) else actionable).append(hit)
    if purchased_hits:
        positions = ", ".join(
            f"({int(hit['centerxy'][0])}, {int(hit['centerxy'][1])})" for hit in purchased_hits
        )
        ctx.log(
            f"当前帧有 {len(purchased_hits)} 个技能替换价格图标上方显示 Purchased"
            f"（商品已买过、点不开弹窗），只记录位置后跳过：{positions}"
        )
        for hit in purchased_hits:
            center = hit["centerxy"]
            _mark_handled(ctx, "", (int(center[0]), int(center[1])))
    pending = actionable
    if not pending:
        ctx.log(
            f"当前帧命中 {len(matches)} 个技能替换商品（价格图标或名字行），剩余位置都已买过或已处理过，本步不点击"
        )
        return
    if len(pending) > 1:
        # 同一帧有多件技能替换商品属正常情况（商店一屏可有多件），按 info 记录，不算歧义告警
        ctx.log(
            f"当前帧有 {len(pending)} 个未处理技能替换商品，先按商品卡名字区分 ID Skill Search 与普通替换",
            level="info",
        )
    # Super Shop 的 ID Skill Search 也是 ?? 价格图标，但它点开的是「在本页底部十二个罪人头像里选人」，
    # 与普通 Replace <罪人>'s Skill 不同：先读每张卡的名字把两类商品分开。
    # 开发者要求：优先处理当前商店里固定的罪人技能替换商品（Replace <罪人>'s Skill），
    # ID Skill Search 的 index 选人放到最后——同一帧还有固定商品可处理时不打开它。
    card_names = [_card_name(ctx, hit["centerxy"]) for hit in pending]
    fixed = [
        (hit, text) for hit, text in zip(pending, card_names) if not _is_id_skill_search(text)
    ]
    indexed = [
        (hit, text) for hit, text in zip(pending, card_names) if _is_id_skill_search(text)
    ]
    if not fixed:
        # 已买过的 ID Skill Search 商品卡（同样带 ?? 价格图标）在上面已按 Purchased 标签剔除
        ctx.log(
            "当前帧没有未处理的固定罪人技能替换商品，只剩 ID Skill Search（index 选人）商品，"
            "按开发者要求放到最后处理：本次处理它"
        )
        _drive_id_skill_search(ctx, indexed[0][0]["centerxy"])
        return
    if indexed:
        ctx.log(
            f"当前帧有 {len(fixed)} 个固定的罪人技能替换商品、{len(indexed)} 个 ID Skill Search 商品："
            "按开发者要求先处理固定的罪人技能替换，index 选人留到最后（固定商品处理完再回来）"
        )
    center = fixed[0][0]["centerxy"]
    name = fixed[0][1]
    sinner, fuzzy = _sinner_from_card(ctx, name)
    if sinner:
        if fuzzy:
            ctx.log(
                f"技能替换商品名 OCR 为 {name!r}，按最多 {MAX_SINNER_EDITS} 个字符的误差匹配到罪人 {sinner}",
                level="warning",
            )
        options = _available_options(ctx, sinner)
        if not options:
            ctx.log(
                f"技能替换商品 {name!r} 的罪人 {sinner} 在本场队伍没有可用的技能替换"
                "（未勾选或本场已用完），不打开弹窗，只记录位置后跳过"
            )
            _mark_handled(ctx, sinner, (int(center[0]), int(center[1])))
            return
    else:
        ctx.log(
            f"没有从商品名字 {name!r} 识别出罪人，仍点开弹窗按标题判断",
            level="warning",
        )

    click_x, click_y = int(center[0]), int(center[1]) - ITEM_CLICK_HEIGHT
    ctx.log(f"点击一次技能替换商品：价格图标 {center} 正上方 ({click_x}, {click_y})")
    ctx.action("control.click", x=click_x, y=click_y)
    # 先记位置再等弹窗：同一商品不会因未确认而重复点击
    _mark_handled(ctx, "", (int(center[0]), int(center[1])))
    ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    opened, title = _popup_state(ctx)
    if not opened:
        ctx.log(
            "点击技能替换商品后没有看到 Replace … Skill 弹窗，本次不继续输入，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return
    _drive_popup(ctx, title)
