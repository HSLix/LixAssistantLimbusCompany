"""主界面体力转换编排：打开 Charge Enkephalin → 取最大数量 → Confirm → 通用等待 → esc 关闭。

每轮重新截图判定弹窗状态，只调一个动作 Step；同一分支前三次可执行，第四次在执行前报错。
"""
import re

from lalc import ExecutionFailure, RunContext, sub_workflow

# 弹窗打开标志：标题 Charge Enkephalin
POPUP_TITLE_REGION = {"x": 500, "y": 95, "width": 280, "height": 55}
POPUP_TITLE_KEYWORD = "chargeenkephalin"
# 底部按钮区：识别到 Confirm 文本才执行确认
CONFIRM_REGION = {"x": 700, "y": 505, "width": 190, "height": 65}
CONFIRM_LABEL = "confirm"
# 数量选择器最右侧的「»」按钮
MAX_ASSET = "main/stamina_charge_max"
# 8 轮上限：打开、取最大、确认、关闭各一轮，留出动画与重试余量
MAX_ROUNDS = 8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _popup_open(ctx: RunContext) -> bool:
    """在当前帧的标题区域 OCR，命中 Charge Enkephalin 即认为兑换弹窗已打开。"""
    result = ctx.action("observe.ocr", region=POPUP_TITLE_REGION) or {}
    items = result.get("items") or []
    return POPUP_TITLE_KEYWORD in _norm("".join(str(item.get("text", "")) for item in items))


def _confirm_visible(ctx: RunContext) -> bool:
    """在当前帧的底部按钮区 OCR，找到文字完全等于 Confirm 的条目才算可确认。"""
    result = ctx.action("observe.ocr", region=CONFIRM_REGION) or {}
    items = result.get("items") or []
    return any(_norm(item.get("text", "")) == CONFIRM_LABEL for item in items)


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """按弹窗状态推进一次体力转换，弹窗在确认后关闭即返回 completed。"""
    previous_branch = ""
    consecutive_hits = 0
    opened = False
    max_applied = False
    confirmed = False

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, MAX_ROUNDS + 1):
        ctx.action("observe.capture_screen")
        if not _popup_open(ctx):
            if confirmed:
                ctx.log(f"第{round_index}轮：确认兑换后弹窗已关闭，体力转换结束")
                return {"completed": True, "reason": "popup_closed"}
            if opened:
                ctx.log(
                    f"第{round_index}轮：点过体力读数但弹窗仍未打开，交回上层重新观察",
                    level="warning",
                    screenshot=True,
                )
                return {"completed": False, "reason": "popup_not_opened"}
            hit("step.stamina_charge_open")
            ctx.log(f"第{round_index}轮：点一次体力读数打开 Charge Enkephalin 弹窗")
            ctx.call("step.stamina_charge_open")
            opened = True
            continue

        if not max_applied:
            hit("step.stamina_charge_max")
            ctx.log(f"第{round_index}轮：弹窗已打开，点一次「»」把数量取到最大")
            applied = ctx.call("step.stamina_charge_max") or {}
            if applied.get("applied"):
                max_applied = True
                continue
            # 取不到最大数量时不用默认的 1 个凑合，直接 esc 收起弹窗交回上层
            ctx.log("未能点到最大数量，按 esc 收起弹窗并交回上层", level="warning", screenshot=True)
            ctx.call("step.stamina_charge_close")
            return {"completed": False, "reason": "max_not_applied"}

        if _confirm_visible(ctx):
            hit("step.stamina_charge_finish")
            ctx.log(f"第{round_index}轮：数量已取到最大，点一次 Confirm→等待→esc 关闭弹窗")
            finished = ctx.call("step.stamina_charge_finish") or {}
            if finished.get("confirmed"):
                confirmed = True
            continue

        hit("unknown")
        ctx.log(
            f"第{round_index}轮：弹窗已打开但未识别到「»」或 Confirm，等待后重新观察",
            level="warning",
            screenshot=True,
        )
        ctx.action("observe.wait", seconds=1.0)

    raise ExecutionFailure("workflow_rounds_exhausted", "体力转换界面在预算内没有完成")
