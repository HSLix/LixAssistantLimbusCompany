"""镜牢商店：点一次右下角 Leave，等 2 秒后按一次 Enter，落点由上层重新观察。"""
import re

from lalc import RunContext, step

PATH_ASSET = "mirror/train_head"
# 商店页标识（四条判据取或，任一成立就算商店页）：
# ① 左下角三个页签（Enhance／Fuse／Sell Gifts）命中两颗以上；② 左上角 Shop 标题文字；
# ③ 右上角普通 Refresh 按钮模板；④ Keyword Refresh 按钮模板。
# 不再靠右下角 Leave 文字（Run 415 里同一帧 Shop 标题读到、Leave 区域却返回空、误判已离开商店）。
#
# Run 645 第 1~4 轮现场（证据 645/76：画面确实是商店页，Leave 在 (1132,652)）：同一帧里
# task.mirror 用整屏 OCR 按左下角页签判出「shop，依据 商店页签 3/3」，本 Step 却判成「既不是寻路页
# 也识别不到任何商店页特征」——它当时的两条判据双双落空：单独裁切 (150,92,280,58) 做局部 OCR 返回
# 空条目，两个刷新按钮模板在 (900,80,330,110) 也都不命中。于是本步零输入返回，上层连续四次命中
# 同一分支，撞上分支上限失败。
# 因此判据改为：一次整屏 OCR，再按区域过滤条目（与 task.mirror 的 _text_in 完全相同的做法），
# 不再对小区域单独裁切识别（小裁切在本机会漏识别）；页签判据放最前，它与上层判商店页的依据一致，
# 大字号多条目时识别最稳。
SHOP_TABS_REGION = {"x": 130, "y": 360, "width": 330, "height": 60}
SHOP_TAB_KEYWORDS = ("enhance", "fuse", "sell")
MIN_SHOP_TABS = 2
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)~(256, 125)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈195 起）与右侧 Cost 数字。
# 因为现在是从整屏 OCR 结果里过滤中心点，区域只决定「算不算这个区域的文字」，放宽几像素不影响识别
SHOP_TITLE_REGION = {"x": 130, "y": 80, "width": 320, "height": 84}
SHOP_TITLE_KEYWORD = "shop"
# 寻路页左上角的 Exploring 文字
PATH_HEADER_REGION = {"x": 30, "y": 80, "width": 290, "height": 60}
PATH_KEYWORD = "exploring"
# 只尝试一次「点 Leave → 等待 → Enter」，不在这里判断是否回到寻路页


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本步所有区域文案都从这份结果里按区域过滤。"""
    result = ctx.action("observe.ocr") or {}
    return list(result.get("items") or [])


def _text_in(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，合并成规范化小写文本；不刷新截图。"""
    left = int(region["x"])
    top = int(region["y"])
    right = left + int(region["width"])
    bottom = top + int(region["height"])
    parts: list[str] = []
    for item in items:
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if left <= x <= right and top <= y <= bottom:
            text = str(item.get("text", ""))
            if text:
                parts.append(text)
    return _norm(" ".join(parts))


def _on_path(ctx: RunContext, items: list[dict]) -> bool:
    """用同一帧的火车头模板或左上角 Exploring 文字判断是否已回到寻路页；不刷新截图。"""
    if ctx.action("observe.match_asset", asset=PATH_ASSET):
        return True
    return PATH_KEYWORD in _text_in(items, PATH_HEADER_REGION)


def _shop_marker(ctx: RunContext, items: list[dict]) -> str:
    """
    在同一帧上判定商店页特征，返回命中的依据；都没有命中返回空字符串。
    页签优先：Run 645 现场同一帧的页签能从整屏 OCR 稳定读到 3/3，而 Shop 标题的小区域裁切识别与
    两个刷新按钮模板当时都落空，只靠后两者会把商店页判成非商店页。
    """
    tabs = _text_in(items, SHOP_TABS_REGION)
    count = sum(1 for keyword in SHOP_TAB_KEYWORDS if keyword in tabs)
    if count >= MIN_SHOP_TABS:
        return f"商店页签 {count}/3"
    if SHOP_TITLE_KEYWORD in _text_in(items, SHOP_TITLE_REGION):
        return "左上角 Shop 标题"
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return asset
    return ""


@step
def execute(
    ctx: RunContext,
    *,
    leave_x: int = 1133,
    leave_y: int = 647,
    wait_seconds: float = 2.0,
    assume_shop: bool = False,
) -> None:
    """
    只负责离开商店，做一组固定动作：
    已在寻路页时零动作返回；识别不到商店页特征时按 assume_shop 决定（上层已按商店页分派就直接点 Leave，
    否则零输入返回）；否则点一次右下角 Leave（默认 (1133, 647)）、等 wait_seconds（默认 2 秒）、
    再按一次 Enter，然后交回。是否已回到寻路页、落在哪一页由 task.mirror 下一轮重新观察，本步不轮询、不重试。

    assume_shop：调用方（task.mirror 的 shop 分支）已经用同一帧的整屏 OCR 把本页判成商店页时传 True。
    Run 645 的失败就是「上层判商店、本步判不出来、本步零输入」三者叠加：上层连续四次命中同一分支后撞分支上限。
    上层既然刚看过商店页特征，就不该在本步再要求一次独立确认，因此这个参数只在本步自己识别不到时生效，
    命中页签／标题／刷新按钮任一条时行为与之前完全一致。
    """
    ctx.action("observe.capture_screen")
    # 情景判定前只做一次整屏 OCR，页签与标题文案都从这份条目里按区域过滤，不再裁切小区域单独识别
    items = _screen_items(ctx)
    if _on_path(ctx, items):
        ctx.log("当前已在寻路页，无需离开商店")
        return

    marker = _shop_marker(ctx, items)
    if marker:
        ctx.log(f"确认仍在商店页（{marker}），准备离开")
    elif not assume_shop:
        ctx.log(
            "当前既不是寻路页也识别不到任何商店页特征（页签、Shop 标题或刷新按钮），不做任何输入",
            level="warning",
            screenshot=True,
        )
        return
    else:
        ctx.log(
            "本帧没有读到商店页特征，但上层已按商店页分派（task.mirror 整屏 OCR 判出商店页），"
            "按商店页处理，仍点一次 Leave",
            level="warning",
            screenshot=True,
        )

    ctx.log(f"点击一次商店 Leave 按钮 ({leave_x}, {leave_y})")
    ctx.action("control.click", x=leave_x, y=leave_y)
    ctx.log(f"已等待 {wait_seconds} 秒，按一次 Enter 确认离开商店")
    ctx.action("observe.wait", seconds=wait_seconds)
    ctx.action("control.key_press", key="enter")
    ctx.log("离开商店的输入已完成，落点由上层重新观察")
