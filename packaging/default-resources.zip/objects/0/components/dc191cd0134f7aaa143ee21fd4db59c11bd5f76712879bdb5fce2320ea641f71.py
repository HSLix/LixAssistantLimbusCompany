"""镜牢商店：一次商品区 OCR 就把所有饰品分成「买」与「不买」，再按购买后的位置规律一次性买完。

买不买按队伍配置页「镜牢饰品偏好」下方「商店购买饰品流派」的多选标签判断：只要饰品在图鉴里的流派落在
该队伍选中的流派集合里就买，可以同时买多个流派；不再用上面的单选初始 E.G.O 饰品流派（gift_keyword）
判别。集合为空时只买镜牢设置页「饰品配置」里设为「优先获取」的饰品。
「优先获取」的饰品不受流派限制：即使流派不在选中集合里也照买（两个条件取或）；
其余饰品仍按流派判断，旧配置没有多选字段或没有偏好字段时购买范围与改动前一致。

饰品名单只来自素材库镜像：镜牢设置页「饰品配置」的键就是素材逻辑名 mirror/gift/<流派>/<名字>
（页面每次按素材目录重建，手工直接加进素材库的饰品也会带一条 default 偏好）；流派只取素材路径的目录段、
名字只取最后一段（目录名，小写、非字母数字转下划线），没有名称标签。商品名只按这个目录名匹配。
单独的饰品图鉴页面资源已退役，本步不再读写它。

不再点开饰品详情复核名字：商品名与图鉴完全相等就按那条图鉴的流派判断；没有完全相等时，取字符修改
次数不超过 MAX_NAME_EDITS 的最近一条图鉴名字，按它判断并记 warning（一定属于图鉴里的某个饰品）。
镜牢设置页「商店设置」的「优先购买未记录饰品」（默认关闭）打开后，名字与名单所有条目差距都过大的商品
（素材库里还没有的饰品）也照买，不受本队购买流派限制；关闭时与改动前一致，按不在名单里处理、不购买。
购买后商品会移到最后，同一行／同列里被买走位置后面的卡片会整体前移：Run 487 实测买走一行第 1 列后，
右侧卡片左移一格、Purchased 卡片移到本行末尾，同一帧预计算的下一个坐标就落到了已买过的卡片上，
点开只读的 E.G.O Gift Info 弹窗、把商店循环卡死。因此本步每次调用只点一次 Purchase 就返回，
由上层重新 OCR 商品区后再买下一件，购买之间不再复用旧坐标。
点过 Purchase 后本步不再自行检测 E.G.O Gift GET! 到手弹窗：只做一段固定等待就交回，
由上层 sub_workflow.mirror_shop 下一轮重新观察，识别到弹窗再交回本步确认。
已买过的卡片被再点一次会弹出只读的 E.G.O Gift Info 弹窗（只有 Confirm），本步识别到它只关掉、不做购买输入。
已处理记录按名字核对，点过 Purchase 的商品先记录再点击，重入不会重放购买。
"""
import re
import unicodedata

from lalc import RunContext, step

# 商店页标识（三条判据取或，任一成立就算商店页）：
# ① 右上角普通 Refresh 按钮模板命中；② Keyword Refresh 按钮模板命中；③ 左上角 Shop 标题文字。
# 单个按钮模板在遮挡／动画帧下可能只命中一个，短标题 OCR 也会偶发漏识别，取或后不再要求两个同时命中。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 商店右侧商品列表：每个商品卡片的图标在上、价格在中、名字在下
SHOP_ITEM_REGION = {"x": 505, "y": 175, "width": 700, "height": 390}
# 当前持有 Cost：Shop 标题右侧硬币图标后面的数字（购买前用它核对阈值）
COST_REGION = {"x": 540, "y": 100, "width": 120, "height": 60}
# 名字行 OCR 的最低分与最短长度：过滤价格数字、图标噪声与单字符
NAME_MIN_SCORE = 0.85
NAME_MIN_LENGTH = 3
# 名字行到卡片图标中心的纵向距离（实测 1280x720：名字行中心 341，图标中心 253）
CARD_CLICK_OFFSET_Y = -88
# 技能替换商品的名字形如 Replace X's Skill，由 step.mirror_shop_skill_replace 处理，本步跳过
SKILL_NAME_KEYWORD = "replace"
# 已买过的商品卡上方会显示 Purchased：标签与名字行的几何关系是纵向高 80~150 像素、横向 90 像素内
GIFT_PURCHASED_TOLERANCE_X = 90
GIFT_PURCHASED_TOP = -150
GIFT_PURCHASED_BOTTOM = -80
# Purchased 标签本身也在商品列表区域里，且能通过名字行过滤，不能把它当成一件商品
PURCHASED_LABEL_KEYWORD = "purchased"
# 买不起的商品卡不再显示商品名，而是在同一行（卡片上方）显示 Not Enough Cost 状态标签。
# Run 487 把这个标签当成饰品商品名字行（并当成未记录饰品），反复点击上方坐标也点不开详情，
# 已处理记录不增加，上层终被停滞保护报错。OCR 会读成 Not-Enough-Cost／Not EnoughaCost／
# Not Enough Cost 等变体，因此只按稳定的 notenough 片段识别，直接跳过、不当作商品。
UNAFFORDABLE_KEYWORDS = ("notenough", "enoughcost")
# 同一张卡片的名字较长时 OCR 会拆成上下两行：横向／纵向都在这个范围内算同一张卡
SAME_CARD_TOLERANCE_X = 60
SAME_CARD_TOLERANCE_Y = 25
# 本次商店已处理过的商品记录在 RunState.settings 的镜牢运行时状态里：
# 名字是主要判据（商品被买走后下方商品会上移，名字不变、位置会变），坐标留给没有名字的旧记录
RUNTIME_KEY = "mirror.runtime"
HANDLED_KEY = "shop_gift_handled"
# 本场镜牢实际使用的队伍记在 mirror.runtime.team_used 里（task.mirror 进场时写入，已是游戏队伍槽位号）：
# 镜牢队伍逐场轮换，设置页的 mirror_team 只是循环里的第一支（Run 417：轮换到第 2 个队伍，
# 饰品流派却按第 1 个队伍读取），所以优先按 team_used 取本队配置
TEAM_USED_KEY = "team_used"
# 同一商品的位置判定半径：商品行高约 170 像素，用 40 像素区分相邻商品
SAME_ITEM_RADIUS = 40
# 商品名与图鉴名字的匹配档位：exact=去掉符号小写后完全相等；near=差距在阈值内或名字被截断；
# unknown=差距过大，按不在图鉴里处理
TIER_EXACT = "exact"
TIER_NEAR = "near"
TIER_UNKNOWN = "unknown"
# 模糊匹配允许的最大字符修改次数（增、删、改各算一次）：没有完全相等时取最近的一条图鉴名字
MAX_NAME_EDITS = 2
# 太短的规范化名字做模糊匹配容易误配，长度不足时只按完全相等匹配
MIN_NEAR_LENGTH = 5
# Cost 阈值只在上层 sub_workflow.mirror_shop 决定是否刷新时使用，本步买饰品不受阈值限制：
# 属于本队且能买下的饰品全部买完，Cost 只读来写日志
# 点击商品卡片后等待详情滑入的固定时间
CLICK_WAIT_SECONDS = 1.5
# 商品详情弹窗：标题 Purchase E.G.O Gifts 用素材 mirror/shop/purchase_ego_gifts（351x25）匹配；
# 不再检测底部 Cancel／Purchase 按钮，购买按钮直接点固定坐标
DETAIL_TITLE_ASSET = "mirror/shop/purchase_ego_gifts"
DETAIL_TITLE_REGION = {"x": 340, "y": 140, "width": 420, "height": 60}
DETAIL_TITLE_THRESHOLD = 0.85
PURCHASE_POINT = (760, 480)
# 已买过（Purchased）的商品卡再点一次不会打开 Purchase E.G.O Gifts，而是弹出只读的 E.G.O Gift Info 弹窗
# （只有 Confirm）：它压暗商店页，刷新按钮模板与 Shop 标题都会失效，上层会误判成「已不是商店页」。
# 标题区覆盖现场标题框 (553,168)~(726,198)；按钮区只覆盖 y>=500 的 Confirm，
# 购买弹窗在 y≈468~497 没有 Confirm，不会被误判成这个弹窗。
GIFT_INFO_TITLE_REGION = {"x": 520, "y": 160, "width": 240, "height": 46}
GIFT_INFO_TITLE_KEYWORD = "egogiftinfo"
GIFT_INFO_BUTTON_REGION = {"x": 430, "y": 500, "width": 400, "height": 70}
GIFT_INFO_CONFIRM_LABEL = "confirm"
# 识别不到 Purchase 文字时的兜底落点（1280x720 实测）
PURCHASE_FALLBACK = (771, 483)
# 购买后到手弹窗 E.G.O Gift GET!：按一次 Enter 确认，仍看到标题时用 Confirm 兜底
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
GIFT_GET_CONFIRM_REGION = {"x": 250, "y": 150, "width": 720, "height": 450}
GIFT_GET_CONFIRM_LABEL = "confirm"
GIFT_GET_CONFIRM_FALLBACK = (765, 495)
# 商店联网反馈：本步不再单独检测 Server Error 弹窗，全部交给上层每轮的通用过渡检测
# （step.detect_normal_transition 命中即抛错交恢复规则，加载过渡也由它统一等待）
# 商店购买流派：队伍配置页「镜牢饰品偏好」下方新增的「商店购买饰品流派」多选标签，
# 按队伍保存成 teams[].shop_keywords（可以同时选中多个流派）；饰品买不买只看这个集合。
# 旧配置没有这个键时退回单选的初始饰品流派 gift_keyword，让旧队伍的购买范围与改动前一致。
MIRROR_PAGE_ID = "mirror.settings"
TEAM_PAGE_ID = "sinners.team_presets"
TEAMS_KEY = "teams"
SHOP_KEYWORDS_KEY = "shop_keywords"
INITIAL_KEYWORD_KEY = "gift_keyword"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
KEYWORD_NONE = "none"
# 镜牢设置页「饰品配置」只保存获取偏好：{饰品逻辑名: prefer|default|consume}
SHOP_GIFTS_KEY = "shop_gifts"
# 素材库镜像的饰品键形状：mirror/gift/<流派>/<名字>；名字就是素材目录名（最后一段）
GIFT_ID_PATTERN = re.compile(r"mirror/gift/[a-zA-Z_][a-zA-Z0-9_-]*/[a-zA-Z_][a-zA-Z0-9_-]*")
# 饰品获取偏好：prefer（优先获取）的饰品在商店里不受本队购买流派限制，
# 流派不在选中集合里也照买；其余取值沿用原来的流派判断；键缺失时全部按默认获取处理。
GIFT_PREFERENCE_KEY = "preferences"
PREFERENCE_PREFER = "prefer"
# 「优先购买未记录饰品」：镜牢设置页「商店设置」页的复选框，缺失、非布尔值或非法时按关闭处理。
# 打开后，名字与图鉴所有条目差距都过大的商品（未记录饰品）也照买，不受本队购买流派限制；
# 关闭时保持改动前的行为——按不在图鉴里处理、不购买。
SHOP_UNRECORDED_KEY = "shop_buy_unrecorded_gifts"
DEFAULT_SHOP_UNRECORDED = False
# 动作之后的固定等待
AFTER_ACTION_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，保留所有语言的字母，避免 OCR 断字影响文字匹配。"""
    return "".join(char for char in unicodedata.normalize("NFKC", str(text)).casefold() if char.isalnum())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _in_shop(ctx: RunContext) -> bool:
    """当前帧是否为镜牢商店页：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题。"""
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


def _labeled(labels: list[tuple[int, int]], center: tuple[int, int]) -> bool:
    """名字行上方是否读到 Purchased 标签：只做几何比对，不再为每张卡单独 OCR。"""
    x, y = int(center[0]), int(center[1])
    return any(
        abs(label_x - x) <= GIFT_PURCHASED_TOLERANCE_X
        and GIFT_PURCHASED_TOP <= label_y - y <= GIFT_PURCHASED_BOTTOM
        for label_x, label_y in labels
    )


def _scan_shelf(ctx: RunContext) -> list[tuple[int, int, str, bool]]:
    """
    对当前帧商品列表做一次局部 OCR，同时读出商品卡名字行与卡片上方的状态标签，
    再按几何位置配对，返回 [(名字行中心 x, 名字行中心 y, 文字, 是否已买过)]，按坐标排序。
    名字行只保留有字母且长度、分数达标的文字，价格数字与单字符噪声因此被过滤；
    Replace … Skill 属于技能替换商品、Purchased 标签本身也不能当成一件商品，两者都排除；
    买不起的商品卡名字行常被 Not Enough Cost 状态标签取代，读不出商品名也点不开详情；
    名字行仍然读得出来时（标签就在名字行正上方，与 Purchased 同一套几何关系）也按买不起处理，
    不当作待处理商品、不做任何购买输入（否则会反复点击买不起的卡片，只弹出只读的 E.G.O Gift Info）。
    """
    result = ctx.action("observe.ocr", region=SHOP_ITEM_REGION) or {}
    cards: list[tuple[int, int, str]] = []
    labels: list[tuple[int, int]] = []
    blocked: list[tuple[int, int]] = []
    for item in result.get("items") or []:
        text = str(item.get("text", "")).strip()
        if not text:
            continue
        flat = _norm(text)
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if PURCHASED_LABEL_KEYWORD in flat:
            labels.append((x, y))
            continue
        if any(keyword in flat for keyword in UNAFFORDABLE_KEYWORDS):
            blocked.append((x, y))
            continue
        if len(flat) < NAME_MIN_LENGTH:
            continue
        if float(item.get("score") or 0.0) < NAME_MIN_SCORE:
            continue
        if not any(char.isalpha() for char in text):
            continue
        if SKILL_NAME_KEYWORD in flat:
            continue
        same = None
        for index, kept in enumerate(cards):
            if (
                abs(x - kept[0]) <= SAME_CARD_TOLERANCE_X
                and abs(y - kept[1]) <= SAME_CARD_TOLERANCE_Y
            ):
                same = index
                break
        if same is None:
            cards.append((x, y, text))
            continue
        # 名字太长被 OCR 拆成上下两行：按 y 顺序拼成一条，锚点保留最上面那一行
        kept_x, kept_y, kept_text = cards[same]
        if y < kept_y:
            cards[same] = (x, y, f"{text} {kept_text}")
        else:
            cards[same] = (kept_x, kept_y, f"{kept_text} {text}")
    labels.sort()
    blocked.sort()
    if blocked:
        # 买不起的位置每帧都可能出现，属于正常识别细节，按 debug 记录（开发者要求）
        ctx.log(
            f"商品区有 {len(blocked)} 个位置显示 Not Enough Cost（Cost 不够买），"
            "名字行被状态标签取代，本步不把它们当成饰品商品、也不点击",
            level="debug",
            screenshot=True,
        )
    # 买不起的商品卡：状态标签就在名字行正上方，与 Purchased 同一套几何关系。
    # Run 487 里这种卡片（Thunderbranch）的名字行仍然读得出来，被当成待买商品反复点击，
    # 每次只弹出只读的 E.G.O Gift Info，已处理记录不增加，最后撞上停滞保护，因此这里一并剔除。
    unaffordable = [(x, y, text) for x, y, text in cards if _labeled(blocked, (x, y))]
    if unaffordable:
        # 买不起的商品卡属正常识别细节，按 debug 记录（开发者要求）
        ctx.log(
            "这些名字行上方是 Not Enough Cost 标签（Cost 不够买），按买不起处理、不点击："
            + "; ".join(f"{text!r}@({x},{y})" for x, y, text in unaffordable),
            level="debug",
            screenshot=True,
        )
        cards = [(x, y, text) for x, y, text in cards if not _labeled(blocked, (x, y))]
    paired = [(x, y, text, _labeled(labels, (x, y))) for x, y, text in cards]
    paired.sort(key=lambda entry: (entry[1], entry[0]))
    return paired


def _handled(ctx: RunContext) -> list:
    """返回本次商店已决定过的饰品商品记录（名字 + 坐标 + 是否已点过 Purchase）。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        return []
    record = runtime.get(HANDLED_KEY)
    return record if isinstance(record, list) else []


def _mark_handled(ctx: RunContext, name: str, center: tuple[int, int], *, bought: bool) -> None:
    """
    记录本次商店已经决定过的一件饰品商品。
    名字是主要判据：商品被买走后下方商品会上移，坐标会变、名字不变；
    坐标只留给没有名字的旧记录按位置跳过。bought 表示这件商品已经点过 Purchase（不可重放）。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录商店饰品商品处理结果", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    record = runtime.get(HANDLED_KEY)
    if not isinstance(record, list):
        record = []
    record.append(
        {"name": str(name or ""), "x": int(center[0]), "y": int(center[1]), "bought": bool(bought)}
    )
    runtime[HANDLED_KEY] = record
    settings[RUNTIME_KEY] = runtime


def _remaining(record: list) -> tuple[dict[str, int], list[dict]]:
    """
    把已处理记录拆成两份：{规范化名字: 剩余可跳过次数} 与没有名字的旧记录。
    同名商品各算一次，避免一件被买走后同名的另一件被一起跳过。
    """
    names: dict[str, int] = {}
    legacy: list[dict] = []
    for item in record:
        if not isinstance(item, dict):
            continue
        name = _norm(item.get("name") or "")
        if name:
            names[name] = names.get(name, 0) + 1
        else:
            legacy.append(item)
    return names, legacy


def _position_recorded(entries: list[dict], center: tuple[int, int]) -> bool:
    """没有名字的记录按坐标判断：半径内算同一个位置。"""
    x, y = int(center[0]), int(center[1])
    for item in entries:
        if item.get("x") is None or item.get("y") is None:
            continue
        if (
            abs(x - int(item["x"])) <= SAME_ITEM_RADIUS
            and abs(y - int(item["y"])) <= SAME_ITEM_RADIUS
        ):
            return True
    return False


def _detail_open(ctx: RunContext) -> bool:
    """当前帧是否已打开饰品商品详情：标题用素材 mirror/shop/purchase_ego_gifts 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=DETAIL_TITLE_ASSET,
            region=DETAIL_TITLE_REGION,
            threshold=DETAIL_TITLE_THRESHOLD,
        )
    )


def _gift_info_open(ctx: RunContext) -> bool:
    """
    当前帧是否叠着只读的 E.G.O Gift Info 弹窗（点已买过的商品卡会弹出）。
    标题 E.G.O Gift Info 为主；标题漏识别时用按钮区的 Confirm 兜底。该按钮区只覆盖 y>=500，
    购买弹窗在 y≈468~497 没有 Confirm，且详情弹窗不再检测按钮，因此不会被误判成这个弹窗。
    """
    if GIFT_INFO_TITLE_KEYWORD in _region_text(ctx, GIFT_INFO_TITLE_REGION):
        return True
    buttons = ctx.action("observe.ocr", region=GIFT_INFO_BUTTON_REGION) or {}
    labels = {_norm(item.get("text", "")) for item in buttons.get("items") or []}
    return GIFT_INFO_CONFIRM_LABEL in labels


def _close_gift_info(ctx: RunContext) -> bool:
    """
    只关闭只读的 E.G.O Gift Info 弹窗：先点 OCR 到的 Confirm，识别不到时按一次 Enter；
    仍看到标题时补按一次 Enter。返回弹窗是否已经关掉，关不掉就交回上层按分支上限处理，不在这里空转。
    """
    result = ctx.action("observe.ocr", region=GIFT_INFO_BUTTON_REGION) or {}
    point = None
    for item in result.get("items") or []:
        if _norm(item.get("text", "")) != GIFT_INFO_CONFIRM_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            point = (int(center[0]), int(center[1]))
            break
    if point is None:
        ctx.log("E.G.O Gift Info 弹窗没有读到 Confirm，按一次 Enter 关闭", level="warning")
        ctx.action("control.key_press", key="enter")
    else:
        ctx.log(f"识别到只读的 E.G.O Gift Info 弹窗，点击 Confirm {point} 关闭（不做任何购买输入）")
        ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
    ctx.action("observe.capture_screen")
    if not _gift_info_open(ctx):
        return True
    ctx.log(
        "点击 Confirm 后 E.G.O Gift Info 弹窗仍在，补按一次 Enter",
        level="warning",
        screenshot=True,
    )
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
    ctx.action("observe.capture_screen")
    return not _gift_info_open(ctx)


def _settings(ctx: RunContext) -> dict:
    """RunState.settings；不可用时按空字典处理。"""
    settings = ctx.run_state.settings
    return settings if isinstance(settings, dict) else {}


def _team_index(ctx: RunContext) -> int:
    """本场镜牢实际使用的队伍序号：只读 mirror.runtime.team_used；缺失时按第 1 个队伍处理。"""
    runtime = _settings(ctx).get(RUNTIME_KEY)
    used = runtime.get(TEAM_USED_KEY) if isinstance(runtime, dict) else None
    if type(used) is int and 1 <= used <= MAX_TEAMS:
        return used
    ctx.log(
        f"没有可用的本场队伍记录 {TEAM_USED_KEY}={used!r}，按第{DEFAULT_TEAM}个队伍处理",
        level="warning",
    )
    return DEFAULT_TEAM


def _shop_keywords(ctx: RunContext) -> set[str]:
    """读取本场镜牢使用队伍（按轮换后的实际队伍）勾选的「商店购买饰品流派」，返回归一化后的键集合。

    优先用队伍配置页的 teams[].shop_keywords（多选）；旧配置没有这个键时退回单选的初始饰品流派
    gift_keyword，让旧队伍的购买范围与改动前一致。没有队伍条目、集合为空或只有「不选择流派」时
    返回空集合，调用方据此不购买任何饰品。
    """
    settings = _settings(ctx)
    team_index = _team_index(ctx)
    teams_page = settings.get(TEAM_PAGE_ID) or {}
    teams = teams_page.get(TEAMS_KEY) if isinstance(teams_page, dict) else None
    if not isinstance(teams, list) or not 1 <= team_index <= len(teams):
        ctx.log(f"队伍配置里没有第{team_index}个队伍，本次不购买饰品", level="warning")
        return set()
    entry = teams[team_index - 1]
    if not isinstance(entry, dict):
        return set()
    raw = entry.get(SHOP_KEYWORDS_KEY)
    if isinstance(raw, list):
        picked = {_archetype_key(value) for value in raw if str(value).strip()}
        return picked
    keyword = str(entry.get(INITIAL_KEYWORD_KEY) or "").strip().casefold()
    if not keyword or keyword == KEYWORD_NONE:
        return set()
    ctx.log(
        f"队伍配置里没有「商店购买饰品流派」多选，退回初始饰品流派 {keyword!r}"
        "（与改动前一致；在队伍配置页勾选标签后按多选判断）"
    )
    return {_archetype_key(keyword)}


def _gift_mirror(ctx: RunContext) -> dict[str, str]:
    """
    素材库镜像里的饰品名单：键是 mirror/gift/<流派>/<名字>，值是该饰品的获取偏好。
    镜牢设置页「饰品配置」每次显示／保存都按素材目录重建，手工直接加进素材库的饰品也会带一条
    default 偏好；工作流无法直接枚举素材库，也不再维护单独的饰品图鉴资源，所以这里以这份配置为准。
    形状不符的旧键一律忽略。
    """
    page = _settings(ctx).get(MIRROR_PAGE_ID) or {}
    gifts = page.get(SHOP_GIFTS_KEY) if isinstance(page, dict) else None
    raw = gifts.get(GIFT_PREFERENCE_KEY) if isinstance(gifts, dict) else None
    if not isinstance(raw, dict):
        return {}
    return {
        str(name): str(value) for name, value in raw.items()
        if isinstance(value, str) and GIFT_ID_PATTERN.fullmatch(str(name))
    }


def _gift_name(gift_id: str) -> str:
    """饰品的名字就是素材目录名（mirror/gift/<流派>/<名字> 的最后一段）；不是这个形状时返回空串。"""
    parts = str(gift_id or "").split("/")
    return parts[3] if len(parts) == 4 else ""


def _gift_archetype(gift_id: str) -> str:
    """流派只取素材目录段（mirror/gift/<流派>/<名字> 的第三段）；不是这个形状时返回空串。"""
    parts = str(gift_id or "").split("/")
    return parts[2] if len(parts) == 4 else ""



def _buy_unrecorded(ctx: RunContext) -> bool:
    """读取「优先购买未记录饰品」开关：缺失或非法时按关闭处理，购买范围与改动前一致。"""
    page = _settings(ctx).get(MIRROR_PAGE_ID) or {}
    raw = page.get(SHOP_UNRECORDED_KEY) if isinstance(page, dict) else None
    if raw is None:
        return DEFAULT_SHOP_UNRECORDED
    if isinstance(raw, bool):
        return raw
    ctx.log(
        f"商店设置的「优先购买未记录饰品」取值 {raw!r} 不是布尔值，按关闭处理",
        level="warning",
    )
    return DEFAULT_SHOP_UNRECORDED


def _archetype_key(value: str) -> str:
    """把图鉴流派与页面上的多选标签归一到同一个键。

    - 沉沦：图鉴与现场识别里 sink／sinking 两种写法都算 sinking；
    - 泛用：页面标签用 general，图鉴里无流派饰品记的是 keywordless（镜牢设置页把 keywordless 显示为「泛用」），
      三种写法统一成 keywordless，页面勾选「泛用」就能买到无流派饰品。
    """
    key = _norm(value)
    if key in ("sink", "sinking"):
        return "sinking"
    if key in ("general", "keywordless", "none"):
        return "keywordless"
    return key


def _tokens(text: str) -> list[str]:
    """按非字母数字切分并转小写，得到名字里的词；只用于识别 OCR 把同一个名字的词序读反。"""
    return [token for token in re.split(r"[\W_]+", str(text).casefold()) if token]


def _edit_distance(left: str, right: str, limit: int) -> int | None:
    """有界编辑距离：返回把 left 改成 right 需要的最少字符增删改次数，超过 limit 时返回 None。"""
    if abs(len(left) - len(right)) > limit:
        return None
    previous = list(range(len(right) + 1))
    for row, left_char in enumerate(left, start=1):
        current = [row]
        for column, right_char in enumerate(right, start=1):
            cost = 0 if left_char == right_char else 1
            current.append(
                min(previous[column] + 1, current[column - 1] + 1, previous[column - 1] + cost)
            )
        previous = current
        if min(previous) > limit:
            # 这一行已经全部超过阈值，往下只会更差
            return None
    best = previous[-1]
    return best if best <= limit else None


def _name_match(catalog: dict, name: str) -> tuple[str, str, list[tuple[str, str, str]]]:
    """
    把商品区的名字与素材库镜像名单里的饰品目录名比对，返回 (匹配档位, 说明, 命中的条目)：
    - TIER_EXACT：去掉符号小写后完全相等；OCR 把同一个名字的词序读反（词集合一致）也算这一档；
    - TIER_NEAR：没有完全相等，但与某个饰品目录名最多差 MAX_NAME_EDITS 次字符修改；
      调用方按最近的那一条看待，并记 warning；
    - TIER_UNKNOWN：差距更大或名字太短，按不在名单里（素材库没有这件饰品）处理。
    命中的条目是 (饰品逻辑名, 流派, 饰品目录名)，按匹配程度只返回最好的一批；
    名字就是素材目录名（最后一段），流派只取素材路径的目录段，名单没有名称标签。
    """
    wanted = _norm(name)
    if not wanted:
        return TIER_UNKNOWN, "名字为空", []
    wanted_tokens = _tokens(name)
    exact: list[tuple[str, str, str]] = []
    reordered: list[tuple[str, str, str]] = []
    nearest: list[tuple[int, tuple[str, str, str]]] = []
    for gift_id in catalog:
        leaf = _gift_name(gift_id)
        flat = _norm(leaf)
        if not flat:
            continue
        entry_hit = (str(gift_id), _gift_archetype(gift_id), leaf)
        if flat == wanted:
            exact.append(entry_hit)
            continue
        leaf_tokens = _tokens(leaf)
        if len(leaf_tokens) >= 2 and sorted(leaf_tokens) == sorted(wanted_tokens):
            reordered.append(entry_hit)
            continue
        if len(flat) < MIN_NEAR_LENGTH or len(wanted) < MIN_NEAR_LENGTH:
            continue
        distance = _edit_distance(flat, wanted, MAX_NAME_EDITS)
        if distance is not None:
            nearest.append((distance, entry_hit))
    if exact:
        return TIER_EXACT, "完全相等", exact
    if reordered:
        return TIER_EXACT, "词序不同但用词完全一致", reordered
    if nearest:
        best = min(distance for distance, _ in nearest)
        return (
            TIER_NEAR,
            f"最近差 {best} 次字符修改",
            [record for distance, record in nearest if distance == best],
        )
    return TIER_UNKNOWN, f"与图鉴名字差距超过 {MAX_NAME_EDITS} 次字符修改", []


def _gift_get(ctx: RunContext) -> bool:
    """当前帧是否叠着购买后的 E.G.O Gift GET! 到手弹窗：只用素材 mirror/ego_gift_get 匹配标题横幅。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=GIFT_GET_ASSET,
            region=GIFT_GET_REGION,
            threshold=GIFT_GET_THRESHOLD,
        )
    )


def _confirm_point(ctx: RunContext) -> tuple[int, int] | None:
    """在到手弹窗区域找 Confirm 按钮中心；识别不到返回 None。"""
    result = ctx.action("observe.ocr", region=GIFT_GET_CONFIRM_REGION) or {}
    for item in result.get("items") or []:
        if _norm(item.get("text", "")) != GIFT_GET_CONFIRM_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            return (int(center[0]), int(center[1]))
    return None


def _confirm_gift_get(ctx: RunContext) -> None:
    """按一次 Enter 确认到手弹窗，仍在时点击一次 Confirm 兜底，然后交回。"""
    point = _confirm_point(ctx) or GIFT_GET_CONFIRM_FALLBACK
    ctx.log(f"识别到 E.G.O Gift GET! 到手弹窗，按一次 Enter 确认（仍看到标题时点 Confirm {point}）")
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
    ctx.action("observe.capture_screen")
    if _gift_get(ctx):
        ctx.log(f"按 Enter 后弹窗标题仍在，改用鼠标点击 Confirm {point}", level="info", screenshot=True)
        ctx.action("control.click", x=point[0], y=point[1])
        ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)


def _cost(ctx: RunContext) -> int | None:
    """读当前持有的 Cost：把硬币右侧的数字按横向顺序拼起来；读不到返回 None。"""
    result = ctx.action("observe.ocr", region=COST_REGION) or {}
    parts: list[tuple[int, str]] = []
    for item in result.get("items") or []:
        digits = re.sub(r"[^0-9]", "", str(item.get("text", "")))
        if digits:
            parts.append((int(item["centerxy"][0]), digits))
    if not parts:
        return None
    parts.sort()
    text = "".join(digits for _, digits in parts)
    return int(text) if text.isdigit() else None


def _buy_one(ctx: RunContext, x: int, y: int, text: str) -> bool:
    """
    从商品区名字行出发买下一件饰品：点开名字行正上方的商品卡 → 确认 Purchase E.G.O Gifts 详情 →
    点一次 Purchase，然后立即返回。
    点 Purchase 之前先记录这件商品（购买是不可安全重复的输入，重入不再重放）；
    详情没有打开时不做任何购买输入并返回 False，交回上层重新观察。
    点过 Purchase 后不在这里检测 E.G.O Gift GET! 到手弹窗：只做一段固定等待让画面成形，
    弹窗由上层 sub_workflow.mirror_shop 下一轮重新观察并交回本步确认，避免购买与到手确认挤在同一次调用里。
    """
    if not _open_card(ctx, x, y, text):
        return False
    point = PURCHASE_POINT
    ctx.log(f"详情已打开，按商品区的图鉴结论点击固定坐标的 Purchase {point}")
    ctx.action("control.click", x=point[0], y=point[1])
    _mark_handled(ctx, text, (x, y), bought=True)
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
    ctx.log(
        "Purchase 已点击，本步不再检测 E.G.O Gift GET! 到手弹窗，"
        "交由上层商店循环下一轮重新观察后确认"
    )
    return True


def _open_card(ctx: RunContext, x: int, y: int, text: str) -> bool:
    """
    点一次商品名字行正上方的卡片，并确认 Purchase E.G.O Gifts 详情已经滑入。
    没有识别到详情时返回 False：调用方不做任何购买输入，也不记录这件商品，
    交回上层重新观察（重复点击商品卡本身不花钱）。
    """
    click_x, click_y = x, y + CARD_CLICK_OFFSET_Y
    ctx.log(f"点击一次饰品商品 {text!r}：名字行 ({x}, {y}) 正上方 ({click_x}, {click_y})")
    ctx.action("control.click", x=click_x, y=click_y)
    ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    if _detail_open(ctx):
        return True
    if _gift_info_open(ctx):
        ctx.log(
            f"点击饰品商品 {text!r} 后弹出只读的 E.G.O Gift Info（该位置已买过／坐标已过期），"
            "本批停止购买，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return False
    ctx.log(
        f"点击饰品商品 {text!r} 后没有看到 Purchase E.G.O Gifts 详情，"
        "本次不做购买输入，交回上层重新观察",
        level="warning",
        screenshot=True,
    )
    return False


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    处理镜牢商店的饰品商品：一次商品区 OCR 就把所有饰品分成「买」与「不买」，再按位置规律一次买完。
    - 不再单独检测 Server Error 弹窗：它由上层每轮的通用过渡检测（step.detect_normal_transition）
      统一识别并交恢复规则，本步不在可能被弹窗盖住的按钮上做额外判断；
    - 购买后的 E.G.O Gift GET! 到手弹窗按一次 Enter 确认（仍看到标题时点一次 Confirm 兜底）；
    - 已买过的卡片被再点一次会弹出只读的 E.G.O Gift Info 弹窗：只点一次 Confirm（识别不到时按 Enter）
      关掉它并返回，不做任何购买输入；
    - 详情弹窗已打开但不是本次调用点开的（上一轮没走完或上次中断）→ 按一次 Enter 退出，
      不再用详情复核名字；
    - 既没有详情也不是商店页时零输入返回；
    - 在商店页时对商品区做一次 OCR，读出商品名字行与 Purchased 标签，按名字与镜牢设置页
      「饰品配置」（素材库镜像）匹配（_name_match）：条目就是素材目录 mirror/gift/<流派>/<名字>，
      商品名只与目录名比对；完全相等就按该条目判断；
      没有完全相等时取字符修改次数不超过 MAX_NAME_EDITS 的最近一条名单名字，按它判断并记 warning；
      差距更大、名字太短或不在名单里 → 未记录饰品（素材库没有）：只有「商店设置」的
      「优先购买未记录饰品」打开时才买，否则不买；
    - 买不买由本场队伍在队伍配置页勾选的「商店购买饰品流派」多选决定：名单流派落在选中集合里就买，
      不再只看单选的初始饰品流派；此外「饰品配置」里设为「优先获取」的饰品不受流派限制，
      流派不在选中集合里也照买；集合为空时只买这些优先获取的饰品；
    - 不买的商品只记一笔；要买的商品按从后往前的顺序挑一件买下：购买后商品会移到最后，
      同一行／同列里被买走位置后面的卡片会整体前移（Run 487 实测右侧卡片左移一格），
      同一帧预计算的其余坐标可能落到已买过的卡片上，所以每次调用只点一次 Purchase 就返回，
      剩余商品由上层重新识别商品区后再买；
    - 点过 Purchase 后本步不检测 E.G.O Gift GET! 到手弹窗，只做固定等待就交回：
      弹窗统一由上层 sub_workflow.mirror_shop 下一轮重新观察，识别到再交回本步确认；
    - Cost 阈值不属于本步：上层只在「商品都处理完、需要刷新」时用它决定是否刷新，
      所以这里不因 Cost 停止购买；每件购买前读一次 Cost 只写进日志（读不到也照买）。
    购买是否生效、Cost 是否下降、到手弹窗是否出现都由 sub_workflow.mirror_shop 下一轮重新观察。
    """
    ctx.action("observe.capture_screen")
    if _gift_get(ctx):
        _confirm_gift_get(ctx)
        return {"action": "gift_get_confirmed"}
    if _gift_info_open(ctx):
        # 只读的 E.G.O Gift Info 弹窗会压暗商店页（点已买过的卡片就会弹出）：先关掉，不做购买输入
        closed = _close_gift_info(ctx)
        return {"action": "gift_info_closed" if closed else "gift_info_unclosed"}
    if _detail_open(ctx):
        ctx.log("饰品购买详情已打开但没有待处理的商品，按一次 Enter 关闭详情")
        ctx.action("control.key_press", key="enter")
        ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
        return {"action": "detail_closed"}
    if not _in_shop(ctx):
        ctx.log("当前不是镜牢商店页，不处理饰品商品", level="warning", screenshot=True)
        return {"action": "not_in_shop"}

    # 商品区只在这个入口扫描一次：买与不买都在这一帧决定，买的时候按从后往前的顺序复用坐标
    cards = _scan_shelf(ctx)
    names, legacy = _remaining(_handled(ctx))
    keywords = _shop_keywords(ctx)
    catalog = _gift_mirror(ctx)
    preferences = catalog
    if not catalog:
        ctx.log(
            "「饰品配置」里还没有素材库派生的条目（mirror/gift/<流派>/<名字> 为空），"
            "无法按名字判断饰品属于哪个流派，本步不购买饰品"
            "（在镜牢设置页打开并保存一次即可按素材库重建名单）",
            level="warning",
            screenshot=True,
        )
    else:
        ctx.log(f"饰品名单来自素材库镜像（「饰品配置」）：{len(catalog)} 件饰品参与名字匹配")
    if not keywords:
        ctx.log(
            "本次队伍没有勾选「商店购买饰品流派」，只购买「饰品配置」里设为优先获取的饰品"
            "（在队伍配置页的镜牢饰品偏好里勾选标签后才会按流派买）",
            level="warning",
        )
    else:
        ctx.log(f"本场商店按选中的购买流派 {sorted(keywords)} 判断饰品买不买")
    preferred_ids = [key for key, value in preferences.items() if value == PREFERENCE_PREFER]
    ctx.log(
        f"「饰品配置」里设为优先获取的饰品 {len(preferred_ids)} 件，"
        "这批饰品即使流派不在选中集合里也会购买"
    )
    buy_unrecorded = _buy_unrecorded(ctx)
    ctx.log(
        "「商店设置」的「优先购买未记录饰品」"
        + ("已打开：名字不在名单里的商品也会购买" if buy_unrecorded
           else "未打开：名字不在名单里的商品不购买")
    )

    buys: list[tuple[int, int, str, tuple[str, str, str]]] = []
    excluded = 0
    for x, y, text, purchased in cards:
        key = _norm(text)
        if key and names.get(key, 0) > 0:
            # 本次商店已经决定过这件商品：位置会随商品被买走而前移，名字不变，按名字跳过
            names[key] = names[key] - 1
            continue
        if not key and _position_recorded(legacy, (x, y)):
            continue
        if purchased:
            ctx.log(f"饰品商品 {text!r} 已买过（Purchased），只记录名字 ({x}, {y}) 后跳过")
            _mark_handled(ctx, text, (x, y), bought=True)
            continue
        if not catalog:
            _mark_handled(ctx, text, (x, y), bought=False)
            excluded += 1
            continue
        tier, note, matches = _name_match(catalog, text)
        unique = {item[0]: item for item in matches}
        if len(unique) > 1:
            ctx.log(f"饰品商品 {text!r} 同时匹配多个名单条目 {list(unique)}，跳过购买",
                    level="warning")
            _mark_handled(ctx, text, (x, y), bought=False)
            excluded += 1
            continue
        if tier == TIER_UNKNOWN:
            # 名字与名单所有条目差距都过大：素材库里没有这件饰品（未记录饰品），无法判断流派。
            # 开关打开时按「优先购买未记录饰品」照买，关闭时保持改动前的不买。
            if buy_unrecorded:
                ctx.log(
                    f"饰品商品 {text!r} 与名单所有名字都差距过大（{note}），"
                    "属于未记录饰品；「商店设置」的「优先购买未记录饰品」已打开，本件照买"
                )
                buys.append((x, y, text, ("", "", text)))
                continue
            excluded += 1
            ctx.log(
                f"饰品商品 {text!r} 与名单所有名字都差距过大（{note}），按不在名单里处理，不购买"
                "（可在「商店设置」打开「优先购买未记录饰品」）",
                level="warning",
            )
            _mark_handled(ctx, text, (x, y), bought=False)
            continue
        if tier == TIER_NEAR and matches:
            gift_id, archetype, label = matches[0]
            ctx.log(
                f"饰品商品 {text!r} 与名单里的名字都不完全相等，按最近的名字 {label!r}"
                f"（{gift_id} / {archetype}，{note}）看待",
                level="warning",
            )
        # 买不买：名单流派落在本队的购买流派集合里就买；流派不在集合里、但在「饰品配置」里
        # 设为「优先获取」的饰品同样买（两条件取或，优先获取不受流派限制）
        own = [item for item in unique.values() if _archetype_key(item[1]) in keywords]
        preferred = [item for item in unique.values()
                     if preferences.get(item[0]) == PREFERENCE_PREFER]
        if own or preferred:
            chosen = (own or preferred)[0]
            if not own and preferred:
                ctx.log(
                    f"饰品商品 {text!r} 对应名单 {chosen[2]!r}（{chosen[1]}），"
                    f"流派不在选中的购买流派 {sorted(keywords)} 里，"
                    "但在「饰品配置」里设为优先获取，仍然购买"
                )
            buys.append((x, y, text, chosen))
            continue
        excluded += 1
        if matches:
            ctx.log(
                f"饰品商品 {text!r} 对应名单 {matches[0][2]!r}（{matches[0][1]}），"
                f"不在选中的商店购买流派 {sorted(keywords)} 里，也未设为优先获取，不购买"
            )
        _mark_handled(ctx, text, (x, y), bought=False)

    if not buys:
        ctx.log(
            f"本次商品区 {len(cards)} 个名字行：没有需要购买的饰品（不买 {excluded} 件），本步不做购买输入"
        )
        return {
            "action": "batch_done",
            "bought": "0",
            "excluded": str(excluded),
            "pending": "0",
        }

    ctx.log(
        f"本次商品区 {len(cards)} 个名字行：{len(buys)} 件要买、{excluded} 件不买；"
        "按从后往前的顺序挑一件买下，买走后商品区会重排，剩余商品交回上层重新识别后再买"
    )
    bought = 0
    pending = len(buys)
    for x, y, text, match in reversed(buys):
        # Cost 只用于日志：阈值只限制刷新，属于本队且买得起的饰品一次调用就买这一件
        cost = _cost(ctx)
        gift_id, archetype, label = match
        member = _archetype_key(archetype) in keywords
        if not gift_id:
            # 未记录饰品：名单里没有对应条目（素材库没有这件饰品），按「优先购买未记录饰品」购买
            detail = "未记录饰品（名单里没有这个名字）"
            reason = "按「商店设置」的「优先购买未记录饰品」购买"
        elif member:
            detail = f"名单 {label!r} / {gift_id} / {archetype}"
            reason = f"属于选中的购买流派 {_archetype_key(archetype)}"
        else:
            detail = f"名单 {label!r} / {gift_id} / {archetype}"
            reason = "流派不在选中集合，但设为优先获取"
        ctx.log(
            f"购买 {text!r}（{detail}，{reason}），"
            f"购买前 Cost {cost if cost is not None else '未读到'}"
        )
        if not _buy_one(ctx, x, y, text):
            break
        bought += 1
        pending -= 1
        # 买走一件后商品区会重排，同一帧预计算的其余坐标不再可靠：只买一件就交回上层重新 OCR
        if pending:
            ctx.log(
                f"已买入 {text!r}，商品区会重排，剩余 {pending} 件交回上层重新识别商品区后再买"
            )
        break
    return {
        "action": "batch_done",
        "bought": str(bought),
        "excluded": str(excluded),
        "pending": str(pending),
    }
