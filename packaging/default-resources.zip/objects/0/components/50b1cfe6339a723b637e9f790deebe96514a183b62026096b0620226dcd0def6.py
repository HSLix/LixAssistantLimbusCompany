"""仅编排寻路局部目标，每次推进后重新观察。"""
import random

from lalc import RunContext, sub_workflow, ExecutionFailure

# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上就算寻路界面；
# 不再用左上角 Exploring 文字，那段文字会忽明忽暗闪烁，读不到不能当作离开寻路界面
PATH_ICON_ASSETS = ("mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects")
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2
TRAIN_ASSET = "mirror/train_head"
# 火车头只用特征匹配（SIFT）：模板匹配回退已移除，失配即视为找不到火车头
# 火车头归位目标与容差，与 step.mirror_path_train_head_drag 的默认值一致；
# 容差 ±40：快拖的位移兑现率在 0.91~1.4 之间摆动（Run 592 实测 235px/s 长拖落在 (161,330)），
# ±20 时每次都要再补拖一次，±40 后这种常见落点直接算归位，节点列识别本身仍按 ±70 容差归列。
TARGET_X = 140
TARGET_Y = 330
TARGET_TOLERANCE = 40
# 节点确认弹窗右下角的 Enter 按钮图标与区域（与 step.mirror_path_enter_node 一致）
ENTER_ASSET = "mirror/path/enter_button"
CONFIRM_REGION = {"x": 1020, "y": 460, "width": 260, "height": 150}
# 弹窗打开时右下角这颗按钮带 Enter 文案；按钮图标模板只有 70x70 的图标本体，
# Run 645 现场（证据 645/118）弹窗明明开着、模板却十次观察全部空结果（645/106~645/122），
# 主循环因此一直判成「没有 Enter」，继续点候选和保底固定点。这里补一条同一区域的 OCR 兜底：
# 归一化文本里出现 enter 就按弹窗已打开处理，不再只依赖那一个模板。
ENTER_TEXT = "enter"
# 点击节点／火车头后的有界观察：点下去可能先进入 CONNECTING／Now Loading 过渡（Run 645 现场），
# 也可能直接弹出确认弹窗，所以每轮新截一帧：过渡交给通用等待，过渡结束后再看 Enter 与寻路页标识。
AFTER_CLICK_POLLS = 5
AFTER_CLICK_POLL_SECONDS = 1.0
# 点击后的过渡最多让本层等待几轮：一次 step.wait_normal_transition 已含 30 秒预算，
# 等完仍是加载态就交回 task.mirror（它每轮都会先处理过渡），不在本层无限等下去
MAX_CLICK_TRANSITION_WAITS = 1
# 交回前固定等待：按 Enter 后等 1 秒让节点加载起步，然后直接退回 task.mirror 大循环重新分派
ENTER_SETTLE_SECONDS = 1.0
# 节点识别与路线规划都在 step.mirror_path_select_node 内完成：本层只读它返回的
# first_count（第一列识别到几个节点）与 clicked（本次是否点击），不再复制一份识别逻辑
# 火车头复位预算：火车头离开 (140,330)±TARGET_TOLERANCE 就是一个复位周期。
# 拖拽 Step 已不限单次位移（速度按残差距离分档 200/150/100px/s），并按统一收手系数 0.9 只走残差的 90%，
# 火车头在地图最右边时（残差上千像素）需要连拖几次，所以预算改成“有进展就续期”：
# 每次拖拽后离目标比上一轮更近至少 PROGRESS_MIN_PX 就把计数清零，否则累加，
# 连续 MAX_HEAD_RESET_ATTEMPTS 次没有明显靠近才失败
PROGRESS_MIN_PX = 10
MAX_HEAD_RESET_ATTEMPTS = 6
# 寻路页里找不到火车头（被拖到画面左/右侧）时的平移找回次数：先向右、再向左各试一次，
# 仍找不到才判 page=exit（以前直接退出，会让 task.mirror 退出整场镜牢，Run 593 就是这样）
MAX_HEAD_FIND_ATTEMPTS = 2
# 保底固定点与 step.mirror_path_probe_node 的 PROBE_POINTS 一一对应：第一列（x=380）
# 上/中/下三个固定 y 坐标。每开始一轮保底先用 random.shuffle 打乱这三个点的点击顺序，
# 再按打乱后的顺序逐个点击，每点一个就检测一次 Enter，只有上一个点没带出 Enter 才点下一个；
# 同一轮内不重复点同一个点，三个点组成一轮保底，最多 MAX_PROBE_ROUNDS 轮（每轮重新打乱）
PROBE_POINT_COUNT = 3
MAX_PROBE_ROUNDS = 3
# 保底固定点下标 → 第一列行号：下标 1=(380,350)、2=(380,130)、3=(380,560)，
# 行号按 step.mirror_path_select_node 的三等分规则算（(y-50)//190，行高 190）：
# 2→上行(0)、1→中行(1)、3→下行(2)。
# 第一列已经点过的行，保底阶段跳过同行的固定点，不在同一行同一列 x 上重复点刚点过的位置；
# 例如第一列点过上行（y 最小），保底里 y 最小的 (380,130) 就不再点
PROBE_POINT_ROWS = {1: 1, 2: 0, 3: 2}
# 第一列的行数（上/中/下）：step.mirror_path_select_node 返回的 row 落在这个范围内才记录
ROW_COUNT = 3
ROW_LABELS = ("上", "中", "下")


def _path_icons(ctx: RunContext) -> int:
    """对当前帧右上角匹配三个按钮素材，返回命中数量；不刷新截图。"""
    return sum(
        1
        for asset in PATH_ICON_ASSETS
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )


def _train_head_center(ctx: RunContext) -> tuple[int, int] | None:
    """对当前帧检测火车头并返回分数最高一处的中心；未命中返回 None。"""
    matches = ctx.action("observe.match_feature", asset=TRAIN_ASSET) or []
    if not matches:
        return None
    if len(matches) > 1:
        centers = [match.get("centerxy") for match in matches]
        ctx.log(f"火车头同时命中{len(matches)}处：{centers}，按最高分命中处理", level="warning")
    best = max(matches, key=lambda item: float(item.get("score", 0.0)))
    center = best.get("centerxy") or (0, 0)
    return int(center[0]), int(center[1])


def _enter_prompt(ctx: RunContext) -> str:
    """
    判断当前帧右下角是否已有节点确认弹窗：先匹配 Enter 按钮图标，再用同一区域的 OCR 文案兜底，
    返回命中方式（用于日志）；都没有命中返回空字符串。不截图、不换帧。
    """
    if ctx.action("observe.match_asset", asset=ENTER_ASSET, region=CONFIRM_REGION):
        return "Enter 按钮模板"
    result = ctx.action("observe.ocr", region=CONFIRM_REGION) or {}
    text = "".join(
        "".join(char for char in str(item.get("text", "")).lower() if char.isalnum())
        for item in (result.get("items") or [])
    )
    if ENTER_TEXT in text:
        return "右下角 Enter 文案"
    return ""


def _observe_after_click(ctx: RunContext, round_index: int, action: str) -> str:
    """
    点击节点／火车头后的有界观察，返回 enter（确认弹窗已出现）、path（仍在寻路页）或 left（两者都不成立）。
    每轮新截一帧：先交通用过渡检测，CONNECTING／Now Loading 期间只等待过渡结束（过渡本身也是点节点后的
    常见状态）；过渡结束后看右下角 Enter，命中就交调用方按一次 Enter；再看右上角寻路按钮，命中两个以上
    说明还停在寻路页，交调用方继续换候选或下一个固定点；整段观察都没有 Enter 也没有寻路按钮才返回 left，
    由调用方交回 task.mirror 重新分派。本函数不检测、不拖拽火车头。
    """
    transitions = 0
    for attempt in range(1, AFTER_CLICK_POLLS + 1):
        meta = ctx.action("observe.capture_screen")
        if ctx.call(
            "step.detect_normal_transition",
            width=int(meta["width"]),
            height=int(meta["height"]),
        ):
            transitions += 1
            if transitions > MAX_CLICK_TRANSITION_WAITS:
                ctx.log(
                    f"第{round_index}轮：{action}后的正常加载／联网过渡仍未结束，"
                    "交回 task.mirror 按其过渡处理继续等待",
                    level="warning",
                    screenshot=True,
                )
                return "left"
            ctx.log(
                f"第{round_index}轮：{action}后处于正常加载／联网过渡"
                f"（第 {attempt}/{AFTER_CLICK_POLLS} 次观察），先等待过渡结束"
            )
            ctx.call("step.wait_normal_transition")
            continue
        how = _enter_prompt(ctx)
        if how:
            ctx.log(
                f"第{round_index}轮：{action}后检测到 {how}，"
                "直接调用 step.mirror_path_enter_node"
            )
            return "enter"
        if _path_icons(ctx) >= MIN_PATH_ICONS:
            ctx.log(f"第{round_index}轮：{action}后右上角寻路按钮仍在且没有 Enter，继续寻路")
            return "path"
        if attempt < AFTER_CLICK_POLLS:
            ctx.action("observe.wait", seconds=AFTER_CLICK_POLL_SECONDS)
    ctx.log(
        f"第{round_index}轮：{action}后观察 {AFTER_CLICK_POLLS} 轮既没有 Enter 也没有寻路按钮，"
        "判定已不在寻路界面，交回 task.mirror 重新分派",
        level="warning",
        screenshot=True,
    )
    return "left"


def _return_after_enter(ctx: RunContext, round_index: int, reason: str) -> dict[str, str | bool]:
    """
    按 Enter 之后的统一退出：固定等 ENTER_SETTLE_SECONDS 秒，然后直接把结果交回 task.mirror 大循环，
    不再在本层重新截图观察。进入节点后的情景（战斗、商店、事件、下层寻路等）全部由 task.mirror 的
    整屏情景分派重新识别，本层不做也不猜测。
    """
    ctx.action("observe.wait", seconds=ENTER_SETTLE_SECONDS)
    ctx.log(
        f"第{round_index}轮：{reason}，等 {ENTER_SETTLE_SECONDS} 秒后直接退出寻路子流程，"
        "交回大循环重新分派"
    )
    return {"completed": True, "reason": reason, "page": "entered"}


@sub_workflow
def execute(ctx: RunContext) -> dict[str, str | bool]:
    """
    观察驱动的寻路编排：每轮先截图，再按当前画面选一个推进动作，动作后回到循环顶部重新观察。
    优先级：先等正常过渡；再判右下角节点确认弹窗（Enter 按钮模板，或同一区域的 Enter 文案兜底），
    命中就调一次 step.mirror_path_enter_node，等 1 秒后直接退出子流程；
    任何一次按 Enter 之后都不再留在本层观察：固定等 1 秒就返回 page=entered，
    由 task.mirror 下一轮重新截图判断已进入哪种情景。
    还没开始点节点时：右上角寻路界面标识与火车头共同判定是否在寻路页；
    在寻路页但找不到火车头 → 先用 step.mirror_path_train_head_drag 的平移找回向右、再向左各试一次，
    仍找不到才 page=exit，交上层调用退出镜牢流程。
    火车头不在 (140,330)±40 时直接调一次 step.mirror_path_train_head_drag 把火车头拖回起点，
    不再先点一次火车头做探针（Run 588 里那个探针每次要 2.1 秒、后面还白跑一整轮观察，
    整场从未因此带出过 Enter）；拖拽 Step 统一按 0.9 收手，速度按距离分档
    （≥600px 用 200px/s、≤300px 用 100px/s、中间 150px/s），
    火车头在地图最右边时分几次拖回，只要每轮离目标更近（PROGRESS_MIN_PX）就续期。
    点火车头的动作改到最后：只有候选和三个保底固定点都没带出 Enter 才点一次，整张地图只点一次，
    作为“当前所在节点需要点一下才弹确认框”的兵底，点完同样立刻复查 Enter。
    第一列还有没试过的候选 → 调一次 step.mirror_path_select_node：它内部识别三列、
    按节点权重与可能交错线路成本规划，点成本最低的候选；第一列只有一个节点时跳过规划直接点击；
    第一列候选全部试过仍没有 Enter 或第一列本来没有节点 → 进入保底阶段，逐个调用
    step.mirror_path_probe_node（第一列三个固定点的保底）：每开始一轮保底先用 random.shuffle
    打乱三个固定点的点击顺序，一次调用只点本轮顺序里的一个固定点，点完等 1 秒交回、立刻检测 Enter，
    没出现才在下一轮点顺序里的下一个固定点；三个固定点都试完仍没有 Enter 时，先点一次火车头
    （整张地图只点这一次）并复查 Enter；仍没有才重新开始下一轮保底并重新打乱顺序，
    最多 MAX_PROBE_ROUNDS 轮，超出抛 path_probe_exhausted。
    保底固定点按第一列已经点过的行跳过：step.mirror_path_select_node 返回本次点击的 row，
    第一列点过某一行（上/中/下）之后，保底里同一行的固定点不再点击，只点剩余固定点；
    例如第一列点过上行（y 最小）就不再点保底里 y 最小的 (380,130)，
    避免在同一行的同一列 x 上重复点刚点过的位置。三行都点过时保底没有可点的固定点，
    直接进入点火车头兜底，点过火车头仍失败即抛 path_probe_exhausted。
    火车头一旦确认已在 (140,330)±TARGET_TOLERANCE，本张地图后续轮次不再做全屏 SIFT 检测，
    直接按已归位处理；只有换图（正常过渡）或右上角寻路按钮不足时才重新检测一次。
    一旦开始点第一列候选或保底固定点（node_click_started），本张地图不再检测、拖拽、平移找火车头：
    点开节点后火车头会变成选中高亮外观，SIFT 会把它误认成「火车头不在起点」并反复拖拽
    （Run 645 现场连拖六次，Enter 弹窗一直没被按下）。这一段只按右上角按钮确认仍在寻路页，
    按钮不足两个且没有 Enter 时才返回 page=not_path，交 task.mirror 重新分派；
    中途出现正常过渡（CONNECTING／Now Loading）也只等待，不复位候选／保底计数，
    避免加载结束后重复点刚点过的同一节点。
    第一列还有没试过的候选 → 调一次 step.mirror_path_select_node：它内部识别三列、
    按节点权重与可能交错线路成本规划，点成本最低的候选；第一列只有一个节点时跳过规划直接点击；
    第一列候选全部试过仍没有 Enter 或第一列本来没有节点 → 进入保底阶段，逐个调用
    step.mirror_path_probe_node（第一列三个固定点的保底）：每开始一轮保底先用 random.shuffle
    打乱三个固定点的点击顺序，一次调用只点本轮顺序里的一个固定点，点完等 1 秒交回、立刻检测 Enter，
    没出现才在下一轮点顺序里的下一个固定点；三个固定点都试完仍没有 Enter 才重新开始下一轮
    保底并重新打乱顺序，最多 MAX_PROBE_ROUNDS 轮，超出抛 path_probe_exhausted。
    保底阶段本张地图不再重跑 step.mirror_path_select_node（该步含三次 SIFT，实测约 3 秒），
    只有换图（正常过渡，probe_stage 复位）才重新回到候选识别阶段。
    某个候选点下去没弹出 Enter 确认弹窗（例如节点不可点），下一轮 attempt 加一，
    换本次规划里的下一个候选，直到列内候选点完才走固定点保底。
    每次候选点击或保底点击后，点击 Step 内已固定等待 1 秒，
    编排层再新截帧做有界观察：先处理 CONNECTING／Now Loading 过渡，过渡结束检测 Enter，
    命中就调用一次 step.mirror_path_enter_node，再等 1 秒后直接返回（page=entered），
    不在本层继续观察已进入的节点情景。
    顶部那条「已有 Enter 就按一次」的分支同样按 Enter 后等 1 秒退出，
    作为点／拖火车头之后以及漏检时的兜底。
    各动作 Step 只执行一次；本层读 step.mirror_path_select_node 返回的 first_count 与 clicked，
    不再复制节点识别逻辑。
    是否已进入节点、进入后属于哪种情景不在本层判定，交给 task.mirror 的整屏情景分派。
    """
    previous_branch = ""
    consecutive_hits = 0
    # 本张地图是否已经在保底点击之后点过一次火车头：整张地图只点一次，
    # 只在三个保底固定点都没带出 Enter 之后才点；换图（正常过渡）复位，
    # 用来覆盖“当前所在节点需要点一下才弹确认框”的情况
    head_clicked = False
    # 火车头复位预算：有进展就续期（单次手势最多 300px，最右边要连拖几次）；
    # head_drag_index 只用于给分支加序号，避免连续拖拽撞上“同一分支第四次”上限
    head_reset_attempts = 0
    head_drag_index = 0
    last_head_distance: int | None = None
    # 本轮已经用了几次“找不到火车头”的平移找回
    head_find_attempts = 0
    # 当前地图的火车头是否已确认归位：确认后不再每轮做全屏 SIFT（每次约 0.9 秒），
    # 只有换图（正常过渡）或右上角寻路按钮不足时才重新检测一次
    head_home_confirmed = False
    # 是否已经开始点第一列候选／保底固定点：一旦开始，本张地图不再检测、拖拽、平移找火车头
    # （Run 645：点开节点后火车头变成选中高亮外观，SIFT 在 (331,232)/(469,258) 反复命中，
    # 主循环把「火车头不在起点」当成地图没摆正，连拖六次，Enter 弹窗始终没被按下）
    node_click_started = False
    # 第一列已经按优先级点过几个候选：每次点完没出现 Enter 就加一，换下一个候选；
    # 只有确认换了新地图（正常过渡）才复位，避免反复点同一个不可点的节点
    column_attempt = 0
    # 本轮保底周期内已经点过几个固定点（1~PROBE_POINT_COUNT）：每点一个就检测一次 Enter，
    # 没出现才继续点下一个；三个固定点都试完才把 probe_round 加一、重新开始一轮保底
    probe_attempt = 0
    probe_round = 0
    # 本轮保底固定点的点击顺序（PROBE_POINTS 的 1 起下标）：每开始一轮保底随机打乱一次，
    # 同一轮内按此顺序依次尝试，避免每次都固定从同一个坐标开始
    probe_order: list[int] = []
    # 本张地图第一列已经点过的行号（0=上、1=中、2=下）：保底阶段按它跳过同行的固定点，
    # 避免重复点第一列刚点过的同一行；只有换图（正常过渡）才复位
    clicked_rows: set[int] = set()
    # 是否已进入保底阶段：进入后本张地图不再重跑 step.mirror_path_select_node（该步含三次 SIFT，
    # 实测约 3 秒），直接按保底随机顺序点固定点；只有换图（正常过渡）才回到候选识别阶段
    probe_stage = False
    # 最近一次候选识别时第一列识别到的节点数：保底阶段不重新识别，日志继续引用这份结果
    first_count = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, 30 + 1):
        meta = ctx.action("observe.capture_screen")
        if ctx.call("step.detect_normal_transition", width=meta["width"], height=meta["height"]):
            if node_click_started:
                # 已经点过节点：过渡只代表点下去之后的加载（CONNECTING／Now Loading），
                # 不能再复位候选／保底计数，否则刚点过的同一行会在加载后被重复点击；
                # 火车头也不再因为过渡而重新检测
                ctx.log(
                    f"第{round_index}轮：已开始点节点，仍处于正常加载／联网过渡，只等待，"
                    "不复位候选／保底与火车头状态"
                )
            else:
                # 正常过渡说明地图重新加载，第一列的候选换了，
                # 重新从优先级最高的候选和第一个保底固定点开始尝试
                column_attempt = 0
                probe_attempt = 0
                probe_round = 0
                probe_order = []
                # 换图后第一列的点也换了：清空已点过的行，保底重新按完整固定点列表尝试
                clicked_rows = set()
                # 换图后火车头可能被重新摆放，下一轮必须重新检测一次再确认归位
                head_home_confirmed = False
                # 换图后第一列候选也换了：退出保底阶段，下一轮重新做候选识别
                probe_stage = False
                first_count = 0
                # 换图后重新给一次“保底之后点火车头”的兜底名额
                head_clicked = False
                head_reset_attempts = 0
                head_drag_index = 0
                last_head_distance = None
                head_find_attempts = 0
            # 通用等待不是业务分支：等待后业务分支重新从 1 计数，长时间加载不会被算成同一分支连续命中
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        # 【优先级】节点确认弹窗的 Enter 先判：弹窗一打开就直接按一次 Enter 进节点，
        # 不再先做火车头检测／归位（Run 645 现场弹窗开着，却先拖了六次火车头）
        enter_how = _enter_prompt(ctx)
        if enter_how:
            # 弹窗出现就该按一次 Enter：不消耗也不检查任何尝试预算，节点数量有限
            hit("step.mirror_path_enter_node")
            ctx.log(f"第{round_index}轮：右下角已有节点确认（{enter_how}），只按一次 Enter")
            ctx.call("step.mirror_path_enter_node")
            return _return_after_enter(ctx, round_index, "按 Enter 进入节点")

        icons = _path_icons(ctx)
        if node_click_started:
            # 【行为变更】已经开始点第一列候选或保底固定点：本张地图不再检测、拖拽、平移找火车头。
            # Run 645 现场点开节点后火车头是「选中高亮」外观，SIFT 在 (331,232)/(469,258) 反复命中，
            # 主循环把「火车头不在起点」当成地图没摆正，连拖六次，Enter 弹窗始终没被按下。
            # 这一段只用右上角按钮确认仍在寻路页，不足两个就再做一次有界复查（含过渡），仍不足才交回上层。
            if icons < MIN_PATH_ICONS:
                after = _observe_after_click(ctx, round_index, "已开始点节点后的页面复查")
                if after == "enter":
                    hit("step.mirror_path_enter_node")
                    ctx.call("step.mirror_path_enter_node")
                    return _return_after_enter(ctx, round_index, "复查后按 Enter 进入节点")
                if after == "left":
                    ctx.log(
                        f"第{round_index}轮：已开始点节点（不再检测火车头），右上角按钮只命中 "
                        f"{icons}/{len(PATH_ICON_ASSETS)} 个且没有 Enter，判定已不在寻路界面，"
                        "交回 task.mirror 重新分派",
                        level="warning",
                        screenshot=True,
                    )
                    return {
                        "completed": False,
                        "reason": "点击节点后已不在寻路界面",
                        "page": "not_path",
                    }
        else:
            # 火车头归位确认后不再每轮做全屏 SIFT：直接按已归位坐标处理，
            # 只有右上角页面标识不足时才退回一次火车头检测，确认是否还在寻路页
            if head_home_confirmed and icons >= MIN_PATH_ICONS:
                center = (TARGET_X, TARGET_Y)
            else:
                if head_home_confirmed:
                    head_home_confirmed = False
                    ctx.log(
                        f"右上角按钮只命中 {icons}/{len(PATH_ICON_ASSETS)} 个，"
                        "重新检测一次火车头确认仍在寻路页",
                        level="warning",
                    )
                center = _train_head_center(ctx)
            # 右上角按钮是寻路界面的主标识；火车头命中同样说明在寻路页，避免按钮素材漏识别时误判离开
            if icons < MIN_PATH_ICONS and center is None:
                ctx.log(
                    f"右上角按钮只命中 {icons}/{len(PATH_ICON_ASSETS)} 个且没有火车头，当前不在寻路界面",
                    level="warning",
                    screenshot=True,
                )
                return {"completed": False, "reason": "当前不在寻路界面", "page": "not_path"}
            if center is None:
                if head_find_attempts < MAX_HEAD_FIND_ATTEMPTS:
                    # 火车头可能被拖到画面左/右侧：先用拖拽 Step 的平移找回（先向右、再向左）
                    pan = 1 if head_find_attempts == 0 else -1
                    head_find_attempts += 1
                    hit(f"step.mirror_path_train_head_drag#find{head_find_attempts}")
                    ctx.log(
                        f"第{round_index}轮：寻路界面里没找到火车头（右上角按钮命中 "
                        f"{icons}/{len(PATH_ICON_ASSETS)} 个），做第 {head_find_attempts}/"
                        f"{MAX_HEAD_FIND_ATTEMPTS} 次平移找回（pan={pan}）",
                        level="warning",
                        screenshot=True,
                    )
                    ctx.call("step.mirror_path_train_head_drag", pan=pan)
                    continue
                ctx.log(
                    f"寻路界面里找不到火车头（右上角按钮命中 {icons}/{len(PATH_ICON_ASSETS)} 个），"
                    f"{MAX_HEAD_FIND_ATTEMPTS} 次平移找回仍未找到，判定寻路失败，交回上层调用退出镜牢流程",
                    level="warning",
                    screenshot=True,
                )
                return {
                    "completed": False,
                    "reason": "寻路界面里找不到火车头，判定寻路失败",
                    "page": "exit",
                }
            # 火车头已找到：平移找回的预算复位
            head_find_attempts = 0

            center_x, center_y = center
            if (
                abs(center_x - TARGET_X) > TARGET_TOLERANCE
                or abs(center_y - TARGET_Y) > TARGET_TOLERANCE
            ):
                # 火车头不在起点：归位确认失效，下一轮重新观察（拖完再确认）
                head_home_confirmed = False
                distance = max(abs(center_x - TARGET_X), abs(center_y - TARGET_Y))
                # 有进展就续期：单次手势最多 300px，火车头在最右边时要连拖几次才能回位
                if (
                    last_head_distance is not None
                    and distance <= last_head_distance - PROGRESS_MIN_PX
                    and head_reset_attempts
                ):
                    ctx.log(
                        f"第{round_index}轮：火车头离目标 {distance}px（上一轮 {last_head_distance}px），"
                        "有进展，复位尝试计数清零后继续拖"
                    )
                    head_reset_attempts = 0
                last_head_distance = distance
                head_reset_attempts += 1
                head_drag_index += 1
                if head_reset_attempts > MAX_HEAD_RESET_ATTEMPTS:
                    raise ExecutionFailure(
                        "path_train_head_not_home",
                        f"火车头连续 {MAX_HEAD_RESET_ATTEMPTS} 次拖拽都没有明显靠近 "
                        f"({TARGET_X}, {TARGET_Y})±{TARGET_TOLERANCE}（当前仍差 {distance}px），无法继续寻路",
                    )
                # 每次拖拽用带序号的标签，避免连拖几次撞上“同一分支第四次”上限
                hit(f"step.mirror_path_train_head_drag#{head_drag_index}")
                ctx.log(
                    f"第{round_index}轮：火车头 ({center_x}, {center_y}) 不在 ({TARGET_X}, {TARGET_Y})"
                    f"±{TARGET_TOLERANCE} 内（差 {distance}px），拖回起点"
                    f"（本张地图第 {head_drag_index} 次拖拽，速度按距离分档）"
                )
                ctx.call("step.mirror_path_train_head_drag")
                continue

            # 火车头已回到起点：本次复位周期结束，进入节点选择阶段，复位记录清零
            head_reset_attempts = 0
            last_head_distance = None
            if not head_home_confirmed:
                head_home_confirmed = True
                ctx.log(
                    f"第{round_index}轮：火车头已在 ({TARGET_X}, {TARGET_Y})±{TARGET_TOLERANCE}，"
                    "本张地图后续轮次不再重复检测火车头，直到换图或页面标识丢失"
                )

        # 候选识别只做一次：第一列候选已试完进入保底阶段后，本张地图不再重跑
        # step.mirror_path_select_node（该步含三次 SIFT，实测约 3 秒），直接按保底顺序继续点固定点；
        # 只有换图（正常过渡）把 probe_stage 复位，才重新回到候选识别阶段
        if not probe_stage:
            selection = ctx.call("step.mirror_path_select_node", attempt=column_attempt + 1)
            clicked = 0
            clicked_row = -1
            if isinstance(selection, dict):
                clicked = int(selection.get("clicked", 0) or 0)
                first_count = int(selection.get("first_count", 0) or 0)
                # row 用 0 表示上行，不能用 `or -1` 转默认值（0 会被当成假值）
                raw_row = selection.get("row")
                if isinstance(raw_row, int) and not isinstance(raw_row, bool):
                    clicked_row = raw_row
            if clicked:
                column_attempt += 1
                # 记下第一列点过的行：保底阶段跳过同一行的固定点，
                # 避免在同一行的同一列 x 上重复点一次（开发者要求：第一列点过的部分保底跳过）
                if 0 <= clicked_row < ROW_COUNT:
                    clicked_rows.add(clicked_row)
                    ctx.log(
                        f"第一列{ROW_LABELS[clicked_row]}行已点击，保底阶段将跳过同一行的固定点；"
                        f"已点过的行 {[ROW_LABELS[row] for row in sorted(clicked_rows)]}"
                    )
                else:
                    ctx.log(
                        "step.mirror_path_select_node 未返回有效的点击行号"
                        f"（row={clicked_row}），本次不更新保底的跳过集合",
                        level="warning",
                    )
                # 已经点过节点：本张地图不再检测／复位火车头
                node_click_started = True
                # 每次尝试的是不同候选，用带序号的标签区分，避免把“换下一个节点”算成同一分支重复命中
                hit(f"step.mirror_path_select_node#{column_attempt}")
                # 点击后 Step 内已等 1 秒：这里新截帧做有界观察（先处理 connecting／Now Loading 过渡），
                # 看到 Enter 就立刻按一次 Enter 进节点，看到寻路页就继续换候选
                after = _observe_after_click(ctx, round_index, f"点击第 {column_attempt} 个候选")
                if after == "enter":
                    hit("step.mirror_path_enter_node")
                    ctx.call("step.mirror_path_enter_node")
                    return _return_after_enter(ctx, round_index, "点击候选后按 Enter 进入节点")
                if after == "left":
                    return {
                        "completed": False,
                        "reason": "点击候选后已不在寻路界面",
                        "page": "not_path",
                    }
                continue

            # 本次没有点击（第一列无节点或候选已试完）：进入保底阶段并停用候选识别
            probe_stage = True
            ctx.log(
                f"第{round_index}轮：第一列识别到 {first_count} 个节点，第 {column_attempt + 1} 次尝试"
                "没有点击（第一列无节点或候选已试完），进入固定点保底；"
                "本张地图此后不再重跑节点识别，只有换图才恢复"
            )
        # 保底计划：probe_attempt 为 0 表示开始新一轮保底。先按第一列已经点过的行剔除同一行的固定点，
        # 再打乱剩余固定点的点击顺序（同一轮内按此顺序逐个尝试，不重复点同一个点）
        if probe_attempt == 0:
            skipped_points = [
                index
                for index in range(1, PROBE_POINT_COUNT + 1)
                if PROBE_POINT_ROWS[index] in clicked_rows
            ]
            probe_order = [
                index
                for index in range(1, PROBE_POINT_COUNT + 1)
                if index not in skipped_points
            ]
            if skipped_points:
                ctx.log(
                    f"第一列已点过的行 {[ROW_LABELS[row] for row in sorted(clicked_rows)]}，"
                    f"保底跳过同一行的固定点下标 {skipped_points}"
                    "（下标 1=(380,350) 中行、2=(380,130) 上行、3=(380,560) 下行）"
                )
            if probe_order:
                random.shuffle(probe_order)
                ctx.log(
                    f"保底固定点顺序随机打乱为 {probe_order}"
                    f"（PROBE_POINTS 的 1 起下标，1=(380,350)、2=(380,130)、3=(380,560)）"
                )
            else:
                ctx.log(
                    "第一列上/中/下三行都点过，保底固定点全部与已点过的行重复，本轮没有可点的固定点",
                    level="warning",
                )
        if probe_attempt < len(probe_order):
            probe_attempt += 1
            point_index = probe_order[probe_attempt - 1]
            # 每次点的是不同固定点，用带序号的标签区分，避免把「换下一个固定点」算成同一分支重复命中
            hit(f"step.mirror_path_probe_node#{probe_attempt}")
            ctx.log(
                f"第{round_index}轮：保底阶段（本张地图最后一次候选识别到 {first_count} 个节点，"
                f"已点 {column_attempt} 次候选，之后不再重跑节点识别）仍没有 Enter，"
                f"按本轮随机顺序保底点击第 {probe_attempt}/{len(probe_order)} 个固定点"
                f"（PROBE_POINTS 下标 {point_index}）"
            )
            node_click_started = True
            ctx.call("step.mirror_path_probe_node", attempt=probe_attempt, point=point_index)
            # 保底点击 Step 内等 1 秒后才交回：同样先处理过渡，再检测 Enter，
            # 命中就直接进入节点；没出现 Enter 才在下一轮继续点下一个固定点
            after = _observe_after_click(ctx, round_index, f"保底点击第 {probe_attempt} 个固定点")
            if after == "enter":
                hit("step.mirror_path_enter_node")
                ctx.call("step.mirror_path_enter_node")
                return _return_after_enter(ctx, round_index, "保底点击后按 Enter 进入节点")
            if after == "left":
                return {
                    "completed": False,
                    "reason": "保底点击后已不在寻路界面",
                    "page": "not_path",
                }
            continue

        # 三个固定点在本轮保底周期内都没带出 Enter：先补一次点火车头（整张地图只点一次）。
        # 点火车头放在保底点击之后：它只用来覆盖“当前所在节点需要点一下才弹确认框”，
        # 不再像以前那样放在拖拽前每轮都试探一次
        if not head_clicked:
            head_clicked = True
            hit("step.mirror_path_click_train_head")
            ctx.log(
                f"第{round_index}轮：本张地图的保底固定点都没有带出 Enter，改点一次火车头"
                "（保底点击之后的兜底，整张地图只点这一次）"
            )
            ctx.call("step.mirror_path_click_train_head")
            after = _observe_after_click(ctx, round_index, "保底固定点用尽后点击火车头")
            if after == "enter":
                hit("step.mirror_path_enter_node")
                ctx.call("step.mirror_path_enter_node")
                return _return_after_enter(ctx, round_index, "保底点击火车头后按 Enter 进入节点")
            if after == "left":
                return {
                    "completed": False,
                    "reason": "点击火车头后已不在寻路界面",
                    "page": "not_path",
                }
            continue

        # 没有可点的保底固定点（第一列上/中/下三行都点过）：点过火车头仍没有 Enter 就直接判失败，
        # 不再空跑剩下的保底轮次
        if not probe_order:
            raise ExecutionFailure(
                "path_probe_exhausted",
                "第一列上/中/下三行都已点击过且已点过火车头，仍未出现节点确认 Enter，判定寻路失败",
            )

        # 本轮保底固定点都没带出 Enter：算完成一轮保底，有界重来，超出即判定寻路失败
        probe_round += 1
        if probe_round >= MAX_PROBE_ROUNDS:
            raise ExecutionFailure(
                "path_probe_exhausted",
                f"保底固定点已连续 {MAX_PROBE_ROUNDS} 轮仍未出现节点确认 Enter"
                f"（每轮最多 {PROBE_POINT_COUNT} 个固定点，第一列已点过的行已跳过），判定寻路失败",
            )
        probe_attempt = 0
        hit("step.mirror_path_probe_restart")
        ctx.log(
            f"第{round_index}轮：本轮保底固定点都没有带出 Enter，"
            f"重新打乱顺序开始第 {probe_round + 1}/{MAX_PROBE_ROUNDS} 轮保底"
            "（保底阶段不重跑节点识别）",
            level="warning",
        )
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
