"""处理 Server Error 弹窗，这个弹窗在需要联网的情况下可能出现"""
import re

from lalc import RunContext

POPUP_NAME = "Server Error"
# 弹窗文案：A server error has occurred. Please try again in a moment.
POPUP_KEYWORD = "servererror"
RETRY_LABEL = "retry"
# Retry 按钮在 1280x720 客户区中的回退坐标
RETRY_FALLBACK = (740, 465)
# 右上角的 Connecting 提示：仍在重连时不能认为恢复完成
CONNECTING_REGION = {"x": 1000, "y": 0, "width": 250, "height": 120}
# Retry 有五秒冷却，点击前至少等够冷却
RETRY_COOLDOWN_SECONDS = 5
# 内部有界重试 7 次，每次点击 Retry 后先等冷却再等 2 秒；耗尽后交还主流程，
# 由外部「恢复规则→重试→恢复规则」再次介入
MAX_RETRIES = 7
POLL_SECONDS = 2


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _ocr_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回整屏 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    return list(result.get("items") or [])


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _popup_visible(items: list[dict]) -> bool:
    """OCR 文本里出现 Server Error 文案即认为弹窗存在。"""
    return POPUP_KEYWORD in _items_text(items)


def _retry_center(items: list[dict]) -> tuple[int, int] | None:
    """找出文字为 Retry 的按钮中心，识别不到时返回 None。"""
    for item in items:
        if _norm(item.get("text", "")) != RETRY_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            return (int(center[0]), int(center[1]))
    return None


def _connecting(ctx: RunContext) -> bool:
    """OCR 检查右上角是否仍在显示 Connecting；换了游戏语言后识别文本可能变化。"""
    ocr = ctx.action("observe.ocr", region=CONNECTING_REGION) or {}
    return any(
        "connecting" in str(item.get("text", "")).strip().lower()
        for item in ocr.get("items", [])
    )


def detect(ctx: RunContext) -> bool:
    """只观察弹窗文字，不在检测阶段点击。"""
    found = _popup_visible(_ocr_items(ctx))
    ctx.log(f"检测 {POPUP_NAME} 弹窗：{found}")
    return found


def recover(ctx: RunContext) -> None:
    """按 Retry 冷却逐次点击 Retry，直到弹窗文案和 Connecting 提示都不再出现。"""
    for attempt in range(1, MAX_RETRIES + 1):
        items = _ocr_items(ctx)
        if not _popup_visible(items):
            if _connecting(ctx):
                ctx.log(f"{POPUP_NAME} 弹窗已消失但仍在 Connecting，继续等待重连结果")
                ctx.action("observe.wait", seconds=POLL_SECONDS)
                continue
            ctx.log(f"{POPUP_NAME} 弹窗已消失，恢复成功")
            return

        ctx.log(
            f"第{attempt}/{MAX_RETRIES}次处理 {POPUP_NAME} 弹窗，"
            f"等待 {RETRY_COOLDOWN_SECONDS} 秒冷却后点击 Retry"
        )
        ctx.action("observe.wait", seconds=RETRY_COOLDOWN_SECONDS)

        items = _ocr_items(ctx)
        if not _popup_visible(items):
            ctx.log("等待冷却期间弹窗已消失，交回主流程")
            return

        center = _retry_center(items)
        if center:
            ctx.log(f"点击识别到的 Retry @ {center}")
            ctx.action("control.click", centerxy=center)
        else:
            ctx.log(
                f"未识别到 Retry 文本，点击回退坐标 {RETRY_FALLBACK}",
                level="warning",
                screenshot=True,
            )
            ctx.action("control.click", x=RETRY_FALLBACK[0], y=RETRY_FALLBACK[1])
        ctx.action("observe.wait", seconds=POLL_SECONDS)

    if _popup_visible(_ocr_items(ctx)):
        ctx.log(
            f"{POPUP_NAME} 弹窗 {MAX_RETRIES} 次重试后仍未消失，交还主流程继续观察",
            level="error",
            screenshot=True,
        )
        return
    ctx.log(f"{POPUP_NAME} 弹窗已消失，恢复成功")

