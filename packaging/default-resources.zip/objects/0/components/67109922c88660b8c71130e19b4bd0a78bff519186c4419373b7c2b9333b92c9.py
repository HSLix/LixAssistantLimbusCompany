"""处理游戏标题界面（TOUCH TO START）：点击屏幕中间进入游戏，以右上角 Connecting 出现为退出信号。"""
import re

from lalc import RunContext

STATE_NAME = "游戏标题界面"
# 标题界面左下角的 Clear all caches，是本状态最独特的稳定特征
TITLE_ASSET = "restart/clear_all_caches"
# 标题界面上的下载询问弹窗归 recovery.popup_download_notice 处理，本规则不参与
DOWNLOAD_POPUP_ASSET = "popup/download_data_notice"
# 标题界面上的 Steam 登录失败弹窗归 recovery.popup_failed_login_steam 处理，本规则不参与；
# 用弹窗文案区 OCR 与该规则互斥，避免同一现场两条规则同时命中造成歧义
LOGIN_ERROR_KEYWORD = "failedtologinviasteam"
# 标题界面上的 Server Error 弹窗归 recovery.popup_server_error 处理（点击 Retry），本规则不参与；
# 该弹窗盖在标题界面上时 Clear all caches 特征仍在，必须用同一块文案区 OCR 与它互斥
SERVER_ERROR_KEYWORD = "servererror"
# 标题界面上的 Cannot operate the game. Shutting down now. 弹窗归 recovery.popup_cannot_operate
# 处理（重启游戏），本规则不参与；该弹窗同样盖在标题界面上、Clear all caches 特征仍在
# （Run 639 现场 639/12961：先关掉服务端维护通知后弹出它），不互斥会让同一现场两条规则
# 同时命中，运行时直接报 Multiple Recovery Rules matched。
CANNOT_OPERATE_KEYWORD = "cannotoperate"
# 标题界面上的 Game client is not up to date. 弹窗归 recovery.popup_client_outdated 处理（重启拉新版本），
# 本规则不参与；该弹窗同样盖在标题界面上、Clear all caches 特征仍在，不互斥会与它同时命中。
CLIENT_OUTDATED_KEYWORD = "gameclientisnotuptodate"
# 弹窗文案区相对 1280x720 客户区的位置，同时覆盖 Server Error 与 Steam 登录失败的文案
POPUP_TEXT_BOX = (380, 270, 520, 150)
# 1280x720 客户区中点；标题界面点击此处即进入游戏
CLICK_X = 640
CLICK_Y = 360
# 每次点击后最多观察 5 轮×1 秒，等待右上角 Connecting 出现
POLL_SECONDS = 1
POLLS_PER_CLICK = 5
MAX_ATTEMPTS = 3
# 右上角 Connecting 提示相对 1280x720 客户区的位置
CONNECTING_BOX = (1000, 0, 250, 120)


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断字或断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region(meta: dict, box: tuple[int, int, int, int]) -> dict[str, int]:
    """把 1280x720 基准框换算成当前客户区像素矩形。"""
    width, height = int(meta["width"]), int(meta["height"])
    x, y, w, h = box
    return {
        "x": x * width // 1280,
        "y": y * height // 720,
        "width": max(1, w * width // 1280),
        "height": max(1, h * height // 720),
    }


def _connecting(ctx: RunContext, meta: dict) -> bool:
    """在当前帧右上角区域做一次 OCR，命中 Connecting 即认为已进入加载过渡。"""
    result = ctx.action("observe.ocr", region=_region(meta, CONNECTING_BOX)) or {}
    items = result.get("items") or []
    return "connecting" in _norm("".join(str(item.get("text", "")) for item in items))


def _title_visible(ctx: RunContext) -> list[dict]:
    """在当前帧匹配标题界面的 Clear all caches 特征，返回全部命中。"""
    return list(ctx.action("observe.match_asset", asset=TITLE_ASSET) or [])


def _popup_text(ctx: RunContext, meta: dict) -> str:
    """在当前帧的弹窗文案区做一次 OCR，返回合并后的规范化文本，供各弹窗关键字互斥判断。"""
    result = ctx.action("observe.ocr", region=_region(meta, POPUP_TEXT_BOX)) or {}
    items = result.get("items") or []
    return _norm("".join(str(item.get("text", "")) for item in items))


def detect(ctx: RunContext) -> bool:
    """只观察标题界面特征，不在检测阶段点击；下载询问、Steam 登录失败或 Server Error 弹窗仍在时不参与。"""
    meta = ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=DOWNLOAD_POPUP_ASSET):
        ctx.log(f"下载询问弹窗仍在{STATE_NAME}上，不属于本规则职责")
        return False
    text = _popup_text(ctx, meta)
    if LOGIN_ERROR_KEYWORD in text:
        ctx.log(f"Steam 登录失败弹窗仍在{STATE_NAME}上，不属于本规则职责")
        return False
    if SERVER_ERROR_KEYWORD in text:
        ctx.log(
            f"Server Error 弹窗仍在{STATE_NAME}上，不属于本规则职责，"
            "交给 recovery.popup_server_error 处理"
        )
        return False
    if CANNOT_OPERATE_KEYWORD in text:
        ctx.log(
            f"Cannot operate 弹窗仍在{STATE_NAME}上，不属于本规则职责，"
            "交给 recovery.popup_cannot_operate 处理"
        )
        return False
    if CLIENT_OUTDATED_KEYWORD in text:
        ctx.log(
            f"客户端版本弹窗仍在{STATE_NAME}上，不属于本规则职责，"
            "交给 recovery.popup_client_outdated 处理"
        )
        return False
    hits = _title_visible(ctx)
    ctx.log(f"检测{STATE_NAME}：命中 {len(hits)} 个 Clear all caches 特征")
    return bool(hits)


def recover(ctx: RunContext) -> None:
    """点击屏幕中间尝试进入游戏：右上角出现 Connecting 即交还主流程，未出现则再点，最多 3 次。

    每次点击后有界观察 Connecting；若同时发现标题特征已经消失，说明确实已离开标题界面，
    不再继续点击，直接交还主流程，避免在未知画面上盲目重复点击。
    """
    for attempt in range(1, MAX_ATTEMPTS + 1):
        ctx.log(f"第{attempt}/{MAX_ATTEMPTS}次点击屏幕中间 {(CLICK_X, CLICK_Y)}，尝试离开{STATE_NAME}")
        ctx.action("control.click", x=CLICK_X, y=CLICK_Y)

        for poll in range(1, POLLS_PER_CLICK + 1):
            ctx.action("observe.wait", seconds=POLL_SECONDS)
            meta = ctx.action("observe.capture_screen")
            if _connecting(ctx, meta):
                ctx.log(f"第{attempt}次点击后右上角出现 Connecting，已离开{STATE_NAME}，交还主流程")
                return
            if not _title_visible(ctx):
                ctx.log(
                    f"第{attempt}次点击后未出现 Connecting，但标题特征已消失，"
                    f"认为已离开{STATE_NAME}，交还主流程",
                    level="warning",
                )
                return

        ctx.log(
            f"第{attempt}/{MAX_ATTEMPTS}次点击后 {POLLS_PER_CLICK} 秒内未出现 Connecting，"
            f"仍在{STATE_NAME}",
            level="warning",
        )

    ctx.log(
        f"{STATE_NAME}点击 {MAX_ATTEMPTS} 次后仍未出现 Connecting，交还主流程继续观察",
        level="error",
        screenshot=True,
    )
