"""Charge Enkephalin 弹窗收尾：点一次 Confirm，通用等待后用 esc 关闭弹窗。"""
import re

from lalc import RunContext, step

POPUP_TITLE_REGION = {"x": 500, "y": 95, "width": 280, "height": 55}
POPUP_TITLE_KEYWORD = "chargeenkephalin"
# 底部按钮区：左侧 Cancel、右侧 Confirm（1280x720 实测 Confirm 文字位于 x738~818、y520~547）
CONFIRM_REGION = {"x": 700, "y": 505, "width": 190, "height": 65}
CONFIRM_LABEL = "confirm"
# 确认后兑换动画与数值刷新需要时间，先做通用等待再关弹窗
WAIT_AFTER_CONFIRM_SECONDS = 1.5
WAIT_AFTER_CLOSE_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


@step
def execute(ctx: RunContext) -> dict[str, bool]:
    """弹窗在且识别到 Confirm 时点一次 Confirm→等待→esc，返回 confirmed；否则只按 esc 收起弹窗。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=POPUP_TITLE_REGION) or {}
    title = "".join(str(item.get("text", "")) for item in (result.get("items") or []))
    if POPUP_TITLE_KEYWORD not in _norm(title):
        ctx.log("Charge Enkephalin 弹窗不在当前画面，不点 Confirm", level="warning", screenshot=True)
        return {"confirmed": False}

    center = None
    buttons = ctx.action("observe.ocr", region=CONFIRM_REGION) or {}
    for item in buttons.get("items") or []:
        if _norm(item.get("text", "")) != CONFIRM_LABEL:
            continue
        target = item.get("centerxy")
        if target:
            center = (int(target[0]), int(target[1]))
            break

    if not center:
        ctx.log(
            "未识别到 Confirm 文本，直接 esc 收起弹窗，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        ctx.action("control.key_press", key="esc")
        ctx.action("observe.wait", seconds=WAIT_AFTER_CLOSE_SECONDS)
        return {"confirmed": False}

    ctx.log(f"点击 Confirm @ {center}，等 {WAIT_AFTER_CONFIRM_SECONDS} 秒后 esc 关闭弹窗")
    ctx.action("control.click", centerxy=center)
    ctx.action("observe.wait", seconds=WAIT_AFTER_CONFIRM_SECONDS)
    ctx.action("control.key_press", key="esc")
    ctx.action("observe.wait", seconds=WAIT_AFTER_CLOSE_SECONDS)
    ctx.log("已确认兑换并按 esc 收起弹窗，兑换结果由上层重新截图判定")
    return {"confirmed": True}
