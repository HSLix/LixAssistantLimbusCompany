"""thread 执行一次的流程：从当前页面单向推进到 Thread 结算"""
from lalc import ExecutionFailure, RunContext, task_workflow

LEVEL_SELECT_ASSET = "luxcavation/thread_level_select"
THREAD_ENTER_ASSET = "luxcavation/thread_enter"
LUXCAVATION_TITLE_ASSET = "luxcavation/title"

# Thread 使用哪个队伍来自 Luxcavation 设置页，与队伍配置页的罪人顺序配合
SETTINGS_PAGE_ID = "luxcavation.settings"
TEAM_KEY = "thread_team"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
# 本 Run 内是否已经为 thread 重排过出战顺序：记在 RunState.settings 的独立键下，与 exp/mirror 分开
RUNTIME_KEY = "thread.runtime"
TEAM_SELECTED_KEY = "battle_team_selected"

PREPARE_ASSETS = ["prepare_team/all_identities", "prepare_team/all_ego", "prepare_team/facades"]
# 事件叙述页 SKIP 按钮的匹配区域（1280x720 客户区）：只做普通／灰化 SKIP 模板匹配，不读 OCR 文案。
# 灰化模板是整颗按钮的裁剪（240x95），宽度与原来的按钮区域相同；区域没有横向余量时模板只有唯一位置可放，
# 按钮偏移几个像素就匹配不到，因此用带余量的右下角区域让两个模板都能按实际位置滑动。
EVENT_BUTTON_REGION = {"x": 980, "y": 560, "width": 300, "height": 160}


def _hit(ctx: RunContext, assets: list[str]) -> bool:
    """同一截图中是否命中任一素材。"""
    return any(ctx.action("observe.match_asset", asset=asset) for asset in assets)


def _event_here(ctx: RunContext, event_assets: list[str], event_skip_assets: list[str]) -> bool:
    """当前帧是否已在事件页面：选项／结果页标题模板，或右下角普通／灰化 SKIP 按钮模板。"""
    if _hit(ctx, event_assets):
        return True
    return any(
        ctx.action("observe.match_asset", asset=asset, region=EVENT_BUTTON_REGION)
        for asset in event_skip_assets
    )


def _team_index(ctx: RunContext) -> int:
    """读取 Luxcavation 设置页里 Thread 使用的队伍序号，非法值退回默认队伍。"""
    page = (ctx.run_state.settings or {}).get(SETTINGS_PAGE_ID) or {}
    text = str(page.get(TEAM_KEY, DEFAULT_TEAM)).strip()
    team = int(text) if text.isdigit() else DEFAULT_TEAM
    return team if 1 <= team <= MAX_TEAMS else DEFAULT_TEAM


def _team_selected(ctx: RunContext) -> bool:
    """本 Run 内 thread 是否已经重排过出战顺序；没有记录时按还没重排处理。"""
    runtime = (ctx.run_state.settings or {}).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(TEAM_SELECTED_KEY) is True


def _set_team_selected(ctx: RunContext, selected: bool) -> None:
    """
    记录本 Run 内 thread 的出战顺序状态；首次写入时 RunState 里还没有这个记录，
    拿到的是空 dict，必须写回 settings 并立即赋值，否则记录不生效。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录 thread 的出战顺序状态", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[TEAM_SELECTED_KEY] = selected
    settings[RUNTIME_KEY] = runtime
    ctx.log(f"记录 thread 出战顺序状态 {TEAM_SELECTED_KEY}={selected}")



@task_workflow
def execute(
    ctx: RunContext,
    *,
    battle_assets: list[str],
    path_train_asset: str,
    event_choices_asset: str,
    event_result_asset: str,
    event_skip_asset: str,
    event_grey_skip_asset: str,
    gift_get_asset: str,
) -> dict[str, str]:
    """优先等待正常过渡，再有界分派；同一分支连续第四次命中或总预算耗尽时失败。"""
    team_index = _team_index(ctx)
    ctx.log(f"task.thread 开始：使用第{team_index}个队伍")
    # 战斗与事件标识由 plan 统一定义后传入：本层只用它们做分派，不再维护自己的素材表
    event_assets = [event_choices_asset, event_result_asset]
    event_skip_assets = [event_skip_asset, event_grey_skip_asset]
    # 队伍列表行是否已点过：只在队伍准备页第一次分派时点一次
    team_row_clicked = False
    # 队伍列表是否已用拖拽拉回顶部：与点击选队分开，每次重新进入准备页时先做一遍上划
    team_list_reset = False
    level = "unknown"
    battle_result = ""
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, 100 + 1):
        meta = ctx.action("observe.capture_screen")
        # 正常加载／联网过渡先于业务分派：Run 637 里过渡帧上业务页仍然匹配，
        # 业务分支会继续对同一画面重复输入直到撞上分支上限；等待后业务分支从 1 重新计数。
        if ctx.call("step.detect_normal_transition", width=meta["width"], height=meta["height"]):
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        if battle_result and ctx.action("observe.match_asset", asset="luxcavation/title"):
            reason = "战斗失败" if battle_result == "defeat" else "战斗胜利"
            return {"result": battle_result, "reason": reason, "level": level}
        observed_result = next(
            (outcome for outcome in ("defeat", "victory") if ctx.action("observe.match_asset", asset=f"battle/{outcome}")),
            "",
        )
        if observed_result:
            battle_result = observed_result
            hit("settlement")
            ctx.call("step.luxcavation_confirm_battle_result")
            continue
        if battle_result:
            hit("unknown")
            ctx.action("observe.wait", seconds=1.0)
            continue
        result = None
        if _hit(ctx, battle_assets):
            # 战斗子流程不再返回业务结果，退出原因写在它自己的日志里：
            # 这里直接回到循环顶部重新截图分派（战果页由下面的 settlement 分支处理）
            hit("sub_workflow.battle_till_end")
            ctx.call(
                "sub_workflow.battle_till_end",
                battle_assets=battle_assets,
                path_asset=path_train_asset,
                event_assets=event_assets,
                event_skip_assets=event_skip_assets,
            )
            continue
        elif _hit(ctx, PREPARE_ASSETS):
            # 队伍准备页分四步推进，每步只做一次动作并交回下一轮重新截图判断：
            # 先用拖拽把列表拉回顶部（每次拖拽后通用检测），再按序号点队伍行，
            # 然后按配置点罪人，最后按 Enter 提交出战
            if not team_list_reset:
                hit("sub_workflow.team_list_drag_top")
                reset = ctx.call("sub_workflow.team_list_drag_top") or {}
                ctx.log(f"队伍列表上划结果：{reset}")
                if str(reset.get("completed")) == "true":
                    team_list_reset = True
                continue
            if not team_row_clicked:
                # 点击与上划分开：点击前再对一帧做一次通用等待检测，弹窗未清就不点队伍行
                click_meta = ctx.action("observe.capture_screen")
                if ctx.call(
                    "step.detect_normal_transition",
                    width=int(click_meta["width"]),
                    height=int(click_meta["height"]),
                ):
                    previous_branch = ""
                    consecutive_hits = 0
                    ctx.call("step.wait_normal_transition")
                    continue
                hit("step.select_team_by_index")
                ctx.call("step.select_team_by_index", team_index=team_index)
                team_row_clicked = True
                continue
            if not _team_selected(ctx):
                hit("step.select_team_sinners")
                ctx.call("step.select_team_sinners", team_index=team_index, first_clear_selection=True)
                _set_team_selected(ctx, True)
                continue
            hit("step.confirm_team_battle")
            ctx.call("step.confirm_team_battle")
            continue
        elif _event_here(ctx, event_assets, event_skip_assets):
            # 事件处理是通用的：与镜牢共用同一个 event 子流程，用 entry 标明本任务是 thread 入口，
            # 子流程据此在事件结束后交回 Luxcavation 关卡页；退出后重新完整分派
            hit("sub_workflow.event")
            result = ctx.call(
                "sub_workflow.event",
                entry="thread",
                event_choices_asset=event_choices_asset,
                event_result_asset=event_result_asset,
                event_skip_asset=event_skip_asset,
                event_grey_skip_asset=event_grey_skip_asset,
                path_train_asset=path_train_asset,
                gift_get_asset=gift_get_asset,
            )
            ctx.log(f"event 子流程交回：{result}")
        elif ctx.action("observe.match_asset", asset=LEVEL_SELECT_ASSET):
            hit("step.thread_enter_highest_level")
            # Step 不再回传难度等级：本步只执行一次拖动与点击，是否进入准备页由下一轮重新截图判断
            ctx.call("step.thread_enter_highest_level")
            continue
        elif ctx.action("observe.match_asset", asset=LUXCAVATION_TITLE_ASSET):
            # 新一场战斗：重置准备页的行点击记录与列表回顶记录，下一轮重新上划并按序号选队伍
            team_row_clicked = False
            team_list_reset = False
            if ctx.action("observe.match_asset", asset=THREAD_ENTER_ASSET):
                hit("THREAD_ENTER_ASSET")
                ctx.call("step.click_asset_until", click_asset=THREAD_ENTER_ASSET, success_assets=[LEVEL_SELECT_ASSET])
            else:
                hit("coordinate:138")
                ctx.call("step.click_coordinate_until", click_x=138, click_y=332, success_assets=[THREAD_ENTER_ASSET])
            continue
        elif _hit(ctx, ["drive/inferno", "main_navigate/drive_selected"]):
            hit("coordinate:450")
            ctx.call("step.click_coordinate_until", click_x=450, click_y=150, success_assets=["luxcavation/title"])
            continue
        elif _hit(ctx, ["main_navigate/window", "main_navigate/window_selected"]):
            hit("main_navigate/drive")
            ctx.call("step.click_asset_until", click_asset="main_navigate/drive", success_assets=["main_navigate/drive_selected", "drive/inferno"])
            continue
        if result is None:
            hit("unknown")
            ctx.action("observe.wait", seconds=1.0)
            continue
        ctx.log(f"thread 第{round_index}轮局部结果：{result}")
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
