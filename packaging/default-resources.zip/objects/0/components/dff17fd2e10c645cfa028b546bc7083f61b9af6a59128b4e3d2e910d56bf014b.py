"""处理服务端维护通知（Server is under Scheduled Maintenance.）：按弹窗给出的时间有界等待后再推进。

现场（1280x720，Run 639 证据 639/12760、639/12961）：
- 通知盖在融合页等业务页之上，文案是 Server is under Scheduled Maintenance. /
  You will be able to login after 12:00 (KST)，底部只有一个居中 Close（实测中心 (638,467)）；
- 维护期内点掉通知会让客户端立刻弹出 Cannot operate the game.／Shutting down now. 并退回标题界面，
  所以维护结束前不做任何输入。
本规则按弹窗里的 “after HH:MM” 时间（KST，UTC+9）算出还要等多久，到点多等 1 分钟后直接重启游戏
（维护期间会话已失效，重启比点掉通知更干净），重启后最多再等 10 分钟观察是否回到标题界面；
时间读不出、超过等待上限时不做长时间等待，只记录后交回。等待都用 observe.wait 分片执行
（单次上限 60 秒），暂停与取消仍由 observe.wait 响应。
"""
import re
from datetime import datetime, timedelta, timezone

from lalc import RunContext

POPUP_NAME = "Server is under Scheduled Maintenance"
# 弹窗文案：Server is under Scheduled Maintenance.
POPUP_KEYWORD = "scheduledmaintenance"
# 登录时间：You will be able to login after 12:00 (KST)
TIME_PATTERN = re.compile(r"after\s*(\d{1,2})\s*:\s*(\d{2})")
# 弹窗里的时间一律按 KST（UTC+9）解释，与运行电脑的本地时区无关
KST = timezone(timedelta(hours=9))
# 维护结束（登录开放）后再多等 1 分钟，避免刚好卡在开服瞬间
EXTRA_SECONDS = 60
# observe.wait 单次上限 60 秒
CHUNK_SECONDS = 60
# 单个 recover 最多等待 6 小时；更远的维护时间不在这里空等，交主流程重新观察
MAX_WAIT_SECONDS = 6 * 3600
# 每 5 分钟记一次等待进度
PROGRESS_SECONDS = 300
# 维护等待到点后的重启：重启后最多观察 10 分钟，等到标题界面且没有阻挡弹窗为止
RESTART_WAIT_SECONDS = 600
POLL_SECONDS = 10
READY_ASSET = "restart/clear_all_caches"
BLOCKING_KEYWORDS = ("gameclientisnotuptodate", "scheduledmaintenance")


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _items_text(items: list[dict]) -> tuple[str, str]:
    """把 OCR 条目合并成 (规范化文本, 保留冒号的清洗原文)，供关键字与时间解析分别使用。"""
    raw = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(raw), re.sub(r"\s+", " ", raw).strip().lower()


def _read(ctx: RunContext) -> tuple[str, str]:
    """刷新截图并整屏 OCR，返回 (规范化文本, 清洗原文)；不点击。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    return _items_text(result.get("items") or [])


def _visible(ctx: RunContext) -> bool:
    """当前帧是否压着服务端维护通知：只看整屏 OCR 文案。"""
    return POPUP_KEYWORD in _read(ctx)[0]


def _current_norm_text(ctx: RunContext) -> str:
    """对当前已捕获帧整屏 OCR，返回规范化文本；不刷新截图。"""
    result = ctx.action("observe.ocr") or {}
    return _items_text(result.get("items") or [])[0]


def _ready(ctx: RunContext) -> bool:
    """当前帧是否已回到标题界面（刚启动／刚登录）且没有挡住流程的弹窗。"""
    if not ctx.action("observe.match_asset", asset=READY_ASSET):
        return False
    text = _current_norm_text(ctx)
    return not any(keyword in text for keyword in BLOCKING_KEYWORDS)


def detect(ctx: RunContext) -> bool:
    """只观察通知文案，不在检测阶段点击或等待。"""
    found = _visible(ctx)
    ctx.log(f"检测 {POPUP_NAME} 通知：{found}")
    return found


def recover(ctx: RunContext) -> None:
    """按弹窗时间有界等待到维护结束（再+1 分钟），点一次 Close 后交回主流程。"""
    norm, raw = _read(ctx)
    if POPUP_KEYWORD not in norm:
        ctx.log(f"{POPUP_NAME} 通知已消失，无需等待")
        return

    match = TIME_PATTERN.search(raw)
    if not match:
        ctx.log(
            f"{POPUP_NAME} 通知里读不出维护结束时间（after HH:MM (KST)），本次不等待，交主流程重新观察",
            level="warning",
            screenshot=True,
        )
        return
    hour, minute = int(match.group(1)), int(match.group(2))
    if hour > 23 or minute > 59:
        ctx.log(
            f"{POPUP_NAME} 通知里的时间 {hour:02d}:{minute:02d} 不合法，本次不等待，交主流程重新观察",
            level="warning",
            screenshot=True,
        )
        return

    now = datetime.now(timezone.utc).astimezone(KST)
    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if target <= now:
        # 今天的这个时间点已过：按明天算，交由下面的上限判断决定是否等待
        target += timedelta(days=1)
    remaining = (target - now).total_seconds() + EXTRA_SECONDS

    if remaining > MAX_WAIT_SECONDS:
        ctx.log(
            f"{POPUP_NAME}：当前 {now:%H:%M} (KST)，通知时间为 {hour:02d}:{minute:02d} (KST)，"
            f"还需等待约 {remaining / 3600:.1f} 小时，超过单次等待上限 {MAX_WAIT_SECONDS / 3600:.0f} 小时，"
            f"本次不等待，交主流程重新观察",
            level="warning",
            screenshot=True,
        )
        return

    ctx.log(
        f"{POPUP_NAME}：当前 {now:%H:%M} (KST)，通知登录时间 {hour:02d}:{minute:02d} (KST)，"
        f"先等待 {remaining:.0f} 秒（含维护结束后的 1 分钟余量），维护结束前不做任何输入"
    )
    waited = 0.0
    next_progress = PROGRESS_SECONDS
    while waited < remaining:
        chunk = min(CHUNK_SECONDS, remaining - waited)
        ctx.action("observe.wait", seconds=chunk)
        waited += chunk
        if waited >= next_progress:
            ctx.log(f"已等待 {waited:.0f}/{remaining:.0f} 秒，仍在等待维护结束")
            next_progress += PROGRESS_SECONDS

    # 维护结束：会话已经失效，直接重启游戏，重启后最多再观察 10 分钟
    ctx.action("control.restart_game")
    ctx.log(
        f"维护时间已到（含 1 分钟余量），已请求重启游戏，"
        f"最多再等 {RESTART_WAIT_SECONDS // 60} 分钟观察是否回到标题界面"
    )
    waited = 0.0
    while waited < RESTART_WAIT_SECONDS:
        ctx.action("observe.wait", seconds=POLL_SECONDS)
        waited += POLL_SECONDS
        ctx.action("observe.capture_screen")
        if _ready(ctx):
            ctx.log(f"重启后 {waited:.0f} 秒已回到标题界面，交回主流程重新观察")
            return
    ctx.log(
        f"重启后等到 {RESTART_WAIT_SECONDS // 60} 分钟仍未回到可识别界面，交回主流程重新观察",
        level="warning",
        screenshot=True,
    )
