"""镜牢主题包自维护：对一个还没收录的主题包点一次详情，把封面裁成 mirror/theme_pack/<名字> 模板。

一次调用只处理一张卡片：封面由上层在点开任何弹窗之前、基于同一帧统一预剪切好，
本步只负责「逐个看名字、用给定的 crop_id 存素材」（与商店饰品自维护同一套做法）：
1) 先重新截图，用上层给出的详情图标中心在附近复验 mirror/theme_pack_detail（28~29 像素的放大镜），
   图标不在就零输入返回 missing_detail，并丢弃上层预剪切的裁剪，避免占用暂存额度；
2) 点一次详情图标，等固定时间让弹窗与标题淡入；
3) 整屏 OCR 一次，只留中心落在标题带（y 120~180、x 240~840）的单词／短语，
   再丢掉页面与弹窗自带的固定文案（SELECT FLOOR / THEME PACK / NORMAL / Refresh / CLEAR BONUS /
   Owned …）和纯数字，剩下的条目按从上到下、从左到右拼成主题包名；
   第一次没读到（标题还在淡入）时固定等待后再读一次，仍读不到就不写素材库；
4) 名字转成素材目录名（小写、非字母数字转下划线，非 ASCII 用哈希目录名），用上层给的 crop_id
   把预剪切的封面存成 mirror/theme_pack/<名字>，最后按 Esc 关掉弹窗。
新收录的主题包由上层按「默认选择」等级的偏好处理；本步只负责收录素材，不改页面配置。
"""
import hashlib
from pathlib import PureWindowsPath
import re
import unicodedata

from lalc import RunContext, step

DETAIL_ASSET = "mirror/theme_pack_detail"
# 详情图标复验窗口：上层给的是本轮观察到的图标中心，这里在附近按默认阈值再匹配一次
DETAIL_SEARCH_PAD = 40
# 收录目录：主题包模板都放在 mirror/theme_pack/<名字>
PACK_ROOT = "mirror/theme_pack"
# 弹窗标题带（1280x720 基准）：整屏 OCR 之后只保留中心落在这条带里的单词／短语，
# 即 y 120~180、x 240~840；再按 CHROME_WORDS 过滤页面与弹窗自带的固定文案。
TITLE_X_MIN = 240
TITLE_X_MAX = 840
TITLE_Y_MIN = 120
TITLE_Y_MAX = 180
TITLE_MIN_SCORE = 0.5
# 拼出来的名字至少要有这么多个字母数字，避免把残留噪声当成名字
TITLE_MIN_LETTERS = 3
# 弹窗／页面自带的固定文案（规范化后按子串过滤）
CHROME_WORDS = (
    "selectfloor",
    "themepack",
    "normal",
    "hard",
    "refresh",
    "packsearch",
    "clearbonus",
    "owned",
    "detail",
    "close",
    "enemies",
    "egogift",
    "egogifts",
    "cancel",
    "confirm",
    "continue",
    "search",
    "difficulty",
)
# 点开详情后的固定等待：弹窗与标题有淡入动画
POPUP_SETTLE_SECONDS = 1.5
# 第一次没读到标题时的第二次等待
TITLE_RETRY_SECONDS = 0.8
# 按 Esc 关掉弹窗后的固定等待
CLOSE_SETTLE_SECONDS = 0.8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行、断字影响文字过滤。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _slug(name: str) -> str:
    """把主题包名转成素材目录名；非 ASCII 名字只能用哈希目录名（匹配只认目录名）。"""
    text = unicodedata.normalize("NFKC", name).strip()
    slug = re.sub(r"[^a-z0-9_-]+", "_", text.lower()).strip("_-")
    if not slug or not text.isascii() or len(slug) > 120 or PureWindowsPath(slug).is_reserved():
        return "pack_" + hashlib.sha256(_norm(name).encode()).hexdigest()[:20]
    return "pack_" + slug if slug[0].isdigit() else slug


def _detail_hit(ctx: RunContext, cx: int, cy: int):
    """在 (cx, cy) 附近的窗口里按默认阈值复验详情图标，返回离该中心最近的一处命中。"""
    region = {
        "x": max(0, cx - DETAIL_SEARCH_PAD),
        "y": max(0, cy - DETAIL_SEARCH_PAD),
        "width": DETAIL_SEARCH_PAD * 2,
        "height": DETAIL_SEARCH_PAD * 2,
    }
    hits = ctx.action("observe.match_asset", asset=DETAIL_ASSET, region=region) or []
    if not hits:
        return None

    def distance(hit: dict) -> int:
        center = hit.get("centerxy") or (0, 0)
        return abs(int(center[0]) - cx) + abs(int(center[1]) - cy)

    return min(hits, key=distance)


def _title(ctx: RunContext) -> tuple[str, str]:
    """
    整屏 OCR 一次，只留中心落在标题带（y 120~180、x 240~840）的单词／短语，
    再过滤固定文案、纯数字与低分条目，剩下的条目按从上到下、从左到右拼成名字。
    返回 (名字, 明细)；明细里带每条文字、中心与分数，标题读不到时用它排查现场。
    """
    result = ctx.action("observe.ocr") or {}
    picked: list[tuple[int, int, str, float]] = []
    dropped: list[str] = []
    for item in result.get("items") or []:
        text = str(item.get("text", "")).strip()
        flat = _norm(text)
        if not flat or not any(char.isalpha() for char in text):
            continue
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if not (TITLE_X_MIN <= x <= TITLE_X_MAX and TITLE_Y_MIN <= y <= TITLE_Y_MAX):
            continue
        score = float(item.get("score") or 0.0)
        if score < TITLE_MIN_SCORE:
            dropped.append(f"{text}@({x},{y})低分 {round(score, 3)}")
            continue
        if any(word in flat for word in CHROME_WORDS):
            dropped.append(f"{text}@({x},{y})是页面固定文案")
            continue
        picked.append((y, x, text, score))
    picked.sort()
    name = " ".join(entry[2] for entry in picked).strip()
    used = "; ".join(
        f"{text}@({x},{y})s={round(score, 3)}" for y, x, text, score in picked
    )
    detail = f"采用 {used or '无'}；丢弃 {('；'.join(dropped)) or '无'}"
    return ("" if len(_norm(name)) < TITLE_MIN_LETTERS else name), detail


@step
def execute(
    ctx: RunContext,
    *,
    detail_cx: int = 0,
    detail_cy: int = 0,
    crop_id: str = "",
    index: int = 0,
) -> dict[str, str]:
    """
    收录一张卡片：复验详情图标 → 点一次详情 → 读弹窗标题 → 用上层预剪切的 crop_id 存素材 →
    按 Esc 关弹窗。封面裁剪由上层在点开弹窗之前基于同一帧统一预剪切，本步不再自己截图裁剪。
    detail_cx／detail_cy 是上层观察到的详情图标中心；crop_id 是上层暂存的 150x240 封面裁剪；
    index 只用于日志（本帧第几张卡片）。复验失败时零输入返回 missing_detail 并丢弃该裁剪。
    返回 status（collected／missing_detail／title_unknown）与名字、素材逻辑名。
    """
    if not isinstance(detail_cx, int) or not isinstance(detail_cy, int):
        raise ValueError("detail_cx、detail_cy 必须是整数坐标")
    if detail_cx <= 0 or detail_cy <= 0:
        raise ValueError("detail_cx、detail_cy 必须是详情图标中心的正整数坐标")
    if not isinstance(crop_id, str) or not crop_id:
        raise ValueError("crop_id 必须是上层预剪切得到的非空字符串")

    label = f"第{index}张卡片" if index else "卡片"
    ctx.action("observe.capture_screen")
    hit = _detail_hit(ctx, detail_cx, detail_cy)
    if hit is None:
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(
            f"{label}：({detail_cx},{detail_cy}) 附近没复验到详情图标 {DETAIL_ASSET}，"
            "可能弹窗还开着或页面已变化，本次不收录并丢弃预剪切的封面",
            level="warning",
            screenshot=True,
        )
        return {"status": "missing_detail"}

    center = hit.get("centerxy") or (0, 0)
    hit_center = (int(center[0]), int(center[1]))
    ctx.log(
        f"{label}：详情图标命中 ({hit.get('x')},{hit.get('y')},"
        f"{hit.get('width')}x{hit.get('height')}) score={round(float(hit.get('score', 0.0)), 3)}，"
        f"点它读标题（封面用上层预剪切的 {crop_id}）"
    )

    ctx.action("control.click", centerxy=hit_center)
    ctx.action("observe.wait", seconds=POPUP_SETTLE_SECONDS)
    ctx.action("observe.capture_screen")
    name, detail = _title(ctx)
    if not name:
        ctx.action("observe.wait", seconds=TITLE_RETRY_SECONDS)
        ctx.action("observe.capture_screen")
        name, detail = _title(ctx)
    if not name:
        ctx.action("observe.discard_asset_crop", crop_id=crop_id)
        ctx.log(
            f"详情弹窗顶部没有读到主题包名（{detail}），本次不收录；按 Esc 关掉弹窗",
            level="warning",
            screenshot=True,
        )
        ctx.action("control.key_press", key="esc")
        ctx.action("observe.wait", seconds=CLOSE_SETTLE_SECONDS)
        return {"status": "title_unknown"}

    asset = f"{PACK_ROOT}/{_slug(name)}"
    saved = ctx.action("observe.save_asset_crop", crop_id=crop_id, asset=asset)
    ctx.log(
        f"主题包 {name} 已收录为素材 {asset}（sha256 {saved.get('sha256')}；标题来源：{detail}），"
        "按默认选择等级的偏好处理",
        level="info",
    )
    ctx.action("control.key_press", key="esc")
    ctx.action("observe.wait", seconds=CLOSE_SETTLE_SECONDS)
    return {"status": "collected", "name": name, "asset": asset}
