"""只读测量试验：量出 Sell E.G.O Gift 弹窗右侧饰品列表的行位置，用于给自维护饰品定几何。

确认三件事（都不点击、不按键、不保存素材）：
1) 每一行卡片下方的价格数字中心 y（价格行可靠且可 OCR，用来反推卡片顶边）；
2) 角标模板 mirror/shop/ego_corner 在较高阈值下命中的位置（角标贴在卡片框左下角，
   可用它倒推整卡矩形：卡片左边 = 角标左边、卡片底边 = 角标底边、卡片顶边 = 底边 − 卡高）；
3) 列表底边能容纳几行完整卡片（开发者说明：最多只完整显示两行，也就是十个饰品）。
输出里按 y 汇总，并给出每个角标倒推出的整卡矩形，便于直接核对卡片行距、卡宽卡高与价格偏移。
"""
import re

from lalc import RunContext, step

# 右侧饰品列表区域：卡片 x 从 645 起、每列 100，列表右边界约 1120
GRID_REGION = {"x": 615, "y": 195, "width": 505, "height": 345}
# 角标模板：贴在卡片框左下角的那块角标（现只有 16x16 一个模板，阈值与主流程保持一致）
CORNER_ASSET = "mirror/shop/ego_corner"
CORNER_THRESHOLD = 0.8
# 卡片尺寸（与 step.mirror_sell_gift_slot 一致），用于把角标位置倒推成整卡矩形；卡片宽高全场统一
CARD_WIDTH = 68
CARD_HEIGHT = 73
# 角标→整卡的内缩（与 step.mirror_sell_gift_slot 的 CORNER_TEMPLATE_INSETS 同步）：
# 卡片左边 = 角标左边 + 左内缩；卡片底边 = 角标底边 − 底内缩
CORNER_TEMPLATE_INSETS = {
    (16, 16): (1, 7),
}


def _card_rect(hit: dict):
    """把一次角标命中换算成整卡矩形；模板尺寸不在内缩表里时返回 None（不猜偏移）。"""
    size = (int(hit.get("width") or 0), int(hit.get("height") or 0))
    if size not in CORNER_TEMPLATE_INSETS:
        return None
    left_inset, bottom_inset = CORNER_TEMPLATE_INSETS[size]
    left = int(hit.get("x") or 0) + left_inset
    bottom = int(hit.get("y") or 0) + size[1] - bottom_inset
    return {"x": left, "y": bottom - CARD_HEIGHT, "width": CARD_WIDTH, "height": CARD_HEIGHT}
# 左上名字区：确认当前是否已经选中了某件饰品（未选中时只有 "???"）
NAME_REGION = {"x": 290, "y": 165, "width": 300, "height": 100}
# 名字区 OCR 检测参数：与 step.mirror_sell_gift_slot 的 NAME_DET_OPTIONS 保持一致（thresh 0.15）
NAME_DET_OPTIONS = {"thresh": 0.15}
# 同一行的价格数字 y 相差不超过这么多像素
ROW_TOLERANCE = 8
# 右侧滚动条区域与滑块模板，用于验证滚动到底判据
SCROLLBAR_REGION = {"x": 1090, "y": 190, "width": 50, "height": 330}
SCROLL_THUMB_ASSET = "mirror/shop/sell_gift_scroll_end"
SCROLL_THUMB_THRESHOLD = 0.8
SCROLL_THUMB_TOP_Y = 235
SCROLL_THUMB_BOTTOM_Y = 466
SCROLL_BOTTOM_TOLERANCE = 6


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    重新截图后只做观察：格区里所有含数字的文字、角标高阈值命中、名字区文字。
    返回汇总字符串，供人工读出卡片行距与价格偏移。
    """
    ctx.action("observe.capture_screen")

    result = ctx.action("observe.ocr", region=GRID_REGION) or {}
    numbers = []
    for item in result.get("items") or []:
        text = str(item.get("text", "")).strip()
        center = item.get("centerxy")
        if not center:
            continue
        digits = re.sub(r"[^0-9]", "", text)
        if not digits:
            continue
        numbers.append((int(center[1]), int(center[0]), text))
    numbers.sort()
    number_detail = "; ".join(f"{text}@({x},{y})" for y, x, text in numbers)
    ctx.log(f"格区含数字文字 {len(numbers)} 条（按 y 排序）：{number_detail}", level="info")

    # 按 y 聚成行，报告每行的 y 与横向位置
    rows: list[list[tuple[int, int, str]]] = []
    for entry in numbers:
        for row in rows:
            if abs(row[0][0] - entry[0]) <= ROW_TOLERANCE:
                row.append(entry)
                break
        else:
            rows.append([entry])
    row_detail = "; ".join(
        f"y≈{min(item[0] for item in row)}~{max(item[0] for item in row)}"
        f"（{len(row)} 个：{', '.join(item[2] for item in row)}）"
        for row in rows
    )
    ctx.log(f"按 y 聚成 {len(rows)} 行：{row_detail}", level="info", screenshot=True)

    corners = (
        ctx.action(
            "observe.match_asset",
            asset=CORNER_ASSET,
            region=GRID_REGION,
            threshold=CORNER_THRESHOLD,
        )
        or []
    )
    corners = sorted(corners, key=lambda hit: (int(hit.get("y", 0)), int(hit.get("x", 0))))
    corner_detail = "; ".join(
        f"({hit.get('x')},{hit.get('y')})s={round(float(hit.get('score', 0.0)), 3)}"
        for hit in corners[:24]
    )
    ctx.log(
        f"角标 {CORNER_ASSET} 在阈值 {CORNER_THRESHOLD} 下命中 {len(corners)} 处（只列前 24）："
        f"{corner_detail}",
        level="info",
    )
    rects = []
    for hit in corners[:24]:
        rect = _card_rect(hit)
        tail = (
            f"整卡 ({rect['x']},{rect['y']},{rect['width']}x{rect['height']})"
            if rect
            else "未知模板尺寸，无内缩可用"
        )
        rects.append(
            f"角标({hit.get('x')},{hit.get('y')},{hit.get('width')}x{hit.get('height')})→{tail}"
        )
    ctx.log(
        "每个角标倒推出的整卡矩形（只列前 24；按 CORNER_TEMPLATE_INSETS 归一化内缩）："
        + "; ".join(rects),
        level="info",
    )

    name = (
        ctx.action("observe.ocr", region=NAME_REGION, det_options=NAME_DET_OPTIONS) or {}
    )
    name_detail = "; ".join(
        f"{str(item.get('text', '')).strip()}@({int(item['centerxy'][0])},{int(item['centerxy'][1])})"
        for item in name.get("items") or []
        if item.get("centerxy")
    )
    ctx.log(f"名字区当前文字：{name_detail}", level="info")

    end_hits = (
        ctx.action(
            "observe.match_asset",
            asset=SCROLL_THUMB_ASSET,
            region=SCROLLBAR_REGION,
            threshold=SCROLL_THUMB_THRESHOLD,
        )
        or []
    )
    end_detail = "; ".join(
        f"({hit.get('centerxy')})s={round(float(hit.get('score', 0.0)), 3)}" for hit in end_hits
    )
    ctx.log(
        f"滑块模板 {SCROLL_THUMB_ASSET} 命中 {len(end_hits)} 处（阈值 {SCROLL_THUMB_THRESHOLD}）："
        f"{end_detail or '未命中'}",
        level="info",
    )
    thumb_ys = [int(hit["centerxy"][1]) for hit in end_hits if hit.get("centerxy")]
    at_bottom = False
    if thumb_ys:
        thumb_y = max(thumb_ys)
        at_bottom = thumb_y >= SCROLL_THUMB_BOTTOM_Y - SCROLL_BOTTOM_TOLERANCE
        ctx.log(
            f"滑块中心 y={thumb_y}（滑轨 {SCROLL_THUMB_TOP_Y}~{SCROLL_THUMB_BOTTOM_Y}）→ "
            f"{'已到底' if at_bottom else '还没到底'}",
            level="info",
        )

    return {
        "numbers": str(len(numbers)),
        "rows": str(len(rows)),
        "corners": str(len(corners)),
        "thumb_y": str(max(thumb_ys)) if thumb_ys else "none",
        "at_bottom": "1" if at_bottom else "0",
    }
