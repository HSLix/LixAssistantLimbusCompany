"""镜牢寻路页面：识别前方三列节点，在第一列里按优先级点击第 attempt 个候选一次。"""
from lalc import RunContext, step

EVENT_ASSET = "mirror/node/event"
SHOP_ASSET = "mirror/node/shop"
ENCOUNTER_ASSET = "mirror/node/regular_encounter"
ELITE_ASSET = "mirror/node/elite_encounter"
FOCUSED_ASSET = "mirror/node/focused_encounter"
ABNORMALITY_ASSET = "mirror/node/abnormality_encounter"
# boss 节点检测与权重设置已移除（Boss 只在楼层末尾出现，SIFT 每次约 0.39 秒却几乎用不上）：
# 原 BOSS_ASSET = "mirror/node/boss_encounter" 与 DEFAULT_WEIGHTS 里的 boss 权重一起下线，
# 需要恢复时把这三处（素材、权重、识别与日志）一并加回
COIN_TAG = "coin"
# 节点类型标签，只用于日志与返回值
KIND_LABELS = {
    "event": "event",
    "shop": "shop",
    "regular": "regular encounter",
    "elite": "elite encounter",
    "focused": "focused encounter",
    "abnormality": "abnormality encounter",
}
# 匹配中心就在节点本体上、点击不需要偏移的节点类型：event、shop 用特征匹配，
# elite encounter、focused encounter 改用模板匹配，命中的同样是节点本体
BODY_KINDS = ("event", "shop", "elite", "focused")
# 只关注节点区域，避开顶部罪孽资源栏和底部罪人栏
REGION = {"x": 200, "y": 50, "width": 900, "height": 570}
# 模板匹配阈值：regular encounter 的 coin 金额图标、elite／focused／abnormality 图标共用
TEMPLATE_THRESHOLD = 0.9
# 模板匹配（regular encounter 的 coin 金额图标、abnormality encounter 图标）命中的是
# 节点上方／节点外的图标，点击点要向下偏移 ICON_TO_NODE_DY 落到节点本体；
# event、shop、elite encounter、focused encounter 与 boss 的匹配中心就在节点本体上，不需要偏移
ICON_TO_NODE_DY = 50
# 火车头归位到 (140, 330)±40 后，寻路页三列节点的固定 x 坐标：
# 第一列（当前节点的下一列）x=380，第二列 x=630，第三列 x=890；
# 识别到的节点中心落在某列 ±COLUMN_X_TOLERANCE 内才算在该列，点击时 x 直接用这个固定值；
# 横向容差左右各 70px：相邻列间距 250/260px，两列容差区间不会重叠；
# 节点本体离固定列坐标偏得较远时仍能归到正确列，不再被误判成“不属于固定列”
COLUMN_XS = (380, 630, 890)
COLUMN_X_TOLERANCE = 70
FIRST_COLUMN_X = COLUMN_XS[0]
# 同一节点被多种模板命中时判重的横向、纵向容忍范围
DEDUPE_DX = 60
# 同一节点被多种类型命中时按这个顺序保留更具体的一条：命中节点本体的类型优先
# （event、shop、elite encounter、focused encounter），其次是 abnormality encounter 图标，
# 最后是靠节点上方 coin 金额图标识别的 regular encounter；
# 这个顺序只决定“同一节点算哪种类型”，不决定选路优先级；
# 同一种匹配在相同区域有多个命中时改为另取分数最高的一处，不记 warning
DEDUPE_ORDER = ("event", "shop", "elite", "focused", "abnormality", "regular")
# 火车头默认停在第二行（中行）：第一列候选同成本时优先离它近的；规划本身不比较火车头到第一列
HEAD_ROW = 1
# 「寻路节点权重」配置：mirror 设置页（PAGE_ID mirror.settings）写入
# settings["mirror.settings"]["path_node_weights"]；兼容旧独立页面写在顶层的配置
MIRROR_PAGE_ID = "mirror.settings"
PATH_WEIGHTS_KEY = "path_node_weights"
LEGACY_PATH_WEIGHTS_KEY = "mirror.path_node_weights"
DEFAULT_WEIGHTS = {
    "shop": 0,
    "event": 1,
    "regular": 3,
    "elite": 6,
    "focused": 9,
    "abnormality": 15,
}
MIN_WEIGHT = 0
MAX_WEIGHT = 99
# 相邻列跨一行（可能交错线路）的成本系数：进入相邻行节点时把该节点权重乘以这个值，默认 1.5
DEFAULT_INTERLEAVE_COST = 1.5
MIN_INTERLEAVE_COST = 0.1
MAX_INTERLEAVE_COST = 10.0
INF = float("inf")
# 纵向容差：两份识别结果落点相差不超过这个距离时视为同一个节点
DEDUPE_DY = 45
# debug log 的行名；三列的固定 x 见 COLUMN_XS
ROW_LABELS = ("上", "中", "下")
ROW_HEIGHT = REGION["height"] // len(ROW_LABELS)
# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上才算寻路界面
PATH_ICON_ASSETS = ("mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects")
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2
# 点击节点后的固定等待秒数：先等确认弹窗动画出来再交回，
# 交回后由 sub_workflow.mirror_pathfind 立刻重新截图检测 Enter（命中就直接进入节点）
AFTER_CLICK_SECONDS = 1.0


def _best_per_region(matches):
    """
    同一种模板匹配在相同区域（DEDUPE_DX／DEDUPE_DY 容差内）有多处命中时，
    只保留匹配分数最高的一处；多命中属于正常现象，不记录 warning。
    """
    kept = []
    for match in matches:
        center = match.get("centerxy") or (0, 0)
        point = (int(center[0]), int(center[1]))
        score = float(match.get("score", 0.0))
        for index, other in enumerate(kept):
            if (
                abs(point[0] - other["point"][0]) <= DEDUPE_DX
                and abs(point[1] - other["point"][1]) <= DEDUPE_DY
            ):
                if score > other["score"]:
                    kept[index] = {"point": point, "score": score, "match": match}
                break
        else:
            kept.append({"point": point, "score": score, "match": match})
    return [item["match"] for item in kept]


def _detect(ctx: RunContext):
    """
    在当前帧的节点区域识别 event、shop、regular encounter、elite encounter、
    focused encounter、abnormality encounter 六类节点（boss 检测已下线）。
    每项候选含 kind、node（节点本体坐标）、icon（需要偏移的图标中心，无偏移的识别结果为 None）：
    event、shop 用特征匹配命中节点本体，命中中心就是节点坐标，不做 y 偏移；
    elite encounter、focused encounter 与 regular encounter 一样用模板匹配，命中的同样是节点本体；
    regular encounter、abnormality encounter 用模板匹配命中节点上方／节点外的图标，
    向下偏移 ICON_TO_NODE_DY 才是节点坐标。
    同一种模板匹配在相同区域有多处命中时只取分数最高的一处，不为多命中记 warning；
    同一节点被多种类型命中时按 DEDUPE_ORDER 去重。
    """
    events = ctx.action("observe.match_feature", asset=EVENT_ASSET, region=REGION) or []
    shops = ctx.action("observe.match_feature", asset=SHOP_ASSET, region=REGION) or []
    elites = (
        ctx.action(
            "observe.match_asset",
            asset=ELITE_ASSET,
            region=REGION,
            threshold=TEMPLATE_THRESHOLD,
        )
        or []
    )
    focuseds = (
        ctx.action(
            "observe.match_asset",
            asset=FOCUSED_ASSET,
            region=REGION,
            threshold=TEMPLATE_THRESHOLD,
        )
        or []
    )
    coins = (
        ctx.action(
            "observe.match_asset",
            asset=ENCOUNTER_ASSET,
            priority_tags=[COIN_TAG],
            region=REGION,
            threshold=TEMPLATE_THRESHOLD,
        )
        or []
    )
    abnormalities = (
        ctx.action(
            "observe.match_asset",
            asset=ABNORMALITY_ASSET,
            region=REGION,
            threshold=TEMPLATE_THRESHOLD,
        )
        or []
    )
    ctx.log(
        f"节点区域 {REGION} 识别到 event {len(events)} 个、shop {len(shops)} 个、"
        f"regular encounter {len(coins)} 个、elite encounter {len(elites)} 个、"
        f"focused encounter {len(focuseds)} 个、abnormality encounter {len(abnormalities)} 个"
    )

    found = []
    for kind, matches in (
        ("event", events),
        ("shop", shops),
        ("elite", _best_per_region(elites)),
        ("focused", _best_per_region(focuseds)),
    ):
        for match in matches:
            center = match.get("centerxy") or (0, 0)
            found.append(
                {"kind": kind, "node": (int(center[0]), int(center[1])), "icon": None}
            )
    for kind, matches in (
        ("abnormality", _best_per_region(abnormalities)),
        ("regular", _best_per_region(coins)),
    ):
        for match in matches:
            center = match.get("centerxy") or (0, 0)
            icon = (int(center[0]), int(center[1]))
            found.append(
                {
                    "kind": kind,
                    "node": (icon[0], icon[1] + ICON_TO_NODE_DY),
                    "icon": icon,
                }
            )

    kept = []
    for kind in DEDUPE_ORDER:
        for item in found:
            if item["kind"] != kind:
                continue
            node = item["node"]
            duplicated = any(
                abs(node[0] - other["node"][0]) <= DEDUPE_DX
                and abs(node[1] - other["node"][1]) <= DEDUPE_DY
                for other in kept
            )
            if duplicated:
                continue
            kept.append(item)
    if len(kept) < len(found):
        ctx.log(f"同一节点被多种模板命中，合并后去掉 {len(found) - len(kept)} 条重复识别结果")
    return kept


def _row_index(node_y: int) -> int:
    """按节点区域高度三等分把节点纵坐标归到上、中、下三行，越界时夹到首尾行。"""
    row = (node_y - REGION["y"]) // ROW_HEIGHT
    return min(max(int(row), 0), len(ROW_LABELS) - 1)


def _column_index(node_x: int):
    """把节点横坐标归到固定的三列之一；超出所有列 ±COLUMN_X_TOLERANCE 范围时返回 None。"""
    matched = None
    best_distance = COLUMN_X_TOLERANCE + 1
    for index, column_x in enumerate(COLUMN_XS):
        distance = abs(node_x - column_x)
        if distance <= COLUMN_X_TOLERANCE and distance < best_distance:
            matched = index
            best_distance = distance
    return matched


def _grid_text(candidates) -> str:
    """
    把候选节点整理成“三列 × 上/中/下”的文本，供寻路 debug log 使用：
    列按固定 x 坐标 COLUMN_XS 归类（第一列是当前节点的下一列），行按节点区域高度三等分。
    每个单元格列出该位置识别到的节点类型，没有节点时写 -；
    落在所有固定列容差之外的识别结果单独列出，不参与点击。
    """
    if not candidates:
        return "寻路节点三列探测：节点区域内没有识别到任何节点"

    cells = [[[], [], []] for _ in COLUMN_XS]
    others = []
    for item in candidates:
        index = _column_index(item["node"][0])
        if index is None:
            others.append(item)
            continue
        cells[index][_row_index(item["node"][1])].append(item["kind"])

    lines = [
        "寻路节点三列探测（第一列＝下一列，固定 x 为 "
        + "/".join(str(column_x) for column_x in COLUMN_XS)
        + f"，容差 ±{COLUMN_X_TOLERANCE}；列内按上/中/下，- 表示未识别到节点）："
    ]
    for index, column_x in enumerate(COLUMN_XS, start=1):
        column_cells = cells[index - 1]
        cell_text = "，".join(
            f"{ROW_LABELS[row]}[{','.join(column_cells[row]) if column_cells[row] else '-'}]"
            for row in range(len(ROW_LABELS))
        )
        lines.append(f"第{index}列 x={column_x}：{cell_text}")
    if others:
        lines.append(
            "不属于固定列的识别结果（不参与点击）："
            + "、".join(
                f"{KIND_LABELS[item['kind']]}({item['node'][0]},{item['node'][1]})"
                for item in others
            )
        )
    return "\n".join(lines)


def _weights(ctx: RunContext):
    """
    读取 settings["mirror.settings"]["path_node_weights"]（兼容顶层旧键 mirror.path_node_weights）
    的节点权重与可能交错线路成本。
    页面未配置、字段缺失或值非法时逐项回落到默认值并记 warning；权重是 0-99 整数，允许同分。
    """
    weights = dict(DEFAULT_WEIGHTS)
    interleave = DEFAULT_INTERLEAVE_COST
    settings = ctx.run_state.settings
    page = None
    if isinstance(settings, dict):
        mirror_settings = settings.get(MIRROR_PAGE_ID)
        if isinstance(mirror_settings, dict) and isinstance(mirror_settings.get(PATH_WEIGHTS_KEY), dict):
            page = mirror_settings[PATH_WEIGHTS_KEY]
        if page is None:
            legacy = settings.get(LEGACY_PATH_WEIGHTS_KEY)
            if isinstance(legacy, dict):
                page = legacy
    if not isinstance(page, dict):
        ctx.log(
            f"未找到寻路节点权重配置 {MIRROR_PAGE_ID}/{PATH_WEIGHTS_KEY}，"
            f"使用默认权重 {weights}、可能交错线路成本 {interleave}"
        )
        return weights, interleave
    raw_weights = page.get("weights")
    if isinstance(raw_weights, dict):
        for kind, default in DEFAULT_WEIGHTS.items():
            value = raw_weights.get(kind)
            if isinstance(value, int) and not isinstance(value, bool) and MIN_WEIGHT <= value <= MAX_WEIGHT:
                weights[kind] = value
            elif value is not None:
                ctx.log(
                    f"寻路权重 {kind}={value!r} 非法（需 {MIN_WEIGHT}-{MAX_WEIGHT} 整数），"
                    f"改用默认 {default}",
                    level="warning",
                )
    raw_cost = page.get("interleave_cost")
    if (
        isinstance(raw_cost, (int, float))
        and not isinstance(raw_cost, bool)
        and MIN_INTERLEAVE_COST <= float(raw_cost) <= MAX_INTERLEAVE_COST
    ):
        interleave = float(raw_cost)
    elif raw_cost is not None:
        ctx.log(
            f"可能交错线路成本 {raw_cost!r} 非法（需 {MIN_INTERLEAVE_COST}-{MAX_INTERLEAVE_COST}），"
            f"改用默认 {DEFAULT_INTERLEAVE_COST}",
            level="warning",
        )
    return weights, interleave


def _grid(candidates):
    """把识别结果放进 3 列 × 上/中/下 的网格；同一格只保留去重后的第一条。"""
    grid = [[None for _ in range(len(ROW_LABELS))] for _ in COLUMN_XS]
    for item in candidates:
        column = _column_index(item["node"][0])
        if column is None:
            continue
        row = _row_index(item["node"][1])
        if grid[column][row] is None:
            grid[column][row] = item
    return grid


def _plan(grid, weights, interleave: float):
    """
    三列三行动态规划：cost(col,row)＝该节点权重 + 后续列最便宜路线的累计成本。
    相邻列同行进入按原权重，相邻行进入把目标节点权重乘以 interleave（可能交错线路成本）；
    行差 2 不算路线；若下一列整列没有节点，该节点视为路线终点。
    返回 {(col,row): {"cost": float, "path": [(col,row,kind), ...]}}。
    """
    best = {}
    last = None
    for column in range(len(COLUMN_XS) - 1, -1, -1):
        if any(grid[column]):
            last = column
            break
    if last is None:
        return best
    for row in range(len(ROW_LABELS)):
        item = grid[last][row]
        if item:
            best[(last, row)] = {
                "cost": float(weights[item["kind"]]),
                "path": [(last, row, item["kind"])],
            }
    for column in range(last - 1, -1, -1):
        next_column = column + 1
        has_next = any(grid[next_column])
        for row in range(len(ROW_LABELS)):
            item = grid[column][row]
            if not item:
                continue
            weight = float(weights[item["kind"]])
            if not has_next:
                best[(column, row)] = {
                    "cost": weight,
                    "path": [(column, row, item["kind"])],
                }
                continue
            options = []
            for next_row in (row - 1, row, row + 1):
                if not 0 <= next_row < len(ROW_LABELS):
                    continue
                entry = best.get((next_column, next_row))
                if entry is None:
                    continue
                factor = 1.0 if next_row == row else interleave
                options.append((entry["cost"] + weight * factor, next_row))
            if not options:
                continue
            total, next_row = min(options)
            best[(column, row)] = {
                "cost": total,
                "path": [(column, row, item["kind"])] + best[(next_column, next_row)]["path"],
            }
    return best


def _rank_first(grid, best):
    """第一列候选按自身最便宜路线的总成本升序；同成本按离火车头默认行近、再按行号靠上。"""
    ranked = []
    for row in range(len(ROW_LABELS)):
        item = grid[0][row]
        if not item:
            continue
        entry = best.get((0, row))
        ranked.append(
            {
                "row": row,
                "kind": item["kind"],
                "node": item["node"],
                "icon": item["icon"],
                "cost": entry["cost"] if entry else INF,
                "path": entry["path"] if entry else [],
            }
        )
    ranked.sort(key=lambda item: (item["cost"], abs(item["row"] - HEAD_ROW), item["row"]))
    return ranked


def _routes_text(ranked, weights, interleave: float) -> str:
    """把第一列各候选的最便宜路线汇总成日志文本，便于核对权重与交错成本。"""
    lines = [
        f"寻路路线比较（权重 {weights}，可能交错线路成本 ×{interleave:.2f}；"
        "相邻列同行与相邻行连通，跨两行不算路线）："
    ]
    for index, item in enumerate(ranked, start=1):
        path_text = " -> ".join(
            f"{KIND_LABELS[kind]}(行{row + 1})" for _, row, kind in item["path"]
        )
        lines.append(
            f"第{index}候选 {KIND_LABELS[item['kind']]} 行{item['row'] + 1}："
            f"总成本 {item['cost']:.1f}，路线 {path_text}"
        )
    return "\n".join(lines)


def _click(ctx: RunContext, item) -> None:
    """点击第一列候选：x 固定用列坐标，y 用节点本体坐标；点完固定等 1 秒交回上层检测 Enter。"""
    click_x = FIRST_COLUMN_X
    click_y = item["node"][1]
    if item["kind"] in BODY_KINDS:
        ctx.log(
            f"点击 {KIND_LABELS[item['kind']]} 节点（匹配中心即节点本体，无需偏移）："
            f"第一列固定 x={click_x} 的 ({click_x}, {click_y})"
        )
        if item["kind"] == "shop":
            ctx.log("进入商店节点后由 task.mirror 的 shop 分支调用 step.mirror_shop_leave 离开商店")
    else:
        icon_x, icon_y = item["icon"]
        ctx.log(
            f"点击 {KIND_LABELS[item['kind']]}：模板命中图标中心 ({icon_x}, {icon_y})，"
            f"向下偏移 {ICON_TO_NODE_DY}px 后点击 ({click_x}, {click_y})"
        )
    ctx.action("control.click", x=click_x, y=click_y)
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)


def _path_page(ctx: RunContext) -> bool:
    """对当前帧右上角匹配三个按钮素材，命中两个及以上才算寻路界面；不刷新截图。"""
    hits = sum(
        1
        for asset in PATH_ICON_ASSETS
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )
    return hits >= MIN_PATH_ICONS


@step
def execute(ctx: RunContext, *, prefer_y: int = 340, attempt: int = 1) -> dict[str, int]:
    """
    识别镜牢寻路页三列节点，按「寻路节点权重」比较第一列各候选成本最低的路线，点击一个候选。
    流程：
    1. 截图复查右上角寻路界面按钮，不足两个时零输入返回。
    2. 识别六类节点（boss 检测已下线），归到固定三列（x=380/630/890，左右各 ±70）与三行
       （上/中/下），打一份网格日志。
    3. 第一列只有一个节点时跳过路线规划、直接点击它（提速路径）。
    4. 第一列有多个节点时读取 settings[mirror.settings][path_node_weights]（兼容顶层旧键）：
       路径成本＝节点权重之和，
       相邻列同行进入按原权重，相邻行（跨一行）进入把目标节点权重乘以「可能交错线路成本」；
       跨两行不算路线；比较第一列各节点各自最便宜的路，成本低者优先，同成本按离火车头
       默认行（第二行）近、再按行号靠上。火车头到第一列不参与成本计算。
    5. attempt 是本次要试的第一列候选序号（1 起，按成本升序）；点下去没出现 Enter 时上层换下一个。
    6. 点击 x 固定为第一列 380，y 用识别到的节点本体纵坐标；点击后固定等 1 秒交回上层检测 Enter。
    返回 {"first_count", "candidate_count", "attempt", "clicked", "row"}；clicked=1 表示本次已点击，
    row 是本次点击节点所在的第一列行号（0=上、1=中、2=下），未点击时为 -1；
    上层据此在保底阶段跳过同一行的固定点，避免重复点刚点过的位置。
    prefer_y 仅为兼容旧调用保留，不再参与排序。
    """
    ctx.action("observe.capture_screen")
    if not _path_page(ctx):
        ctx.log(
            "右上角寻路界面按钮不足，当前不是镜牢寻路页面，不点击节点",
            level="warning",
            screenshot=True,
        )
        return {
            "first_count": 0,
            "candidate_count": 0,
            "attempt": attempt,
            "clicked": 0,
            "row": -1,
        }

    candidates = _detect(ctx)
    if candidates:
        # 三列 × 上/中/下的探测结果连同当前截图一起保存，方便对照识别结果与点击位置
        ctx.log(_grid_text(candidates), screenshot=True)
    else:
        # 没有识别到任何节点时只保留文字信息，不再附带截图
        ctx.log(_grid_text(candidates))
        ctx.log("节点区域里没有识别到任何节点，本步不点击", level="warning")
        return {
            "first_count": 0,
            "candidate_count": 0,
            "attempt": attempt,
            "clicked": 0,
            "row": -1,
        }

    # 只认固定的第一列（下一列）；第一列没有节点时不能退到更远的列
    first_column = [item for item in candidates if _column_index(item["node"][0]) == 0]
    if not first_column:
        ctx.log(
            f"第一列 x={FIRST_COLUMN_X}±{COLUMN_X_TOLERANCE} 里没有识别到节点，本步不点击更远的列",
            level="warning",
            screenshot=True,
        )
        return {
            "first_count": 0,
            "candidate_count": 0,
            "attempt": attempt,
            "clicked": 0,
            "row": -1,
        }

    # 提速：第一列只有一个节点，不做三列路线规划，直接点击；已试过一次就不再重复点，交回上层保底
    if len(first_column) == 1:
        if attempt != 1:
            ctx.log(
                f"第一列只有 1 个节点，第 {attempt} 次尝试不再重复点击，交回上层进入固定点保底",
                level="warning",
            )
            return {
                "first_count": 1,
                "candidate_count": 1,
                "attempt": attempt,
                "clicked": 0,
                "row": -1,
            }
        chosen = first_column[0]
        row = _row_index(chosen["node"][1])
        ctx.log(
            f"第一列只有 1 个节点（{KIND_LABELS[chosen['kind']]}，行{row + 1}），"
            "跳过路线规划直接点击"
        )
        _click(ctx, chosen)
        return {
            "first_count": 1,
            "candidate_count": 1,
            "attempt": 1,
            "clicked": 1,
            "row": row,
        }

    weights, interleave = _weights(ctx)
    grid = _grid(candidates)
    best = _plan(grid, weights, interleave)
    ranked = _rank_first(grid, best)
    ctx.log(_routes_text(ranked, weights, interleave), screenshot=True)

    if attempt < 1 or attempt > len(ranked):
        # 候选数比上层记录少（识别结果变化）：不点击，交回上层重新观察并换下一个候选
        ctx.log(
            f"第一列目前有 {len(ranked)} 个候选，第 {attempt} 次尝试超出范围，本步不点击",
            level="warning",
            screenshot=True,
        )
        return {
            "first_count": len(first_column),
            "candidate_count": len(ranked),
            "attempt": attempt,
            "clicked": 0,
            "row": -1,
        }

    chosen = ranked[attempt - 1]
    ctx.log(
        f"按最低成本点击第 {attempt}/{len(ranked)} 个候选：{KIND_LABELS[chosen['kind']]} "
        f"行{chosen['row'] + 1}，总成本 {chosen['cost']:.1f}，"
        f"路线 {[KIND_LABELS[kind] for _, _, kind in chosen['path']]}"
    )
    _click(ctx, chosen)
    return {
        "first_count": len(first_column),
        "candidate_count": len(ranked),
        "attempt": attempt,
        "clicked": 1,
        "row": chosen["row"],
    }
