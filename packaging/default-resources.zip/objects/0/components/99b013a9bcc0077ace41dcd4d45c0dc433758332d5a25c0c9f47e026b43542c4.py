"""处理 Exploration Reward 结算弹窗：按参数或页面配置点 Give Up Rewards / Claim，并确认弹窗关闭。"""
import re

from lalc import ExecutionFailure, RunContext, step

# 弹窗标题与按钮所在区域（1280x720 客户区）
POPUP_REGION = {"x": 210, "y": 90, "width": 850, "height": 510}
# 以下文本均为去掉空白和符号后的小写形式，便于和 OCR 结果比较
TITLE_TEXT = "explorationreward"
GIVE_UP_LABEL = "giveuprewards"
CLAIM_LABEL = "claim"
# 点 Give Up Rewards 后游戏会再弹一次确认弹窗
END_TEXT = "endexpeditionwithoutclaimingrewards"
CONFIRM_LABEL = "confirm"
CONFIRM_FALLBACK = (780, 492)
# 每次点击后的固定等待秒数；弹窗推进由 sub_workflow.mirror_reward_settlement 重新观察
AFTER_CLICK_SECONDS = 0.5
# 弹窗两个按钮的回退坐标：最左 Give Up Rewards，最右 Claim
GIVE_UP_FALLBACK = (407, 544)
CLAIM_FALLBACK = (861, 545)
# 页面配置位置：settings[PAGE_ID]["reward_rules"] = {"victory": 领取/放弃, "defeat": ..., "unknown": ...}
SETTINGS_PAGE_ID = "mirror.settings"
RULES_KEY = "reward_rules"
# 本场镜牢刚结算结果：由 victory／defeat 的结算 Step 写入，plan 进入 task.mirror 前刷新为 unknown
RUNTIME_KEY = "mirror.runtime"
LAST_RESULT_KEY = "last_result"
MODE_GIVE_UP = "give_up"
MODE_CLAIM = "claim"
# 未配置或配置非法时的默认值：刚胜利默认领取，刚失败与未知默认不领取
DEFAULT_MODES = {"victory": MODE_CLAIM, "defeat": MODE_GIVE_UP, "unknown": MODE_GIVE_UP}
CONDITIONS = ("victory", "defeat", "unknown")


def _region_items(ctx: RunContext, region: dict[str, int]) -> list[dict]:
    """刷新截图并返回指定区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=region) or {}
    return list(result.get("items") or [])


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 把按钮读成 GiveUpRewards 这类连写形式。"""
    return re.sub(r"[^a-z0-9]", "", text.lower())


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _popup_visible(texts: str) -> bool:
    """弹窗特征：标题 Exploration Reward 出现，或两个按钮文案同时出现。"""
    return TITLE_TEXT in texts or (GIVE_UP_LABEL in texts and CLAIM_LABEL in texts)


def _configured_mode(ctx: RunContext) -> tuple[str, str]:
    """
    按「本场镜牢刚结算结果」读取页面配置的结算方式，返回 (模式, 判定说明)。
    刚胜利默认领取，刚失败与未知默认不领取；读不到刚结算结果时按 unknown 处理。
    """
    settings = ctx.run_state.settings or {}
    runtime = settings.get(RUNTIME_KEY)
    last = "unknown"
    if isinstance(runtime, dict):
        last = str(runtime.get(LAST_RESULT_KEY) or "unknown").strip().lower()
    if last not in CONDITIONS:
        last = "unknown"
    page = settings.get(SETTINGS_PAGE_ID)
    rules = page.get(RULES_KEY) if isinstance(page, dict) else None
    value = ""
    if isinstance(rules, dict):
        value = str(rules.get(last) or "").strip().lower()
    mode = value if value in (MODE_CLAIM, MODE_GIVE_UP) else DEFAULT_MODES[last]
    return mode, f"last_result={last}，规则 {mode}"


def _click_button(
    ctx: RunContext,
    items: list[dict],
    label: str,
    fallback: tuple[int, int],
    allow_fallback: bool = True,
) -> bool:
    """点击文字（规范化后）包含 label 且最接近 fallback 的按钮；未识别到且 allow_fallback 时才用固定坐标。"""
    wanted = _norm(label)
    candidates = [
        item for item in items if wanted and wanted in _norm(str(item.get("text", "")))
    ]
    if not candidates:
        if not allow_fallback:
            # 等待期间状态可能已变化，盲点固定坐标会误触其它弹窗的按钮
            ctx.log(f"当前帧未识别到 {label}，不做盲点，重新判断状态", level="warning")
            return False
        ctx.log(f"弹窗未识别到 {label} 文本，点击回退坐标 {fallback}", level="warning")
        ctx.action("control.click", x=fallback[0], y=fallback[1])
        return True

    def distance(item: dict) -> float:
        """候选按钮中心到回退坐标的距离。"""
        center = item.get("centerxy") or fallback
        return ((center[0] - fallback[0]) ** 2 + (center[1] - fallback[1]) ** 2) ** 0.5

    target = min(candidates, key=distance)
    ctx.log(f"弹窗点击 {label} @ {target.get('centerxy')}")
    ctx.action("control.click", centerxy=tuple(target.get("centerxy")))
    return True


@step
def execute(
    ctx: RunContext,
    *,
    claim: bool | None = None,
) -> None:
    """
    处理 Exploration Reward 结算弹窗，只做一次局部尝试：
    claim=True 点最右 Claim 领取奖励，claim=False 点最左 Give Up Rewards 不领取，
    claim=None 时按「刚结算结果 + reward_rules」判定。
    End expedition without claiming rewards 确认弹窗在时只点一次 Confirm，不做任何其它输入。
    不在该弹窗时零输入返回；动作后最多固定等 0.5 秒就交回，
    弹窗是否关闭、确认弹窗是否出现由 sub_workflow.mirror_reward_settlement 下一轮重新观察。
    """
    items = _region_items(ctx, POPUP_REGION)
    texts = _items_text(items)
    if END_TEXT in texts:
        ctx.log("End expedition without claiming rewards 弹窗已在，点击一次 Confirm")
        _click_button(ctx, items, CONFIRM_LABEL, CONFIRM_FALLBACK, allow_fallback=False)
        ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
        return

    if not _popup_visible(texts):
        ctx.log("当前没有 Exploration Reward 结算弹窗，无需处理")
        return

    if claim is None:
        mode, detail = _configured_mode(ctx)
        claim = mode == MODE_CLAIM
        ctx.log(f"未显式指定结算方式，按镜牢结算规则处理：{detail}")

    label, fallback = (CLAIM_LABEL, CLAIM_FALLBACK) if claim else (GIVE_UP_LABEL, GIVE_UP_FALLBACK)
    action = "claim" if claim else "give_up"
    _click_button(ctx, items, label, fallback)
    ctx.log(f"Exploration Reward 结算弹窗点击一次 {label}（action={action}），等 {AFTER_CLICK_SECONDS} 秒后交回")
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
