"""处理 Game client is not up to date 弹窗：重启游戏，最多等待 10 分钟观察是否回到可识别界面。

现场（1280x720，2026-11-26 11:03，服务端维护结束后的那一帧）：
标题界面（TOUCH TO START）上弹出 Game client is not up to date. / Please update to the latest version.，
底部一个居中 Close（实测文字中心 (638,467)）。维护结束往往伴随客户端版本更新：点掉弹窗只会留在旧客户端，
所以本规则直接 control.restart_game 让启动器重新拉起并拉取新版本，重启后最多等 10 分钟，
以标题界面特征（restart/clear_all_caches）且没有新的阻挡弹窗作为就绪证据。
等待分片执行（单次 observe.wait 上限 60 秒），暂停与取消仍由 observe.wait 响应；预算耗尽只记录后交回。
"""
import re

from lalc import RunContext

POPUP_NAME = "Game client is not up to date"
# 弹窗文案：Game client is not up to date. / Please update to the latest version.
POPUP_KEYWORD = "gameclientisnotuptodate"
# 重启后最多观察 10 分钟
RESTART_WAIT_SECONDS = 600
POLL_SECONDS = 10
# 就绪证据：标题界面左下角 Clear all caches（与 recovery.title_to_main 同一素材）
READY_ASSET = "restart/clear_all_caches"
# 仍压着这些弹窗就不算就绪，交由对应规则或下一轮检测处理
BLOCKING_KEYWORDS = (POPUP_KEYWORD, "scheduledmaintenance", "cannotoperatethegame")


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _current_text(ctx: RunContext) -> str:
    """对当前已捕获帧整屏 OCR，返回规范化文本；不刷新截图。"""
    result = ctx.action("observe.ocr") or {}
    items = result.get("items") or []
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _visible(ctx: RunContext) -> bool:
    """刷新截图后判断当前帧是否压着本弹窗。"""
    ctx.action("observe.capture_screen")
    return POPUP_KEYWORD in _current_text(ctx)


def _ready(ctx: RunContext) -> bool:
    """当前帧是否已回到标题界面且没有挡住流程的弹窗。"""
    if not ctx.action("observe.match_asset", asset=READY_ASSET):
        return False
    text = _current_text(ctx)
    return not any(keyword in text for keyword in BLOCKING_KEYWORDS)


def detect(ctx: RunContext) -> bool:
    """只观察弹窗文案，不在检测阶段点击或重启。"""
    found = _visible(ctx)
    ctx.log(f"检测 {POPUP_NAME} 弹窗：{found}")
    return found


def recover(ctx: RunContext) -> None:
    """重启游戏（让启动器拉取新版本），重启后最多等待 10 分钟观察是否回到可识别界面。"""
    if POPUP_KEYWORD not in _current_text(ctx):
        ctx.log(f"{POPUP_NAME} 弹窗已消失，无需重启")
        return

    ctx.log(f"检测到 {POPUP_NAME} 弹窗，重启游戏以加载最新客户端")
    ctx.action("control.restart_game")
    waited = 0.0
    while waited < RESTART_WAIT_SECONDS:
        ctx.action("observe.wait", seconds=POLL_SECONDS)
        waited += POLL_SECONDS
        ctx.action("observe.capture_screen")
        if _ready(ctx):
            ctx.log(f"重启后 {waited:.0f} 秒已回到标题界面，交回主流程重新观察")
            return
    ctx.log(
        f"重启后等到 {RESTART_WAIT_SECONDS // 60} 分钟仍未回到可识别界面，交回主流程重新观察",
        level="warning",
        screenshot=True,
    )
