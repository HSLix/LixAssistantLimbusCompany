"""镜牢商店「自维护饰品」辅助一步：把 Sell E.G.O Gift 弹窗右侧饰品列表上下滚动。

子流程本身不能直接调用鼠标滚动这类控制动作，所以滚动集中放在这个 Step 里：
鼠标移到格区中间、按 direction 向下或向上滚 steps 格，再等固定时间让列表停稳；
滚动效果由上层重新截图后的观察来判断（现在看右侧滚动条滑块位置，开发期也用价格数字核实）。
"""
from lalc import RunContext, step

# 格区中间偏下的滚动位置（1280x720 实测列表区域 x 615~1120、y 195~535）
GRID_SCROLL_POINT = (880, 365)
# 滚动后等待列表停稳
SCROLL_SETTLE_SECONDS = 0.8


@step
def execute(ctx: RunContext, *, steps: int = 3, direction: str = "down") -> dict[str, str]:
    """
    在格区中间按 direction 滚动 steps 格并等待停稳；返回滚动的方向与格数。
    滚动不改变任何选中状态，也不点选饰品；是否已经到底由上层看右侧滚动条滑块位置判断。
    """
    if not isinstance(steps, int) or not 1 <= steps <= 10:
        raise ValueError("steps 必须是 1~10 的整数")
    if direction not in ("down", "up"):
        raise ValueError("direction 只能是 down 或 up")
    ctx.log(f"把饰品格区往{'下' if direction == 'down' else '上'}滚 {steps} 格（位置 {GRID_SCROLL_POINT}）")
    ctx.action("control.scroll", direction=direction, steps=steps, centerxy=GRID_SCROLL_POINT)
    ctx.action("observe.wait", seconds=SCROLL_SETTLE_SECONDS)
    return {"steps": str(steps), "direction": direction}
