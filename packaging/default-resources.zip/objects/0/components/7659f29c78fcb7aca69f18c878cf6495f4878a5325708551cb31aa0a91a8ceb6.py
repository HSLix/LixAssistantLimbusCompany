"""镜牢商店「自维护饰品」子流程：购买循环开始前，把 Sell E.G.O Gift 弹窗里还没存过的饰品按流派存进素材库。

格子定位靠「价格行给标称位置 + 角标给精确矩形」两级：现场（1280x720）实测卡片宽 68、高 73，
第 1 列卡片左边 645、列距 92（不是整百）、行距 107，价格数字中心 y 比卡片顶边低 89
（卡片顶 215 → 价格 304、顶 322 → 价格 411）。列距按固定 100 算会让第 5 列偏 32 像素，
所以这里只用价格行反推「这一屏有哪些完整可见的行、每行的标称顶边」，真正的整卡裁剪由
step.mirror_sell_gift_slot 在点击之前用卡片框左下角的角标 mirror/shop/ego_corner 倒推：
命中角标就按角标定位，匹配不到才退回标称几何。价格行同时用于行级去重与到底判据。
（Run 437/438 的结论仍成立：拿角标在整片格区做 0.5 阈值聚类是噪声灾难，卡片被选中后边框高亮
也会破坏角标；这里只在单格窗口内、点击之前按高阈值匹配。）
开发者也说明弹窗最多只完整显示两行、也就是十个饰品，并且贴近列表上沿、被裁掉大半的残行连卡片
都截不全，必须忽略（留一点缓冲）。

流程（每轮先截图，所有识别都来自本次截图）：
- 弹窗没开 → 调 step.mirror_sell_gift_popup 点一次商店页的 Sell Gifts 按钮；仍打不开就返回 completed=False；
- 每一屏：先按价格数字聚行、反推卡片顶边，只保留完整可见的行（顶边不低于首行 215 减 8 像素缓冲，
  且卡片底边不超过列表下沿 535）；再对格区做一次 mirror/gift 整组批量匹配
  （阈值不显式传参，沿用 observe.match_asset_group 的默认值 0.9），
  命中中心落在格子里的视为已保存、不点，并把命中结果按「行从上到下、行内从左到右」逐条写进日志；
  其余格子按从上到下、从左到右逐个调 step.mirror_sell_gift_slot（一格只点一次，点击前用角标倒推
  整卡矩形再暂存裁剪，读到名字与流派后才保存成 mirror/gift/<流派>/<名字>）。开发者要求：整组匹配
  达不到默认阈值 0.9 的格子一律纳入收录范围，不再用 0.75 放宽阈值复核判成「已存过」——无论这格是新饰品，
  还是已入库但当前外观与现有模板差得较多（换皮肤、缩放漂移、残留选中态等），都要在点选后补一张裁剪
  （已入库的饰品追加到原逻辑名下，新饰品才按流派建目录），下次才能按默认阈值 0.9 命中；只有点击后名字与点击前不同的格子才会保存——
  点空格子或点到本来就处于选中态的卡片时名字不变，这类裁剪可能带选中高亮，Run 472 就是因此把
  mirror/gift/keywordless/perversion 存成了同名第二张图（高亮态模板，与干净态 d8b268… 并存）；
- 一屏处理完后先看右侧滚动条：滑块中心 y 到了滑轨底部（实测顶端 235、底端 466）就说明已经到底、
  结束扫描；没到底则把格区往下滚 5 格继续处理下一屏，最多 MAX_SCREENS 屏；
- 收到 dry_run=True 时整条链路只做识别与日志，不写共享素材库（用于现场验证几何与名字/流派识别是否准确）；
- 结束时调 step.mirror_sell_gift_close 关掉弹窗，关不掉再试一次。
只点饰品格与 Close，绝不点弹窗里的 Sell 按钮；任何识别失败都只记 warning 并跳过该饰品，
不让自维护拖住后面的购买循环。
检测明细集中在 debug 级别（info 只留每屏一行摘要）：这一屏反推出的卡片行几何、命中的饰品、
未命中的格子都逐条记录，命中按「行从上到下、行内从左到右」排好，未命中另起一条日志单独记录，
两类都带行号／列号与画面坐标（命中给真实匹配中心，未命中给格子标称中心），便于对照整屏核对哪一格还没入库。
日志口径：saved 统计的是「本轮写入素材的个数」，不是图鉴新增饰品数（同名素材已存在但本次裁剪哈希不同时
会新增一张图并计数），所以最终日志同时给出「涉及几个饰品名」和「同名重复写入几次」。
"""
import re

from lalc import RunContext, sub_workflow

# 右侧饰品列表区域（1280x720 实测：卡片 x=645+92*列，列表右边界 ≈1120）
GRID_REGION = {"x": 615, "y": 195, "width": 505, "height": 345}
# 已保存饰品图鉴组：整组匹配不传 threshold，直接用 observe.match_asset_group 的默认阈值 0.9
# （开发者要求删除原来 0.85 的自定义阈值，改用默认值）。达不到该默认阈值的格子一律进入点选收录：
# 无论它是新饰品还是已入库但外观与现有模板差得较多，都要补一张裁剪，下次才能按默认阈值命中。
GIFT_GROUP = "mirror/gift"
# 命中中心与格子中心的横纵偏差在这个范围内就算同一个格子
SAME_CELL_RADIUS = 40
# 卡片几何（与 step.mirror_sell_gift_slot 保持一致，1280x720 现场实测）：
# 第 1 列卡片左边 645、列距 92（不是整百）、卡宽 68、卡高 73；行距 107
COLUMNS = 5
COLUMN_LEFT = 645
COL_STEP = 92
CARD_WIDTH = 68
CARD_HEIGHT = 73
# 每列卡片中心的标称 x（列号 0 起），只用于 debug 日志里说明这一屏扫到了哪些格子位置
COLUMN_CENTERS = [COLUMN_LEFT + COL_STEP * column + CARD_WIDTH // 2 for column in range(COLUMNS)]
# 价格数字中心 y 比卡片顶边低 89（现场复核：卡片顶 215 的价格在 304、顶 322 的价格在 411）
PRICE_TOP_DELTA = 89
# 同一行的价格数字 y 相差不超过这么多像素
ROW_TOLERANCE = 8
# 一行至少要有这么多个价格数字才算真实的卡片行（单条数字是等级字样与图标噪声）
MIN_ROW_PRICES = 2
# 开发者现场说明：弹窗最多只完整显示两行（十个）；首行卡片顶边实测 215，
# 高于首行再减 TOP_BUFFER 的价格行属于被列表上沿裁切的残行，连卡片都截不到，一律忽略。
FIRST_ROW_TOP = 215
TOP_BUFFER = 8
# 列表底边：卡片底边超过这里就算被裁切（实测列表区域下沿约 535）
LIST_BOTTOM = 535
# 一屏处理完后往下滚的格数（滚动动作集中在 step.mirror_sell_gift_scroll 里）
SCROLL_STEPS = 5
# 右侧滚动条区域（1280x720 实测：滑块 x≈1103..1122、滑轨 y≈197..504），用滑块位置判定是否到底
SCROLLBAR_REGION = {"x": 1090, "y": 190, "width": 50, "height": 330}
# 滑块模板：同一块滑块在滑轨顶端和底端都能命中，靠命中中心的 y 判断位置
SCROLL_THUMB_ASSET = "mirror/shop/sell_gift_scroll_end"
SCROLL_THUMB_THRESHOLD = 0.8
# 滑块命中中心 y：实测顶端 235、滚 10 格到底后 466
SCROLL_THUMB_TOP_Y = 235
SCROLL_THUMB_BOTTOM_Y = 466
SCROLL_BOTTOM_TOLERANCE = 6
# 最多处理几屏：每屏至多两行十个，防止滚动不生效时空转
MAX_SCREENS = 4


def _cell_center(row_top: int, column: int):
    """卡片标称顶边 + 列号 → 标称卡片中心（仅作为角标搜索基准，实际裁剪由角标倒推）。"""
    left = COLUMN_LEFT + COL_STEP * column
    return (left + CARD_WIDTH // 2, row_top + CARD_HEIGHT // 2)


def _rows(ctx: RunContext) -> list:
    """
    从格区价格数字反推这一屏的卡片行：价格中心 y 按 8 像素聚行，行顶边 = 价格 y - 89。
    只保留完整可见的行：顶边不低于首行基线 215 再减 8 像素缓冲，且卡片底边不超过列表下沿；
    滚动后贴在列表上沿、被裁掉大半的残行一律忽略——这类行既截不到完整卡片，点它也选不中饰品
    （开发者补充的现场说明）。返回 [(行顶边, 该行价格数字列表), ...]，按行顶边从上到下。
    """
    result = ctx.action("observe.ocr", region=GRID_REGION) or {}
    clusters: list = []
    for item in result.get("items") or []:
        digits = re.sub(r"[^0-9]", "", str(item.get("text", "")))
        center = item.get("centerxy")
        if len(digits) < 2 or not center:
            continue
        y = int(center[1])
        for cluster in clusters:
            if abs(cluster[0] - y) <= ROW_TOLERANCE:
                cluster[1].append(digits)
                break
        else:
            clusters.append([y, [digits]])
    rows = []
    for y, prices in clusters:
        if len(prices) < MIN_ROW_PRICES:
            continue
        top = y - PRICE_TOP_DELTA
        if top < FIRST_ROW_TOP - TOP_BUFFER:
            ctx.log(
                f"价格行 y={y} 反推的卡片顶边 {top} 高于首行 {FIRST_ROW_TOP}，"
                "按被裁切的残行忽略（截不到完整卡片）"
            )
            continue
        if top + CARD_HEIGHT > LIST_BOTTOM:
            ctx.log(
                f"价格行 y={y} 反推的卡片底边 {top + CARD_HEIGHT} 超出列表下沿 {LIST_BOTTOM}，忽略"
            )
            continue
        rows.append((top, prices))
    rows.sort()
    return rows


def _rows_report(title: str, rows: list, cells: dict) -> str:
    """
    把命中格子排成一条日志文案：行从上到下，行内从左到右。
    rows 是本次识别到的完整卡片行（顺序即屏内行序）；cells 的键是 (行顶边, 0 起列号)，
    值是 (素材逻辑名, 匹配分数, 哈希, 命中中心)。没命中的行也写出来，方便对照整屏核对。
    """
    lines = []
    for index, (top, _prices) in enumerate(rows, start=1):
        parts = [
            f"第{column + 1}列 {name or '(同名素材)'}（score {score}）"
            for (cell_top, column), (name, score, _sha256, _center) in sorted(
                cells.items(), key=lambda item: item[0][1]
            )
            if cell_top == top
        ]
        lines.append(f"第{index}行（卡片顶边 {top}）：" + ("；".join(parts) if parts else "未命中"))
    return (
        f"{title}命中 {len(cells)} 个已存过的饰品（按行从上到下、行内从左到右）："
        + " ｜ ".join(lines)
    )


def _layout_report(ctx: RunContext, title: str, rows: list, cells: dict) -> None:
    """
    debug 级别记录本屏检测明细：命中的饰品按「行从上到下、行内从左到右」排好，
    未命中的格子另起一条日志单独记录，两类都带格子位置（行号／列号）与画面坐标。
    rows 是本次识别到的完整卡片行（顺序即屏内行序）；cells 的键是 (行顶边, 0 起列号)，
    值是 (素材逻辑名, 匹配分数, 哈希, 命中中心)。命中中心取真实匹配位置，
    未命中只能给出格子的标称中心，便于对照整屏核对哪一格还没入库。
    """
    matched_lines = []
    missing = []
    for index, (top, _prices) in enumerate(rows, start=1):
        parts = []
        for column in range(COLUMNS):
            cx, cy = _cell_center(top, column)
            cell = cells.get((top, column))
            if cell is None:
                missing.append(f"第{index}行第{column + 1}列@({cx},{cy})")
                continue
            name, score, _sha256, center = cell
            hit_center = center or (cx, cy)
            parts.append(
                f"第{column + 1}列 {name or '(同名素材)'}"
                f"（score {score}，命中中心 {hit_center[0]},{hit_center[1]}）"
            )
        matched_lines.append(
            f"第{index}行（卡片顶边 {top}）：" + ("；".join(parts) if parts else "本行没有命中")
        )
    ctx.log(
        f"{title}：命中 {len(cells)} 个饰品，按行从上到下、行内从左到右排列 → "
        + " ｜ ".join(matched_lines),
        level="debug",
    )
    ctx.log(
        f"{title}：未命中 {len(missing)} 个格子（行／列／标称中心）→ "
        + ("、".join(missing) if missing else "无"),
        level="debug",
    )


def _saved_cells(ctx: RunContext, rows: list) -> dict:
    """
    对当前帧的格区做一次 mirror/gift 图鉴组整组识别（一次匹配拿到库里所有已存饰品模板的命中；
    阈值不显式传参，沿用 observe.match_asset_group 的默认值 0.9），
    返回 {命中格子(行顶边, 列号): (素材逻辑名, score, sha256, 命中中心)}；
    本屏最终的命中／未命中明细由 _layout_report 在 debug 级别按行列写清。
    落在这些格子里的饰品说明素材库里已经存过，本次不再点选、也不重复保存；
    只有没命中的格子才进入逐个点选、读名字、判流派、存档的循环。
    整组识别是唯一判据：开发者要求取消原来 0.75 的放宽阈值复核，并删除 0.85 的自定义阈值、
    改用 Action 默认的 0.9——低于这个默认阈值的格子不能判成「已存过」，
    无论它是新饰品还是已入库但当前外观与现有模板差得较多（换皮肤、缩放漂移、残留选中态），
    都交给点选收录补一张裁剪，这样图鉴下次才能按默认阈值命中同一件饰品。
    """
    hits = (
        ctx.action(
            "observe.match_asset_group",
            group=GIFT_GROUP,
            region=GRID_REGION,
        )
        or []
    )
    cells: dict = {}
    for hit in hits:
        center = hit.get("centerxy")
        if not center:
            continue
        x, y = int(center[0]), int(center[1])
        best = None
        for top, _prices in rows:
            for column in range(COLUMNS):
                cx, cy = _cell_center(top, column)
                if abs(x - cx) <= SAME_CELL_RADIUS and abs(y - cy) <= SAME_CELL_RADIUS:
                    distance = abs(x - cx) + abs(y - cy)
                    if best is None or distance < best[0]:
                        best = (distance, top, column)
        if best is None:
            ctx.log(
                f"mirror/gift 命中 {hit.get('logical_name')} @{center} 但中心落在格子外"
                "（多在被裁切的残行上），忽略"
            )
            continue
        cells[(best[1], best[2])] = (
            str(hit.get("logical_name") or ""),
            round(float(hit.get("score", 0.0)), 3),
            str(hit.get("sha256") or ""),
            (x, y),
        )
    ctx.log(_rows_report("本屏 mirror/gift 全组匹配（默认阈值 0.9）", rows, cells))
    # 不再有 0.75 放宽阈值的第二遍复核：没达到默认阈值 0.9 的格子全部留给上层点选收录
    unmatched = len(rows) * COLUMNS - len(cells)
    ctx.log(
        f"本屏 {len(rows) * COLUMNS} 个格子里 {len(cells)} 个按默认阈值 0.9 命中已存过，"
        f"其余 {unmatched} 个格子无论新老饰品都进入点选收录"
    )
    # 本屏最终的命中／未命中明细：命中按行列排好，未命中另起一行，全部带位置（debug 级）
    _layout_report(ctx, "本屏 mirror/gift 检测明细", rows, cells)
    return cells


def _at_bottom(ctx: RunContext) -> bool:
    """
    用右侧滚动条滑块的位置判定是否到底：先在滚动条区域匹配滑块模板（镜像不同状态都能命中），
    再看命中中心的 y 是否到了滑轨底部（实测底端 466，容差 6 像素）。
    比对比格区价格数字更快（一次模板匹配，不用 OCR），也不会被饰品价格变化干扰；
    滑块没匹配到时按未到底处理，靠行签名与屏数上限兜底。
    """
    hits = (
        ctx.action(
            "observe.match_asset",
            asset=SCROLL_THUMB_ASSET,
            region=SCROLLBAR_REGION,
            threshold=SCROLL_THUMB_THRESHOLD,
        )
        or []
    )
    ys = [int(hit["centerxy"][1]) for hit in hits if hit.get("centerxy")]
    if not ys:
        ctx.log(
            f"右侧滚动条没匹配到滑块模板 {SCROLL_THUMB_ASSET}，按未到底处理",
            level="warning",
        )
        return False
    thumb_y = max(ys)
    at_bottom = thumb_y >= SCROLL_THUMB_BOTTOM_Y - SCROLL_BOTTOM_TOLERANCE
    ctx.log(
        f"右侧滚动条滑块中心 y={thumb_y}（滑轨 {SCROLL_THUMB_TOP_Y}~{SCROLL_THUMB_BOTTOM_Y}），"
        f"{'已到底' if at_bottom else '还没到底'}"
    )
    return at_bottom


def _popup_open(ctx: RunContext) -> bool:
    """弹窗是否还开着：标题横幅里同时有 sell 与 gift，或左下角读到 Close。"""
    title = ctx.action("observe.ocr", region={"x": 500, "y": 76, "width": 300, "height": 54}) or {}
    text = re.sub(
        r"[^a-z0-9]",
        "",
        " ".join(str(item.get("text", "")) for item in title.get("items") or []).lower(),
    )
    if "sell" in text and "gift" in text:
        return True
    close = ctx.action(
        "observe.ocr", region={"x": 438, "y": 560, "width": 116, "height": 48}
    ) or {}
    flat = re.sub(
        r"[^a-z0-9]",
        "",
        " ".join(str(item.get("text", "")) for item in close.get("items") or []).lower(),
    )
    return "close" in flat


@sub_workflow
def execute(ctx: RunContext, *, dry_run: bool = False, max_slots: int = 0) -> dict[str, str | bool]:
    """
    自维护饰品主流程：打开 Sell E.G.O Gift 弹窗 → 逐屏逐格识别未保存的饰品并按流派存档 → 关闭弹窗。
    dry_run=True 时只识别与记录日志、不写共享素材库；max_slots>0 时最多处理这么多个格子（0 表示不限制）。
    返回 completed（是否走完关闭弹窗）、reason、saved（写入素材的张数）、distinct（涉及几个饰品名）、
    skipped、empty、screens 计数。
    任何识别失败都不抛错，最多返回 completed=False，让购买循环继续。
    """
    ctx.action("observe.capture_screen")
    opened = ctx.call("step.mirror_sell_gift_popup") or {}
    status = str(opened.get("status") or "")
    if status not in ("opened", "already_open"):
        ctx.log(
            "Sell E.G.O Gift 弹窗打不开，本次跳过饰品自维护（不影响后续购买）",
            level="warning",
            screenshot=True,
        )
        return {
            "completed": False,
            "reason": "sell_gift_popup_missing",
            "saved": "0",
            "skipped": "0",
            "empty": "0",
            "screens": "0",
        }

    checked_assets = set()
    handled: list = []
    # 本轮写入过的素材逻辑名，用于在日志里区分「写入几张图」与「涉及几个饰品名」
    written_assets: list = []
    saved = 0
    skipped = 0
    empty = 0
    processed = 0
    screens = 0
    # 已处理过的卡片行签名（该行价格数字集合）：滚动后与上一屏重叠的行不再重复点选
    seen_rows: set = set()
    for screen_index in range(1, MAX_SCREENS + 1):
        ctx.action("observe.capture_screen")
        if not _popup_open(ctx):
            ctx.log(
                f"第{screen_index}屏：Sell E.G.O Gift 弹窗已不在，结束扫描",
                level="warning",
                screenshot=True,
            )
            break
        screens = screen_index
        rows = _rows(ctx)
        if not rows:
            ctx.log(f"第{screen_index}屏：格区里没有完整可见的卡片行，结束扫描")
            break
        fresh_rows = [
            (top, prices)
            for top, prices in rows
            if tuple(sorted(prices)) not in seen_rows
        ]
        if not fresh_rows:
            ctx.log(f"第{screen_index}屏：识别到的卡片行都已经处理过，结束扫描")
            break
        rows = fresh_rows
        already = _saved_cells(ctx, rows)
        geometry = "；".join(
            f"第{index}行 卡片顶边 {top}、价格中心 y={sorted(prices)}、"
            f"列中心 x={COLUMN_CENTERS}"
            for index, (top, prices) in enumerate(rows, start=1)
        )
        ctx.log(f"第{screen_index}屏格区几何：{geometry}", level="debug")
        ctx.log(
            f"第{screen_index}屏：按价格行反推出 {len(rows)} 个未处理过的完整卡片行"
            f"（卡片顶边 {[top for top, _prices in rows]}），"
            f"mirror/gift 整组命中 {len(already)} 个已存过的格子，"
            f"其余 {len(rows) * COLUMNS - len(already)} 个格子逐个点选收录"
            "（未达默认阈值 0.9 一律收录）"
        )
        limit_reached = False
        for row_number, (top, _prices) in enumerate(rows, start=1):
            seen_rows.add(tuple(sorted(_prices)))
            for column in range(COLUMNS):
                column_number = column + 1
                known_cell = already.get((top, column))
                if known_cell is not None:
                    known_asset, known_score, _known_sha256, known_center = known_cell
                    skipped += 1
                    ctx.log(
                        f"第{row_number}行第{column_number}列：mirror/gift 已存过 {known_asset}"
                        f"（score {known_score}，命中中心 "
                        f"{known_center or _cell_center(top, column)}，"
                        f"格子标称中心 {_cell_center(top, column)}），本格不点选",
                        level="debug",
                    )
                    continue
                if max_slots > 0 and processed >= max_slots:
                    ctx.log(f"已达到本次处理的格子上限 {max_slots}，提前结束扫描")
                    limit_reached = True
                    break
                cx, cy = _cell_center(top, column)
                processed += 1
                scan_reason = "mirror/gift 未达默认阈值 0.9，进入点选收录（无论新老饰品）"
                ctx.log(
                    f"第{row_number}行第{column_number}列：{scan_reason}"
                    f"（格子标称中心 {cx},{cy}）",
                    level="debug",
                )
                result = (
                    ctx.call(
                        "step.mirror_sell_gift_slot",
                        row=row_number,
                        col=column_number,
                        cx=cx,
                        cy=cy,
                        handled="|".join(handled),
                        dry_run=dry_run,
                    )
                    or {}
                )
                slot_status = str(result.get("status") or "")
                name = str(result.get("name") or "")
                if slot_status in ("saved", "dry_run"):
                    if slot_status == "saved":
                        checked_assets.add(result["asset"])
                    saved += 1
                    written_assets.append(str(result.get("asset") or name))
                    if name:
                        handled.append(name)
                elif slot_status in ("keyword_unknown", "name_conflict"):
                    skipped += 1
                    if name:
                        handled.append(name)
                elif slot_status == "unchanged":
                    # 点击前后左侧名字相同：这一击没有换选中项（空格子，或该卡本来就是选中态、裁剪带高亮）
                    empty += 1
                elif slot_status in ("empty", "duplicate"):
                    empty += 1
                    if name:
                        handled.append(name)
                else:
                    ctx.log(
                        f"第{row_number}行第{column_number}列返回未知状态 {slot_status!r}，按跳过处理",
                        level="warning",
                    )
                    skipped += 1
            if limit_reached:
                break
        ctx.log(
            f"第{screen_index}屏处理完：写入素材 {saved} 个（涉及 {len(set(written_assets))} 个饰品名）、"
            f"跳过 {skipped}、空格 {empty}（演练模式 {dry_run}）"
        )
        # 到底判据放在处理完之后：最后一屏仍需要扫完才停，只是滚动后滑块到滑轨底部就说明没有下一屏
        if _at_bottom(ctx):
            ctx.log(f"第{screen_index}屏：滚动条滑块已经到滑轨底部，列表到底，结束扫描")
            break
        if max_slots > 0 and processed >= max_slots:
            break
        if screen_index < MAX_SCREENS:
            ctx.log(f"第{screen_index}屏处理完，把格区往下滚 {SCROLL_STEPS} 格找下一屏")
            ctx.call("step.mirror_sell_gift_scroll", steps=SCROLL_STEPS)

    closed = ctx.call("step.mirror_sell_gift_close") or {}
    if str(closed.get("status") or "") == "still_open":
        ctx.log("第一次没能关掉 Sell E.G.O Gift 弹窗，再点一次 Close", level="warning")
        ctx.call("step.mirror_sell_gift_close")
    distinct_assets = len(set(written_assets))
    ctx.log(
        f"饰品自维护结束：扫描 {screens} 屏、处理 {processed} 个格子；"
        f"{'演练识别' if dry_run else '写入素材'} {saved} 个（涉及 {distinct_assets} 个饰品名，"
        f"同名重复写入 {max(0, saved - distinct_assets)} 次）、跳过 {skipped}、空格 {empty}"
        f"（演练模式 {dry_run}）；写入数是本轮写入素材的格子数，不是图鉴新增饰品数"
    )
    return {
        "completed": True,
        "reason": "dry_run" if dry_run else "done",
        "saved": str(saved),
        "distinct": str(distinct_assets),
        "skipped": str(skipped),
        "empty": str(empty),
        "screens": str(screens),
    }
