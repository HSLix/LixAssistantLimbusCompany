"""处理 The weekly record has been reset. / Moving over to the Window. 通知：点一次 Cancel 留在当前镜牢探索。"""
import re

from lalc import RunContext, step

# 通知文案（Run 639 现场）：The weekly record has been reset. / Moving over to the Window.
# 两行都按规范化小写匹配，避开句号和断行；两句同时出现才认定是该通知，避免其它弹窗误匹配
NOTICE_KEYWORDS = ("weeklyrecordhasbeenreset", "movingovertothewindow")
CANCEL_LABEL = "cancel"
# Cancel 按钮在 1280x720 客户区的实测中心 (537, 465)；识别不到按钮文字时退回该坐标
CANCEL_FALLBACK = (537, 465)
# 点击后的固定等待秒数；通知是否已关闭由上层下一轮重新观察，本步不轮询
AFTER_CLICK_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _click_cancel(ctx: RunContext, items: list[dict]) -> None:
    """点击文字包含 cancel 的按钮，识别不到时退回固定坐标。"""
    candidates = [
        item for item in items if CANCEL_LABEL in _norm(str(item.get("text", "")))
    ]
    if not candidates:
        ctx.log(f"通知里未识别到 Cancel 文本，点击回退坐标 {CANCEL_FALLBACK}", level="warning")
        ctx.action("control.click", x=CANCEL_FALLBACK[0], y=CANCEL_FALLBACK[1])
        return

    def distance(item: dict) -> float:
        """候选按钮中心到回退坐标的距离。"""
        center = item.get("centerxy") or CANCEL_FALLBACK
        return (
            (center[0] - CANCEL_FALLBACK[0]) ** 2 + (center[1] - CANCEL_FALLBACK[1]) ** 2
        ) ** 0.5

    target = min(candidates, key=distance)
    ctx.log(f"通知点击 Cancel @ {target.get('centerxy')}")
    ctx.action("control.click", centerxy=tuple(target.get("centerxy")))


@step
def execute(ctx: RunContext) -> None:
    """
    截图后没看到 weekly record 重置通知时零输入返回；看到时只点一次 Cancel（不离开当前探索），
    等固定 1 秒后交回。通知是否已关闭由上层下一轮重新观察，本步不轮询、不重复点击。
    """
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    items = list(result.get("items") or [])
    text = _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))
    if not all(word in text for word in NOTICE_KEYWORDS):
        ctx.log("当前没有 weekly record 重置通知，无需处理")
        return

    _click_cancel(ctx, items)
    ctx.log(f"已点击 Cancel，等 {AFTER_CLICK_SECONDS} 秒后交回上层重新观察通知是否关闭")
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
