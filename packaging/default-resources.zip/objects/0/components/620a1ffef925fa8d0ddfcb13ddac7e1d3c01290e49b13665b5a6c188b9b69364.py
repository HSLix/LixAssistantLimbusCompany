"""队伍准备页：按队伍配置的罪人顺序选出战罪人，需要时先点 Clear Selection 清空顺序。"""
import re

from lalc import RunContext, step

PREPARE_ASSETS = (
    "prepare_team/all_identities",
    "prepare_team/all_ego",
    "prepare_team/facades",
)
SELECTED_ASSET = "prepare_team/selected"
BACKUP_ASSET = "prepare_team/backup"
# Clear Selection 有亮色可点与灰色不可点两种外观，素材库都收录，只用来确认按钮存在
CLEAR_ASSET = "prepare_team/clear_selection"
# 队伍配置页（sinners.team_presets）保存的 PAGE_ID
TEAM_PRESET_PAGE_ID = "sinners.team_presets"

MAX_TEAMS = 40
TEAM_SIZE = 12
COLUMNS = 6
# 罪人顺序与游戏配队页面中间的十二个人像框一致（左到右、上到下），也是队伍配置页的保存顺序
SINNERS = (
    "yi_sang",
    "faust",
    "don_quixote",
    "ryoshu",
    "meursault",
    "hong_lu",
    "heathcliff",
    "ishmael",
    "rodion",
    "sinclair",
    "outis",
    "gregor",
)
# 人像框中心横坐标与点击纵坐标：纵坐标取中间偏下，避开顶部会打开罪人详情的区域
COLUMN_X = (293, 426, 559, 691, 824, 957)
ROW_Y = (270, 470)
# 右下角 Participants Total 的上限数字区域（0/12 中的 12）：已选用模板命中数统计，上限只在这里找一个 1~12 的数
CAPACITY_REGION = {"x": 1180, "y": 490, "width": 50, "height": 60}
CAPACITY_PATTERN = re.compile(r"\d+")
CAPACITY_DEFAULT = TEAM_SIZE
# 点击 Clear Selection 后等 2 秒让 Reset Deployment Order? 弹窗出现；按 Enter 确认后再等 2 秒
CLEAR_WAIT = 2.0
ENTER_WAIT = 2.0


def _configured_team(ctx: RunContext, team_index: int) -> list[str]:
    """从队伍配置页的保存结果里取出第 team_index 个队伍（1 起）的罪人顺序。"""
    page = (ctx.run_state.settings or {}).get(TEAM_PRESET_PAGE_ID) or {}
    teams = page.get("teams")
    if not isinstance(teams, list) or not 1 <= team_index <= len(teams):
        ctx.log(f"队伍配置里没有第{team_index}个队伍，按空队伍处理", level="warning")
        return []
    entry = teams[team_index - 1]
    if isinstance(entry, dict):
        entry = entry.get("sinners")
    if not isinstance(entry, list):
        return []
    return [str(value).strip() for value in entry]


def _on_prepare_page(ctx: RunContext) -> bool:
    """重新截图并判断当前是否处于队伍准备页面。"""
    ctx.action("observe.capture_screen")
    return any(ctx.action("observe.match_asset", asset=asset) for asset in PREPARE_ASSETS)


def _count(ctx: RunContext) -> int:
    """用 SELECTED 与 BACKUP 两个标识的命中数统计当前已选人数。"""
    selected = ctx.action("observe.match_asset", asset=SELECTED_ASSET) or []
    backup = ctx.action("observe.match_asset", asset=BACKUP_ASSET) or []
    return len(selected) + len(backup)


def _capacity(ctx: RunContext) -> int:
    """
    只从右下角上限数字区域（1180,490）-（1230,550）里找一个 1~12 的数字作为可选人数；
    识别不到合法的 1~12 数字时记 warning，按默认 12 人处理。
    """
    result = ctx.action("observe.ocr", region=CAPACITY_REGION) or {}
    items = sorted(
        result.get("items") or [],
        key=lambda item: (
            int((item.get("box") or {}).get("y", 0)),
            int((item.get("box") or {}).get("x", 0)),
        ),
    )
    text = "".join(str(item.get("text", "")) for item in items)
    for match in CAPACITY_PATTERN.finditer(text):
        value = int(match.group(0))
        if 1 <= value <= TEAM_SIZE:
            ctx.log(f"右下角识别到可选人数上限 {value} 人（区域文字 {text!r}）")
            return value
    ctx.log(
        f"右下角未识别到 1~{TEAM_SIZE} 的可选人数上限（区域文字 {text!r}），按默认 {CAPACITY_DEFAULT} 人处理",
        level="warning",
        screenshot=True,
    )
    return CAPACITY_DEFAULT


def _clear(ctx: RunContext) -> None:
    """
    只做一次清空尝试：找不到 Clear Selection 或已选 0 人时零输入返回；
    否则点一次 Clear Selection、等 2 秒让 Reset Deployment Order? 弹窗出现，
    按一次 Enter 确认、再等 2 秒后返回，清空是否生效由上层重新截图判断。
    已选 0 人时按钮是灰色不可点，点击和按 Enter 都不会有响应，直接视为无需清空。
    """
    matches = ctx.action("observe.match_asset", asset=CLEAR_ASSET) or []
    if not matches:
        ctx.log("队伍准备页找不到 Clear Selection 按钮，跳过清空，交回上层", level="warning", screenshot=True)
        return

    # 按钮存在但已选 0 人时它是灰色不可点的，不点击也不按 Enter，避免误触发其他操作
    if _count(ctx) == 0:
        ctx.log("当前已选 0 人，Clear Selection 为灰色不可点，跳过清空")
        return

    if len(matches) > 1:
        ctx.log(f"Clear Selection 命中{len(matches)}个，存在歧义，按第一个点击", level="warning")
    ctx.action("control.click", centerxy=matches[0]["centerxy"])
    ctx.log(f"点击 Clear Selection，等待 {CLEAR_WAIT} 秒让 Reset Deployment Order? 弹窗出现")
    ctx.action("observe.wait", seconds=CLEAR_WAIT)
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=ENTER_WAIT)
    ctx.log("已按 Enter 确认清空选择，清空结果由上层重新截图判断")


def _target_order(ctx: RunContext, configured: list[str]) -> tuple[list[str], int]:
    """按配置顺序得到待点击的罪人顺序；无论可选上限多少，都固定凑满 12 人。"""
    order: list[str] = []
    for value in configured:
        sinner = str(value).strip()
        if sinner not in SINNERS:
            ctx.log(f"队伍配置里的 {sinner} 不是已知罪人，已忽略", level="warning")
            continue
        if sinner not in order:
            order.append(sinner)
    if len(order) > TEAM_SIZE:
        ctx.log(f"配置了 {len(order)} 人，超过队伍上限 {TEAM_SIZE} 人，只选前 {TEAM_SIZE} 人", level="warning")
        order = order[:TEAM_SIZE]
    filled = 0
    if len(order) < TEAM_SIZE:
        ctx.log(f"配置只选出 {len(order)} 人，没到 {TEAM_SIZE} 人，开始默认补位")
        for sinner in SINNERS:
            if len(order) >= TEAM_SIZE:
                break
            if sinner not in order:
                order.append(sinner)
                filled += 1
        ctx.log(f"默认补位 {filled} 人，本次选择顺序：{','.join(order)}")
    return order, filled


def _point(sinner: str) -> tuple[int, int]:
    """返回罪人人像框的点击坐标：第一行 6 人，第二行 6 人，按罪人固定顺序排列。"""
    index = SINNERS.index(sinner)
    return COLUMN_X[index % COLUMNS], ROW_Y[index // COLUMNS]


@step
def execute(
    ctx: RunContext,
    *,
    team_index: int = 1,
    team: list[str] | None = None,
    first_clear_selection: bool = True,
) -> None:
    """
    在队伍准备页把出战罪人调整成队伍配置的样子（只选人，不点 To Battle）。
    队伍顺序默认读队伍配置页里第 team_index 个队伍，也可用 team 直接指定。

    first_clear_selection=True：先做一次 Clear Selection 清空尝试（已选 0 人时按钮灰色不可点，直接跳过），
    再按配置顺序依次点击罪人。点击人数固定为 12 人，与右下角可选上限无关：
    配置人数不足 12 人时其余罪人按默认顺序补位；可选上限小于 12 人时多点的罪人不会生效，
    由上层下一轮重新截图判断实际人数。
    first_clear_selection=False：调用方表示本场镜牢已经按配置选过出战顺序（runtime 已记录）；
    已选人数正好等于可选上限时直接交回，不重复清空与重选；
    人数少于上限（镜牢里可能有人阵亡、队伍被改动）时无法确认顺序，记 warning 后清空重选。
    跳过条件是“已选 == 可选”而不是写死的 12 人，实际人数随可选上限变化。
    已选人数用 SELECTED 与 BACKUP 两个模板的命中数统计，只用于入口判断；
    可选上限只从右下角上限数字区域找一个 1~12 的数字，识别不到时默认 12 人。
    点击罪人是一组固定动作：每个罪人只点一次，点完不观察、不补点，
    也不在这里核对最终人数，是否选好由上层下一轮重新截图分派。
    """
    if type(team_index) is not int or not 1 <= team_index <= MAX_TEAMS:
        raise ValueError(f"team_index 必须是 1~{MAX_TEAMS} 的整数")

    if team is None:
        configured = _configured_team(ctx, team_index)
    else:
        configured = [str(value).strip() for value in team]

    if not _on_prepare_page(ctx):
        ctx.log("当前不是队伍准备页面，本 Step 不点击，交回上层", level="warning")
        return

    # 队伍列表中点击新队伍后，中间阵容会重新加载：固定等 1 秒后重新截图取人数
    ctx.action("observe.wait", seconds=1.0)
    ctx.action("observe.capture_screen")

    capacity = _capacity(ctx)
    before = _count(ctx)
    ctx.log(f"第{team_index}个队伍的配置顺序：{configured}；可选上限 {capacity} 人，当前已选 {before} 人")

    if not first_clear_selection and before == capacity:
        ctx.log(
            f"本场镜牢已记录选过出战顺序，且已选 {before} 人正好等于可选上限 {capacity} 人，本次不清空、不重选"
        )
        return

    if not first_clear_selection:
        ctx.log(
            f"已选 {before} 人与可选上限 {capacity} 人不同（镜牢里可能有人阵亡或队伍被改动），"
            "无法确认顺序，改为清空后按配置重选",
            level="warning",
        )

    _clear(ctx)

    order, filled = _target_order(ctx, configured)
    if not order:
        ctx.log("没有可点击的罪人，队伍无法配置，交回上层", level="warning", screenshot=True)
        return

    # 逐个点出按配置顺序的罪人：这是一组固定动作，每个罪人只点一次，点完不观察、不补点，
    # 是否生效由上层下一轮重新截图分派
    for position, sinner in enumerate(order, start=1):
        x, y = _point(sinner)
        ctx.action("control.click", x=x, y=y)
        ctx.log(f"点击第{position}个罪人 {sinner} ({x}, {y})")
    ctx.log(
        f"已按配置顺序点击 {len(order)} 个罪人（可选上限 {capacity} 人，默认补位 {filled} 人）：{','.join(order)}"
    )
