"""镜牢寻路界面：点 Dungeon Progress 弹窗的 To Window，再按 Enter，确认已离开寻路界面。"""
import re

from lalc import RunContext, step

# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上就算寻路界面
PATH_ICON_ASSETS = ("mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects")
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2
# Dungeon Progress 弹窗：标题是弹窗独有文案，To Window 是弹窗里横排第四个按钮
POPUP_REGION = {"x": 350, "y": 165, "width": 580, "height": 400}
POPUP_KEYWORD = "dungeonprogress"
TO_WINDOW_POINT = (739, 452)
TO_WINDOW_WAIT = 1.5
# 按 Enter 后的固定等待秒数；是否已离开寻路界面交给上层下一轮重新观察
AFTER_ENTER_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响弹窗标题匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _texts(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做 OCR，返回合并后的规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _icons(ctx: RunContext) -> int:
    """对当前帧右上角匹配三个按钮素材，返回命中数量；不刷新截图。"""
    return sum(
        1
        for asset in PATH_ICON_ASSETS
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )


def _left_path(ctx: RunContext) -> bool:
    """寻路界面标识不足两个且 Dungeon Progress 弹窗不在，判定已经离开寻路界面；不刷新截图。"""
    return _icons(ctx) < MIN_PATH_ICONS and POPUP_KEYWORD not in _texts(ctx, POPUP_REGION)


@step
def execute(ctx: RunContext) -> None:
    """
    先截图复查入口：寻路界面标识已消失（已离开）时零输入返回；
    Dungeon Progress 弹窗不在时也不做任何输入；
    否则点一次 To Window 固定坐标、等 1.5 秒让新弹窗出现，再按一次 Enter，
    等固定 1 秒后交回。是否已离开寻路界面由 sub_workflow.mirror_exit 下一轮重新观察。
    """
    ctx.action("observe.capture_screen")
    if _left_path(ctx):
        ctx.log("寻路界面标识已经消失，无需再点 To Window")
        return
    if POPUP_KEYWORD not in _texts(ctx, POPUP_REGION):
        ctx.log("Dungeon Progress 弹窗不在，本轮不做任何输入", level="warning", screenshot=True)
        return

    ctx.action("control.click", centerxy=TO_WINDOW_POINT)
    ctx.log(f"点击 Dungeon Progress 弹窗的 To Window 固定坐标 {TO_WINDOW_POINT}")
    ctx.action("observe.wait", seconds=TO_WINDOW_WAIT)
    ctx.action("control.key_press", key="enter")
    ctx.log(f"在新弹窗按 Enter 确认回主界面，等 {AFTER_ENTER_SECONDS} 秒后交回")
    ctx.action("observe.wait", seconds=AFTER_ENTER_SECONDS)
