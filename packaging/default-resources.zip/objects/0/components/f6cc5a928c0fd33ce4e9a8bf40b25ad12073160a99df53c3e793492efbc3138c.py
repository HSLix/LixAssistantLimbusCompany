"""现场观察探针：重新截图后按固定坐标点击一次并等待，供人工/工具侧观察落点；不做业务判断。"""
from lalc import RunContext, step


@step
def execute(ctx: RunContext, *, x: int, y: int, wait_seconds: float = 1.2) -> None:
    """
    开发期观察用的最小动作：重新截图 → 点击一次固定坐标 → 等固定秒数 → 再截图。
    本步没有页面入口判据，只在画面风险可控时由开发者手动试运行；
    点击是否生效、落到哪个界面由试运行后的截图与 OCR 判断，本步不重试也不轮询。
    """
    if not 0 <= x < 10000 or not 0 <= y < 10000:
        raise ValueError("点击坐标必须是合理的客户区像素坐标")
    if not 0.0 <= wait_seconds <= 60.0:
        raise ValueError("wait_seconds 必须在 0~60 秒之间")

    meta = ctx.action("observe.capture_screen")
    ctx.log(
        f"探针点击前画面 {meta['width']}x{meta['height']}，准备点击 ({x}, {y})",
        screenshot=True,
    )
    ctx.action("control.click", x=x, y=y)
    ctx.action("observe.wait", seconds=wait_seconds)
    ctx.action("observe.capture_screen")
    ctx.log(f"探针已点击 ({x}, {y}) 并等待 {wait_seconds} 秒，落点见本次截图", screenshot=True)
