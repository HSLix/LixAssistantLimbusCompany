"""把前序任务留在 Luxcavation 页面的现场退回主页面，供 plan 在进入镜牢前调用。"""
from lalc import RunContext, task_workflow

# Luxcavation 页独有的标题：模板优先，漏识别时用标题区域 OCR 兜底
TITLE_ASSET = "luxcavation/title"
TITLE_REGION = {"x": 60, "y": 178, "width": 175, "height": 42}
TITLE_KEYWORD = "luxcavation"
# 主页面底部导航：Drive 图标与 Window 页图标同时出现才算回到主页面
DRIVE_ASSETS = ("main_navigate/drive", "main_navigate/drive_selected")
WINDOW_ASSETS = ("main_navigate/window", "main_navigate/window_selected")
# 图标模板都漏识别时的兜底：底部导航图标下方的 Window／Drive 文字区域
NAV_REGION = {"x": 770, "y": 630, "width": 265, "height": 45}
NAV_KEYWORDS = ("window", "drive")


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回合并后的小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    return " ".join(str(item.get("text", "")) for item in items if item.get("text")).lower()


def _any_asset(ctx: RunContext, assets: tuple[str, ...]) -> bool:
    """一组模板里任意一个命中即为真。"""
    return any(ctx.action("observe.match_asset", asset=asset) for asset in assets)


def _title_present(ctx: RunContext) -> bool:
    """当前帧是否仍有 Luxcavation 标题：模板优先，漏识别时用标题区域 OCR 兜底。"""
    if ctx.action("observe.match_asset", asset=TITLE_ASSET):
        return True
    return TITLE_KEYWORD in _region_text(ctx, TITLE_REGION)


def _on_main(ctx: RunContext) -> bool:
    """当前帧是否为主页面：Drive 与 Window 图标同时命中，模板都漏识别时用导航文字兜底。"""
    if _any_asset(ctx, DRIVE_ASSETS) and _any_asset(ctx, WINDOW_ASSETS):
        return True
    text = _region_text(ctx, NAV_REGION)
    return all(keyword in text for keyword in NAV_KEYWORDS)


@task_workflow
def execute(ctx: RunContext) -> dict[str, str]:
    """调用一次退出步骤后自行重新截图，判断标题消失且主页图标出现，返回文本完成状态。"""
    ctx.call("step.luxcavation_back_to_main")
    ctx.action("observe.capture_screen")
    title_gone = not _title_present(ctx)
    on_main = _on_main(ctx)
    if title_gone and on_main:
        ctx.log("Luxcavation 标题已消失，主页面 Drive/Window 图标已出现")
        return {"completed": "true", "reason": "back_to_main"}
    ctx.log(
        f"退出后尚未确认回到主页面：标题消失={title_gone} 主页图标={on_main}",
        level="warning",
        screenshot=True,
    )
    return {"completed": "false", "reason": "not_on_main"}
