"""处理 Could Not Load Notice 弹窗：用 OCR 文字特征识别，避免与其它羊皮纸弹窗误匹配。"""
from lalc import RunContext

POPUP_NAME = "Could Not Load Notice"
# 弹窗文案：Could not load notices. Please check your network connection.
POPUP_KEYWORD = "could not load"
CONFIRM_X = 650
CONFIRM_Y = 500
# 3 次 × 2 秒；耗尽后交还主流程，由外部「恢复规则→重试→恢复规则」再次介入
MAX_RETRIES = 3
POLL_SECONDS = 2


def _ocr_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回整屏 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    return list(result.get("items") or [])


def _visible(items: list[dict]) -> bool:
    """任一 OCR 文本包含弹窗关键字即认为弹窗存在。"""
    return any(POPUP_KEYWORD in str(item.get("text", "")).lower() for item in items)


def _confirm_target(items: list[dict]) -> dict | None:
    """找文字完全等于 confirm 的按钮条目。"""
    for item in items:
        if str(item.get("text", "")).strip().lower() == "confirm":
            return item
    return None


def detect(ctx: RunContext) -> bool:
    """只观察弹窗文字，不在检测阶段点击。"""
    found = _visible(_ocr_items(ctx))
    ctx.log(f"检测 {POPUP_NAME} 弹窗：{found}")
    return found

def recover(ctx: RunContext) -> None:
    """逐次点击 Confirm，直到 OCR 不再命中弹窗文案。"""
    for attempt in range(1, MAX_RETRIES + 1):
        items = _ocr_items(ctx)
        if not _visible(items):
            ctx.log(f"{POPUP_NAME} 弹窗已消失，恢复成功")
            return

        target = _confirm_target(items)
        center = target.get("centerxy") if target else None
        if center:
            ctx.log(f"{POPUP_NAME} 弹窗存在，点击识别到的 Confirm @ {center}")
            ctx.action("control.click", centerxy=tuple(center))
        else:
            ctx.log(f"{POPUP_NAME} 弹窗存在，点击固定坐标 {(CONFIRM_X, CONFIRM_Y)}", level="warning")
            ctx.action("control.click", x=CONFIRM_X, y=CONFIRM_Y)

        ctx.log(f"第{attempt}/{MAX_RETRIES}次点击后等待弹窗消失")
        ctx.action("observe.wait", seconds=POLL_SECONDS)

    if _visible(_ocr_items(ctx)):
        ctx.log(
            f"{POPUP_NAME} 弹窗 {MAX_RETRIES} 次点击后仍未消失，交还主流程继续观察",
            level="error",
            screenshot=True,
        )
        return
    ctx.log(f"{POPUP_NAME} 弹窗已消失，恢复成功")

