"""主界面体力读数：OCR 左下角体力条区域，解析「当前/上限」并计算溢出比例，只识别不点击。"""
import re

from lalc import RunContext, step

# 主界面左下角体力读数区域（1280x720 实测 "21/159" 位于 x362~417、y659~685，"159/159" 位于 x359~421）。
# 只框住「当前/上限」这一行：同一 HUD 上方的 226 计数（x356~392、y627~654）与脑啡肽模块数
# 977（x442~477、y627~654）被一起框进来时，整段 OCR 会拼成 "22697721/159"，
# Run 490 因此把体力解析成 7721/159（4856%）误判成溢出，反复重做体力转换直到分支上限。
STAMINA_REGION = {"x": 340, "y": 656, "width": 100, "height": 46}
# 体力右侧的脑啡肽模块数量（1280x720 实测 "977" 位于 x442~477、y627~654）
MODULE_REGION = {"x": 430, "y": 620, "width": 70, "height": 45}
# 模块上限：达到 999 后没有兑换余量，不再执行体力转换
MODULE_CAP = 999
# 当前体力占上限的比例超过该值就认为体力将要溢出，需要先做体力转换
OVERFLOW_THRESHOLD = 0.7
# OCR 可能把读数识别成 "159/159" 或拆成多段，先去空白再按分隔符解析
STAMINA_PATTERN = re.compile(r"(\d{1,4})[/\\|](\d{1,4})")
# 模块数量是单独的数字（可能带图标噪声），取区域内第一段 1~4 位数字
MODULE_PATTERN = re.compile(r"\d{1,4}")


def _region_items(ctx: RunContext, region: dict[str, int]) -> list[str]:
    """对当前帧指定区域做一次局部 OCR，返回每条文本去空白后的小写结果；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    return [
        re.sub(r"\s+", "", str(item.get("text", ""))).lower()
        for item in items
        if item.get("text")
    ]


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回去掉空白的小写合并文本；不刷新截图。"""
    return "".join(_region_items(ctx, region))


def _module_count(text: str) -> int | None:
    """从模块区域文字里取模块数量；读不到数字时返回 None。"""
    match = MODULE_PATTERN.search(text)
    return int(match.group(0)) if match else None


def _read_stamina(texts: list[str]) -> tuple[int, int] | None:
    """
    从体力区域文字里解析（当前, 上限）；解析不出可采信读数时返回 None。
    先按单条 OCR 文本整条匹配，避免相邻数字被拼进同一段；单条都不成立时才拼接兜底。
    只采信「当前不大于上限」的读数：游戏内体力不会超过上限，超出即说明读到了别的数字
    （Run 490 的 7721/159 就是模块数 977 与 226 计数被拼进来的结果）。
    """

    def _accept(current_text: str, maximum_text: str) -> tuple[int, int] | None:
        current, maximum = int(current_text), int(maximum_text)
        if maximum > 0 and current <= maximum:
            return current, maximum
        return None

    for text in texts:
        match = STAMINA_PATTERN.fullmatch(text)
        if match:
            read = _accept(match.group(1), match.group(2))
            if read:
                return read
    joined = "".join(texts)
    for current_text, maximum_text in reversed(STAMINA_PATTERN.findall(joined)):
        read = _accept(current_text, maximum_text)
        if read:
            return read
    return None


@step
def execute(ctx: RunContext) -> dict[str, str | int | float | bool]:
    """
    读取主界面体力条与脑啡肽模块数量，返回 current／max／ratio／overflow／modules／module_full。

    模块数量达到 MODULE_CAP 时 module_full=True，上层据此跳过体力转换（没有兑换余量）。
    读不到「当前/上限」时只记 warning 并返回 readable=False，不把识别失败当成业务失败；
    本步不点击、不等待。
    """
    ctx.action("observe.capture_screen")
    texts = _region_items(ctx, STAMINA_REGION)
    text = "".join(texts)
    module_text = _region_text(ctx, MODULE_REGION)
    modules = _module_count(module_text)
    module_full = modules is not None and modules >= MODULE_CAP

    read = _read_stamina(texts)
    if read is None:
        ctx.log(
            f"体力区域未读到可采信的「当前/上限」读数，区域文字：{text}；模块读数 {modules}",
            level="warning",
            screenshot=True,
        )
        return {
            "readable": False,
            "text": text,
            "current": 0,
            "max": 0,
            "ratio": 0.0,
            "overflow": False,
            "modules": modules if modules is not None else -1,
            "module_full": module_full,
        }

    current, maximum = read
    ratio = current / maximum
    overflow = ratio > OVERFLOW_THRESHOLD
    ctx.log(
        f"体力读数 {current}/{maximum}，比例 {ratio:.1%}，"
        f"{'超过' if overflow else '未超过'} {OVERFLOW_THRESHOLD:.0%} 阈值；"
        f"脑啡肽模块 {modules if modules is not None else '未读到'}"
        f"（上限 {MODULE_CAP}，{'已满' if module_full else '未满'}）"
    )
    return {
        "readable": True,
        "text": text,
        "current": current,
        "max": maximum,
        "ratio": ratio,
        "overflow": overflow,
        "modules": modules if modules is not None else -1,
        "module_full": module_full,
    }
