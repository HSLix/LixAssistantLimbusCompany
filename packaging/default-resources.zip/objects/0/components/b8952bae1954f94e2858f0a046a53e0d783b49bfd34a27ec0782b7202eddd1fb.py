"""事件判定提示面板（右上角 Advantage）：复查入口后点击一次右下角固定坐标推进，是否推进交回上层重新观察。"""
import re

from lalc import RunContext, step

# 判定提示面板：右上角 Advantage／Disadvantage 提示条所在区域（1280x720 客户区）
ADVANTAGE_REGION = {"x": 820, "y": 100, "width": 380, "height": 100}
ADVANTAGE_KEYWORD = "advantage"
DISADVANTAGE_KEYWORD = "disadvantage"
# 右下角固定落点：与判定结算页、（事件）结果页共用同一位置，避免依赖按钮文案；
# 这块画面右下角的 SKIP 此时不可用，只点一次固定坐标，不再按 Enter
ADVANTAGE_CLICK_POINT = (1140, 650)
# 点击后固定等待秒数：本步只做一次动作，是否已离开面板由上层下一轮重新截图判断
CLICK_WAIT_SECONDS = 1.0


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _advantage_open(ctx: RunContext) -> bool:
    """右上角提示条是否读到 Advantage：Disadvantage 含同样的子串，先排除再判断。"""
    text = _region_text(ctx, ADVANTAGE_REGION)
    return ADVANTAGE_KEYWORD in text and DISADVANTAGE_KEYWORD not in text


@step
def execute(ctx: RunContext) -> None:
    """
    事件判定提示面板的一次局部尝试：
    1. 先重新截图复查入口：右上角没有 Advantage（含已推进到选人页、叙述页等情况）时零输入返回；
    2. 确认仍在判定提示面板时，只点击一次右下角固定坐标 ADVANTAGE_CLICK_POINT，
       不再按 Enter（面板上的 Enter 不稳定），等 CLICK_WAIT_SECONDS 秒后返回。
    是否已离开面板、是否进入判定选人页都由 sub_workflow.event 下一轮重新截图验收：
    本步不轮询、不重试，也不返回任何局部结果。
    """
    ctx.action("observe.capture_screen")
    if not _advantage_open(ctx):
        ctx.log("右上角没有 Advantage 判定提示，本步不点击", level="warning", screenshot=True)
        return

    click_x, click_y = ADVANTAGE_CLICK_POINT
    ctx.log(
        f"右上角识别到 Advantage 判定提示，点击右下角固定坐标 ({click_x}, {click_y}) 一次推进判定（不按 Enter）"
    )
    ctx.action("control.click", x=click_x, y=click_y)
    ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
