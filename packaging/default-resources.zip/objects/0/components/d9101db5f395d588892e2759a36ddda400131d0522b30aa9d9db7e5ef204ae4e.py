"""事件结果页：识别到 Result 标题后先按两次 Enter（间隔 1 秒），再点击右下角固定坐标，最后再按一次 Enter 推进，不再检测 Proceed 文字。"""
from lalc import RunContext, step

# 结果页判据：右上角 Result 标题模板（1280x720 客户区）
RESULT_ASSET = "event/result"
# 结果页推进先连续按 Enter RESULT_ENTER_TIMES 次，每次间隔 RESULT_ENTER_SECONDS 秒
RESULT_ENTER_TIMES = 2
RESULT_ENTER_SECONDS = 1.0
# 按完 Enter 后点击的右下角固定坐标：Proceed / Continue / SKIP 在不同阶段共用同一位置
CLICK_POINT = (1140, 650)


def _result_page(ctx: RunContext) -> bool:
    """当前帧是否显示事件结果页：只看 Result 标题模板，不读右下角按钮文案。"""
    return bool(ctx.action("observe.match_asset", asset=RESULT_ASSET))


@step
def execute(ctx: RunContext) -> None:
    """
    事件结果页的一次局部尝试：重新截图复查 Result 标题入口，适用时只做一组固定动作，
    先连续按 Enter RESULT_ENTER_TIMES（2）次、每次间隔 RESULT_ENTER_SECONDS（1）秒，
    再点击一次右下角固定坐标 CLICK_POINT，最后等待 RESULT_ENTER_SECONDS（1）秒后再按一次 Enter，
    不判断结果页是否已经推进。
    入口失配（没有 Result 标题）时零输入返回；是否离开结果页由上层下一轮重新截图验收。
    """
    ctx.action("observe.capture_screen")
    if not _result_page(ctx):
        ctx.log("没有识别到 Result 标题，当前不是事件结果页，未按键也未点击", level="warning", screenshot=True)
        return

    ctx.log(
        f"识别到 Result 标题，先连续按 Enter {RESULT_ENTER_TIMES} 次（间隔 {RESULT_ENTER_SECONDS} 秒），"
        f"再点击右下角固定坐标 ({CLICK_POINT[0]}, {CLICK_POINT[1]})，最后再按一次 Enter"
    )
    for index in range(1, RESULT_ENTER_TIMES + 1):
        ctx.action("control.key_press", key="enter")
        ctx.action("observe.wait", seconds=RESULT_ENTER_SECONDS)
        ctx.log(f"第{index}/{RESULT_ENTER_TIMES}次按 Enter 推进事件结果页")
    ctx.action("control.click", centerxy=CLICK_POINT)
    ctx.action("observe.wait", seconds=RESULT_ENTER_SECONDS)
    ctx.action("control.key_press", key="enter")
    ctx.log("点击后再次按一次 Enter 推进事件结果页")
