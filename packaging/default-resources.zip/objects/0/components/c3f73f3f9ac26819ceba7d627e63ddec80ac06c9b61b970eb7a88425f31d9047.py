"""通用战斗处理：从战斗到脱离战斗相关页面为止。

判定“还在战斗”的素材由 plan 统一定义、作为参数下放，本子流程不再维护自己的界面素材表；
脱离战斗的具体识别集中在 step.wait_battle_end，本层只在看不到战斗标识时中断交回上层。
"""
from lalc import RunContext, sub_workflow, ExecutionFailure


CONTINUE_BATTLE_ASSETS = [
    "battle/first_turn",
    "battle/select_line",
    "battle/win_rate",
    "battle/win_rate_selected",
    "battle/damage",
]

RESULT_ASSETS = ["battle/defeat", "battle/victory", "battle/confirm"]
BATTLEING_SIGNAL_ASSETS = ["battle/pause", "battle/setting"]

# 局内战斗确实需要很长的轮次预算：一场战斗包含多回合、技能动画、EGO 播放和较长的过渡画面，
# 期间可能连续几十轮都拿不到可用标识，且这些都不依赖网络。因此这里保留 100 轮的有界循环，
# 不压缩为短轮询；进出战斗的加载等待仍由外层 step.wait_normal_transition 统一处理。
MAX_RETRIES = 100
# 本层只保留两套战斗页动作素材（语义分组），plan 下放的 battle_assets 是它们的并集：
# 可推进素材决定按 P／点 win rate／按 Enter，其余战斗素材一律按“战斗中等待”交给 step.wait_battle_end。
# 战斗出口（战果页、寻路页、事件页、奖励卡片页、楼层饰品页、通用加载）不在本层判定。


def _hit(ctx: RunContext, assets: list[str]) -> list[str]:
    """按同一截图统计命中素材，返回命中名称。"""
    return [asset for asset in assets if ctx.action("observe.match_asset", asset=asset)]






@sub_workflow
def execute(
    ctx: RunContext,
    *,
    battle_assets: list[str],
    path_asset: str,
    event_assets: list[str],
    event_skip_assets: list[str],
) -> None:
    """只保留“还在战斗”的推进；脱离战斗的识别集中在 step.wait_battle_end。

    每轮只截一次图并只做一轮整帧匹配，命中集合直接复用于后续分派，避免分派依据的帧在
    调用动作 Step 前过期。按 plan 下放的 battle_assets 判断是否仍在战斗界面：
    命中可推进素材（first_turn／select_line／win_rate／win_rate_selected／damage）时，
    按 win rate 是否选中调用一次 step.start_battle_until 或 step.battle_select_winrate；
    后者在确认 P 键生效后已自行按一次 Enter，所以开战不再占用下一轮的重新截图分派；
    命中其余战斗素材（pause／setting 等）时调用一次 step.wait_battle_end，由它识别战果页、
    寻路页、事件页（event/choices、event/result 模板与普通／灰化 SKIP）、奖励卡片页、
    楼层饰品页与通用加载，并返回 reason：reason 不是 continue 就退出本子流程；
    battle_assets 一个都没命中时直接中断，交回上层按新画面重新分派。
    本层不自行检测任何战斗出口，也不返回业务结果。
    """
    # battle_assets 是“可推进”与“战斗中等待”两组的并集：可推进组由本文件的动作素材决定，
    # 其余一律按战斗中等待处理，plan 新增等待类素材时本层无需改动
    continue_assets = [asset for asset in battle_assets if asset in CONTINUE_BATTLE_ASSETS]
    waiting_assets = [asset for asset in battle_assets if asset not in CONTINUE_BATTLE_ASSETS]
    previous_branch = ""
    consecutive_hits = 0

    def hit(branch: str) -> None:
        """同一分支前三次可执行，第四次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > 3:
            raise ExecutionFailure("workflow_branch_limit", f"连续第四次命中分支：{branch}")

    for round_index in range(1, MAX_RETRIES + 1):
        ctx.action("observe.capture_screen")
        # 同一帧只做一轮整帧匹配：battle_assets 已覆盖 continue_assets，重复匹配同一批素材
        # 会把截图到调用 Step 的间隔拉长到约 1.3 秒，战斗动画期间画面早已变化，入口复查必然失配
        matched = _hit(ctx, battle_assets)
        if not matched:
            ctx.log(f"第{round_index}轮没有命中任何战斗标识，中断战斗子流程，交回上层重新分派")
            return
        matched_continue = [asset for asset in matched if asset in CONTINUE_BATTLE_ASSETS]
        if matched_continue:
            # win_rate_selected 通常由 plan 下放在 battle_assets 里，直接复用命中集合；
            # 未下放时补一次单独匹配，保持原来的选中态判定
            win_rate_selected = "battle/win_rate_selected" in matched or (
                "battle/win_rate_selected" not in battle_assets
                and bool(ctx.action("observe.match_asset", asset="battle/win_rate_selected"))
            )
            # 两个动作 Step 各自只做一次动作，调用后直接交回下一轮重新截图判定
            if win_rate_selected:
                hit("step.start_battle_until")
                ctx.call("step.start_battle_until", continue_battle_assets=continue_assets, battleing_signal_assets=waiting_assets)
            else:
                hit("step.battle_select_winrate")
                ctx.call("step.battle_select_winrate", continue_battle_assets=continue_assets)
            continue
        # 其余战斗素材说明这一帧在战斗中且暂时无法推进：交给 wait_battle_end 长等待，
        # 由它判定是否已经脱离战斗，并把 reason 交回本层决定是否退出
        hit("step.wait_battle_end")
        outcome = ctx.call(
            "step.wait_battle_end",
            continue_battle_assets=continue_assets,
            battleing_signal_assets=waiting_assets,
            result_assets=RESULT_ASSETS,
            path_assets=[path_asset],
            event_assets=event_assets,
            event_skip_assets=event_skip_assets,
        ) or {}
        if outcome.get("reason") != "continue":
            ctx.log(f"第{round_index}轮 step.wait_battle_end 报告已脱离战斗：{outcome}，退出战斗子流程")
            return
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
