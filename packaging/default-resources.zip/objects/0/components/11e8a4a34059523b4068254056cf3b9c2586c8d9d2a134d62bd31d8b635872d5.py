"""镜牢饰品选择页：点 Select 或 Refuse Gift 提交本次选择，处理确认弹窗，以离开本页作为完成证据。"""
import re

from lalc import ExecutionFailure, RunContext, step

GIFT_ASSET = "mirror/gift_select"
# 底部按钮区域：Refuse Gift、Select 与 Select 右侧的 已选/上限 计数
BOTTOM_REGION = {"x": 760, "y": 550, "width": 480, "height": 80}
# 中央弹窗区域：拿到饰品的 E.G.O Gift GET! 展示与放弃选择的确认都出现在这里
POPUP_REGION = {"x": 330, "y": 160, "width": 630, "height": 410}
# E.G.O Gift GET! 展示弹窗：标题横幅用素材 mirror/ego_gift_get（430x34）做原尺寸模板匹配，
# 不再读标题文字；放弃选择的确认弹窗仍按独有标题文字识别
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
ABANDON_TITLE = "continuewithoutselecting"
CONFIRM_LABEL = "confirm"
# Select / Refuse Gift 之后确认弹窗有滑入动画，等动画结束再识别和点击
POPUP_SETTLE_SECONDS = 1
# Confirm 按钮在 1280x720 客户区中的回退坐标
CONFIRM_FALLBACK = (765, 495)
REFUSE_POINT = (888, 587)
SELECT_POINT = (1054, 587)
COUNTER_PATTERN = re.compile(r"^\s*(\d+)\s*/\s*(\d+)\s*$")


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或连写影响按钮文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _bottom_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回底部按钮区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=BOTTOM_REGION) or {}
    return list(result.get("items") or [])


def _gift_page(ctx: RunContext) -> bool:
    """判断是否还在饰品选择页：优先用 Selected E.G.O Gift 模板，其次用 Refuse Gift 文字。"""
    if ctx.action("observe.match_asset", asset=GIFT_ASSET):
        return True
    return "refusegift" in _items_text(_bottom_items(ctx))


def _counter(items: list[dict]) -> tuple[int, int] | None:
    """解析 Select 右侧的 已选/上限 计数，读不到时返回 None。"""
    for item in items:
        match = COUNTER_PATTERN.match(str(item.get("text") or ""))
        if match:
            return int(match.group(1)), int(match.group(2))
    return None


def _popup_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回中央确认弹窗区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=POPUP_REGION) or {}
    return list(result.get("items") or [])


def _gift_get(ctx: RunContext) -> bool:
    """当前帧是否叠着 E.G.O Gift GET! 展示弹窗：只用素材 mirror/ego_gift_get 匹配标题横幅。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=GIFT_GET_ASSET,
            region=GIFT_GET_REGION,
            threshold=GIFT_GET_THRESHOLD,
        )
    )


def _popup_kind(ctx: RunContext, items: list[dict]) -> str:
    """
    区分弹窗：gift_get（E.G.O Gift GET! 拿到饰品的展示，按标题横幅模板匹配）、
    abandon（Continue without selecting… 未选饰品直接继续，按独有标题文字识别）、
    unknown（只看到 Confirm 按钮）、none。
    """
    if _gift_get(ctx):
        return "gift_get"
    text = _items_text(items)
    if ABANDON_TITLE in text:
        return "abandon"
    return "unknown" if _confirm_center(items) else "none"


def _confirm_center(items: list[dict]) -> tuple[int, int] | None:
    """找出文字为 Confirm 的按钮中心，识别不到时返回 None。"""
    for item in items:
        if _norm(item.get("text", "")) != CONFIRM_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            return (int(center[0]), int(center[1]))
    return None


def _popup_present(ctx: RunContext, items: list[dict]) -> bool:
    """看得到弹窗标题横幅、标题文字或 Confirm 按钮时，认为页面仍被弹窗遮住。"""
    return _popup_kind(ctx, items) != "none"


POPUP_LABELS = {
    "gift_get": "E.G.O Gift GET! 拿到饰品展示弹窗",
    "abandon": "Continue without selecting an E.G.O Gift? 未选饰品确认弹窗",
    "unknown": "未识别到标题的弹窗",
}


def _click_popup_confirm(ctx: RunContext, items: list[dict]) -> bool:
    """弹窗出现时点击 Confirm 关闭它；没有弹窗时不做任何点击并返回 False。"""
    kind = _popup_kind(ctx, items)
    if kind == "none":
        return False

    label = POPUP_LABELS[kind]
    level = "info" if kind == "gift_get" else "warning"
    center = _confirm_center(items)

    if center:
        ctx.log(
            f"识别到{label}，点击其中的 Confirm @ {tuple(center)}",
            level=level,
            screenshot=True,
        )
        ctx.action("control.click", centerxy=(int(center[0]), int(center[1])))
    else:
        ctx.log(
            f"识别到{label}但未识别到 Confirm 文本，点击回退坐标 {CONFIRM_FALLBACK}",
            level="warning",
            screenshot=True,
        )
        ctx.action("control.click", x=CONFIRM_FALLBACK[0], y=CONFIRM_FALLBACK[1])
    ctx.action("observe.wait", seconds=1.0)
    return True


@step
def execute(ctx: RunContext, *, selected: int = 0) -> None:
    """
    在镜牢饰品选择页提交一次选择：
    - 确认弹窗在（E.G.O Gift GET! 展示或 Continue without selecting… 确认）时只点一次 Confirm 后交回；
    - 既不在饰品选择页也没有弹窗时零输入返回；
    - 否则点一次 Select（selected>0 且当前确有已选饰品）或 Refuse Gift，等固定 1 秒让确认弹窗滑入后交回。
    后续逐个 Confirm 与是否真正离开本页由 sub_workflow.mirror_gift_select 下一轮重新观察，
    本步不轮询、不重点。
    注意：本页 Select 确认后不可回退，只能退出镜牢重新进入才能再次看到该页面。
    """
    if _click_popup_confirm(ctx, _popup_items(ctx)):
        ctx.log("确认弹窗已在，已点击一次 Confirm，交回上层重新观察是否还有下一个弹窗")
        return

    ctx.action("observe.capture_screen")
    if not _gift_page(ctx):
        ctx.log("已不在镜牢饰品选择页面，也没有确认弹窗，本步不做动作")
        return

    counter = _counter(_bottom_items(ctx))
    if counter:
        ctx.log(f"提交前 Select 右侧计数：{counter[0]}/{counter[1]}")
    use_select = selected > 0 and (counter is None or counter[0] > 0)
    if selected > 0 and not use_select:
        ctx.log(
            "要求点击 Select，但当前没有饰品处于选中状态（Select 不可用），改为 Refuse Gift",
            level="warning",
            screenshot=True,
        )

    if use_select:
        ctx.log(f"点击 Select {SELECT_POINT}")
        ctx.action("control.click", x=SELECT_POINT[0], y=SELECT_POINT[1])
    else:
        ctx.log(f"点击 Refuse Gift {REFUSE_POINT}，不拿饰品继续")
        ctx.action("control.click", x=REFUSE_POINT[0], y=REFUSE_POINT[1])
    ctx.log(f"等待 {POPUP_SETTLE_SECONDS} 秒让确认弹窗滑入，之后由上层重新观察")
    ctx.action("observe.wait", seconds=POPUP_SETTLE_SECONDS)
