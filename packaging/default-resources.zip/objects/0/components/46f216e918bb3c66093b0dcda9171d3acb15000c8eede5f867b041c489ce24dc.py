"""战斗准备确认：队伍与出战顺序已就绪后按 Enter 提交出战，不等待加载完成。"""
from lalc import RunContext, step

# 对局内战斗准备页的判据：右下角 Clear Selection 命中即算，不再要求右侧三个页签模板。
# 那三个页签是队伍／罪人选择页的标签，放在对局内准备页上会被队伍数量、贴边与皮肤影响而低于阈值
# （Run 646 三个页签模板全部空返回，只有 clear_selection 命中 0.934）；也不用 OCR 文案兜底。
CLEAR_SELECTION_ASSET = "prepare_team/clear_selection"
# 按 Enter 后固定等 2 秒让画面响应；是否进入加载或战斗由上层下一轮重新截图判断
ENTER_WAIT_SECONDS = 2.0












def _in_prepare(ctx: RunContext) -> bool:
    """重新截图，判断是否仍停在战斗准备页：右下角 Clear Selection 命中即算。"""
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=CLEAR_SELECTION_ASSET):
        ctx.log(f"战斗准备页判定：{CLEAR_SELECTION_ASSET} 命中", level="debug")
        return True
    return False












@step
def execute(ctx: RunContext) -> None:
    """重新观察，只在战斗准备页按一次 Enter 后交回；是否进入加载或战斗由上层重新截图判断。"""
    if not _in_prepare(ctx):
        ctx.log("当前不在战斗准备页，本 Step 不按键，交回上层", level="warning")
        return
    ctx.log("战斗准备页提交一次 Enter")
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=ENTER_WAIT_SECONDS)
