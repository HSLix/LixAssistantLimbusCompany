"""开发期只读试验：在 Fuse E.G.O Gift 弹窗上验证素材命中与列表几何，不做任何点击。

一次调用只观察当前帧，输出：
1) fusion_available / final_fuse_place 两个素材的命中位置；
2) 右侧 Gifts Owned 列表区域用 mirror/gift 图鉴整组匹配的结果（不同阈值各一次），
   用来判断售出弹窗的 68x73 卡片模板能否直接命中融合弹窗里更小的礼物图标；
3) 几个已知饰品（现场商店里出现过的）做 SIFT 特征匹配的框与缩放，作为原尺寸匹配失败时的后备；
4) 右侧滚动条区域能否用 sell_gift_scroll_end 模板命中，以及右侧区域 OCR 结果。
"""
from lalc import RunContext, step

RIGHT_REGION = {"x": 615, "y": 200, "width": 535, "height": 350}
LIST_REGION = {"x": 630, "y": 240, "width": 500, "height": 300}
SCROLL_REGION = {"x": 1105, "y": 195, "width": 40, "height": 320}
GIFT_GROUP = "mirror/gift"
KNOWN_ASSETS = (
    "mirror/gift/sink/thorny_path",
    "mirror/gift/slash/overused_whetstone",
    "mirror/gift/charge/nightuision_coggles",
    "mirror/gift/rupture/crown_of_roses",
)


def _hits_text(hits: list) -> str:
    """把命中列表压成一行可读文本：逻辑名、中心、分数、模板尺寸。"""
    if not hits:
        return "无命中"
    return "; ".join(
        f"{hit.get('logical_name') or hit.get('asset') or '?'}@({hit.get('centerxy')})"
        f"s={round(float(hit.get('score', 0.0)), 3)}"
        f"{(' ' + str(hit.get('width')) + 'x' + str(hit.get('height'))) if hit.get('width') else ''}"
        for hit in hits[:20]
    )


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """只观察当前帧：验证 fuse 相关素材与图鉴模板在当前弹窗上的命中情况。"""
    ctx.action("observe.capture_screen")

    for asset in ("mirror/shop/fuse/fusion_available", "mirror/shop/fuse/final_fuse_place"):
        hits = ctx.action("observe.match_asset", asset=asset, threshold=0.8) or []
        ctx.log(f"{asset} 全屏阈值 0.8 命中 {len(hits)}：{_hits_text(hits)}", level="info")

    for threshold in (0.9, 0.85, 0.8, 0.75):
        hits = (
            ctx.action(
                "observe.match_asset_group",
                group=GIFT_GROUP,
                region=LIST_REGION,
                threshold=threshold,
            )
            or []
        )
        ctx.log(
            f"mirror/gift 整组在右侧列表区域阈值 {threshold} 命中 {len(hits)}：{_hits_text(hits)}",
            level="info",
        )

    for asset in KNOWN_ASSETS:
        hits = ctx.action("observe.match_feature", asset=asset, region=LIST_REGION) or []
        ctx.log(f"SIFT {asset} 命中 {len(hits)}：{_hits_text(hits)}", level="info")

    thumb = (
        ctx.action(
            "observe.match_asset",
            asset="mirror/shop/sell_gift_scroll_end",
            region=SCROLL_REGION,
            threshold=0.7,
        )
        or []
    )
    ctx.log(f"滚动条区域滑块模板命中 {len(thumb)}：{_hits_text(thumb)}", level="info")

    result = ctx.action("observe.ocr", region=RIGHT_REGION) or {}
    texts = [
        f"{str(item.get('text', '')).strip()}@({item.get('centerxy')})"
        for item in result.get("items") or []
        if str(item.get("text", "")).strip()
    ]
    ctx.log("右侧列表区域 OCR：" + ("; ".join(texts) if texts else "无文字"), level="info", screenshot=True)

    return {
        "thumbs": str(len(thumb)),
    }
