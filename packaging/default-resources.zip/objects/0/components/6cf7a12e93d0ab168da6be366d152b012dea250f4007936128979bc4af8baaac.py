"""处理 Cannot operate the game 弹窗：用 OCR 文字特征识别，避免依赖弹窗截图素材误匹配。"""
import re

from lalc import RunContext

POPUP_NAME = "Cannot operate the game"
# 弹窗文案：Cannot operate the game. Shutting down now.
POPUP_KEYWORD = "cannot operate"
STARTUP_ASSET = "restart/clear_all_caches"
# 3 次重启尝试；单次等待取决于游戏启动耗时，不能按 2 秒轮询
MAX_RETRIES = 3
STARTUP_WAIT_SECONDS = 60


def _screen_text(ctx: RunContext) -> str:
    """刷新截图并返回整屏 OCR 合并后的规范化小写文本。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    items = result.get("items") or []
    merged = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return re.sub(r"\s+", " ", merged).strip().lower()


def detect(ctx: RunContext) -> bool:
    """只观察弹窗文字，不在检测阶段点击。"""
    found = POPUP_KEYWORD in _screen_text(ctx)
    ctx.log(f"检测 {POPUP_NAME} 弹窗：{found}")
    return found


def recover(ctx: RunContext) -> None:
    """最多重启 3 次并等到可识别的主界面标志；次数耗尽后交还主流程。"""
    for attempt in range(1, MAX_RETRIES + 1):
        ctx.log(f"第{attempt}/{MAX_RETRIES}次处理 {POPUP_NAME} 弹窗，尝试重启游戏")
        ctx.action("control.restart_game")
        ctx.log(f"等待游戏启动 {STARTUP_WAIT_SECONDS} 秒")
        ctx.action("observe.wait", seconds=STARTUP_WAIT_SECONDS)
        ctx.action("observe.capture_screen")
        if ctx.action("observe.match_asset", asset=STARTUP_ASSET):
            ctx.log("游戏已启动，剩下步骤交还主流程处理")
            return
        ctx.log(
            f"第{attempt}/{MAX_RETRIES}次重启后等待 {STARTUP_WAIT_SECONDS} 秒仍未匹配到游戏启动标志",
            level="warning",
            screenshot=True,
        )

    ctx.log(
        f"{POPUP_NAME} 弹窗 {MAX_RETRIES} 次重启后仍未回到可识别界面，交还主流程继续观察",
        level="error",
        screenshot=True,
    )
