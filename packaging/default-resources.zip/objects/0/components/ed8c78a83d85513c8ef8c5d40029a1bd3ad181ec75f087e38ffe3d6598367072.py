"""镜牢楼层通关后的 Acquire E.G.O Gift 页面：按规避顺序逐个点手形图标，再点一次右下角 Select。"""
import re

from lalc import ExecutionFailure, RunContext, step

HAND_ASSET = "mirror/acquire_ego_gift_hand"
# 三张饰品卡上方的 Acquire E.G.O Gift 标题；手形模板漏识别时用它兜底确认仍在本页
TITLE_REGION = {"x": 350, "y": 140, "width": 700, "height": 50}
TITLE_KEYWORD = "acquireegogift"
# 右下角 Select 按钮在 1280x720 客户区中的固定坐标（与右侧 已选/上限 计数同一行）
SELECT_POINT = (1116, 578)
# E.G.O Gift GET! 展示弹窗：点 Select 后弹出，是本步的退出信号，识别到就按 Enter 并交回外层大循环
GIFT_GET_ASSET = "mirror/ego_gift_get"
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
POPUP_REGION = {"x": 250, "y": 150, "width": 720, "height": 450}
# 点击每个手形图标后的等待，等卡片选中反馈落定（属于同一组固定动作）
CLICK_WAIT_SECONDS = 0.6
# 点击 Select 后的固定等待：弹窗滑入动画与页面响应都需要时间
SELECT_WAIT_SECONDS = 1.2
# 按 Enter 后的固定等待：确认后页面要时间切换，落点由外层重新观察
ENTER_WAIT_SECONDS = 1.0
# Enter 补点：按 Enter 后弹窗标题仍在时的鼠标兜底，标签与回退坐标跟 step.mirror_gift_submit 保持一致
CONFIRM_LABEL = "confirm"
CONFIRM_FALLBACK = (765, 495)
CONFIRM_WAIT_SECONDS = 1.0
# 卡片上的 Mounting Trials 板块：手形图标贴在卡片左边缘，卡片宽约 244、卡间距约 265 像素，
# 所以按本张卡手形图标的位置推算卡片横向范围，避免整屏 OCR 的文字串到相邻卡片
CARD_LEFT_MARGIN = 20
CARD_RIGHT_MARGIN = 235
# Mounting Trials 板块在手形图标底边下方一段（1280x720 实测文字 y≈419~516，图标底边 383），
# 这个区间不含卡片上半部的饰品名与效果说明
TRIAL_TOP_OFFSET = 30
TRIAL_BOTTOM_OFFSET = 145
# 整屏 OCR 里出现这些文字才说明本页带 Mounting Trials，才走优先 debuff 策略（OCR 常把
# Mounting Trials 截成 Mountin、把 Enemy Level 读成 Enemy Lovel，所以只认这两个词干）
TRIAL_MARKERS = ("mountin", "enemylevel")
# 优先规避的 trial debuff 顺序改由镜牢设置页「楼层饰品选择的 debuff 规避」配置：
# settings["mirror.settings"]["floor_gift_debuffs"] 存游戏内英文关键词原文，本步按同一套规范化规则匹配。
# 越靠前越先点对应卡片，让这张卡的选择被后面的点击覆盖下去；卡片一次只能选一张，
# 所以「先点带规避 debuff 的卡、再点其余卡」= 最终选到没有该 debuff 的卡。
MIRROR_PAGE_ID = "mirror.settings"
FLOOR_DEBUFFS_KEY = "floor_gift_debuffs"
# 设置里还没有该字段（旧配置）或内容不可用时用这份默认顺序兜底，与页面默认值保持一致
DEFAULT_AVOID_DEBUFF_PRIORITY = (
    "coinpower",
    "clashpower",
    "basepower",
    "offenselevel",
    "damagedealt",
    "damagetaken",
    "defenselevel",
    "maxhp",
)


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响标题匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _avoid_priority(ctx: RunContext) -> tuple[str, ...]:
    """
    读取镜牢设置页保存的 debuff 规避顺序，返回规范化后的关键词元组（越靠前越先规避）。
    字段存在时以页面为准：空列表表示不规避任何 debuff，直接返回空元组；
    字段缺失或全部条目都规范化不出内容时退回页面默认顺序，并记一条日志说明用的是兜底值。
    """
    settings = ctx.run_state.settings or {}
    page = settings.get(MIRROR_PAGE_ID)
    raw = page.get(FLOOR_DEBUFFS_KEY) if isinstance(page, dict) else None
    if not isinstance(raw, list):
        ctx.log(
            f"设置里没有 {MIRROR_PAGE_ID}.{FLOOR_DEBUFFS_KEY}，按默认 debuff 规避顺序 "
            f"{list(DEFAULT_AVOID_DEBUFF_PRIORITY)} 处理",
            level="info",
        )
        return DEFAULT_AVOID_DEBUFF_PRIORITY
    priority: list[str] = []
    for item in raw:
        keyword = _norm(item)
        if keyword and keyword not in priority:
            priority.append(keyword)
    if raw and not priority:
        ctx.log(
            f"设置里的 debuff 规避顺序 {raw!r} 全部无法转成关键词，按默认顺序 "
            f"{list(DEFAULT_AVOID_DEBUFF_PRIORITY)} 处理",
            level="warning",
        )
        return DEFAULT_AVOID_DEBUFF_PRIORITY
    return tuple(priority)


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做 OCR，返回合并后的规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _gift_get(ctx: RunContext) -> bool:
    """退出信号：用素材 mirror/ego_gift_get 的标题横幅模板匹配 E.G.O Gift GET! 展示弹窗。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=GIFT_GET_ASSET,
            region=GIFT_GET_REGION,
            threshold=GIFT_GET_THRESHOLD,
        )
    )


def _hands(ctx: RunContext) -> list[dict]:
    """匹配当前帧的全部手形图标，按从上到下、从左到右排序；命中数由业务决定逐个点击。"""
    matches = list(ctx.action("observe.match_asset", asset=HAND_ASSET) or [])
    matches.sort(
        key=lambda item: (
            int((item.get("centerxy") or (0, 0))[1]),
            int((item.get("centerxy") or (0, 0))[0]),
        )
    )
    return matches


def _on_page(ctx: RunContext, hands: list[dict]) -> bool:
    """仍在本页：手形图标命中，或标题文字（三张卡上方各有一处 Acquire E.G.O Gift）命中。"""
    if hands:
        return True
    return TITLE_KEYWORD in _region_text(ctx, TITLE_REGION)


def _card_trial_text(items: list[dict], hand: dict) -> str:
    """
    用整屏 OCR 结果还原这张卡片 Mounting Trials 板块的文字，返回规范化小写文本。
    横向按本张卡手形图标的位置推算（图标贴在卡片左边缘），纵向只取图标底边下方一段，
    避开同一张卡上半部的饰品名与效果说明。
    """
    center = hand.get("centerxy") or (0, 0)
    left = int(center[0]) - CARD_LEFT_MARGIN
    right = int(center[0]) + CARD_RIGHT_MARGIN
    hand_bottom = int(hand.get("y") or 0) + int(hand.get("height") or 0)
    top = hand_bottom + TRIAL_TOP_OFFSET
    bottom = hand_bottom + TRIAL_BOTTOM_OFFSET
    texts: list[str] = []
    for item in items:
        item_center = item.get("centerxy")
        if not item_center:
            continue
        x, y = int(item_center[0]), int(item_center[1])
        if left <= x <= right and top <= y <= bottom:
            text = str(item.get("text") or "").strip()
            if text:
                texts.append(text)
    return _norm(" ".join(texts))


def _avoid_rank(text: str, priority: tuple[str, ...]) -> int:
    """
    按 priority 返回要规避的程度：越小越先点，未命中任何 debuff 返回列表长度。
    一张卡命中多项 debuff 时只取优先级最高的那一项（首个命中即返回），这张卡在点击顺序里只占一个位置。
    """
    for rank, keyword in enumerate(priority):
        if keyword in text:
            return rank
    return len(priority)


def _click_order(ctx: RunContext, hands: list[dict], priority: tuple[str, ...]) -> list[dict]:
    """
    整屏 OCR 一次读出本页全部文字，给出本次点击手形图标的顺序（始终把全部手形图标点一遍）：
    - 文字里没有 Mounting Trials／Enemy Level → 返回原顺序（从上到下、从左到右）；
    - 有 trial → 带优先规避 debuff 的卡先点（同级先后按设置页保存的规避顺序 priority，
      同一级并列按原顺序），其余卡片保持原顺序排在后面；
    - 有 trial 但没有任何卡带优先规避 debuff（含顺序为空）→ 返回原顺序，并记一条 info 日志。
    卡片一次只能选一张、后点的会覆盖先点的，所以先点要规避的卡、最后落在无该 debuff 的卡上，
    等于把优先规避的 debuff 覆盖下去。
    """
    result = ctx.action("observe.ocr") or {}
    items = list(result.get("items") or [])
    joined = _norm(" ".join(str(item.get("text") or "") for item in items))
    markers = [marker for marker in TRIAL_MARKERS if marker in joined]
    if not markers:
        ctx.log("整屏 OCR 没有 Mounting Trials／Enemy Level，按原顺序逐个点全部手形图标", level="info")
        return list(hands)

    ranked: list[tuple[int, int, dict]] = []
    for index, hand in enumerate(hands):
        text = _card_trial_text(items, hand)
        rank = _avoid_rank(text, priority)
        ranked.append((rank, index, hand))
    avoided = [entry for entry in ranked if entry[0] < len(priority)]
    others = [entry for entry in ranked if entry[0] >= len(priority)]
    if not avoided:
        ctx.log(
            f"识别到 Mounting Trials（标记 {markers}），没有卡片带优先规避的 debuff "
            f"{list(priority)}，按原顺序逐个点击",
            level="info",
        )
        return list(hands)
    avoided.sort(key=lambda entry: (entry[0], entry[1]))
    ordered = [entry[2] for entry in avoided] + [entry[2] for entry in others]
    detail = "、".join(
        f"x={int((hand.get('centerxy') or (0, 0))[0])}（{priority[rank]}）"
        for rank, _, hand in avoided
    )
    ctx.log(
        f"识别到 Mounting Trials（标记 {markers}），先点要规避的卡片 {detail}，"
        f"再点其余 {len(others)} 张覆盖下去",
        level="info",
    )
    return ordered


def _confirm_center(ctx: RunContext) -> tuple[int, int] | None:
    """对弹窗区域做一次 OCR，返回文字为 Confirm 的按钮中心；识别不到时返回 None。"""
    result = ctx.action("observe.ocr", region=POPUP_REGION) or {}
    for item in result.get("items") or []:
        if _norm(item.get("text", "")) != CONFIRM_LABEL:
            continue
        center = item.get("centerxy")
        if center:
            return (int(center[0]), int(center[1]))
    return None


def _click_confirm_if_still_popup(ctx: RunContext) -> bool:
    """
    Enter 之后的补点：重新截图确认 E.G.O Gift GET! 弹窗标题是否还在，
    还在就用鼠标点击 Confirm 关闭弹窗并等待页面响应，返回是否执行了点击。
    这是 Enter 没有生效时的安全补点，属于正常兜底路径，日志记 info。
    """
    ctx.action("observe.capture_screen")
    if not _gift_get(ctx):
        return False
    center = _confirm_center(ctx)
    if center:
        ctx.log(
            f"按 Enter 后 E.G.O Gift GET! 弹窗标题仍在，改用鼠标点击 Confirm @ {center}",
            level="info",
            screenshot=True,
        )
        ctx.action("control.click", centerxy=(int(center[0]), int(center[1])))
    else:
        ctx.log(
            "按 Enter 后 E.G.O Gift GET! 弹窗标题仍在但未识别到 Confirm 文本，"
            f"点击回退坐标 {CONFIRM_FALLBACK}",
            level="info",
            screenshot=True,
        )
        ctx.action("control.click", x=CONFIRM_FALLBACK[0], y=CONFIRM_FALLBACK[1])
    ctx.action("observe.wait", seconds=CONFIRM_WAIT_SECONDS)
    return True


@step
def execute(ctx: RunContext) -> None:
    """
    处理镜牢楼层通关后的 Acquire E.G.O Gift 页面，一次只做一组动作：
    - 既没有手形图标、Acquire E.G.O Gift 标题，也没有 E.G.O Gift GET! 弹窗时零输入返回；
    - E.G.O Gift GET! 弹窗已在时按一次 Enter（仍看到弹窗标题时用鼠标点一次 Confirm 兜底）后交回；
    - 否则先整屏 OCR 一次，整理出点手形图标的顺序（始终把当前帧匹配到的手形图标全点一遍）：
      卡片上出现 Mounting Trials／Enemy Level 时，按镜牢设置页保存的 debuff 规避顺序
      （settings["mirror.settings"]["floor_gift_debuffs"]，未配置时用默认顺序）先点带规避 debuff 的卡、
      其余卡后点，让要规避的 debuff 被后面的点击覆盖下去；没有 trial 或没有卡带规避 debuff 时
      保持原顺序（从上到下、从左到右）；最后点一次右下角固定坐标的 Select，等固定 1.2 秒后交回。
    选择前只保留一条初始画面 info 日志（附开头那一帧截图，此时尚未点击、未做 trial 策略判断）；
    trial 策略只记结论日志，不再逐卡记录识别到的文字。
    是否拿到饰品、页面是否切换由 task.mirror 下一轮重新观察，本步不轮询退出信号、不重点 Select。
    """
    ctx.action("observe.capture_screen")
    if _gift_get(ctx):
        ctx.log("识别到 E.G.O Gift GET! 弹窗，按一次 Enter 确认")
        ctx.action("control.key_press", key="enter")
        ctx.action("observe.wait", seconds=ENTER_WAIT_SECONDS)
        _click_confirm_if_still_popup(ctx)
        return

    hands = _hands(ctx)
    if not _on_page(ctx, hands):
        ctx.log(
            "当前既没有手形图标、Acquire E.G.O Gift 标题，也没有 E.G.O Gift GET! 弹窗，本步不做任何点击",
            level="warning",
            screenshot=True,
        )
        return

    # 选择前先记录一次初始画面：此时还没点过任何卡片，也没有做 trial 策略判断，
    # 附的是 execute 开头 capture_screen 的那一帧，用来回看本次选择的原始页面
    ctx.log(
        f"楼层饰品选择页初始画面：匹配到手形图标 {len(hands)} 处，尚未选择、未做 trial 策略判断",
        level="info",
        screenshot=True,
    )

    if hands:
        for item in _click_order(ctx, hands, _avoid_priority(ctx)):
            center = item.get("centerxy") or (0, 0)
            x, y = int(center[0]), int(center[1])
            ctx.log(f"点击手形图标 ({x}, {y})，匹配分数 {item.get('score')}")
            ctx.action("control.click", centerxy=(x, y))
            ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
        ctx.log(f"已逐个点击 {len(hands)} 处手形图标")
    else:
        ctx.log("本页没有匹配到手形图标，仍按约定点击一次右下角 Select", level="warning", screenshot=True)

    ctx.log(f"点击右下角 Select {SELECT_POINT}，等 {SELECT_WAIT_SECONDS} 秒后交回")
    ctx.action("control.click", x=SELECT_POINT[0], y=SELECT_POINT[1])
    ctx.action("observe.wait", seconds=SELECT_WAIT_SECONDS)
