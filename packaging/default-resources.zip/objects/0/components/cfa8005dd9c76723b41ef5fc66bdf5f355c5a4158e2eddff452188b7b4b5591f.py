"""镜牢商店：Keyword Refresh 一次调用走完「打开弹窗 → 选关键词 → 提交」。
在商店页点右上角第二个按钮（Keyword Refresh）打开「Shop - Keyword Refresh」弹窗后，
弹窗一出现就在同一次调用里按本队流派选关键词（固定坐标），再点弹窗底部 Refresh 提交一次（提交才扣 Cost）；
打开失败或弹窗中途关闭时零输入返回对应动作名，由上层决定退回普通 Refresh。
只用于「技能替换已经买完、饰品还有未买下的位置」的刷新；技能替换没买完时仍用普通 Refresh。"""
import re

from lalc import RunContext, step

# 商店页标识（三条判据取或，任一成立就算商店页）：
# ① 右上角普通 Refresh 按钮模板命中；② Keyword Refresh 按钮模板命中；③ 左上角 Shop 标题文字。
# 单个按钮模板在遮挡／动画帧下可能只命中一个，短标题 OCR 也会偶发漏识别，取或后不再要求两个同时命中。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 当前持有 Cost：Shop 标题右侧硬币图标后面的数字
COST_REGION = {"x": 540, "y": 100, "width": 120, "height": 60}
# 右上角两个刷新按钮：靠左是普通 Refresh，靠右是 Keyword Refresh。
# 只用素材 mirror/shop/keyword_refresh 模板定位按钮中心，不再读 Refresh 文字；
# 模板没命中时用兜底落点，不把左边的普通 Refresh 当成关键词刷新（那会白花 Cost 且不抬升流派概率）
REFRESH_BUTTON_REGION = {"x": 920, "y": 95, "width": 300, "height": 90}
KEYWORD_REFRESH_BUTTON_ASSET = "mirror/shop/keyword_refresh"
KEYWORD_REFRESH_BUTTON_THRESHOLD = 0.85
KEYWORD_REFRESH_FALLBACK = (1158, 128)
# Keyword Refresh 弹窗：标题横幅 Shop - Keyword Refresh 用素材 mirror/shop/shop_keyword_refresh（388x37）匹配，
# 不再读标题文字，也不再检测底部 Cancel／Refresh 按钮
KEYWORD_POPUP_TITLE_ASSET = "mirror/shop/shop_keyword_refresh"
KEYWORD_POPUP_TITLE_REGION = {"x": 300, "y": 100, "width": 620, "height": 52}
KEYWORD_POPUP_TITLE_THRESHOLD = 0.85
# 弹窗第二行提示 Spend N Cost to Keyword Refresh?：读它只为区分免费关键词刷新（N=0，Cost 不会下降）
KEYWORD_POPUP_COST_REGION = {"x": 500, "y": 185, "width": 290, "height": 30}
# 弹窗中部十个流派卡片的固定点击落点（1280x720 实测标签中心，两行五列，列间距≈153、行间距≈139）：
# 行 1 BURN／BLEED／TREMOR／RUPTURE／SINKING，行 2 POISE／CHARGE／SLASH／PIERCE／BLUNT
KEYWORD_CELLS = {
    "burn": (334, 335),
    "bleed": (487, 336),
    "tremor": (641, 336),
    "rupture": (795, 335),
    "sinking": (948, 336),
    "poise": (334, 474),
    "charge": (488, 474),
    "slash": (640, 475),
    "pierce": (795, 474),
    "blunt": (949, 474),
}
# 弹窗底部 Refresh 按钮的固定落点（1280x720 实测中心）：只有确认弹窗仍开着才点，避免在商店页误点商品区
POPUP_REFRESH_POINT = (807, 560)
# 技能替换弹窗会盖住右上角两个刷新按钮，不能盲点
SKILL_POPUP_REGION = {"x": 175, "y": 95, "width": 570, "height": 78}
SKILL_POPUP_KEYWORDS = ("replace", "skill")
SKILL_POPUP_ACTION_REGION = {"x": 400, "y": 505, "width": 520, "height": 70}
SKILL_POPUP_ACTION_KEYWORDS = ("cancel", "confirm")
# 饰品详情弹窗盖在商店页上：此时点刷新按钮只会落到详情或商品区上。
# 标题 Purchase E.G.O Gifts 用素材 mirror/shop/purchase_ego_gifts（351x25）做模板匹配，
# 搜索区域放宽到能完整容纳模板
DETAIL_TITLE_ASSET = "mirror/shop/purchase_ego_gifts"
DETAIL_TITLE_REGION = {"x": 340, "y": 140, "width": 420, "height": 60}
DETAIL_TITLE_THRESHOLD = 0.85
# 本队流派：队伍配置页按队伍保存的初始饰品类别（gift_keyword），取值与弹窗里的关键词一致（小写）
MIRROR_PAGE_ID = "mirror.settings"
TEAM_PAGE_ID = "sinners.team_presets"
TEAMS_KEY = "teams"
KEYWORD_KEY = "gift_keyword"
DEFAULT_TEAM = 1
MAX_TEAMS = 40
KEYWORD_NONE = "none"
# 本次关键词刷新已经点过弹窗里的 Refresh 的记录：弹窗仍开着时不能再点一次（会重复扣 Cost）。
# 打开弹窗的第一段会清掉它，弹窗关闭后的下一段也会重新开始
RUNTIME_KEY = "mirror.runtime"
COMMITTED_KEY = "shop_keyword_refresh_committed"
# 本场镜牢实际使用的队伍记在 mirror.runtime.team_used 里（task.mirror 进场时写入）：
# 镜牢队伍逐场轮换，设置页的 mirror_team 只是循环里的第一支，不能代表本场队伍
TEAM_USED_KEY = "team_used"
# 固定等待秒数：打开弹窗、选中关键词、提交刷新各等一次；是否生效由上层重新观察判断
OPEN_WAIT_SECONDS = 1.2
SELECT_WAIT_SECONDS = 0.6
SUBMIT_WAIT_SECONDS = 1.5
# 点击 Keyword Refresh 后弹窗要等滑入动画：打开后在本步内有界复查几次，
# 一看到弹窗就紧接着选关键词并提交，不再交回上层等下一轮
POPUP_WAIT_SECONDS = 0.7
POPUP_WAIT_ATTEMPTS = 4


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _in_shop(ctx: RunContext) -> bool:
    """当前帧是否为镜牢商店页：右上角两个刷新按钮模板任一命中，或左上角读到 Shop 标题。"""
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


def _skill_popup_open(ctx: RunContext) -> bool:
    """当前帧是否停在技能替换弹窗（它会盖住右上角刷新按钮）。"""
    text = _region_text(ctx, SKILL_POPUP_REGION)
    if all(word in text for word in SKILL_POPUP_KEYWORDS):
        return True
    actions = _region_text(ctx, SKILL_POPUP_ACTION_REGION)
    return all(word in actions for word in SKILL_POPUP_ACTION_KEYWORDS)


def _detail_open(ctx: RunContext) -> bool:
    """当前帧是否已打开饰品商品详情：标题用素材 mirror/shop/purchase_ego_gifts 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=DETAIL_TITLE_ASSET,
            region=DETAIL_TITLE_REGION,
            threshold=DETAIL_TITLE_THRESHOLD,
        )
    )


def _keyword_popup_open(ctx: RunContext) -> bool:
    """当前帧是否已打开 Shop - Keyword Refresh 弹窗：只用标题素材 mirror/shop/shop_keyword_refresh 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=KEYWORD_POPUP_TITLE_ASSET,
            region=KEYWORD_POPUP_TITLE_REGION,
            threshold=KEYWORD_POPUP_TITLE_THRESHOLD,
        )
    )


def _pending_cost(ctx: RunContext) -> int | None:
    """读弹窗第二行 Spend N Cost 里的 N（免费刷新时为 0）；读不到返回 None。"""
    result = ctx.action("observe.ocr", region=KEYWORD_POPUP_COST_REGION) or {}
    parts = [
        re.sub(r"[^0-9]", "", str(item.get("text", "")))
        for item in result.get("items") or []
    ]
    digits = "".join(part for part in parts if part)
    return int(digits) if digits.isdigit() else None


def _cost(ctx: RunContext) -> int | None:
    """读当前持有的 Cost：把硬币右侧的数字按横向顺序拼起来；读不到返回 None。"""
    result = ctx.action("observe.ocr", region=COST_REGION) or {}
    parts: list[tuple[int, str]] = []
    for item in result.get("items") or []:
        digits = re.sub(r"[^0-9]", "", str(item.get("text", "")))
        if digits:
            parts.append((int(item["centerxy"][0]), digits))
    if not parts:
        return None
    parts.sort()
    text = "".join(digits for _, digits in parts)
    return int(text) if text.isdigit() else None


def _settings(ctx: RunContext) -> dict:
    """RunState.settings；不可用时按空字典处理。"""
    settings = ctx.run_state.settings
    return settings if isinstance(settings, dict) else {}


def _team_index(ctx: RunContext) -> int:
    """本场镜牢实际使用的队伍序号：只读 mirror.runtime.team_used；缺失时按第 1 个队伍处理。"""
    runtime = _settings(ctx).get(RUNTIME_KEY)
    used = runtime.get(TEAM_USED_KEY) if isinstance(runtime, dict) else None
    if type(used) is int and 1 <= used <= MAX_TEAMS:
        return used
    ctx.log(
        f"没有可用的本场队伍记录 {TEAM_USED_KEY}={used!r}，按第{DEFAULT_TEAM}个队伍处理",
        level="warning",
    )
    return DEFAULT_TEAM


def _keyword(ctx: RunContext) -> str:
    """读取本场镜牢使用队伍（按轮换后的实际队伍）的初始饰品类别；未配置或为「不选择流派」时返回空串。"""
    settings = _settings(ctx)
    team_index = _team_index(ctx)
    teams_page = settings.get(TEAM_PAGE_ID) or {}
    teams = teams_page.get(TEAMS_KEY) if isinstance(teams_page, dict) else None
    if not isinstance(teams, list) or not 1 <= team_index <= len(teams):
        ctx.log(f"队伍配置里没有第{team_index}个队伍，本次不按流派选择关键词", level="warning")
        return ""
    entry = teams[team_index - 1]
    keyword = str(entry.get(KEYWORD_KEY) or "").strip() if isinstance(entry, dict) else ""
    return "" if keyword.casefold() == KEYWORD_NONE else _norm(keyword)


def _committed(ctx: RunContext) -> bool:
    """本次关键词刷新是否已经点过弹窗里的 Refresh。"""
    runtime = _settings(ctx).get(RUNTIME_KEY)
    return isinstance(runtime, dict) and runtime.get(COMMITTED_KEY) is True


def _mark_committed(ctx: RunContext, value: bool) -> None:
    """记录／清除「已点过弹窗 Refresh」的标记；写不进去只记 warning，不影响本步动作。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录关键词刷新提交标记", level="warning")
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[COMMITTED_KEY] = value
    settings[RUNTIME_KEY] = runtime


def _keyword_refresh_point(ctx: RunContext) -> tuple[int, int] | None:
    """用素材 mirror/shop/keyword_refresh 匹配右上角的 Keyword Refresh 按钮，返回中心；没命中返回 None。"""
    hits = (
        ctx.action(
            "observe.match_asset",
            asset=KEYWORD_REFRESH_BUTTON_ASSET,
            region=REFRESH_BUTTON_REGION,
            threshold=KEYWORD_REFRESH_BUTTON_THRESHOLD,
        )
        or []
    )
    centers = [
        (int(hit["centerxy"][0]), int(hit["centerxy"][1]))
        for hit in hits
        if hit.get("centerxy")
    ]
    if not centers:
        return None
    centers.sort()
    return centers[0]


def _open_popup(ctx: RunContext) -> dict[str, str]:
    """第一段：在商店页点一次 Keyword Refresh 按钮打开弹窗，只打开、不提交（不扣 Cost）。"""
    if _skill_popup_open(ctx) or _detail_open(ctx):
        ctx.log(
            "技能替换弹窗或饰品详情仍开着，刷新按钮被挡住，本次不打开 Keyword Refresh 弹窗",
            level="warning",
            screenshot=True,
        )
        return {"action": "skipped"}
    if not _in_shop(ctx):
        ctx.log("当前不是镜牢商店页，不点击 Keyword Refresh", level="warning", screenshot=True)
        return {"action": "skipped"}
    keyword = _keyword(ctx)
    if keyword not in KEYWORD_CELLS:
        ctx.log(
            f"本次队伍没有配置可用的流派关键词（读到 {keyword!r}），不打开 Keyword Refresh 弹窗",
            level="warning",
        )
        return {"action": "no_keyword", "keyword": keyword}
    before = _cost(ctx)
    if before is None:
        ctx.log("没有读到当前持有的 Cost，不做盲点刷新", level="warning", screenshot=True)
        return {"action": "skipped"}

    point = _keyword_refresh_point(ctx)
    if point is None:
        point = KEYWORD_REFRESH_FALLBACK
        ctx.log(
            f"右上角没有匹配到 Keyword Refresh 按钮模板 {KEYWORD_REFRESH_BUTTON_ASSET}，"
            f"按兜底落点 {point} 点击（不点普通 Refresh）",
            level="warning",
        )
    # 新的关键词刷新从打开弹窗开始：清掉上一次的提交标记
    _mark_committed(ctx, False)
    ctx.log(
        f"点击一次 Keyword Refresh {point} 打开弹窗（点击前 Cost={before}，本步还不扣 Cost），"
        f"弹窗一出现就在本次调用里按本队流派选关键词 {keyword} 并提交"
    )
    ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=OPEN_WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    # 弹窗滑入需要时间：在本步内有界复查几次，看到弹窗就立刻返回，由调用方在同一次调用里继续处理
    for attempt in range(1, POPUP_WAIT_ATTEMPTS + 1):
        if _keyword_popup_open(ctx):
            ctx.log(f"Keyword Refresh 弹窗已打开（点击后第{attempt}次复查命中），立即选关键词并提交")
            return {"action": "popup_opened", "keyword": keyword}
        if attempt < POPUP_WAIT_ATTEMPTS:
            ctx.action("observe.wait", seconds=POPUP_WAIT_SECONDS)
            ctx.action("observe.capture_screen")
    ctx.log(
        "点击 Keyword Refresh 后没有出现 Shop - Keyword Refresh 弹窗，交回上层按普通 Refresh 处理",
        level="warning",
        screenshot=True,
    )
    return {"action": "open_failed", "keyword": keyword}


def _commit_popup(ctx: RunContext) -> dict[str, str]:
    """第二段：弹窗里按本队流派点固定坐标选关键词，再点一次弹窗底部 Refresh 提交。"""
    keyword = _keyword(ctx)
    if keyword not in KEYWORD_CELLS:
        ctx.log(
            f"弹窗打开后读到本队流派 {keyword!r} 不在关键词卡片表里，本次不选关键词也不提交",
            level="warning",
            screenshot=True,
        )
        return {"action": "no_keyword", "keyword": keyword}
    if _committed(ctx):
        ctx.log(
            "本次关键词刷新已经点过弹窗里的 Refresh，弹窗仍在：不再重复点击（避免重复扣 Cost）",
            level="warning",
            screenshot=True,
        )
        return {"action": "refresh_unconfirmed", "keyword": keyword}

    center = KEYWORD_CELLS[keyword]
    ctx.log(f"在 Keyword Refresh 弹窗里按固定坐标选择流派关键词 {keyword} @ {center}")
    ctx.action("control.click", x=center[0], y=center[1])
    ctx.action("observe.wait", seconds=SELECT_WAIT_SECONDS)
    # 动作后先刷新截图再判断：弹窗是否还在、花费提示都从新截的这一帧读，不沿用点击前的旧帧
    ctx.action("observe.capture_screen")
    if not _keyword_popup_open(ctx):
        ctx.log(
            "选择流派关键词后弹窗已经不在了，本次不点击 Refresh",
            level="warning",
            screenshot=True,
        )
        return {"action": "popup_closed", "keyword": keyword}
    # 提交前读一次弹窗里的花费提示：免费关键词刷新（0）不会扣 Cost，供上层选择验收方式
    pending = _pending_cost(ctx)

    ctx.log(
        f"点击弹窗底部 Refresh {POPUP_REFRESH_POINT} 提交一次关键词刷新"
        f"（弹窗显示花费 {pending if pending is not None else '未知'}，本步只点一次）"
    )
    ctx.action("control.click", x=POPUP_REFRESH_POINT[0], y=POPUP_REFRESH_POINT[1])
    _mark_committed(ctx, True)
    ctx.action("observe.wait", seconds=SUBMIT_WAIT_SECONDS)
    # 提交后同样先重新截一帧，再判断弹窗是否已关闭（不在旧帧上反复空检测）
    ctx.action("observe.capture_screen")
    pending_text = "" if pending is None else str(pending)
    if _keyword_popup_open(ctx):
        ctx.log(
            "点击 Refresh 后弹窗仍在，本次不再重复点击，交回上层重新观察是否已重掷",
            level="warning",
            screenshot=True,
        )
        return {
            "action": "refresh_unconfirmed",
            "keyword": keyword,
            "pending_cost": pending_text,
        }
    return {"action": "refresh_clicked", "keyword": keyword, "pending_cost": pending_text}


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    按当前画面推进一次 Keyword Refresh，每次调用最多提交一次（提交即扣一次 Cost）：
    - 弹窗已打开（上一次调用留下的）→ 直接按本队流派的固定坐标选关键词，再点一次弹窗底部 Refresh；
    - 弹窗没打开 → 复查商店页与两个挡住的弹窗后，点一次右上角 Keyword Refresh（不扣 Cost），
      然后在本次调用里有限次复查弹窗是否滑入，一出现就立即选关键词并提交，不再交回上层等下一轮；
    - 没有可用流派关键词、不在商店页、Cost 读不到、弹窗始终没出现 → 零输入返回对应动作名，
      由上层决定退回普通 Refresh。
    返回动作名（action）与流派关键词；刷新是否真的生效由 sub_workflow.mirror_shop 下一轮重新读 Cost 判断，
    本步不做无限轮询、不重复提交，也不自行清空商店已处理记录。
    """
    ctx.action("observe.capture_screen")
    if not _keyword_popup_open(ctx):
        # 弹窗还没打开：点一次 Keyword Refresh，并在本步内有界等它滑入（这一步还不扣 Cost）
        opened = _open_popup(ctx)
        if opened.get("action") != "popup_opened":
            return opened
        # 弹窗刚打开：不交回上层，立即在本次调用里按本队流派选关键词并提交一次
    return _commit_popup(ctx)
