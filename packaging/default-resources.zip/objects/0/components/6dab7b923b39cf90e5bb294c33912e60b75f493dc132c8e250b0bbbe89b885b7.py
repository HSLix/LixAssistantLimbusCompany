"""镜牢商店：点一次右下角 Leave，等 2 秒后按一次 Enter，落点由上层重新观察。"""
import re

from lalc import RunContext, step

PATH_ASSET = "mirror/train_head"
# 商店页标识（三条判据取或，任一成立就算商店页）：
# ① 右上角普通 Refresh 按钮模板命中；② Keyword Refresh 按钮模板命中；③ 左上角 Shop 标题文字。
# 不再靠右下角 Leave 文字（Run 415 里同一帧 Shop 标题读到、Leave 区域却返回空、误判已离开商店）。
SHOP_REFRESH_ASSET = "mirror/shop/refresh"
SHOP_KEYWORD_REFRESH_ASSET = "mirror/shop/keyword_refresh"
SHOP_BUTTONS_REGION = {"x": 900, "y": 80, "width": 330, "height": 110}
# 左上角 Shop 标题：1280x720 实测文字中心 (256, 122)、宽约 70；
# 区域只包标题横幅，避开下方 Shop Mirror Dungeon 海报里的 Shop 字样（y≈180 起）与右侧 Cost 数字
SHOP_TITLE_REGION = {"x": 150, "y": 92, "width": 280, "height": 58}
SHOP_TITLE_KEYWORD = "shop"
# 寻路页左上角的 Exploring 文字
PATH_HEADER_REGION = {"x": 30, "y": 80, "width": 290, "height": 60}
PATH_KEYWORD = "exploring"
# 只尝试一次「点 Leave → 等待 → Enter」，不在这里判断是否回到寻路页


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _on_path(ctx: RunContext) -> bool:
    """重新截图，用火车头模板或左上角 Exploring 文字判断是否已回到寻路页。"""
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=PATH_ASSET):
        return True
    return PATH_KEYWORD in _region_text(ctx, PATH_HEADER_REGION)


def _in_shop(ctx: RunContext) -> bool:
    """重新截图，用右上角两个刷新按钮模板任一命中或左上角 Shop 标题判断是否还停在商店页。"""
    ctx.action("observe.capture_screen")
    for asset in (SHOP_REFRESH_ASSET, SHOP_KEYWORD_REFRESH_ASSET):
        if ctx.action("observe.match_asset", asset=asset, region=SHOP_BUTTONS_REGION):
            return True
    return SHOP_TITLE_KEYWORD in _region_text(ctx, SHOP_TITLE_REGION)


@step
def execute(
    ctx: RunContext,
    *,
    leave_x: int = 1133,
    leave_y: int = 647,
    wait_seconds: float = 2.0,
) -> None:
    """
    只负责离开商店，做一组固定动作：
    已在寻路页时零动作返回；识别不到商店页特征（刷新按钮模板与左上角 Shop 标题都没命中）时零输入返回；
    否则点一次右下角 Leave（默认 (1133, 647)）、等 wait_seconds（默认 2 秒）、再按一次 Enter，然后交回。
    是否已回到寻路页、落在哪一页由 task.mirror 下一轮重新观察，本步不轮询、不重试。
    """
    if _on_path(ctx):
        ctx.log("当前已在寻路页，无需离开商店")
        return

    if not _in_shop(ctx):
        ctx.log(
            "当前既不是寻路页也识别不到任何商店页特征（刷新按钮或 Shop 标题），不做任何输入",
            level="warning",
            screenshot=True,
        )
        return

    ctx.log(f"点击一次商店 Leave 按钮 ({leave_x}, {leave_y})")
    ctx.action("control.click", x=leave_x, y=leave_y)
    ctx.log(f"已等待 {wait_seconds} 秒，按一次 Enter 确认离开商店")
    ctx.action("observe.wait", seconds=wait_seconds)
    ctx.action("control.key_press", key="enter")
    ctx.log("离开商店的输入已完成，落点由上层重新观察")
