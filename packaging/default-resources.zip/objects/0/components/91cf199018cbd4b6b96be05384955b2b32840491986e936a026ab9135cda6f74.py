from lalc import RunContext, step

WIN_RATE_SELECTED_ASSET = "battle/win_rate_selected"
# 未选中状态下的 Win Rate 按钮文字模板：P 键无效时按它的 centerxy 用鼠标点一次
WIN_RATE_ASSET = "battle/win_rate"
# 按 P 后等待选中状态刷新，以及点击后交回上层前的短暂等待
KEY_WAIT_SECONDS = 0.5
CLICK_WAIT_SECONDS = 0.5
# 确认 win rate 已选中后立即按 Enter 开战，再短暂等待让开战画面刷新
ENTER_WAIT_SECONDS = 0.5


def _hit(ctx: RunContext, assets: list[str]) -> list[str]:
    """按同一截图统计命中素材，返回命中名称。"""
    return [asset for asset in assets if ctx.action("observe.match_asset", asset=asset)]


def _selected(ctx: RunContext) -> bool:
    """当前内存帧是否已出现 win rate 选中标记；不刷新截图。"""
    return bool(ctx.action("observe.match_asset", asset=WIN_RATE_SELECTED_ASSET))


@step
def execute(ctx: RunContext, *, continue_battle_assets: list[str]) -> None:
    """截图复查入口条件，未选中 win rate 时先按一次 P；按键后复查仍未选中就点一次 Win Rate 按钮。

    只做这一组固定尝试（一次按键 + 至多一次点击），不在本步内轮询或重试业务输入。
    按键后已用新截图确认 win rate 选中时，直接按一次 Enter 开战，不再交回上层等下一轮
    重新截图后再走 step.start_battle_until；鼠标点击兜底是否选中仍由上层用新画面验收。
    """

    ctx.action("observe.capture_screen")

    if not _hit(ctx, continue_battle_assets):
        ctx.log("未在 可选winrate 的页面，本轮不操作", level="warning", screenshot=True)
        return

    if _selected(ctx):
        ctx.log("win rate 已选中，本轮不操作")
        return

    ctx.log("未选中 win rate，按一次 P")
    ctx.action("control.key_press", key="p")
    ctx.action("observe.wait", seconds=KEY_WAIT_SECONDS)

    # 按键后必须重新截图再判：部分战斗画面里 P 键无效（会命中，选中状态不变化），
    # 沿用按键前的帧无法发现没生效，也就不会走到鼠标点击兜底
    ctx.action("observe.capture_screen")
    if _selected(ctx):
        # P 键生效即在同一帧证据下开战，省掉“下一轮重新截图再分派 start_battle_until”的一次循环
        ctx.log("P 键已生效，win rate 处于选中状态，立即按一次 Enter 开战")
        ctx.action("control.key_press", key="enter")
        ctx.action("observe.wait", seconds=ENTER_WAIT_SECONDS)
        return

    matches = ctx.action("observe.match_asset", asset=WIN_RATE_ASSET)
    if not matches:
        ctx.log(
            f"P 键未生效且当前帧未匹配到 {WIN_RATE_ASSET} 按钮，不输入，交回上层",
            level="warning",
            screenshot=True,
        )
        return
    if len(matches) > 1:
        ctx.log(f"{WIN_RATE_ASSET} 命中{len(matches)}个，存在歧义，按第一个命中点击", level="warning")

    ctx.action("control.click", centerxy=matches[0]["centerxy"])
    ctx.log(
        f"P 键未生效，已改用鼠标点击 Win Rate 按钮 @ {matches[0]['centerxy']}，是否选中由上层重新截图验收"
    )
    ctx.action("observe.wait", seconds=CLICK_WAIT_SECONDS)
