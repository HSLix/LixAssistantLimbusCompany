"""从 Luxcavation 页面点击左上角返回箭头回到主页面，供进入镜牢前退出该页面。"""
from lalc import RunContext, step

# Luxcavation 页独有的标题，用来判断本步骤是否适用
TITLE_ASSET = "luxcavation/title"
# Luxcavation 页面左上角的返回箭头
BACK_ASSET = "ui/back"
# 标题模板漏识别时的兜底：Luxcavation 标题文字区域
TITLE_REGION = {"x": 60, "y": 178, "width": 175, "height": 42}
TITLE_KEYWORD = "luxcavation"


def _title_present(ctx: RunContext) -> bool:
    """当前帧是否仍有 Luxcavation 标题：模板优先，漏识别时用标题区域 OCR 兜底。"""
    if ctx.action("observe.match_asset", asset=TITLE_ASSET):
        return True
    result = ctx.action("observe.ocr", region=TITLE_REGION) or {}
    text = " ".join(
        str(item.get("text", "")) for item in (result.get("items") or [])
    ).lower()
    return TITLE_KEYWORD in text


@step
def execute(ctx: RunContext) -> None:
    """不在 Luxcavation 页面时零输入返回；否则点一次左上角返回箭头后交回。"""
    ctx.action("observe.capture_screen")
    if not _title_present(ctx):
        ctx.log("未检测到 Luxcavation 标题，当前不在该页面，本 Step 不点击", level="warning")
        return

    back = ctx.action("observe.match_asset", asset=BACK_ASSET)
    if not back:
        ctx.log("Luxcavation 页面上未匹配到左上角返回箭头，不输入，交回上层", level="warning", screenshot=True)
        return
    if len(back) > 1:
        ctx.log(f"返回箭头命中{len(back)}个，存在歧义，按第一个点击", level="warning")
    ctx.action("control.click", centerxy=back[0]["centerxy"])
    ctx.log("已点击 Luxcavation 页面的返回箭头，是否回到主页面由上层重新截图判断")
