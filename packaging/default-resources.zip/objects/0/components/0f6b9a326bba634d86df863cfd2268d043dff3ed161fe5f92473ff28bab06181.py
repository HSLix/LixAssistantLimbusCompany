"""镜牢：关闭压在业务页之上的服务端维护通知（Server is under Scheduled Maintenance.）。

现场（1280x720，Run 639 第 99~102 轮）：维护通知盖在 Fuse E.G.O Gift 页之上，下层页面被压暗但
融合页标题横幅仍然命中，主循环把被盖住的融合页当成当前业务页反复点底部 Close，通知本身一直没人关，
第四次撞上分支上限失败（证据 639/12928 就是那一帧：通知上的 Close 在 (638,467)，融合页的 Cancel
在 (492,583)）。本步只点通知自带的 Close，不碰被盖住页面的任何按钮，也不做其它输入。
"""
import re

from lalc import RunContext, step

# 弹窗文案：Server is under Scheduled Maintenance. / You will be able to login after 12:00 (KST)。
# 区域只包住弹窗标题与正文，避开下层的队伍栏数字，减少误判。
POPUP_REGION = {"x": 300, "y": 280, "width": 680, "height": 260}
POPUP_KEYWORD = "scheduledmaintenance"
# 通知自带的 Close 按钮：1280x720 实测文字中心 (638,467)
CLOSE_REGION = {"x": 540, "y": 420, "width": 200, "height": 95}
CLOSE_FALLBACK = (638, 467)
WAIT_SECONDS = 1.2


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _notice_open(ctx: RunContext) -> bool:
    """当前帧是否压着服务端维护通知。"""
    return POPUP_KEYWORD in _region_text(ctx, POPUP_REGION)


def _button_point(ctx: RunContext, region: dict[str, int], keyword: str):
    """在指定区域找按钮文字中心；找不到返回 None。"""
    result = ctx.action("observe.ocr", region=region) or {}
    for item in result.get("items") or []:
        if keyword in _norm(item.get("text", "")):
            center = item.get("centerxy")
            if center:
                return (int(center[0]), int(center[1]))
    return None


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    按当前画面关闭服务端维护通知：
    - 通知在 → 点一次通知上的 Close，等待后重新截图复查；
    - 已经不在通知上 → 零输入返回 not_open。
    是否真的关闭由上层重新观察确认，本步不重试、不判断游戏能否继续。
    """
    ctx.action("observe.capture_screen")
    if not _notice_open(ctx):
        ctx.log("当前不在服务端维护通知上，无需关闭")
        return {"action": "not_open"}

    point = _button_point(ctx, CLOSE_REGION, "close") or CLOSE_FALLBACK
    ctx.log(f"点击维护通知的 Close {point} 关闭弹窗（不操作被盖住的业务页）")
    ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    if _notice_open(ctx):
        ctx.log(
            "点击 Close 后维护通知仍在，交上层按服务端仍在维护处理",
            level="warning",
            screenshot=True,
        )
        return {"action": "still_open"}
    ctx.log("服务端维护通知已关闭，落点由上层重新观察")
    return {"action": "closed"}
