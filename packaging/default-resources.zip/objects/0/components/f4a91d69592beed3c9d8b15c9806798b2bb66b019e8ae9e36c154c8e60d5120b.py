"""镜牢寻路：节点确认弹窗出现后按一次 Enter（或点一次右下角 Enter 按钮），落点由上层观察。"""
from lalc import RunContext, step

# 节点确认弹窗右下角的 Enter 按钮所在区域，及按钮图标素材（与 step.mirror_path_select_node 共用）
CONFIRM_REGION = {"x": 1020, "y": 460, "width": 260, "height": 150}
ENTER_ASSET = "mirror/path/enter_button"
# 寻路界面标识：右上角齿轮下方的三个按钮，命中两个及以上就算寻路界面；
# 不再用左上角 Exploring 文字，那段文字会忽明忽暗闪烁
PATH_ICON_ASSETS = ("mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects")
PATH_ICON_REGION = {"x": 1180, "y": 70, "width": 100, "height": 190}
MIN_PATH_ICONS = 2
# Enter 按钮模板命中但结果缺少 centerxy 字段时的点击坐标兜底；模板未命中时改用 Enter 文案／Enter 键
ENTER_FALLBACK = (1156, 542)
# 弹窗打开时右下角这颗按钮带 Enter 文案；按钮图标模板只有 70x70 的图标本体，
# Run 645 现场（证据 645/118）弹窗明明开着、模板却一直空结果，本步因此会误判成「不在确认弹窗」
# 而零输入返回。同一区域再读一次 Enter 文案，识别到就点它的中心，不再只依赖模板。
ENTER_TEXT = "enter"
# 输入后的固定等待秒数；是否已进入节点由 task.mirror 下一轮情景分派重新观察
AFTER_INPUT_SECONDS = 1.0


def _path_icons(ctx: RunContext) -> int:
    """对当前帧右上角匹配三个按钮素材，返回命中数量；不刷新截图。"""
    return sum(
        1
        for asset in PATH_ICON_ASSETS
        if ctx.action("observe.match_asset", asset=asset, region=PATH_ICON_REGION)
    )


def _ocr_enter_center(ctx: RunContext) -> tuple[int, int] | None:
    """在确认弹窗区域做一次局部 OCR，返回文字里含 enter 的条目中心；没命中返回 None。不截图。"""
    result = ctx.action("observe.ocr", region=CONFIRM_REGION) or {}
    for item in result.get("items") or []:
        text = "".join(
            char for char in str(item.get("text", "")).lower() if char.isalnum()
        )
        if ENTER_TEXT not in text:
            continue
        center = item.get("centerxy") or ()
        if len(center) >= 2:
            return int(center[0]), int(center[1])
    return None


def _enter_prompt(ctx: RunContext) -> bool:
    """当前帧是否已有节点确认弹窗：Enter 按钮模板，或同一区域 OCR 到的 Enter 文案。不截图。"""
    if ctx.action("observe.match_asset", asset=ENTER_ASSET, region=CONFIRM_REGION):
        return True
    return _ocr_enter_center(ctx) is not None


def _still_on_path(ctx: RunContext) -> bool:
    """重新截图后判断是否还停在节点确认弹窗或寻路界面上：先看 Enter（模板／文案），再看右上角按钮。"""
    ctx.action("observe.capture_screen")
    if _enter_prompt(ctx):
        return True
    return _path_icons(ctx) >= MIN_PATH_ICONS


@step
def execute(ctx: RunContext) -> None:
    """
    先截图复查入口：既没有节点确认弹窗的 Enter（按钮模板或右下角 Enter 文案）、也不在寻路界面时零输入返回。
    本步不判断是否已进入节点，进入后属于哪种情景由 task.mirror 的情景分派负责。
    否则只做一次输入：右下角模板匹配到 Enter 按钮就点它一次；模板漏识别但同一区域 OCR 读到 Enter 文案时，
    点这段文案的中心；两者都没有才按一次 Enter 键。然后等固定 1 秒交回。
    是否真正进入节点、落到哪个情景由 task.mirror 下一轮情景分派重新观察，本步不补点、不轮询。
    """
    ctx.action("observe.capture_screen")
    if not _still_on_path(ctx):
        ctx.log(
            "当前既不在节点确认弹窗也不在寻路界面，本步不做输入",
            level="warning",
            screenshot=True,
        )
        return

    matches = list(ctx.action("observe.match_asset", asset=ENTER_ASSET, region=CONFIRM_REGION) or [])
    if matches:
        if len(matches) > 1:
            ctx.log(
                f"Enter 按钮模板在确认区域内命中 {len(matches)} 处，按分数最高的一处点击",
                level="warning",
            )
        center = matches[0].get("centerxy") or list(ENTER_FALLBACK)
        point = (int(center[0]), int(center[1]))
        ctx.log(f"点击一次右下角 Enter 按钮 {point}，等 {AFTER_INPUT_SECONDS} 秒后交回")
        ctx.action("control.click", centerxy=point)
    else:
        center = _ocr_enter_center(ctx)
        if center:
            ctx.log(
                f"Enter 按钮模板未命中，按同一区域 OCR 到的 Enter 文案点击 {center}，"
                f"等 {AFTER_INPUT_SECONDS} 秒后交回"
            )
            ctx.action("control.click", centerxy=center)
        else:
            ctx.log(
                f"右下角没有 Enter 按钮模板也没有 Enter 文案，按一次 Enter 键，"
                f"等 {AFTER_INPUT_SECONDS} 秒后交回"
            )
            ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=AFTER_INPUT_SECONDS)


