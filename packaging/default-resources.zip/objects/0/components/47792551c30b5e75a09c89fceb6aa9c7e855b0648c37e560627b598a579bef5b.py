"""从 Drive 页面点一次镜牢入口，是否进入由上层下一轮重新观察。"""
from lalc import RunContext, step

DRIVE_ASSET = "drive/inferno"
ENTRY_ASSET = "mirror/entry"
# 点击 Drive 后的固定等待秒数；只让入口页加载，不用来判定是否已经进入
AFTER_CLICK_SECONDS = 1.0

# 客户区固定 1280x720：Drive 页中列按钮自上而下是 Luxcavation、Mirror Dungeons、Under construction、
# Refraction Railway；镜牢入口是第二个按钮（Run 352 现场：按钮 358~528 x 176~263），
# 旧的 (450, 290) 落在不可用的 Under construction 上，点了四次都没有离开 Drive 页
MIRROR_TILE_REGION = {"x": 350, "y": 165, "width": 200, "height": 110}
MIRROR_KEYWORDS = ("mirror", "dungeon")


def _mirror_tile_center(ctx: RunContext) -> list[int] | None:
    """在当前帧的 Drive 按钮列里用 OCR 找 Mirror Dungeons 文字，返回文字区域中心；找不到返回 None。"""
    result = ctx.action("observe.ocr", region=MIRROR_TILE_REGION) or {}
    boxes = []
    for item in result.get("items") or []:
        text = str(item.get("text", "")).lower()
        box = item.get("box") or {}
        if box and any(keyword in text for keyword in MIRROR_KEYWORDS):
            boxes.append(box)
    if not boxes:
        return None
    left = min(box["x"] for box in boxes)
    top = min(box["y"] for box in boxes)
    right = max(box["x"] + box["width"] for box in boxes)
    bottom = max(box["y"] + box["height"] for box in boxes)
    return [(left + right) // 2, (top + bottom) // 2]


@step
def execute(ctx: RunContext, *, drive_x: int = 443, drive_y: int = 220) -> None:
    """
    先截图复查入口：已在镜牢入口页、或当前不在 Drive 页面时零输入返回；
    确在 Drive 页面才点击一次 Mirror Dungeons 按钮（优先用 OCR 定位按钮文字，定位失败时用固定坐标），
    等固定 1 秒后交回。是否已经进入入口页由上层下一轮重新观察，本步不轮询、不判定成败。
    """
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=ENTRY_ASSET):
        ctx.log("已在镜牢入口页，无需再点 Drive")
        return
    if not ctx.action("observe.match_asset", asset=DRIVE_ASSET):
        ctx.log("当前不是 Drive 页面，不点击镜牢入口", level="warning", screenshot=True)
        return

    found = _mirror_tile_center(ctx)
    if found:
        point, how = (found[0], found[1]), "OCR 定位 Mirror Dungeons 文字"
    else:
        point, how = (drive_x, drive_y), "固定按钮坐标"
    ctx.log(f"在 Drive 页面点击 Mirror Dungeons 按钮 {point}（{how}），等 {AFTER_CLICK_SECONDS} 秒后交回")
    ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
