"""通用事件节点编排：按入口（exp／thread／mirror）区分事件结束后的已知业务页面，
有限循环内按当前页面分派 Step，未命中任何 Step 时按一次 Enter 推进。
每轮只做一次整屏 OCR，路径文字、右下角 Continue／SKIP、Server Error 都从这份结果里按区域过滤复用。"""
import re
from typing import Literal

from lalc import ExecutionFailure, RunContext, sub_workflow

# 事件与寻路标识的素材名由 plan 统一定义、通过调用参数传入：本文件不再维护素材名副本
# 各状态判据所在区域（1280x720 客户区）。
# 右下角这块区域同时是 Continue 与 SKIP 的位置：每轮只过滤一次，两个关键字共用同一份文本
BUTTON_REGION = {"x": 1020, "y": 590, "width": 240, "height": 120}
# 普通／灰化 SKIP 模板的匹配区域：灰化模板是整颗按钮的裁剪（240x95），宽度正好等于按钮区域的 240，
# 搜索区域没有横向余量时模板只有唯一一个可放置位置，按钮相对裁剪位置偏几个像素就永远匹配不到。
# 因此 SKIP 匹配改用带余量的右下角区域；BUTTON_REGION 仍只负责 Continue 等按钮文字的 OCR 过滤。
SKIP_MATCH_REGION = {"x": 980, "y": 560, "width": 300, "height": 160}
# 战斗准备界面判据：右下角 clear selection 按钮，识别到即作为事件退出信号
PREPARE_ASSET = "prepare_team/clear_selection"
# 战斗场景素材：事件结束后可能直接进入战斗（与 sub_workflow.battle_till_end 的
# CONTINUE_BATTLE_ASSETS 保持一致），命中即作为事件退出信号，交回上层战斗处理
CONTINUE_BATTLE_ASSETS = (
    "battle/first_turn",
    "battle/select_line",
    "battle/win_rate",
    "battle/win_rate_selected",
    "battle/damage",
)
# 事件之外的已知业务页面按入口区分：事件结束后不同任务会落到不同页面，识别到入口对应的页面就交回上层，
# 不在事件里继续按 Enter。exp／thread：Luxcavation 的副本入口、Thread 等级选择与 Thread 进入按钮
LUXCAVATION_EXIT_ASSETS = (
    "luxcavation/title",
    "luxcavation/thread_level_select",
    "luxcavation/thread_enter",
)
# mirror：镜牢内的事件结束会回到寻路页，也可能直接进入楼层 Acquire E.G.O Gift 页（与 step.mirror_floor_gift_select 一致）
MIRROR_EXIT_ASSETS = (
    "mirror/acquire_ego_gift_hand",
    "mirror/gift_select",
)
# 镜牢事件里拿到饰品时会弹出 E.G.O Gift GET! 到手弹窗，它盖在下层页面之上，是事件的正常出口：
# 用标题横幅素材（plan 下放的 gift_get_asset）做原尺寸模板匹配，区域与阈值跟 task.mirror、
# step.mirror_gift_get_confirm 的 gift_get 判定保持一致（380x110 搜索区、0.85），
# 命中即交回 task.mirror，由那里的 gift_get 分支按 Enter 确认弹窗，不在本层重复输入
GIFT_GET_REGION = {"x": 380, "y": 130, "width": 520, "height": 110}
GIFT_GET_THRESHOLD = 0.85
# 镜牢战斗后的 Select Encounter Reward Card 奖励卡片页标题条（与 sub_workflow.battle_till_end 保持一致）
REWARD_CARD_TITLE_REGION = {"x": 270, "y": 100, "width": 540, "height": 70}
REWARD_CARD_TITLE_KEYWORD = "encounterrewardcard"
# 支持的入口：与调用方 task.exp／task.thread／task.mirror 一一对应，值是该入口事件结束后的已知业务页面素材
ENTRY_EXIT_ASSETS = {
    "exp": LUXCAVATION_EXIT_ASSETS,
    "thread": LUXCAVATION_EXIT_ASSETS,
    "mirror": MIRROR_EXIT_ASSETS,
}
# Server Error 弹窗文案所在区域与关键字（与 recovery.popup_server_error 保持一致）
POPUP_REGION = {"x": 320, "y": 150, "width": 640, "height": 420}
POPUP_KEYWORD = "servererror"
# 叙述页 SKIP 按钮改用模板匹配，不再依赖右下角 OCR 文案；
# 普通与灰化两种模板的素材名由 plan 传入（event_skip_asset／event_grey_skip_asset）。
# 灰化 SKIP：打字动画中或刚点过 SKIP 时按钮变暗、点不动，但按 Enter 仍能推进文本；
# 由 step.event_grey_skip_enter 连续按 3 次 Enter（间隔 1 秒），落点仍由下一轮重新截图验收
CONTINUE_KEYWORD = "continue"
# 判定提示面板：选择带判定的选项后，右上角面板显示「Glut./Pride Advantage」+ 一句提示，
# 这块画面右下角同样有 SKIP 文字（此时 SKIP 不可用），推进方式是点击一次右下角固定坐标（不再按 Enter），
# 因此必须在叙述页判断之前单独分流，否则会被当成叙述页反复「跳过」而不动
ADVANTAGE_REGION = {"x": 820, "y": 100, "width": 380, "height": 100}
ADVANTAGE_KEYWORD = "advantage"
DISADVANTAGE_KEYWORD = "disadvantage"
# 判定提示面板的推进改由 step.event_advantage_proceed 完成：复查入口后点击一次右下角固定坐标，
# 这里不再自己调 control 动作，也不按 Enter
# 判定选择阶段改用成功率档次标签素材判定：任意一档命中就算在选罪人，不再依赖 OCR 文案
PASS_TIER_ASSETS = (
    "event/pass/veryhigh",
    "event/pass/high",
    "event/pass/normal",
    "event/pass/low",
    "event/pass/verylow",
)
# 五档成功率标签统一使用 0.8 的模板匹配阈值（observe.match_asset 默认 0.9，更严格）
PASS_TIER_THRESHOLD = 0.8
PATH_KEYWORD = "exploring"
# 未命中任何 Step 的无效循环上限，以及整体循环上限（防止无界循环）
MAX_INVALID = 3
# 完整事件确实需要很长的轮次预算：一个事件可能包含多段叙述、选项、判定、战斗和结果页，
# 每段都要等打字机效果与过渡动画结束，单次推进可能只有一两轮有效动作。
# 因此保留 100 轮的有界上限，不压缩为短轮询；轮数耗尽仍抛 workflow_rounds_exhausted。
# 完整事件可能包含多段文本、判定、战斗等阶段，整体上限放宽到 100 轮
MAX_ITERATIONS = 100
# 同一分支允许连续命中的上限；再命中一次就在输入前失败，避免卡在画面上重复推进
MAX_BRANCH_REPEAT = 7
# 判定页（check_select）每轮交给 step.event_check_select 推进一次：未选人时点档次最高的罪人头像，
# 并在同一次调用里重新截图复查右下角，读到亮色 Commence 就紧接着点一次确认判定，
# 把「选人参与判定」和「点击右下角确认判定」合并到同一轮完成；只在这轮复查没读到时，
# 才由下一轮的 Commence 分支补点。这里不再自己按 Enter：
# Run 412 连续 4 轮停留在选人阶段就是选人后按 Enter 把已选中的罪人取消（Predicted 回到 ???）。
# 连续 MAX_CHECK_ROUNDS 轮仍在判定页（含判定动画与结算）就在输入前失败，不重复同样的输入
CHECK_CONFIRM_WAIT_SECONDS = 1.0
MAX_CHECK_ROUNDS = 8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _screen_items(ctx: RunContext) -> list[dict]:
    """对当前帧整屏 OCR 一次，返回全部条目；本轮后续的区域文字判断都从这一份结果里过滤。"""
    result = ctx.action("observe.ocr") or {}
    return list(result.get("items") or [])


def _text_in(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 结果里挑出中心落在该区域的条目，合并成规范化小写文本；不刷新截图。"""
    left = int(region["x"])
    top = int(region["y"])
    right = left + int(region["width"])
    bottom = top + int(region["height"])
    parts: list[str] = []
    for item in items:
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if left <= x <= right and top <= y <= bottom:
            text = str(item.get("text", ""))
            if text:
                parts.append(text)
    return _norm(" ".join(parts))


def _all_text(items: list[dict]) -> str:
    """整屏 OCR 结果的整体规范化文本，用于未知页面的 Server Error 兜底确认。"""
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _check_select(ctx: RunContext) -> bool:
    """成功率档次标签任意一档命中就认为处在判定选择阶段；不读 OCR 文案，避免文案/断行差异。"""
    return any(
        ctx.action("observe.match_asset", asset=asset, threshold=PASS_TIER_THRESHOLD)
        for asset in PASS_TIER_ASSETS
    )


def _advantage(items: list[dict]) -> bool:
    """右上角判定提示面板是否出现 Advantage；Disadvantage 含同样子串，先排除再判断。"""
    text = _text_in(items, ADVANTAGE_REGION)
    return ADVANTAGE_KEYWORD in text and DISADVANTAGE_KEYWORD not in text


def _skip_asset(ctx: RunContext, asset: str) -> bool:
    """右下角是否命中普通 SKIP 模板；只在带余量的右下角区域匹配，不读 OCR 文案。"""
    return bool(ctx.action("observe.match_asset", asset=asset, region=SKIP_MATCH_REGION))


def _grey_skip_asset(ctx: RunContext, asset: str) -> bool:
    """右下角是否命中灰化 SKIP 模板；只在带余量的右下角区域匹配，不读 OCR 文案。

    灰化模板比普通模板大（整颗按钮 240x95），与按钮区域同宽时没有横向余量，
    必须用放宽后的区域才能容忍按钮位置／动画偏移。
    """
    return bool(ctx.action("observe.match_asset", asset=asset, region=SKIP_MATCH_REGION))


def _page(
    ctx: RunContext,
    items: list[dict],
    entry: str,
    event_choices_asset: str,
    event_result_asset: str,
    event_skip_asset: str,
    event_grey_skip_asset: str,
    path_train_asset: str,
    gift_get_asset: str,
) -> str:
    """
    用本轮那一次整屏 OCR 的条目判断当前页面状态：choices、result、path、mirror、luxcavation、prepare、
    check_select、advantage、continue、narrative、grey_skip 或 unknown；入口决定事件结束后的已知业务页面。
    选项页、寻路页、战斗准备与战斗场景仍用模板；文字判据全部从同一份 OCR 条目里按区域过滤，
    不再对各区域分别裁切识别：
    入口为 exp／thread 时把 Luxcavation 关卡页当事件退出信号，入口为 mirror 时把寻路页（plan 下放的
    火车头模板）、奖励卡片页、楼层 Acquire E.G.O Gift 页与 E.G.O Gift GET! 到手弹窗当退出信号；
    识别到 clear selection 按钮时说明已进入战斗准备界面，直接算事件退出信号；
    识别到战斗场景素材（继续战斗页的 first_turn／select_line／win_rate 等）同样算事件退出；
    右下角按钮文字只过滤一次，只剩 Continue 用它；叙述页 SKIP 用 event/skip 与 event/grey_skip
    模板匹配（只搜带余量的右下角区域，让两个模板都能按实际位置滑动）；
    判定选择阶段用成功率档次标签模板判定（任意一档命中即算，不看面板文案）；
    结果页只看右上角 Result 标题模板，不再检测 Proceed／Continue 等按钮文案；
    SKIP 变灰点不动时由 event/grey_skip 模板单独识别，交给连按 Enter 的分支；
    判定提示面板（右上角 Advantage）按区域文字判定，并优先于叙述页，因为这块画面右下角也有 SKIP；
    不认识的画面交给未知分支，由上层按一次 Enter 尝试推进；
    判定页、结果页、判定提示面板与两种 SKIP 都优先于未知分支判断，因为它们右下角同样有 SKIP 文字。
    """
    if ctx.action("observe.match_asset", asset=event_choices_asset):
        return "choices"
    if entry == "mirror":
        # 镜牢入口：事件结束后回到寻路页，或直接进入奖励卡片页／楼层 Acquire E.G.O Gift 页，
        # 都作为事件退出信号交回 task.mirror 重新分派
        # 事件里拿到饰品时的 E.G.O Gift GET! 到手弹窗盖在下层页面之上，必须先判：
        # 命中即交回 task.mirror 的 gift_get 分支按 Enter 确认，避免在本层对被盖住的页面继续按 Enter
        if gift_get_asset and ctx.action(
            "observe.match_asset",
            asset=gift_get_asset,
            region=GIFT_GET_REGION,
            threshold=GIFT_GET_THRESHOLD,
        ):
            return "gift_get"
        if ctx.action("observe.match_asset", asset=path_train_asset):
            return "path"
        if any(ctx.action("observe.match_asset", asset=asset) for asset in MIRROR_EXIT_ASSETS):
            return "mirror"
        if REWARD_CARD_TITLE_KEYWORD in _text_in(items, REWARD_CARD_TITLE_REGION):
            return "mirror"
    else:
        # exp／thread 入口：事件结束后可能直接回到 Luxcavation 关卡页，识别到就交回上层
        if any(ctx.action("observe.match_asset", asset=asset) for asset in LUXCAVATION_EXIT_ASSETS):
            return "luxcavation"
    if ctx.action("observe.match_asset", asset=PREPARE_ASSET):
        return "prepare"
    if any(ctx.action("observe.match_asset", asset=asset) for asset in CONTINUE_BATTLE_ASSETS):
        return "battle"
    # 右下角按钮区的文字仍只过滤一次，但只剩 Continue 用它：
    # 叙述页 SKIP 不再读文字，改用 event/skip 模板匹配，避免灰化／低对比度帧 OCR 时有时无
    buttons = _text_in(items, BUTTON_REGION)
    if CONTINUE_KEYWORD in buttons:
        return "continue"
    if _check_select(ctx):
        return "check_select"
    if ctx.action("observe.match_asset", asset=event_result_asset):
        return "result"
    # 判定提示面板（右上角 Advantage）与叙述页共用右下角 SKIP 文字，而且此时 SKIP 不可用，
    # 必须在叙述页之前分流，否则会被当成叙述页反复尝试跳过而卡住不动
    if _advantage(items):
        return "advantage"
    if _skip_asset(ctx, event_skip_asset):
        return "narrative"
    # SKIP 可用时优先走叙述页点击分支；变灰点不动时才按灰化 SKIP 处理，由 Step 连按 Enter 推进
    if _grey_skip_asset(ctx, event_grey_skip_asset):
        return "grey_skip"
    return "unknown"


def _server_error(items: list[dict]) -> bool:
    """弹窗区域是否识别到 Server Error 文案，命中则交给恢复规则处理。"""
    return POPUP_KEYWORD in _text_in(items, POPUP_REGION)


def _server_error_all(items: list[dict]) -> bool:
    """整屏文本是否识别到 Server Error 文案，用于未知页面的兜底确认。"""
    return POPUP_KEYWORD in _all_text(items)


@sub_workflow
def execute(
    ctx: RunContext,
    *,
    entry: Literal["exp", "thread", "mirror"],
    event_choices_asset: str,
    event_result_asset: str,
    event_skip_asset: str,
    event_grey_skip_asset: str,
    path_train_asset: str,
    gift_get_asset: str,
) -> dict[str, str | bool]:
    """按入口分派事件推进：优先等待正常过渡再有界分派；同一分支连续超过 MAX_BRANCH_REPEAT 次命中或总预算耗尽时失败。

    entry 标明调用方（task.exp／task.thread／task.mirror），只影响事件结束后的已知业务页面：
    exp／thread 认 Luxcavation 关卡页，mirror 认寻路页、奖励卡片页、楼层 Acquire E.G.O Gift 页，
    以及事件里拿到饰品时弹出的 E.G.O Gift GET! 到手弹窗（plan 下放的 gift_get_asset，标题横幅模板匹配）：
    弹窗会盖住下层页面，命中即作为事件出口交回 task.mirror 的 gift_get 分支按 Enter 确认，本层不再输入；
    叙述页的 SKIP 变灰点不动时改由 step.event_grey_skip_enter 连续按 3 次 Enter（间隔 1 秒）推进；
    结果页（result）改由 step.event_result_proceed 先连续按 Enter 2 次（间隔 1 秒），
    再点击一次右下角固定坐标 (1140, 650)，最后再按一次 Enter，是否已离开结果页由下一轮重新截图验收；

    判定提示面板（advantage）是最后一个业务分支，只点击一次右下角固定坐标（step.event_advantage_proceed），
    推进仍由下一轮重新截图验收；
    各 event Step 都是一次局部尝试且不返回局部结果，所以调用后直接 continue，
    由下一轮重新截图分派，不读取也不记录 Step 的返回值；
    判定页（check_select）每轮只调用一次 step.event_check_select：未选人时由该步点档次最高的罪人头像，
    并在同一次调用内接着确认判定（右下角亮色 Commence），「选人」与「确认」合并成同一轮完成，
    只在确认复查没读到时才由下一轮的 Commence 分支补点；结果面板亮起时由该步先连续按 Enter 2 次（间隔 1 秒）、
    再点击一次右下角固定坐标推进结算；
    本层不再交替按 Enter，因为判定页的 Enter 会取消已选中的罪人（Run 412 的 4 轮空转）；
    每次输入后立即重新截一帧，让下一轮分派基于点击之后的画面；连续 MAX_CHECK_ROUNDS 轮仍在判定页
    就抛 workflow_check_stalled，不再在同一个画面上反复空转；
    退出按入口对应的已知业务页面（exp／thread 为 luxcavation，mirror 为 path／mirror／gift_get）与 prepare／battle 判定，
    Server Error 仍抛 ExecutionFailure。
    """
    if entry not in ENTRY_EXIT_ASSETS:
        raise ExecutionFailure(
            "workflow_invalid_entry",
            f"event 子流程不支持的入口：{entry}",
        )
    previous_branch = ""
    consecutive_hits = 0
    check_round = 0

    def hit(branch: str) -> None:
        """同一分支前七次可执行，第八次在输入前报错。"""
        nonlocal previous_branch, consecutive_hits
        consecutive_hits = consecutive_hits + 1 if branch == previous_branch else 1
        previous_branch = branch
        if consecutive_hits > MAX_BRANCH_REPEAT:
            raise ExecutionFailure(
                "workflow_branch_limit",
                f"连续第{MAX_BRANCH_REPEAT + 1}次命中分支：{branch}",
            )

    for round_index in range(1, MAX_ITERATIONS + 1):
        # 上一轮点击刚返回时画面常处在过渡中（例如 SKIP 已变灰、Continue 还没出现）；
        # 分派前先等待并重新截图，避免拿动作前的旧帧判定，把已经推进的画面重复计入同一分支。
        ctx.action("observe.wait", seconds=1.0)
        meta = ctx.action("observe.capture_screen")
        # 本轮只做一次整屏 OCR：后续路径文字、右下角 Continue／SKIP、Server Error 判断
        # 以及未知页面的兜底确认都从这一份条目里按区域过滤，不再对同一帧反复裁切识别
        items = _screen_items(ctx)
        # Server Error 先交恢复规则，再处理正常加载／联网过渡，最后才做业务分派（Run 637）：
        # 过渡帧上业务页仍然匹配，先分派业务就会对同一画面重复输入直到撞上分支上限。
        if _server_error(items):
            raise ExecutionFailure("server_error_popup")
        if ctx.call(
            "step.detect_normal_transition",
            width=meta["width"],
            height=meta["height"],
            ocr_texts=[str(item.get("text") or "") for item in items],
            ocr_centers=[[int(c[0]), int(c[1])] for c in (item.get("centerxy") or [0, 0] for item in items)],
        ):
            # 过渡轮不调用 hit(page)，避免把加载中的画面计入业务分支连续命中
            previous_branch = ""
            consecutive_hits = 0
            ctx.call("step.wait_normal_transition")
            continue
        page = _page(
            ctx,
            items,
            entry,
            event_choices_asset,
            event_result_asset,
            event_skip_asset,
            event_grey_skip_asset,
            path_train_asset,
            gift_get_asset,
        )
        if page in ("path", "mirror", "gift_get", "luxcavation", "prepare", "battle"):
            return {"completed": True, "reason": "事件已退出", "page": page, "entry": entry}
        if page == "unknown" and _server_error_all(items):
            raise ExecutionFailure("server_error_popup")
        # 判定页选人不可重复：选过罪人后本轮改为按一次 Enter 推进，画面仍未变化才回到选人，
        # 两个动作交替，避免在没刷新的画面上反复点同一个人像把选择又取消掉
        check_round = check_round + 1 if page == "check_select" else 0
        if check_round > MAX_CHECK_ROUNDS:
            ctx.log(
                f"判定页连续{MAX_CHECK_ROUNDS}轮没有推进，停止重复相同输入",
                level="warning",
                screenshot=True,
            )
            raise ExecutionFailure(
                "workflow_check_stalled",
                f"判定页连续{MAX_CHECK_ROUNDS}轮仍停在选人／确认阶段，点击后画面没有变化",
            )
        hit(page)
        if page == "choices":
            ctx.call("step.event_choice_pick")
        elif page == "result":
            # 结果页由该步复查 Result 标题后先连续按 Enter 2 次（间隔 1 秒），再点击一次右下角固定坐标，
            # 最后再按一次 Enter；
            # 是否已经离开结果页由下一轮重新截图验收，本层不重复输入
            ctx.call("step.event_result_proceed")
        elif page == "narrative":
            ctx.call("step.event_skip_narrative")
        elif page == "grey_skip":
            # 灰化 SKIP 点不动：由该步连续按 3 次 Enter（间隔 1 秒）推进文本，落点由下一轮重新截图验收
            ctx.call("step.event_grey_skip_enter")
        elif page == "check_select":
            # 判定页每轮只调用一次 step.event_check_select：未选人时点档次最高的罪人头像，
            # 并在同一次调用内重新截图复查右下角，读到亮色 Commence 就紧接着点一次确认判定，
            # 让「选人」与「确认判定」在同一轮完成；确认复查没读到时才由下一轮的 Commence 分支补点，
            # 结果面板亮起时点击一次右下角固定坐标推进结算
            ctx.call("step.event_check_select")
            ctx.action("observe.wait", seconds=CHECK_CONFIRM_WAIT_SECONDS)
            # 判定页每次输入后都重新截一帧：下一轮分派与验收必须基于点击之后的画面，
            # 不能沿用点击前那一帧，否则会在同一画面上重复计入同一分支形成空转循环
            ctx.action("observe.capture_screen")
        elif page == "continue":
            ctx.call("step.event_continue")
        elif page == "advantage":
            # 判定提示面板不按 Enter：由该步复查入口后点击一次右下角固定坐标，落点由下一轮重新截图验收
            ctx.call("step.event_advantage_proceed")
        else:
            ctx.log(
                f"第{round_index}轮未命中任何 event 分支（{page}），调用 step.event_press_enter 按一次 Enter 尝试推进",
                level="info",
            )
            ctx.call("step.event_press_enter")
        continue
    raise ExecutionFailure("workflow_rounds_exhausted", "总推进预算耗尽，未完成当前流程")
