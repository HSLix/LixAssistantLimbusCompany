"""Charge Enkephalin 弹窗里点一次「»」（最大可兑换数量），不做确认。"""
import re

from lalc import RunContext, step

POPUP_TITLE_REGION = {"x": 500, "y": 95, "width": 280, "height": 55}
POPUP_TITLE_KEYWORD = "chargeenkephalin"
# 数量选择器最右侧的「»」按钮（1280x720 实测 x792~842、y304~354）
MAX_ASSET = "main/stamina_charge_max"
AFTER_CLICK_SECONDS = 0.8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


@step
def execute(ctx: RunContext) -> dict[str, bool]:
    """复查弹窗与「»」按钮：都命中才点一次；返回 applied 表示是否点到了最大数量。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=POPUP_TITLE_REGION) or {}
    items = result.get("items") or []
    title = "".join(str(item.get("text", "")) for item in items)
    if POPUP_TITLE_KEYWORD not in _norm(title):
        ctx.log("Charge Enkephalin 弹窗不在当前画面，不点最大数量", level="warning", screenshot=True)
        return {"applied": False}

    matches = ctx.action("observe.match_asset", asset=MAX_ASSET) or []
    if not matches:
        ctx.log(
            f"未匹配到最大数量按钮 {MAX_ASSET}，不点击，交回上层重新观察",
            level="warning",
            screenshot=True,
        )
        return {"applied": False}
    if len(matches) > 1:
        ctx.log(f"{MAX_ASSET} 命中{len(matches)}个，存在歧义，按第一个命中点击", level="warning")

    ctx.log(f"点击最大数量按钮 @ {matches[0]['centerxy']}，等 {AFTER_CLICK_SECONDS} 秒后交回")
    ctx.action("control.click", centerxy=matches[0]["centerxy"])
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
    return {"applied": True}
