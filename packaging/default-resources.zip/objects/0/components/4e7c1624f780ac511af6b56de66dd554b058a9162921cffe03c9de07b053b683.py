"""结束当前镜牢探索：在入口页打开进度弹窗，点击 Halt Exploration 并确认回到未开始状态。"""
import re

from lalc import ExecutionFailure, RunContext, step

ENTRY_ASSET = "mirror/entry"
INFO_REGION = {"x": 890, "y": 130, "width": 320, "height": 55}
# 覆盖进度弹窗、Forfeit 确认弹窗和 Exploration Reward 弹窗（按钮在弹窗下缘）
POPUP_REGION = {"x": 210, "y": 90, "width": 850, "height": 510}
# 以下文本均为去掉空白和符号后的小写形式，便于和 OCR 结果比较
BEFORE_TEXT = "beforeentry"
HALT_TEXT = "haltexploration"
FORFEIT_TEXT = "forfeitpreviousexplorationprogress"
# 每次动作后的固定等待秒数；弹窗如何推进交给上层下一轮重新观察
AFTER_ACTION_SECONDS = 0.8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 把按钮读成 GiveUpRewards 这类连写形式。"""
    return re.sub(r"[^a-z0-9]", "", text.lower())


def _region_texts(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做 OCR，返回合并后的规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    return _norm(" ".join(str(item.get("text", "")) for item in items if item.get("text")))


def _popup_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回中央弹窗区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=POPUP_REGION) or {}
    return list(result.get("items") or [])


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _click_popup_button(
    ctx: RunContext,
    items: list[dict],
    label: str,
    fallback: tuple[int, int],
    allow_fallback: bool = True,
) -> bool:
    """在弹窗内点击文字（规范化后）包含 label 的最近按钮；未识别到且 allow_fallback 时才用固定坐标。"""
    wanted = _norm(label)
    candidates = [
        item for item in items if wanted and wanted in _norm(str(item.get("text", "")))
    ]
    if not candidates:
        if not allow_fallback:
            # 等待期间状态可能已变化，盲点固定坐标会误触其它弹窗的按钮
            ctx.log(f"当前帧未识别到 {label}，不做盲点，重新判断状态", level="warning")
            return False
        ctx.log(f"弹窗未识别到 {label} 文本，点击回退坐标 {fallback}", level="warning")
        ctx.action("control.click", x=fallback[0], y=fallback[1])
        return True

    def distance(item: dict) -> float:
        """候选按钮中心到回退坐标的距离。"""
        center = item.get("centerxy") or fallback
        return ((center[0] - fallback[0]) ** 2 + (center[1] - fallback[1]) ** 2) ** 0.5

    target = min(candidates, key=distance)
    ctx.log(f"弹窗点击 {label} @ {target.get('centerxy')}")
    ctx.action("control.click", centerxy=tuple(target.get("centerxy")))
    return True


@step
def execute(
    ctx: RunContext,
    *,
    entry_x: int = 1108,
    entry_y: int = 493,
    halt_x: int = 640,
    halt_y: int = 443,
    confirm_x: int = 780,
    confirm_y: int = 492,
) -> None:
    """
    结束镜牢探索的 halt 点击阶段：只做一次局部尝试。
    先截图复查入口：镜牢入口已回到 Before Entry、或既没有进度／Forfeit 弹窗也不在入口页时零输入返回。
    否则按当前画面只执行一个动作：
    Forfeit previous exploration progress 弹窗点一次 Confirm；
    进度弹窗点一次 Halt Exploration；两者都不在时点一次入口 Enter 打开进度弹窗。
    动作后最多固定等 0.8 秒就交回，弹窗推进与最终回到未开始状态由 sub_workflow.mirror_halt 重新观察。
    """
    ctx.action("observe.capture_screen")
    if BEFORE_TEXT in _region_texts(ctx, INFO_REGION):
        ctx.log("镜牢入口已是未开始状态，无需结束探索")
        return

    popup_text = _region_texts(ctx, POPUP_REGION)
    if FORFEIT_TEXT in popup_text:
        items = _popup_items(ctx)
        if FORFEIT_TEXT not in _items_text(items):
            # 等待期间弹窗可能已变化，盲点固定坐标会误触其它弹窗的按钮
            ctx.log("Forfeit 弹窗已变化，本轮不点击，交回上层重新观察", level="warning", screenshot=True)
            return
        _click_popup_button(ctx, items, "confirm", (confirm_x, confirm_y), allow_fallback=False)
        ctx.log(f"在 Forfeit previous exploration progress 弹窗点击 Confirm，等 {AFTER_ACTION_SECONDS} 秒")
        ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
        return

    if HALT_TEXT in popup_text:
        items = _popup_items(ctx)
        if HALT_TEXT not in _items_text(items):
            ctx.log("进度弹窗已变化，本轮不点击 Halt Exploration，交回上层重新观察", level="warning", screenshot=True)
            return
        _click_popup_button(ctx, items, HALT_TEXT, (halt_x, halt_y))
        ctx.log(f"已点击 Halt Exploration，等 {AFTER_ACTION_SECONDS} 秒后交回")
        ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
        return

    # 已有弹窗时入口按钮会被遮罩压暗，模板匹配不可靠，所以先判弹窗再校验入口页
    if not ctx.action("observe.match_asset", asset=ENTRY_ASSET):
        ctx.log("当前不在镜牢入口页，也没有进度弹窗，不执行动作", level="warning", screenshot=True)
        return
    ctx.action("control.click", x=entry_x, y=entry_y)
    ctx.log(f"点击入口 Enter 打开进度弹窗 ({entry_x}, {entry_y})，等 {AFTER_ACTION_SECONDS} 秒后交回")
    ctx.action("observe.wait", seconds=AFTER_ACTION_SECONDS)
