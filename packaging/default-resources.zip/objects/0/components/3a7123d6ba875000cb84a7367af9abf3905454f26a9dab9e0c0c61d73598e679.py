"""临时识别试验：只观察 Sell E.G.O Gift 弹窗的格子几何、左侧饰品名文字与流派图标识别，不做任何游戏输入。

第一版试验（Run 437）已确认：角标模板在 0.5 阈值下噪声过多（186 处），聚类不可用；
左侧大图右下角 37x42 流派图标模板与预览里约 20x22 的图标尺寸不一致，模板匹配 0 命中。
本版试验改为确认：① 格子价格数字的 OCR 位置（用于按固定网格推断有饰品的格子）；
② 左侧饰品名文字区能否稳定读出名字（需过滤纯数字价格）；③ 流派图标用 SIFT 多尺度匹配能否识别。
命中结果写进日志；本步不点击、不按键、不保存素材。
"""
from lalc import RunContext, step

# 弹窗右侧饰品格区域（1280x720 实测：格子在 x≈645 起、每列间距 100、每行间距约 137，
# 右侧滚动条在 x≈1105，因此右边界收到 1108，顶部避开 By Tier 下拉框）
GRID_REGION = {"x": 600, "y": 180, "width": 508, "height": 372}
# 饰品格四角的黄色斜纹角标：每格左上与右下各一个，用同一模板
CORNER_ASSET = "mirror/shop/ego_corner"
# 已保存饰品图鉴（按流派分目录）与流派图标
GIFT_GROUP = "mirror/gift"
KEYWORD_GROUP = "mirror/gift_keyword_icon"
# 选中饰品左侧大图的右下角：流派图标画在饰品框右下角，实测约 20x22（sink 约在 (232,282)~(252,302)）
KEYWORD_REGION = {"x": 190, "y": 250, "width": 95, "height": 75}
# 左侧名字区：选中饰品后名字横幅与说明文字，价格数字也在这里，需要过滤纯数字
NAME_REGION = {"x": 295, "y": 165, "width": 290, "height": 110}
# 现有流派图标素材（37x42，比预览里大一号，先试多尺度 SIFT）
KEYWORDS = (
    "bleed",
    "blunt",
    "burn",
    "charge",
    "keywordless",
    "pierce",
    "poise",
    "rupture",
    "sink",
    "slash",
    "tremor",
)
# 格区 + 价位：第三行格子的价格被列表底边裁切，OCR 只用来确认可见价格行的位置
PRICE_BOTTOM = 440
# 同一格两个角标的横纵距离都约 52 像素，相邻格子横向 100、纵向 137：
# 横纵都不超过 60 像素的角标算同一格，相邻格子不会被合并
CELL_MERGE = 60
# 聚类出的格子框至少要有这么大，否则说明该格只识别到一个角标，框不完整
MIN_CELL_WIDTH = 60
MIN_CELL_HEIGHT = 60


def _cells(hits: list) -> list[tuple[int, int, int, int]]:
    """把角标命中按横纵距离合并成格子框：返回每个格子的 (x, y, width, height) 包围框，按从上到下、从左到右排序。"""
    clusters: list[list[int]] = []
    for hit in hits:
        x = int(hit.get("x", 0))
        y = int(hit.get("y", 0))
        width = int(hit.get("width", 0))
        height = int(hit.get("height", 0))
        for cluster in clusters:
            if (
                x <= cluster[0] + cluster[2] + CELL_MERGE
                and cluster[0] <= x + width + CELL_MERGE
                and y <= cluster[1] + cluster[3] + CELL_MERGE
                and cluster[1] <= y + height + CELL_MERGE
            ):
                left = min(cluster[0], x)
                top = min(cluster[1], y)
                right = max(cluster[0] + cluster[2], x + width)
                bottom = max(cluster[1] + cluster[3], y + height)
                cluster[:] = [left, top, right - left, bottom - top]
                break
        else:
            clusters.append([x, y, width, height])
    clusters.sort(key=lambda box: (box[1], box[0]))
    return [(box[0], box[1], box[2], box[3]) for box in clusters]


@step
def execute(ctx: RunContext, *, threshold: float = 0.5, nms_iou: float = 0.3) -> dict[str, int]:
    """
    重新截图后只做观察：角标模板在弹窗右侧格区的命中、格子聚类结果、已保存饰品图鉴命中，
    以及左侧大图右下角的流派图标命中（三种模板各自的最低分与中心坐标）。"""
    if not 0.0 <= threshold <= 1.0:
        raise ValueError("threshold 必须在 0~1 之间")
    ctx.action("observe.capture_screen")
    corners = ctx.action(
        "observe.match_asset",
        asset=CORNER_ASSET,
        region=GRID_REGION,
        threshold=threshold,
        nms=True,
        nms_iou_threshold=nms_iou,
    ) or []
    corner_detail = "; ".join(
        f"({hit.get('x')},{hit.get('y')},{hit.get('width')}x{hit.get('height')})"
        f"score={round(float(hit.get('score', 0.0)), 3)}"
        for hit in corners[:12]
    )
    ctx.log(
        f"角标 {CORNER_ASSET} 在格区命中 {len(corners)} 处（阈值 {threshold}、NMS {nms_iou}，只列前 12）："
        f"{corner_detail}",
        level="info",
        screenshot=True,
    )

    cells = _cells(corners)
    cell_detail = "; ".join(f"({box[0]},{box[1]},{box[2]}x{box[3]})" for box in cells)
    small = [box for box in cells if box[2] < MIN_CELL_WIDTH or box[3] < MIN_CELL_HEIGHT]
    ctx.log(
        f"聚类得到 {len(cells)} 个格子（其中 {len(small)} 个框不足 {MIN_CELL_WIDTH}x{MIN_CELL_HEIGHT}）："
        f"{cell_detail}"
    )

    gifts = ctx.action(
        "observe.match_asset_group", group=GIFT_GROUP, region=GRID_REGION, threshold=0.55
    ) or []
    gift_detail = "; ".join(
        f"{hit.get('logical_name')}@{tuple(hit.get('centerxy') or ())}"
        f"score={round(float(hit.get('score', 0.0)), 3)}"
        for hit in gifts[:10]
    )
    ctx.log(f"图鉴组 {GIFT_GROUP} 在格区命中 {len(gifts)} 处：{gift_detail}")

    price_region = dict(GRID_REGION)
    price_region["height"] = PRICE_BOTTOM
    result = ctx.action("observe.ocr", region=price_region) or {}
    items = result.get("items") or []
    numeric = [
        (int(item["centerxy"][0]), int(item["centerxy"][1]), str(item.get("text", "")).strip())
        for item in items
        if item.get("centerxy") and any(char.isdigit() for char in str(item.get("text", "")))
    ]
    numeric.sort(key=lambda entry: (entry[1], entry[0]))
    ctx.log(
        f"格区+价位 OCR 读出 {len(items)} 条文字、其中 {len(numeric)} 条含数字："
        + "; ".join(f"{text}@{x},{y}" for x, y, text in numeric[:40]),
        level="info",
    )

    result = ctx.action("observe.ocr", region=NAME_REGION) or {}
    items = result.get("items") or []
    ctx.log(
        f"左侧名字区 OCR 读出 {len(items)} 条："
        + "; ".join(
            f"{str(item.get('text', '')).strip()}"
            f"@{int(item['centerxy'][0])},{int(item['centerxy'][1])}"
            f"score={round(float(item.get('score') or 0.0), 3)}"
            for item in items
            if item.get("centerxy")
        ),
        level="info",
    )

    found = 0
    for keyword in KEYWORDS:
        asset = f"{KEYWORD_GROUP}/{keyword}"
        templ = ctx.action(
            "observe.match_asset", asset=asset, region=KEYWORD_REGION, threshold=0.55
        ) or []
        best = round(float(templ[0]["score"]), 3) if templ else 0.0
        features = ctx.action(
            "observe.match_feature",
            asset=asset,
            region=KEYWORD_REGION,
            min_inliers=4,
            min_scale=0.3,
            max_scale=1.2,
        ) or []
        detail = ""
        if features:
            detail = "（" + "; ".join(
                f"@{tuple(hit.get('centerxy') or ())}inliers={hit.get('inliers')}"
                f"scale={round(float(hit.get('max_scale') or 0.0), 2)}"
                f"ratio={round(float(hit.get('inlier_ratio') or 0.0), 2)}"
                for hit in features[:3]
            ) + "）"
        ctx.log(
            f"流派 {keyword}：模板（阈值 0.55）命中 {len(templ)} 处、最高 {best}；"
            f"SIFT 命中 {len(features)} 处{detail}",
            level="info" if (templ or features) else "debug",
        )
        if templ or features:
            found += 1
    return {"corners": len(corners), "cells": len(cells), "numbers": len(numeric), "keyword_hits": found}
