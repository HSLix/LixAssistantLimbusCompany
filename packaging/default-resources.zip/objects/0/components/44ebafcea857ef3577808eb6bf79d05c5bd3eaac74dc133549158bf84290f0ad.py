"""临时识别试验：只观察 event/skip 模板在当前帧的匹配情况，不做任何游戏输入。"""
from lalc import RunContext, step

SKIP_ASSET = "event/skip"
SKIP_REGION = {"x": 1020, "y": 590, "width": 240, "height": 120}


@step
def execute(ctx: RunContext) -> dict[str, int]:
    """重新截图后分别用整屏和右下角区域匹配 event/skip，只记录结果供评估，不点击不按键。"""
    ctx.action("observe.capture_screen")
    full = ctx.action("observe.match_asset", asset=SKIP_ASSET) or []
    region = ctx.action("observe.match_asset", asset=SKIP_ASSET, region=SKIP_REGION) or []
    detail = "; ".join(
        f"{m.get('centerxy')} score={round(float(m.get('score', 0.0)), 4)}" for m in region
    )
    ctx.log(
        f"event/skip 整屏命中 {len(full)} 处，右下角区域命中 {len(region)} 处 {detail}",
        level="info",
        screenshot=True,
    )
    return {"full": len(full), "region": len(region)}
