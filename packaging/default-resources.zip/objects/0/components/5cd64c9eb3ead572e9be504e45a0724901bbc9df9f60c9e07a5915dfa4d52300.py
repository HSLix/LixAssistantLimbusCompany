"""镜牢饰品选择页：在左侧流派列表中点击配置的流派，必要时从顶部开始逐屏向下拖动列表。"""
import re

from lalc import ExecutionFailure, RunContext, step

GIFT_ASSET = "mirror/gift_select"
# 左侧流派卡片列表区域（1280x720 客户区），含最下面一行刚露出的卡片标题
LEFT_REGION = {"x": 130, "y": 140, "width": 590, "height": 440}
# 右侧 Selected E.G.O Gift 标题下方区域：点击流派后这里会显示当前流派的饰品
RIGHT_REGION = {"x": 770, "y": 220, "width": 470, "height": 290}
# 底部按钮区域：Selected E.G.O Gift 模板失效时用 Refuse Gift 文字兜底识别本页
BOTTOM_REGION = {"x": 760, "y": 550, "width": 480, "height": 80}
# 流派列表只在卡片间隙拖动才会滚动（下箭头为位置指示，点击不可靠）
DRAG_DOWN = ((288, 520), (288, 300))
DRAG_UP = ((288, 300), (288, 520))
# 本次饰品选择第一次调用时先把列表拉回顶部，之后只向下、不回首
BACK_TO_TOP_PLAN = ("up", "up", "up")
# 之后每次调用只向下走一屏；是否命中流派由 sub_workflow.mirror_gift_select 下一轮重新观察
SCROLL_PLAN = ("down", "down")
# 本次饰品选择的扫描进度记录在 RunState.settings 的 mirror.runtime 里，
# 由 sub_workflow.mirror_gift_select 在每次进入饰品选择时复位
MIRROR_RUNTIME_KEY = "mirror.runtime"
SCAN_STARTED_KEY = "gift_scan_started"
SCAN_EXHAUSTED_KEY = "gift_scan_exhausted"
# 点击流派后的固定等待秒数
AFTER_CLICK_SECONDS = 0.6
# 每次拖动后的固定等待：等惯性停稳（属于同一组固定动作）
DRAG_SETTLE_SECONDS = 0.8


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或连写影响流派标题匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _items_text(items: list[dict]) -> str:
    """把 OCR 条目合并成规范化小写文本。"""
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _gift_page(ctx: RunContext) -> bool:
    """判断是否还在饰品选择页：优先用 Selected E.G.O Gift 模板，其次用 Refuse Gift 文字。"""
    if ctx.action("observe.match_asset", asset=GIFT_ASSET):
        return True
    result = ctx.action("observe.ocr", region=BOTTOM_REGION) or {}
    return "refusegift" in _items_text(list(result.get("items") or []))


def _left_items(ctx: RunContext) -> list[dict]:
    """刷新截图并返回左侧流派列表区域的 OCR 条目。"""
    ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr", region=LEFT_REGION) or {}
    return list(result.get("items") or [])


def _keyword_hits(items: list[dict], keyword: str) -> list[dict]:
    """在 OCR 条目中找出文本（去符号小写后）等于 keyword 的流派标题，按分数从高到低返回。"""
    wanted = _norm(keyword)
    hits = [item for item in items if wanted and _norm(item.get("text", "")) == wanted]
    hits.sort(key=lambda item: float(item.get("score") or 0.0), reverse=True)
    return hits


def _drag_scroll(ctx: RunContext, direction: str) -> None:
    """在两张卡片之间的空隙拖动左侧流派列表，direction 为 down／up。"""
    start, end = DRAG_DOWN if direction == "down" else DRAG_UP
    ctx.log(f"流派不在可见区域，在流派列表间隙从 {start} 拖动到 {end} 向{'下' if direction == 'down' else '上'}滚动")
    ctx.action(
        "control.drag",
        x=start[0],
        y=start[1],
        end_x=end[0],
        end_y=end[1],
        seconds=0.8,
    )
    ctx.action("observe.wait", seconds=DRAG_SETTLE_SECONDS)


def _scan_state(ctx: RunContext) -> tuple[bool, bool]:
    """读取本次饰品选择的扫描进度：(是否已从顶部起步, 是否已确认列表到底)。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        return False, False
    runtime = settings.get(MIRROR_RUNTIME_KEY)
    if not isinstance(runtime, dict):
        return False, False
    return bool(runtime.get(SCAN_STARTED_KEY)), bool(runtime.get(SCAN_EXHAUSTED_KEY))


def _mark_scan(ctx: RunContext, *, started: bool, exhausted: bool) -> None:
    """把扫描进度写回 RunState.settings，供后续调用与 sub_workflow.mirror_gift_select 读取。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log("RunState.settings 不可写，无法记录流派列表扫描进度", level="warning")
        return
    runtime = settings.get(MIRROR_RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    runtime[SCAN_STARTED_KEY] = started
    runtime[SCAN_EXHAUSTED_KEY] = exhausted
    settings[MIRROR_RUNTIME_KEY] = runtime


@step
def execute(ctx: RunContext, *, keyword: str) -> None:
    """
    在镜牢饰品选择页选一次流派，只做一次局部尝试：
    - 不在饰品选择页（Selected E.G.O Gift 模板与 Refuse Gift 文字都不成立）时零输入返回；
    - 当前屏左侧列表命中标题等于 keyword 的流派时点一次（多处命中取分数最高的一处），
      等固定 0.6 秒后交回；
    - 当前屏没有命中且本次尚未从顶部起步时，按 BACK_TO_TOP_PLAN 把列表拉回顶部后交回；
    - 已从顶部起步时只按 SCROLL_PLAN 向下走一屏，绝不回首；向下拖动后列表内容没有变化
      则判定到底，写 SCAN_EXHAUSTED 后交回。
    流派是否已选中、右侧是否显示该流派饰品由 sub_workflow.mirror_gift_select 下一轮重新观察，
    本步不轮询右侧内容，也不再重试点击。
    """
    wanted = _norm(keyword)
    if not wanted:
        ctx.log("未提供饰品流派关键字，无法选择流派", level="warning")
        return

    ctx.action("observe.capture_screen")
    if not _gift_page(ctx):
        ctx.log("当前不在镜牢饰品选择页面，不选择流派", level="warning", screenshot=True)
        return

    items = _left_items(ctx)
    hits = _keyword_hits(items, wanted)
    if not hits:
        started, exhausted = _scan_state(ctx)
        if exhausted:
            ctx.log(
                "本次饰品选择已确认流派列表滚到最底部仍未找到目标流派，不再拖动",
                level="warning",
                screenshot=True,
            )
            return
        if not started:
            ctx.log(
                f"当前屏左侧流派列表没有 {keyword}，先把列表拉回顶部 {BACK_TO_TOP_PLAN}，"
                "之后只向下逐屏扫描，不回首",
                screenshot=True,
            )
            for direction in BACK_TO_TOP_PLAN:
                _drag_scroll(ctx, direction)
            _mark_scan(ctx, started=True, exhausted=False)
            return
        before = _items_text(items)
        ctx.log(
            f"当前屏左侧流派列表没有 {keyword}，只向下拖动一屏 {SCROLL_PLAN}",
            screenshot=True,
        )
        for direction in SCROLL_PLAN:
            _drag_scroll(ctx, direction)
        after = _items_text(_left_items(ctx))
        if after == before:
            _mark_scan(ctx, started=True, exhausted=True)
            ctx.log(
                "向下拖动后流派列表内容没有变化，判定已到列表底部，本次不再继续拖动",
                level="warning",
                screenshot=True,
            )
        return

    if len(hits) > 1:
        ctx.log(
            f"流派 {keyword} 命中 {len(hits)} 处，取分数最高的一处："
            f"{[hit.get('centerxy') for hit in hits]}",
            level="warning",
        )
    target = hits[0]
    center = (int(target.get("centerxy")[0]), int(target.get("centerxy")[1]))
    ctx.log(f"点击流派 {keyword} @ {center}")
    ctx.action("control.click", centerxy=center)
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)
