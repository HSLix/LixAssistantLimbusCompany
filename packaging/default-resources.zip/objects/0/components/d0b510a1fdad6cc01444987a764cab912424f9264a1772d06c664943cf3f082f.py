"""战斗准备确认：队伍与出战顺序已就绪后按 Enter 提交出战，不等待加载完成。"""
from lalc import RunContext, step

# 仍在战斗准备页的判据：右下角 Clear Selection 与右侧任一页签同时成立
CLEAR_SELECTION_ASSET = "prepare_team/clear_selection"
PREPARE_TAB_ASSETS = (
    "prepare_team/all_identities",
    "prepare_team/all_ego",
    "prepare_team/facades",
)
# 按 Enter 后固定等 2 秒让画面响应；是否进入加载或战斗由上层下一轮重新截图判断
ENTER_WAIT_SECONDS = 2.0











def _in_prepare(ctx: RunContext) -> bool:
    """重新截图，判断是否仍停在战斗准备页：右下角 Clear Selection 与右侧任一页签同时成立。"""
    ctx.action("observe.capture_screen")
    if not ctx.action("observe.match_asset", asset=CLEAR_SELECTION_ASSET):
        return False
    return any(ctx.action("observe.match_asset", asset=asset) for asset in PREPARE_TAB_ASSETS)












@step
def execute(ctx: RunContext) -> None:
    """重新观察，只在战斗准备页按一次 Enter 后交回；是否进入加载或战斗由上层重新截图判断。"""
    if not _in_prepare(ctx):
        ctx.log("当前不在战斗准备页，本 Step 不按键，交回上层", level="warning")
        return
    ctx.log("战斗准备页提交一次 Enter")
    ctx.action("control.key_press", key="enter")
    ctx.action("observe.wait", seconds=ENTER_WAIT_SECONDS)
