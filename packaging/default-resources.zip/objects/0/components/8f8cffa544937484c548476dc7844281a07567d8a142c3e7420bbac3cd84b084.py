"""镜牢队伍准备页点一次 Confirm，再关闭队伍等级提示，落点由上层重新观察。"""
import re

from lalc import RunContext, step

TEAM_ASSET = "mirror/team_select"
STAR_ASSET = "mirror/star"
# 点击 Confirm 后的固定等待秒数；只留给页面切换，不用来判定是否已到 star 页
AFTER_CLICK_SECONDS = 1.0
# 确认队伍后屏幕中间出现的队伍等级提示：Current Avg（当前平均等级）／Recommend Level（推荐等级）。
# 区域按 1280x720 基准设计，判定时按实际客户区缩放；只认屏幕中间，避免把其他位置的字当成提示
MIDDLE_REGION = {"x": 320, "y": 160, "width": 640, "height": 400}
# 提示语按规范化文本匹配：Current Avg 允许被 OCR 断成两行；
# Recommend Level 用 recommend + level 两个词判定，兼容游戏里的 Recommended Level 写法
CURRENT_AVG_KEYWORD = "currentavg"
RECOMMEND_KEYWORD = "recommend"
LEVEL_KEYWORD = "level"


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _scaled(meta: dict, region: dict[str, int]) -> dict[str, int]:
    """把 1280x720 基准坐标的观察区域按当前客户区缩放，避免换分辨率后区域错位。"""
    width, height = int(meta["width"]), int(meta["height"])
    return {
        "x": region["x"] * width // 1280,
        "y": region["y"] * height // 720,
        "width": max(1, region["width"] * width // 1280),
        "height": max(1, region["height"] * height // 720),
    }


def _middle_text(items: list[dict], region: dict[str, int]) -> str:
    """从整屏 OCR 条目里挑出中心点落在屏幕中间区域的文字，合并成规范化小写文本。"""
    left = int(region["x"])
    top = int(region["y"])
    right = left + int(region["width"])
    bottom = top + int(region["height"])
    parts: list[str] = []
    for item in items:
        center = item.get("centerxy") or (0, 0)
        x, y = int(center[0]), int(center[1])
        if left <= x <= right and top <= y <= bottom:
            text = str(item.get("text", ""))
            if text:
                parts.append(text)
    return _norm(" ".join(parts))


@step
def execute(ctx: RunContext, *, confirm_x: int = 1146, confirm_y: int = 587) -> None:
    """
    先截图复查入口：已在 star 页面时零输入返回；不在镜牢队伍准备页时也不点击；
    确在队伍准备页才点击一次固定坐标的 Confirm，等固定 1 秒后重新截图做一次全屏 OCR：
    屏幕中间读到 Current Avg／Recommend Level（确认队伍后的等级提示）就按一次 Enter 关闭提示后交回；
    没有读到就零输入交回。提示是否消失、是否已进入 star 页由上层下一轮重新观察，本步不轮询。
    """
    ctx.action("observe.capture_screen")
    if ctx.action("observe.match_asset", asset=STAR_ASSET):
        ctx.log("已在 star 页面，无需再次 Confirm")
        return
    if not ctx.action("observe.match_asset", asset=TEAM_ASSET):
        ctx.log("当前不是镜牢队伍准备页，不点击 Confirm", level="warning", screenshot=True)
        return

    ctx.log(f"点击镜牢队伍准备页 Confirm ({confirm_x}, {confirm_y})，等 {AFTER_CLICK_SECONDS} 秒后复查队伍等级提示")
    ctx.action("control.click", x=confirm_x, y=confirm_y)
    ctx.action("observe.wait", seconds=AFTER_CLICK_SECONDS)

    # 提示随页面切换出现：observe.ocr 只读当前帧，必须先重新截图；全屏识别一次后按中心点筛中间区域
    meta = ctx.action("observe.capture_screen")
    result = ctx.action("observe.ocr") or {}
    items = list(result.get("items") or [])
    middle = _middle_text(items, _scaled(meta, MIDDLE_REGION))
    current_avg = CURRENT_AVG_KEYWORD in middle
    recommend_level = RECOMMEND_KEYWORD in middle and LEVEL_KEYWORD in middle
    if not (current_avg or recommend_level):
        ctx.log("确认队伍后屏幕中间未读到 Current Avg／Recommend Level，不按 Enter", screenshot=True)
        return
    keyword = "Current Avg" if current_avg else "Recommend Level"
    ctx.log(f"确认队伍后屏幕中间读到 {keyword}，按一次 Enter 关闭队伍等级提示后交回")
    ctx.action("control.key_press", key="enter")
