"""按 Dashboard 次数执行 EXP、Thread 和镜牢，保留每次任务的完整结果。"""
from lalc import RunContext, automation_plan

SUPPORTED_TASK_IDS = ["exp", "thread", "mirror"]

# 各 Task／子流程共用的界面标识：只在这里定义一份，作为业务输入下放给 task，
# 避免 task.exp／task.thread／task.mirror 各自维护一份素材表而逐渐不一致。
# 战斗界面（局内）标识：任一命中都说明当前画面在战斗里，进入战斗子流程；
# 必须包含 win_rate_selected：胜率选中后 battle/win_rate 可能不再命中，只有该状态稳定可辨。
BATTLE_ASSETS = [
    "battle/first_turn",
    "battle/select_line",
    "battle/win_rate",
    "battle/win_rate_selected",
    "battle/damage",
    "battle/pause",
    "battle/setting",
]
# 事件节点标识：选项页／结果页标题模板；叙述页 SKIP 按钮分普通与灰化两种模板
EVENT_CHOICES_ASSET = "event/choices"
EVENT_RESULT_ASSET = "event/result"
EVENT_SKIP_ASSET = "event/skip"
EVENT_GREY_SKIP_ASSET = "event/grey_skip"
# 镜牢事件里拿到饰品时的 E.G.O Gift GET! 到手弹窗（盖在下层页面上）：标题横幅模板，
# 作为 mirror 入口的事件出口交给 task.mirror 的 gift_get 分支按 Enter 确认
GIFT_GET_ASSET = "mirror/ego_gift_get"
# 镜牢寻路页标识：火车头模板 + 右上角三个按钮（task.mirror 与战斗子流程共用同一份）
PATH_TRAIN_ASSET = "mirror/train_head"
PATH_ICON_ASSETS = ["mirror/path/legend", "mirror/path/sinners", "mirror/path/active_effects"]

# 镜牢「本场」运行时记录在 RunState.settings 中的位置：这些值只对同一场镜牢有效，
# 每场开始前必须复位（键名与 task.mirror 的同名常量一致）
MIRROR_RUNTIME_KEY = "mirror.runtime"
MIRROR_LAST_RESULT_KEY = "last_result"
MIRROR_RESULT_UNKNOWN = "unknown"
# exploration_complete 是 task.mirror 首步 step.mirror_finished 的收尾依据：上一场领奖完成后它仍是 True，
# 若不复位，下一场的第一次判定就会在主界面直接判成已收尾（Run 348 的现象：index 2 起每场约 3 秒返回 finished）
MIRROR_EXPLORATION_COMPLETE_KEY = "exploration_complete"
# 星光点选与出战顺序记录同样只在本场内有效，一并按每场边界复位，避免恢复重入后沿用上一场的记录
MIRROR_STAR_CONFIGURED_KEY = "star_configured"
MIRROR_TEAM_SELECTED_KEY = "battle_team_selected"
# 主题包页难度箭头「每场最多点一次」的记录（键名与 step.mirror_theme_difficulty 的同名常量一致）
MIRROR_DIFFICULTY_SWITCHED_KEY = "difficulty_switched"
# 技能替换「本场已用完」的罪人（键名与 step.mirror_shop_skill_replace 的同名常量一致）：
# 初始 1 技能 3 个、2 技能 2 个、3 技能 1 个，技能替换只做 1→2、1→3 或 2→3，
# 源技能份数换完后这个罪人本场就再换不动了；新一场镜牢开始必须清空
MIRROR_SKILL_EXHAUSTED_KEY = "shop_skill_exhausted"
# 每场镜牢开始前要复位的本场记录；楼层级记录（shop_visited／shop_skill_handled）
# 由 step.mirror_refresh_shop_state 在主题包选择成功时刷新，不在这里复位
MIRROR_RUN_SCOPED_STATE = {
    MIRROR_LAST_RESULT_KEY: MIRROR_RESULT_UNKNOWN,
    MIRROR_EXPLORATION_COMPLETE_KEY: False,
    MIRROR_STAR_CONFIGURED_KEY: False,
    MIRROR_TEAM_SELECTED_KEY: False,
    MIRROR_DIFFICULTY_SWITCHED_KEY: False,
    MIRROR_SKILL_EXHAUSTED_KEY: [],
}


def _reset_mirror_run_state(ctx: RunContext, label: str) -> None:
    """
    进入 task.mirror 前复位本场镜牢的运行时记录，让每一场都从干净状态开始。
    复位点放在 plan 的每场边界而不是 task.mirror 入口：task.mirror 内部失败重入时仍要保留本场已有进度
    （例如已经领奖完成），避免重复领奖或重复进入；而新一场开始时这些记录一律无效。
    """
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        ctx.log(f"{label} 前无法复位镜牢本场运行时记录：RunState.settings 不可写", level="warning")
        return
    runtime = settings.get(MIRROR_RUNTIME_KEY)
    if not isinstance(runtime, dict):
        runtime = {}
    # 列表值（技能替换用完的罪人）每次取一份新副本：直接 update 常量字典会把同一个 list 共享给
    # RunState，后续在 Step 里追加会污染模块级常量
    reset = {
        key: list(value) if isinstance(value, list) else value
        for key, value in MIRROR_RUN_SCOPED_STATE.items()
    }
    previous = {key: runtime.get(key) for key in reset}
    runtime.update(reset)
    settings[MIRROR_RUNTIME_KEY] = runtime
    ctx.log(f"{label} 前复位镜牢本场运行时记录 {reset}（原 {previous}）")


@automation_plan
def execute(ctx: RunContext) -> None:
    """普通任务失败停止该任务的剩余重复；控制信号及环境异常由执行器传播。"""
    ctx.log(
        f"plan 开始：task_repetitions={ctx.run_state.task_repetitions} settings={ctx.run_state.settings}",
        level="debug",
    )
    # 开始前先确认游戏已离开标题界面；停在标题界面时本 Step 会按恢复规则的思路点击屏幕中间进入游戏
    ready = ctx.call("task.check_game_ready")
    ctx.log(f"开始前检查游戏是否就绪：{ready}")
    # ctx.call 返回 Task 信封 {status, output}，完成标志在 output 里，不是信封顶层
    ready_output = ready.get("output") or {}
    if ready.get("status") != "success" or ready_output.get("completed") != "true":
        ctx.log(
            f"游戏就绪检查未确认：status={ready.get('status')} output={ready_output}，按当前画面继续调度",
            level="warning",
        )

    repetitions = ctx.run_state.task_repetitions or {}
    # 本次 Run 里 exp/thread 是否至少完成过一次 Task：只有跑过前序任务，现场才可能停在 Luxcavation 页面
    prior_task_done = False
    total = int(repetitions.get("exp", 0) or 0)
    for index in range(1, total + 1):
        task = ctx.call(
            "task.exp",
            battle_assets=BATTLE_ASSETS,
            path_train_asset=PATH_TRAIN_ASSET,
            event_choices_asset=EVENT_CHOICES_ASSET,
            event_result_asset=EVENT_RESULT_ASSET,
            event_skip_asset=EVENT_SKIP_ASSET,
            event_grey_skip_asset=EVENT_GREY_SKIP_ASSET,
            gift_get_asset=GIFT_GET_ASSET,
        )
        status = task["status"]
        ctx.log(f"task.exp {index}/{total} status={status} result={task}")
        if status == "failure":
            ctx.log(f"task.exp {index}/{total} failure_code={task.get('failure_code')} failure_message={task.get('failure_message')}", level="error")
            break
        prior_task_done = True
        output = task.get("output") or {}
        ctx.log(f"task.exp {index}/{total} status={status} output={output}")
        if output.get("result") == "defeat":
            ctx.log("task.exp 战败，跳过该任务的剩余重复", level="warning")
            break
    total = int(repetitions.get("thread", 0) or 0)
    for index in range(1, total + 1):
        task = ctx.call(
            "task.thread",
            battle_assets=BATTLE_ASSETS,
            path_train_asset=PATH_TRAIN_ASSET,
            event_choices_asset=EVENT_CHOICES_ASSET,
            event_result_asset=EVENT_RESULT_ASSET,
            event_skip_asset=EVENT_SKIP_ASSET,
            event_grey_skip_asset=EVENT_GREY_SKIP_ASSET,
            gift_get_asset=GIFT_GET_ASSET,
        )
        status = task["status"]
        ctx.log(f"task.thread {index}/{total} status={status} result={task}")
        if status == "failure":
            ctx.log(f"task.thread {index}/{total} failure_code={task.get('failure_code')} failure_message={task.get('failure_message')}", level="error")
            break
        prior_task_done = True
        output = task.get("output") or {}
        ctx.log(f"task.thread {index}/{total} status={status} output={output}")
        if output.get("result") == "defeat":
            ctx.log("task.thread 战败，跳过该任务的剩余重复", level="warning")
            break
    total = int(repetitions.get("mirror", 0) or 0)
    # 只有本次 Run 的 exp/thread 至少完成过一次，前序任务才可能停在 Luxcavation 页面；
    # 否则不需要退出该页面的检测，镜牢直接从当前页面开始
    if total > 0 and prior_task_done:
        back = ctx.call("task.leave_luxcavation")
        ctx.log(f"进入 task.mirror 前退出 Luxcavation 页面：{back}")
        # ctx.call 返回 Task 信封 {status, output}，完成标志在 output 里，不是信封顶层
        back_output = back.get("output") or {}
        if back.get("status") != "success" or back_output.get("completed") != "true":
            ctx.log(
                f"未确认已离开 Luxcavation 页面：status={back.get('status')} output={back_output}",
                level="warning",
            )
    elif total > 0:
        ctx.log("mirror 有执行次数，但本次 Run 的 exp/thread 一次都没有完成过，跳过退出 Luxcavation 的检测")
    if total > 0:
        # 镜牢队伍顺序由 task.mirror 自己在进场时读取（页面 team_order 资源的第一支，就是最新的队伍配置），这里不再预先换算下标
        ctx.log(f"本次 Run 将执行 {total} 场镜牢，队伍顺序由 task.mirror 每场读取")
    for index in range(1, total + 1):
        _reset_mirror_run_state(ctx, f"task.mirror {index}/{total}")
        task = ctx.call(
            "task.mirror",
            battle_assets=BATTLE_ASSETS,
            path_train_asset=PATH_TRAIN_ASSET,
            path_icon_assets=PATH_ICON_ASSETS,
            event_choices_asset=EVENT_CHOICES_ASSET,
            event_result_asset=EVENT_RESULT_ASSET,
            event_skip_asset=EVENT_SKIP_ASSET,
            event_grey_skip_asset=EVENT_GREY_SKIP_ASSET,
            gift_get_asset=GIFT_GET_ASSET,
        )
        status = task["status"]
        ctx.log(f"task.mirror {index}/{total} status={status} result={task}")
        if status == "failure":
            ctx.log(f"task.mirror {index}/{total} failure_code={task.get('failure_code')} failure_message={task.get('failure_message')}", level="error")
            break
        output = task.get("output") or {}
        ctx.log(f"task.mirror {index}/{total} status={status} output={output}")
        if output.get("result") == "defeat":
            ctx.log("task.mirror 战败，跳过该任务的剩余重复", level="warning")
            break
