"""事件判定结算页：右下角出现 Continue 时尝试点击一次。"""
import re

from lalc import RunContext, step

# 右下角 Continue 按钮区域与固定点击坐标（1280x720 客户区）
CONTINUE_REGION = {"x": 1020, "y": 590, "width": 240, "height": 120}
CONTINUE_KEYWORD = "continue"
CONTINUE_POINT = (1131, 647)


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _continue_text(ctx: RunContext) -> bool:
    """当前帧右下角是否还有 Continue 文字，作为结算页判据。"""
    result = ctx.action("observe.ocr", region=CONTINUE_REGION) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return CONTINUE_KEYWORD in _norm(joined)


@step
def execute(ctx: RunContext) -> None:
    """复查当前操作入口，适用时仅点击一次。"""
    ctx.action("observe.capture_screen")
    if not _continue_text(ctx):
        ctx.log("右下角没有 Continue，当前不在判定结算页", level="warning", screenshot=True)
        return

    point_x, point_y = CONTINUE_POINT
    ctx.log(f"结算页点击右下角 Continue ({point_x}, {point_y})")
    ctx.action("control.click", x=point_x, y=point_y)
