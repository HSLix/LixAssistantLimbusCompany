"""镜牢商店融合：关闭 Fuse E.G.O Gift 弹窗（以及叠在上面的关键词弹窗），回到商店页。

现场（1280x720，Run 503~512）实测：
- 融合页底部左侧 Close 按钮中心 (493,585)；
- Fusion - Keyword Selection 弹窗底部左侧 Cancel 中心 (492,566)，Close 被它盖住；
- 关闭融合弹窗不会融合任何饰品：只有点 Fuse 才会真正消耗材料，本步绝不点 Fuse。
先处理关键词弹窗（Cancel），再点融合页 Close；仍关不掉时补按一次 Esc（游戏里通用的回退键）。
关闭后清掉本次融合会话的运行时标记，下一楼层重新开始。
"""
import re

from lalc import RunContext, step

# 融合页标识：标题横幅用素材 mirror/shop/fuse/fuse_ego_gift（425x44）做原尺寸模板匹配，
# 不再读标题文字，也不再读右上角 Fusion Guide 文字。
FUSE_TITLE_ASSET = "mirror/shop/fuse/fuse_ego_gift"
FUSE_TITLE_REGION = {"x": 390, "y": 55, "width": 500, "height": 90}
FUSE_TITLE_THRESHOLD = 0.85
# 关键词弹窗：标题与底部 Cancel 按钮
FUSE_KEYWORD_TITLE_REGION = {"x": 380, "y": 70, "width": 520, "height": 60}
FUSE_KEYWORD_TITLE_KEYWORD = "fusionkeywordselection"
KEYWORD_CANCEL_REGION = {"x": 420, "y": 535, "width": 230, "height": 65}
KEYWORD_CANCEL_FALLBACK = (492, 566)
# 融合页底部 Close 按钮
FUSE_CLOSE_REGION = {"x": 400, "y": 555, "width": 230, "height": 60}
FUSE_CLOSE_FALLBACK = (493, 585)
# 本次融合会话的运行时标记：关闭后一起清掉
RUNTIME_KEY = "mirror.runtime"
KEYWORD_SELECTED_KEY = "fuse_keyword_selected"
USED_KEY = "fuse_used"
WAIT_SECONDS = 1.2


def _norm(text: str) -> str:
    """去掉空白和符号并转小写，避免 OCR 断行或断字影响文字匹配。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _region_text(ctx: RunContext, region: dict[str, int]) -> str:
    """对当前帧指定区域做一次局部 OCR，返回规范化小写文本；不刷新截图。"""
    result = ctx.action("observe.ocr", region=region) or {}
    items = result.get("items") or []
    joined = " ".join(str(item.get("text", "")) for item in items if item.get("text"))
    return _norm(joined)


def _fuse_popup_open(ctx: RunContext) -> bool:
    """当前帧是否在 Fuse E.G.O Gift 弹窗上：只用标题横幅素材 mirror/shop/fuse/fuse_ego_gift 匹配。"""
    return bool(
        ctx.action(
            "observe.match_asset",
            asset=FUSE_TITLE_ASSET,
            region=FUSE_TITLE_REGION,
            threshold=FUSE_TITLE_THRESHOLD,
        )
    )


def _keyword_popup_open(ctx: RunContext) -> bool:
    """当前帧是否叠着 Fusion - Keyword Selection 弹窗。"""
    return FUSE_KEYWORD_TITLE_KEYWORD in _region_text(ctx, FUSE_KEYWORD_TITLE_REGION)


def _button_point(ctx: RunContext, region: dict[str, int], keyword: str):
    """在指定区域找按钮文字中心；找不到返回 None。"""
    result = ctx.action("observe.ocr", region=region) or {}
    for item in result.get("items") or []:
        if keyword in _norm(item.get("text", "")):
            center = item.get("centerxy")
            if center:
                return (int(center[0]), int(center[1]))
    return None


def _clear_session(ctx: RunContext) -> None:
    """清掉本次融合会话的流派/耗材记录；写不进去只记 warning。"""
    settings = ctx.run_state.settings
    if not isinstance(settings, dict):
        return
    runtime = settings.get(RUNTIME_KEY)
    if not isinstance(runtime, dict):
        return
    runtime[KEYWORD_SELECTED_KEY] = False
    runtime[USED_KEY] = []
    settings[RUNTIME_KEY] = runtime


@step
def execute(ctx: RunContext) -> dict[str, str]:
    """
    按当前画面关闭融合相关弹窗：
    - 关键词弹窗开着 → 点一次 Cancel；
    - 融合页还开着 → 点一次底部 Close，等待后仍在时补按一次 Esc；
    - 已经不在融合页 → 零输入返回。
    只关闭、不融合：本步不会点击 Fuse，也不会选择任何礼物。
    """
    ctx.action("observe.capture_screen")
    if _keyword_popup_open(ctx):
        point = _button_point(ctx, KEYWORD_CANCEL_REGION, "cancel") or KEYWORD_CANCEL_FALLBACK
        ctx.log(f"关键词弹窗还开着，点击 Cancel {point} 关闭（不做任何融合输入）")
        ctx.action("control.click", x=point[0], y=point[1])
        ctx.action("observe.wait", seconds=WAIT_SECONDS)
        ctx.action("observe.capture_screen")

    if not _fuse_popup_open(ctx):
        _clear_session(ctx)
        ctx.log("当前已经不在 Fuse E.G.O Gift 弹窗上，无需关闭")
        return {"action": "not_open"}

    point = _button_point(ctx, FUSE_CLOSE_REGION, "close") or FUSE_CLOSE_FALLBACK
    ctx.log(f"点击融合页底部 Close {point} 关闭弹窗（不点 Fuse，不融合）")
    ctx.action("control.click", x=point[0], y=point[1])
    ctx.action("observe.wait", seconds=WAIT_SECONDS)
    ctx.action("observe.capture_screen")
    if _fuse_popup_open(ctx):
        ctx.log("点击 Close 后融合弹窗仍在，补按一次 Esc", level="warning", screenshot=True)
        ctx.action("control.key_press", key="esc")
        ctx.action("observe.wait", seconds=WAIT_SECONDS)
        ctx.action("observe.capture_screen")
    closed = not _fuse_popup_open(ctx)
    _clear_session(ctx)
    if not closed:
        ctx.log("融合弹窗仍然开着，交上层重新观察后再关", level="warning", screenshot=True)
        return {"action": "still_open"}
    ctx.log("Fuse E.G.O Gift 弹窗已关闭，回到商店页")
    return {"action": "closed"}
