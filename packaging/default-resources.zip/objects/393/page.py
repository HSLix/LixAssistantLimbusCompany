"""通用事件选项设置页：配置事件选项阶段优先选择的关键词（镜牢事件与其他事件的选项界面共用），并提示 OCR 的语言限制。"""
from PySide6.QtWidgets import QPlainTextEdit, QVBoxLayout, QWidget
from qfluentwidgets import BodyLabel, FluentIcon, PushButton, isDarkTheme

# PAGE_ID 保持 mirror.choices 以兼容已保存的配置；页面已改为通用的通用事件选项
PAGE_ID = "mirror.choices"
PAGE_NAME = "General Event Choices"
PAGE_NAMES = {"zh_CN": "通用事件选项", "en_US": "General Event Choices"}
# 页面图标：文本关键词配置，沿用 qfluentwidgets 的 Edit 图标
PAGE_ICON = FluentIcon.EDIT

# 纯设置页：不注册任务次数，只提供优先关键词配置
TASKS = []

# 与事件选项 Step 共用的字段名：一行一个关键词
KEYWORDS_KEY = "preferred_keywords"
DEFAULT_KEYWORDS = "select to gain\npass to gain"


def _caption_color() -> str:
    """次要文字颜色，跟随深浅主题，避免提示文字看不清。"""
    return "#b8a98e" if isDarkTheme() else "#6b5f4b"


class ChoicesPage(QWidget):
    """通用事件选项页设置：优先关键词列表与 OCR 语言限制提示。"""

    def __init__(self, context):
        super().__init__()
        self._context = context
        config = context.load({KEYWORDS_KEY: DEFAULT_KEYWORDS})

        layout = QVBoxLayout(self)
        layout.setSpacing(8)

        title = BodyLabel(
            context.translate(
                "通用事件选项（General Event Choices）优先关键词：命中关键词的选项会被优先选择。",
                "Preferred keywords for general event choices: a matching option is picked first.",
            )
        )
        title.setWordWrap(True)
        layout.addWidget(title)

        scope = BodyLabel(
            context.translate(
                "适用范围：所有事件选项阶段共用这一份配置，不只是镜牢事件；任何事件里出现选项列表时，"
                "都会按这里的关键词优先选择。",
                "Scope: every event choice screen shares this configuration, not only Mirror Dungeon "
                "events; whenever an event shows a list of options, these keywords are preferred.",
            )
        )
        scope.setWordWrap(True)
        scope.setStyleSheet(f"color: {_caption_color()};")
        layout.addWidget(scope)

        rule = BodyLabel(
            context.translate(
                "匹配规则：每行一个关键词；输入会先统一转成小写，再与同样转成小写的 OCR 文本做包含匹配。",
                "Matching rule: one keyword per line; every keyword is lower-cased and matched as a "
                "substring against the lower-cased OCR text.",
            )
        )
        rule.setWordWrap(True)
        rule.setStyleSheet(f"color: {_caption_color()};")
        layout.addWidget(rule)

        notice = BodyLabel(
            context.translate(
                "注意：当前 OCR 工具（PPOCRv6）不支持韩文。请只填写英文、数字或符号等可被识别的文字，"
                "韩文关键词永远不会命中。",
                "Note: the current OCR engine (PPOCRv6) does not support Korean. Use only Latin letters, "
                "digits or symbols that can be recognized; Korean keywords will never match.",
            )
        )
        notice.setWordWrap(True)
        notice.setStyleSheet(f"color: {_caption_color()};")
        layout.addWidget(notice)

        self._editor = QPlainTextEdit()
        saved = config.get(KEYWORDS_KEY)
        self._editor.setPlainText(saved if isinstance(saved, str) else DEFAULT_KEYWORDS)
        self._editor.setPlaceholderText(
            context.translate(
                "每行一个关键词，例如：\nselect to gain\npass to gain",
                "One keyword per line, for example:\nselect to gain\npass to gain",
            )
        )
        self._editor.setMinimumHeight(220)
        layout.addWidget(self._editor)

        footer = BodyLabel(
            context.translate(
                "留空表示不使用关键词优先，工作流会退回内置默认关键词。",
                "Leave it empty to fall back to the built-in default keywords.",
            )
        )
        footer.setWordWrap(True)
        footer.setStyleSheet(f"color: {_caption_color()};")
        layout.addWidget(footer)

        restore = PushButton(context.translate("恢复默认关键词", "Restore default keywords"))
        restore.clicked.connect(self._restore_defaults)
        layout.addWidget(restore, 0)
        layout.addStretch(1)

    def _restore_defaults(self):
        """把编辑框内容恢复成内置默认关键词。"""
        self._editor.setPlainText(DEFAULT_KEYWORDS)

    def submit(self) -> dict:
        """提交优先关键词原文，具体拆分与小写化由工作流读取时处理。"""
        return {KEYWORDS_KEY: self._editor.toPlainText()}


def create_page(context):
    """返回通用事件选项设置页实例。"""
    return ChoicesPage(context)
