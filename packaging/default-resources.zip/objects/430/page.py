"""队伍配置页：仿照游戏配队页面，配置最多 40 个队伍的出战罪人顺序，及每个队伍各自的镜牢配置。"""
from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QBoxLayout,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QStackedWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)
from qfluentwidgets import (
    BodyLabel, CaptionLabel, CardWidget, FluentIcon, ListWidget, Pivot, PushButton,
    StrongBodyLabel, SubtitleLabel, TitleLabel, themeColor,
)

PAGE_ID = "sinners.team_presets"
PAGE_NAME = "Team Presets"
PAGE_NAMES = {"zh_CN": "队伍配置", "en_US": "Team Presets"}
# 页面图标：队伍／编队主题，使用 qfluentwidgets 的 People 图标
PAGE_ICON = FluentIcon.PEOPLE

# 纯配置页：不注册任务（任务 id 还必须出现在 Plan 的 SUPPORTED_TASK_IDS 中才能执行）
TASKS = []

MAX_TEAMS = 40
TEAM_SIZE = 12
COLUMNS = 6
BOX_WIDTH = 92
BOX_HEIGHT = 124
# 方格之间的间距：罪人编队与技能替换共用同一个值，两页签的行内／行间距离保持一致
GRID_SPACING = 6
ICON_WIDTH = 66
ICON_HEIGHT = 84
# 技能替换方格：三个小框高度／间距与底部名字行高度固定下来，保证名字始终可见、
# 且方格尺寸与「罪人编队」的十二个人像框完全一致（92×124）
SKILL_BUTTON_HEIGHT = 22
SKILL_CELL_SPACING = 2
SKILL_NAME_HEIGHT = 20

# 顺序与游戏 Sinners／配队页面中间的十二个人像框一致（左到右、上到下）
SINNERS = (
    ("yi_sang", "李箱", "Yi Sang", "assets/sinners/yi_sang.png"),
    ("faust", "浮士德", "Faust", "assets/sinners/faust.png"),
    ("don_quixote", "唐吉诃德", "Don Quixote", "assets/sinners/don_quixote.png"),
    ("ryoshu", "良秀", "Ryōshū", "assets/sinners/ryoshu.png"),
    ("meursault", "默尔索", "Meursault", "assets/sinners/meursault.png"),
    ("hong_lu", "鸿璐", "Hong Lu", "assets/sinners/hong_lu.png"),
    ("heathcliff", "希斯克利夫", "Heathcliff", "assets/sinners/heathcliff.png"),
    ("ishmael", "以实玛利", "Ishmael", "assets/sinners/ishmael.png"),
    ("rodion", "罗佳", "Rodion", "assets/sinners/rodion.png"),
    ("sinclair", "辛克莱", "Sinclair", "assets/sinners/sinclair.png"),
    ("outis", "奥提斯", "Outis", "assets/sinners/outis.png"),
    ("gregor", "格里高尔", "Gregor", "assets/sinners/gregor.png"),
)

# 镜牢配置：饰品选择页左侧的流派，其余值与游戏内流派标题一致，末项「不选择流派」固定放最后
KEYWORDS = (
    ("burn", "烧伤（Burn）", "Burn"),
    ("bleed", "流血（Bleed）", "Bleed"),
    ("tremor", "震颤（Tremor）", "Tremor"),
    ("rupture", "破裂（Rupture）", "Rupture"),
    ("sinking", "沉沦（Sinking）", "Sinking"),
    ("poise", "呼吸法（Poise）", "Poise"),
    ("charge", "充能（Charge）", "Charge"),
    ("slash", "斩击（Slash）", "Slash"),
    ("pierce", "贯穿（Pierce）", "Pierce"),
    ("blunt", "打击（Blunt）", "Blunt"),
    ("none", "不选择流派", "No keyword"),
)
# 队伍没有保存过镜牢配置时默认不选流派
DEFAULT_KEYWORD = "none"
# 流派按钮每行的列数
KEYWORD_COLUMNS = 4

# 商店购买饰品流派：把游戏饰品选择页的流派标签全部列出（顺序与游戏内标签一致），
# 与上面的「初始 E.G.O 饰品」不同，这里可以同时选中多个流派；「泛用」是游戏里的通用流派。
# 取值与工作流的图鉴流派键名一致（sinking 的旧写法 sink 由工作流兼容）。
SHOP_KEYWORDS = (
    ("bleed", "流血", "Bleed"),
    ("burn", "燃烧", "Burn"),
    ("rupture", "破裂", "Rupture"),
    ("poise", "呼吸法", "Poise"),
    ("tremor", "震颤", "Tremor"),
    ("blunt", "打击", "Blunt"),
    ("pierce", "突刺", "Pierce"),
    ("slash", "斩击", "Slash"),
    ("charge", "充能", "Charge"),
    ("sinking", "沉沦", "Sinking"),
    ("general", "泛用", "General"),
)
# 标签按钮每行的列数：11 个标签排成两行（6 + 5），窄窗口下也不会被压成一条细缝
SHOP_KEYWORD_COLUMNS = 6

# 右侧三个饰品格子纵向排列（上→下）模仿游戏饰品选择页右侧的三个饰品，与点击顺序一一对应
SLOT_LABELS = (
    (1, "位置 1 · 上", "Gift 1 (top)"),
    (2, "位置 2 · 中", "Gift 2 (middle)"),
    (3, "位置 3 · 下", "Gift 3 (bottom)"),
)
MAX_SLOTS = 3
SLOT_BOX_WIDTH = 126
SLOT_BOX_HEIGHT = 35

# 镜牢技能替换：每个罪人三个可勾选的小横框，纵向堆叠，从上到下依次是 1→2、2→3、1→3。
# 只保存哪些选项被勾选（编号 1／2／3），不保存点击顺序，因此编号与「从上往下第几个框」一一对应。
SKILL_SWAP_OPTIONS = (
    (1, "1 → 2", "1 → 2"),
    (2, "2 → 3", "2 → 3"),
    (3, "1 → 3", "1 → 3"),
)
def _checked_style(selector="PushButton"):
    """选中态沿用应用强调色。"""
    color = themeColor().name()
    return f"{selector}:checked {{border: 1px solid {color}; background-color: {color}; color: white;}}"


def _load_icon(context, relative_path):
    """按包内相对路径载入图片，缺失或读取失败时返回空图标，页面仍可用。"""
    try:
        path = context.resource_path(relative_path)
        if not path.exists():
            return QIcon()
    except Exception:
        return QIcon()
    return QIcon(str(path))


def _compact_grid(columns):
    """建一个按固定间距紧凑排布的网格容器，返回 (容器布局, 网格布局)。

    格子宽度固定时，网格本身放在一个「靠左 + 末尾弹性留白」的行里，
    这样剩余宽度由留白吸收，不会被均摊进列间距，行内格子的间距就固定为 GRID_SPACING，
    与罪人编队页签的方格间距保持一致。
    """
    holder = QWidget()
    grid = QGridLayout(holder)
    grid.setContentsMargins(0, 0, 0, 0)
    grid.setSpacing(GRID_SPACING)
    grid.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
    for column in range(columns):
        grid.setColumnStretch(column, 0)
    row = QHBoxLayout()
    row.setContentsMargins(0, 0, 0, 0)
    row.setSpacing(0)
    row.addWidget(holder, 0)
    row.addStretch(1)
    return row, grid


class _SlotBox(PushButton):
    """镜牢配置里的一个饰品格子，文字显示它在点击顺序里排第几次。"""

    def __init__(self, slot: int, caption: str):
        super().__init__()
        self.slot = slot
        self._caption = caption
        self.setMinimumSize(SLOT_BOX_WIDTH, SLOT_BOX_HEIGHT)
        self.setCheckable(True)
        self.setStyleSheet(_checked_style())
        self.show_order(0)

    def show_order(self, order_index: int) -> None:
        """按点击顺序刷新格子文字，order_index 为 0 表示本次不点击。"""
        if order_index <= 0:
            self.setChecked(False)
            self.setText(f"{self._caption} · —")
        else:
            self.setChecked(True)
            self.setText(f"{self._caption} · {order_index}")


class TeamPresetsPage(QWidget):
    """队伍配置页：左侧队伍列表、中间十二罪人方框、右侧已选顺序；右侧页签是镜牢饰品偏好与镜牢技能替换。"""

    def __init__(self, context):
        super().__init__()
        self._context = context
        config = context.load({"teams": [], "active_team": 0})
        (
            self._teams,
            self._gift_keywords,
            self._gift_orders,
            self._shop_keywords,
            self._skill_configs,
        ) = self._restore_teams(config.get("teams"))
        self._active = self._restore_active(config.get("active_team"))
        self._skill_cells = []
        self._compact = None
        self._team_buttons = []
        self._sinner_buttons = {}
        self._slot_boxes = {}
        self._keyword_buttons = {}
        self._shop_keyword_buttons = {}
        self._shop_keyword_status = None
        self._skill_buttons = {}
        self._team_scroll = None
        self._build_ui()
        self._refresh()

    # ---------- 构建界面 ----------
    def _build_ui(self):
        tr = self._context.translate
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 12, 20, 10)
        root.setSpacing(10)
        root.addWidget(TitleLabel(tr("队伍配置", "Team Presets")))
        row = QHBoxLayout()
        row.setSpacing(12)
        self._team_card = self._build_team_column()
        row.addWidget(self._team_card)
        editor = QVBoxLayout()
        editor.setSpacing(6)
        self._team_label = SubtitleLabel()
        editor.addWidget(self._team_label)
        self._pivot = Pivot()
        editor.addWidget(self._pivot)
        self._tabs = QStackedWidget()
        self._formation_layout = QBoxLayout(QBoxLayout.Direction.LeftToRight)
        self._formation_layout.setSpacing(10)
        formation = QWidget()
        form = QVBoxLayout(formation)
        form.setContentsMargins(0, 2, 0, 0)
        hint = CaptionLabel(tr("点选罪人加入或移出；数字表示出战顺序。", "Click a Sinner to add or remove. Numbers show deployment order."))
        hint.setWordWrap(True)
        form.addWidget(hint)
        portraits = QWidget()
        portraits.setLayout(self._build_sinner_column())
        self._formation_layout.addWidget(portraits, 1)
        self._order_card = CardWidget()
        self._order_card.setLayout(self._build_side_column())
        self._formation_layout.addWidget(self._order_card, 0, Qt.AlignmentFlag.AlignTop)
        form.addLayout(self._formation_layout)
        form.addStretch(1)

        self._routes = {}
        for key, zh, en, widget in (
            ("formation", "罪人编队", "Formation", formation),
            ("gifts", "镜牢饰品偏好", "Gift preferences", self._build_mirror_section()),
            ("skills", "镜牢技能替换", "Skill swaps", self._build_skill_section()),
        ):
            scroll = QScrollArea()
            scroll.setFrameShape(QFrame.Shape.NoFrame)
            scroll.setWidgetResizable(True)
            scroll.setWidget(widget)
            self._routes[key] = self._tabs.addWidget(scroll)
            self._pivot.addItem(key, tr(zh, en))
        self._pivot.setItemFontSize(15)
        self._pivot.currentItemChanged.connect(lambda key: self._tabs.setCurrentIndex(self._routes[key]))
        self._pivot.setCurrentItem("formation")
        editor.addWidget(self._tabs, 1)
        row.addLayout(editor, 1)
        root.addLayout(row, 1)

        self._save_error = CardWidget()
        actions = QHBoxLayout(self._save_error)
        message = CaptionLabel(tr("队伍配置未保存。", "Team changes were not saved."))
        message.setWordWrap(True)
        actions.addWidget(message, 1)
        retry = PushButton(tr("重试", "Retry"))
        retry.clicked.connect(self._persist)
        actions.addWidget(retry)
        root.addWidget(self._save_error)
        self._save_error.hide()

    def _build_team_column(self):
        """队伍列表占用左栏可用高度，不跟随右侧编辑区滚动。"""
        tr = self._context.translate
        card = CardWidget()
        column = QVBoxLayout(card)
        column.setContentsMargins(9, 9, 9, 9)
        column.setSpacing(5)
        column.addWidget(StrongBodyLabel(tr("队伍列表", "Teams")))
        team_scroll = QScrollArea()
        team_scroll.setWidgetResizable(True)
        team_scroll.setFrameShape(QFrame.Shape.NoFrame)
        team_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        holder = QWidget()
        holder_layout = QVBoxLayout(holder)
        holder_layout.setContentsMargins(0, 0, 4, 0)
        holder_layout.setSpacing(4)
        for index in range(MAX_TEAMS):
            button = PushButton()
            button.setCheckable(True)
            button.setFixedHeight(32)
            button.setStyleSheet(_checked_style())
            button.clicked.connect(lambda checked=False, team_index=index: self._select_team(team_index))
            self._team_buttons.append(button)
            holder_layout.addWidget(button)
        holder_layout.addStretch(1)
        team_scroll.setWidget(holder)
        self._team_scroll = team_scroll
        column.addWidget(team_scroll, 1)
        return card

    def showEvent(self, event):
        super().showEvent(event)
        self._resize_editor()
        self._team_scroll.ensureWidgetVisible(self._team_buttons[self._active], 0, 0)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._resize_editor()

    def _resize_editor(self):
        """窄窗口保持队伍栏常驻，把已选顺序移到编队下方。"""
        compact = self.width() < 850
        if self._compact == compact:
            return
        self._compact = compact
        self._team_card.setFixedWidth(119 if compact else 146)
        self._formation_layout.setDirection(
            QBoxLayout.Direction.TopToBottom if compact else QBoxLayout.Direction.LeftToRight
        )
        self._order_card.setMinimumWidth(0 if compact else 150)
        self._order_card.setMaximumWidth(16777215 if compact else 150)
        self._order_list.setMinimumHeight(110 if compact else 224)
        self._order_list.setMaximumHeight(135 if compact else 245)
        width = 68 if compact else BOX_WIDTH
        height = 103 if compact else BOX_HEIGHT
        for button, _, _ in self._sinner_buttons.values():
            button.setFixedSize(width, height)
            button.setIconSize(QSize(46, 62) if compact else QSize(ICON_WIDTH, ICON_HEIGHT))
        for cell in self._skill_cells:
            cell.setFixedSize(width, height)

    def _build_sinner_column(self):
        """中间：十二个罪人方框，选中后显示其在当前队伍里的出战顺序。"""
        column = QVBoxLayout()
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(6)
        # 与人像框一样用固定 92×124 的格子、GRID_SPACING 间距，靠左紧凑排列
        row, grid = _compact_grid(COLUMNS)
        for position, (sinner_id, zh_name, en_name, resource) in enumerate(SINNERS):
            button = QToolButton()
            button.setCheckable(True)
            button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
            button.setFixedSize(BOX_WIDTH, BOX_HEIGHT)
            button.setStyleSheet(
                "QToolButton {border: 1px solid palette(midlight); border-radius: 6px; font-size: 11px;}"
                + _checked_style("QToolButton")
            )
            button.setIconSize(QSize(ICON_WIDTH, ICON_HEIGHT))
            icon = _load_icon(self._context, resource)
            if not icon.isNull():
                button.setIcon(icon)
            button.clicked.connect(
                lambda checked=False, sinner=sinner_id: self._toggle_sinner(sinner)
            )
            self._sinner_buttons[sinner_id] = (button, zh_name, en_name)
            grid.addWidget(button, position // COLUMNS, position % COLUMNS)
        column.addLayout(row)
        column.addStretch(1)
        return column

    def _build_side_column(self):
        """右侧：已选顺序紧接清空按钮，按钮贴着上面的列表。"""
        column = QVBoxLayout()
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(6)
        column.setContentsMargins(8, 8, 8, 8)
        column.addWidget(StrongBodyLabel(self._context.translate("已选顺序", "Selection order")))
        self._count_label = CaptionLabel()
        column.addWidget(self._count_label)
        self._order_list = ListWidget()
        column.addWidget(self._order_list)
        actions = QHBoxLayout()
        actions.setContentsMargins(0, 0, 0, 0)
        actions.setSpacing(6)
        for caption, callback in (
            ("↑", lambda: self._move_sinner(-1)),
            ("↓", lambda: self._move_sinner(1)),
            (self._context.translate("移除", "Remove"), self._remove_sinner),
        ):
            button = PushButton(caption)
            button.setMinimumWidth(27)
            button.clicked.connect(callback)
            actions.addWidget(button)
        column.addLayout(actions)
        self._clear_button = PushButton(
            self._context.translate("清空选择", "Clear selection")
        )
        self._clear_button.clicked.connect(self._clear_selection)
        column.addWidget(self._clear_button)
        column.addStretch(1)
        return column

    def _build_mirror_section(self):
        """区分初始流派与商店购买流派，保留上／中／下的饰品顺序。"""
        tr = self._context.translate
        section = QWidget()
        outer = QVBoxLayout(section)
        outer.setContentsMargins(0, 2, 0, 0)
        outer.setSpacing(8)
        initial = CardWidget()
        initial_layout = QVBoxLayout(initial)
        initial_layout.addWidget(StrongBodyLabel(tr("初始 E.G.O 饰品", "Initial E.G.O Gifts")))
        row = QHBoxLayout()
        chooser = QVBoxLayout()
        chooser.addWidget(CaptionLabel(tr("选择流派", "Choose a keyword")))
        keywords = QGridLayout()
        keywords.setSpacing(GRID_SPACING)
        for index, (value, zh, en) in enumerate(KEYWORDS):
            button = PushButton(tr(zh.split("（", 1)[0], en))
            button.setCheckable(True)
            button.setStyleSheet(_checked_style())
            button.clicked.connect(lambda checked=False, row_index=index: self._keyword_changed(row_index))
            self._keyword_buttons[value] = button
            keywords.addWidget(button, index // KEYWORD_COLUMNS, index % KEYWORD_COLUMNS)
        chooser.addLayout(keywords)
        note = CaptionLabel(tr(
            "没选流派或未设置顺序时，跳过领取。",
            "If no keyword or order is selected, the gift is declined.",
        ))
        note.setWordWrap(True)
        chooser.addWidget(note)
        chooser.addStretch(1)
        row.addLayout(chooser, 1)
        order = QVBoxLayout()
        order.addWidget(CaptionLabel(tr("饰品点击顺序", "Gift click order")))
        for slot, zh, en in SLOT_LABELS:
            button = _SlotBox(slot, tr(zh, en))
            button.clicked.connect(lambda checked=False, index=slot: self._toggle_slot(index))
            self._slot_boxes[slot] = button
            order.addWidget(button)
        self._gift_status = CaptionLabel()
        self._gift_status.setWordWrap(True)
        order.addWidget(self._gift_status)
        self._clear_order_button = PushButton(tr("清空点击顺序", "Clear click order"))
        self._clear_order_button.clicked.connect(self._clear_order)
        order.addWidget(self._clear_order_button)
        row.addLayout(order)
        initial_layout.addLayout(row)
        outer.addWidget(initial)

        shop = CardWidget()
        shop_layout = QVBoxLayout(shop)
        shop_layout.addWidget(StrongBodyLabel(tr("商店购买饰品流派", "Shop purchase keywords")))
        shop_note = CaptionLabel(tr("可多选；选初始流派时会一并勾上。", "Select several. The initial keyword is also selected here."))
        shop_note.setWordWrap(True)
        shop_layout.addWidget(shop_note)
        grid = QGridLayout()
        grid.setSpacing(GRID_SPACING)
        for index, (value, zh, en) in enumerate(SHOP_KEYWORDS):
            button = PushButton(tr(zh, en))
            button.setCheckable(True)
            button.setStyleSheet(_checked_style())
            button.clicked.connect(lambda checked=False, key=value: self._toggle_shop_keyword(key))
            self._shop_keyword_buttons[value] = button
            grid.addWidget(button, index // SHOP_KEYWORD_COLUMNS, index % SHOP_KEYWORD_COLUMNS)
        shop_layout.addLayout(grid)
        self._shop_keyword_status = CaptionLabel()
        self._shop_keyword_status.setWordWrap(True)
        shop_layout.addWidget(self._shop_keyword_status)
        outer.addWidget(shop)
        outer.addStretch(1)
        return section

    def _build_skill_section(self):
        """沿用罪人编队的两行六列；每名罪人独立勾选三种替换。"""
        section = QWidget()
        outer = QVBoxLayout(section)
        outer.setContentsMargins(0, 2, 0, 0)
        self._skill_status = CaptionLabel()
        outer.addWidget(self._skill_status)
        row, grid = _compact_grid(COLUMNS)
        for position, (sinner_id, zh, en, _) in enumerate(SINNERS):
            cell = self._build_skill_cell(sinner_id, zh, en)
            grid.addWidget(cell, position // COLUMNS, position % COLUMNS)
        outer.addLayout(row)
        outer.addStretch(1)
        return section

    def _build_skill_cell(self, sinner_id, zh_name, en_name):
        card = CardWidget()
        card.setFixedSize(BOX_WIDTH, BOX_HEIGHT)
        self._skill_cells.append(card)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(SKILL_CELL_SPACING)
        title = self._context.translate(zh_name, en_name)
        buttons = {}
        for value, zh, en in SKILL_SWAP_OPTIONS:
            button = PushButton(self._context.translate(zh, en))
            button.setCheckable(True)
            button.setFixedHeight(SKILL_BUTTON_HEIGHT)
            button.setStyleSheet(_checked_style())
            button.setAccessibleName(f"{title} · {button.text()}")
            button.clicked.connect(lambda checked=False, sinner=sinner_id, option=value: self._toggle_skill(sinner, option))
            layout.addWidget(button)
            buttons[value] = button
        layout.addStretch(1)
        name = CaptionLabel(title)
        name.setAlignment(Qt.AlignmentFlag.AlignCenter)
        name.setToolTip(title)
        layout.addWidget(name)
        self._skill_buttons[sinner_id] = buttons
        return card

    # ---------- 状态处理 ----------
    def _restore_teams(self, raw):
        """读入已保存的队伍配置，返回罪人顺序、镜牢饰品流派、饰品点击顺序、商店购买流派与技能替换五组数据。

        兼容旧格式（每个队伍只有罪人列表）与新格式（每项是含 sinners、gift_keyword、
        gift_slot_order、shop_keywords、skill_replacements 的字典），未知或重复的罪人忽略，
        队伍与五组配置都补齐到 MAX_TEAMS 个。
        """
        known = [sinner[0] for sinner in SINNERS]
        teams = []
        keywords = []
        orders = []
        shops = []
        skills = []
        if isinstance(raw, list):
            for entry in raw[:MAX_TEAMS]:
                sinners = entry.get("sinners") if isinstance(entry, dict) else entry
                team = []
                if isinstance(sinners, list):
                    for value in sinners:
                        sinner_id = str(value).strip()
                        if sinner_id in known and sinner_id not in team:
                            team.append(sinner_id)
                teams.append(team[:TEAM_SIZE])
                keyword = self._restore_keyword(entry)
                keywords.append(keyword)
                orders.append(self._restore_order(entry))
                shops.append(self._restore_shop_keywords(entry, keyword))
                skills.append(self._restore_skills(entry))
        while len(teams) < MAX_TEAMS:
            teams.append([])
            keywords.append(DEFAULT_KEYWORD)
            orders.append([])
            shops.append([])
            skills.append({})
        return teams, keywords, orders, shops, skills

    @staticmethod
    def _restore_keyword(entry) -> str:
        """读入一个队伍保存的镜牢饰品流派，未知值退回不选流派。"""
        if not isinstance(entry, dict):
            return DEFAULT_KEYWORD
        keyword = str(entry.get("gift_keyword") or DEFAULT_KEYWORD).strip().lower()
        if keyword not in [value for value, _, _ in KEYWORDS]:
            return DEFAULT_KEYWORD
        return keyword

    @staticmethod
    def _restore_shop_keywords(entry, keyword: str) -> list[str]:
        """读入一个队伍保存的「商店购买饰品流派」多选集合。

        没有这个键的是旧配置（只有单选的初始流派）：此时把初始流派当作唯一选中的流派，
        让旧队伍的商店购买范围与改动前一致；存过空列表表示一个都不选，保持为空。
        未知取值忽略，结果按 SHOP_KEYWORDS 的固定顺序返回。
        """
        allowed = [value for value, _, _ in SHOP_KEYWORDS]
        fallback = [keyword] if keyword in allowed else []
        raw = entry.get("shop_keywords") if isinstance(entry, dict) else None
        if not isinstance(raw, list):
            return fallback
        picked = set()
        for value in raw:
            text = str(value).strip().lower()
            if text in allowed:
                picked.add(text)
        return [value for value in allowed if value in picked]

    @staticmethod
    def _restore_order(entry) -> list[int]:
        """读入一个队伍保存的饰品点击顺序，忽略非法或重复的序号。"""
        if not isinstance(entry, dict):
            return []
        order: list[int] = []
        raw = entry.get("gift_slot_order")
        if isinstance(raw, list):
            for value in raw:
                text = str(value).strip()
                if not text.isdigit():
                    continue
                slot = int(text)
                if 1 <= slot <= MAX_SLOTS and slot not in order:
                    order.append(slot)
        return order[:MAX_SLOTS]

    @staticmethod
    def _restore_skills(entry) -> dict[str, list[int]]:
        """读入一个队伍保存的技能替换勾选：{罪人 id: [1, 2, 3]}。

        忽略未知罪人、非列表的值以及 1~3 之外的编号；结果按编号排序，因为这里只记录
        「哪些选项被勾选」，勾选顺序没有意义。
        """
        if not isinstance(entry, dict):
            return {}
        raw = entry.get("skill_replacements")
        if not isinstance(raw, dict):
            return {}
        known = {sinner[0] for sinner in SINNERS}
        allowed = {value for value, _, _ in SKILL_SWAP_OPTIONS}
        skills: dict[str, list[int]] = {}
        for sinner_id, values in raw.items():
            key = str(sinner_id).strip()
            if key not in known or not isinstance(values, list):
                continue
            picked = set()
            for value in values:
                text = str(value).strip()
                if text.isdigit() and int(text) in allowed:
                    picked.add(int(text))
            if picked:
                skills[key] = sorted(picked)
        return skills

    @staticmethod
    def _restore_active(raw):
        """读入上次编辑的队伍序号，超出范围时回到第一个队伍。"""
        try:
            index = int(raw)
        except (TypeError, ValueError):
            return 0
        if 0 <= index < MAX_TEAMS:
            return index
        return 0

    def _team_title(self, index):
        """队伍在界面上的显示名。"""
        return self._context.translate(f"队伍 {index + 1}", f"Team {index + 1}")

    def _select_team(self, index):
        """切换正在编辑的队伍。"""
        if not 0 <= index < MAX_TEAMS:
            return
        if self._active == index:
            self._team_buttons[index].setChecked(True)
            return
        self._active = index
        self._refresh()
        self._persist()

    def focus_team(self, index):
        """外部页面跳转时定位到指定队伍：选中它并把左侧列表滚动到可见位置。

        index 从 0 开始，越界时保持当前队伍不变，便于其它页面按需调用。
        """
        try:
            value = int(index)
        except (TypeError, ValueError):
            return
        if not 0 <= value < MAX_TEAMS:
            return
        self._pivot.setCurrentItem("formation")
        self._tabs.setCurrentIndex(self._routes["formation"])
        self._select_team(value)
        if self._team_scroll is not None:
            self._team_scroll.ensureWidgetVisible(self._team_buttons[value], 0, 0)

    def _toggle_sinner(self, sinner_id):
        """点击罪人方框：未选中时排到当前队伍最后，已选中时取消并保持其余顺序。"""
        team = self._teams[self._active]
        if sinner_id in team:
            team.remove(sinner_id)
        else:
            team.append(sinner_id)
        self._refresh()
        self._persist()

    def _clear_selection(self):
        """清空当前队伍已选的罪人。"""
        self._teams[self._active] = []
        self._refresh()
        self._persist()

    def _keyword_changed(self, index):
        """流派按钮被点击时写入当前队伍的镜牢配置，并把对应流派一并加入「商店购买饰品流派」。

        上面是单选（一队一个初始 E.G.O 饰品流派），下面是多选：这里只做「加进去」，
        不做取消——之后无论取消上面还是取消下面，都不会连带改动另一边。
        """
        if 0 <= index < len(KEYWORDS):
            keyword = KEYWORDS[index][0]
            self._gift_keywords[self._active] = keyword
            allowed = [value for value, _, _ in SHOP_KEYWORDS]
            if keyword in allowed and keyword not in self._shop_keywords[self._active]:
                picked = set(self._shop_keywords[self._active]) | {keyword}
                self._shop_keywords[self._active] = [
                    value for value in allowed if value in picked
                ]
            self._refresh_mirror()
            self._persist()

    def _keyword_index(self, keyword):
        """返回流派配置值在按钮网格里的序号，未知值退回不选流派。"""
        for index, (value, _, _) in enumerate(KEYWORDS):
            if value == keyword:
                return index
        return len(KEYWORDS) - 1

    def _toggle_shop_keyword(self, keyword):
        """点击商店购买流派标签：未选中时加入，已选中时取消，其它标签保持不变。"""
        allowed = [value for value, _, _ in SHOP_KEYWORDS]
        if keyword not in allowed:
            return
        picked = set(self._shop_keywords[self._active])
        if keyword in picked:
            picked.discard(keyword)
        else:
            picked.add(keyword)
        self._shop_keywords[self._active] = [
            value for value in allowed if value in picked
        ]
        self._refresh_shop_keywords()
        self._persist()

    def _toggle_slot(self, slot):
        """点击格子：未参与时排到当前队伍点击顺序末尾，已参与时移出并重新编号。"""
        order = self._gift_orders[self._active]
        if slot in order:
            order.remove(slot)
        else:
            order.append(slot)
        self._refresh_mirror()
        self._persist()

    def _clear_order(self):
        """清空当前队伍的饰品点击顺序。"""
        self._gift_orders[self._active] = []
        self._refresh_mirror()
        self._persist()

    def _refresh_mirror(self):
        """把当前队伍的镜牢配置同步到流派按钮、三个饰品格子与商店购买流派标签。"""
        for keyword, button in self._keyword_buttons.items():
            button.setChecked(keyword == self._gift_keywords[self._active])
        order = self._gift_orders[self._active]
        for slot, box in self._slot_boxes.items():
            index = order.index(slot) + 1 if slot in order else 0
            box.show_order(index)
        skipping = self._gift_keywords[self._active] == DEFAULT_KEYWORD or not order
        self._gift_status.setText(self._context.translate(
            "当前：跳过初始饰品" if skipping else "点击顺序：" + " → ".join(map(str, order)),
            "Current: refuse gifts" if skipping else "Click order: " + " → ".join(map(str, order)),
        ))
        self._refresh_shop_keywords()

    def _refresh_shop_keywords(self):
        """把当前队伍的「商店购买饰品流派」多选同步到标签按钮与摘要。"""
        picked = self._shop_keywords[self._active]
        for keyword, button in self._shop_keyword_buttons.items():
            button.setChecked(keyword in picked)
        if self._shop_keyword_status is None:
            return
        names = [
            self._context.translate(zh_name, en_name)
            for value, zh_name, en_name in SHOP_KEYWORDS
            if value in picked
        ]
        if names:
            self._shop_keyword_status.setText(
                self._context.translate(
                    "已选商店购买流派：" + "、".join(names),
                    "Shop purchase keywords: " + ", ".join(names),
                )
            )
        else:
            self._shop_keyword_status.setText(
                self._context.translate("已选商店购买流派：无", "Shop purchase keywords: none")
            )

    def _toggle_skill(self, sinner_id, option):
        """点击技能替换小框：勾选／取消当前队伍该罪人的这一项，不记录顺序。"""
        if sinner_id not in self._skill_buttons or option not in self._skill_buttons[sinner_id]:
            return
        config = self._skill_configs[self._active]
        picked = set(config.get(sinner_id) or ())
        if option in picked:
            picked.discard(option)
        else:
            picked.add(option)
        if picked:
            config[sinner_id] = sorted(picked)
        else:
            config.pop(sinner_id, None)
        self._refresh_skill()
        self._persist()

    def _refresh_skill(self):
        """把当前队伍保存的技能替换勾选同步到十二个罪人的三个小框，并刷新摘要。"""
        config = self._skill_configs[self._active]
        for sinner_id, buttons in self._skill_buttons.items():
            picked = config.get(sinner_id) or []
            for option, button in buttons.items():
                button.setChecked(option in picked)
        total = sum(len(values) for values in config.values())
        self._skill_status.setText(
            self._context.translate(
                f"当前队伍已勾选 {total} 项技能替换，涉及 {len(config)} 个罪人",
                f"{total} replacements ticked for {len(config)} sinners in the current team",
            )
        )

    def _move_sinner(self, delta):
        """调整当前罪人顺序，边界外保持不变。"""
        row = self._order_list.currentRow()
        team = self._teams[self._active]
        target = row + delta
        if row < 0 or not 0 <= target < len(team):
            return
        team[row], team[target] = team[target], team[row]
        self._refresh()
        self._order_list.setCurrentRow(target)
        self._persist()

    def _remove_sinner(self):
        """移除已选列表中的当前罪人并同步卡片编号。"""
        row = self._order_list.currentRow()
        if row >= 0:
            self._teams[self._active].pop(row)
            self._refresh()
            self._persist()

    def _refresh(self):
        """按当前状态刷新队伍列表、罪人方框、右侧顺序摘要、镜牢配置、商店购买流派与技能替换。"""
        team = self._teams[self._active]
        for index, button in enumerate(self._team_buttons):
            name = self._team_title(index)
            count = len(self._teams[index])
            button.setText(
                self._context.translate(
                    f"{name}　{count}/{TEAM_SIZE}",
                    f"{name}  {count}/{TEAM_SIZE}",
                )
            )
            button.setChecked(index == self._active)

        self._team_label.setText(self._team_title(self._active))

        for sinner_id, (button, zh_name, en_name) in self._sinner_buttons.items():
            title = self._context.translate(zh_name, en_name)
            if sinner_id in team:
                button.setText(f"{team.index(sinner_id) + 1}. {title}")
                button.setChecked(True)
            else:
                button.setText(title)
                button.setChecked(False)

        self._count_label.setText(
            self._context.translate(
                f"已选 {len(team)} / {TEAM_SIZE}", f"{len(team)} / {TEAM_SIZE} selected"
            )
        )
        current = self._order_list.currentRow()
        self._order_list.clear()
        for position, sinner_id in enumerate(team, 1):
            _, zh, en = self._sinner_buttons[sinner_id]
            self._order_list.addItem(f"{position}. {self._context.translate(zh, en)}")
        if team:
            self._order_list.setCurrentRow(min(max(current, 0), len(team) - 1))
        self._refresh_mirror()
        self._refresh_skill()

    def _persist(self):
        """一次设置操作完成后保存；失败保留界面状态供重试。"""
        try:
            self._context.save(self.submit())
        except (OSError, ValueError, RuntimeError):
            self._save_error.show()
        else:
            self._save_error.hide()

    def submit(self) -> dict:
        """提交 40 个队伍的出战顺序、各自的镜牢配置、商店购买流派、技能替换与当前编辑队伍。"""
        return {
            **self._context.load(),
            "teams": [
                {
                    "sinners": list(team),
                    "gift_keyword": self._gift_keywords[index],
                    "gift_slot_order": list(self._gift_orders[index]),
                    # 商店购买饰品的流派多选：按 SHOP_KEYWORDS 的固定顺序保存，空列表表示一个都不选
                    "shop_keywords": list(self._shop_keywords[index]),
                    # 只保存被勾选的编号（1=1→2、2=2→3、3=1→3），空队伍／空选择不写键
                    "skill_replacements": {
                        sinner_id: list(values)
                        for sinner_id, values in self._skill_configs[index].items()
                        if values
                    },
                }
                for index, team in enumerate(self._teams)
            ],
            "active_team": self._active,
        }


def create_page(context):
    """返回队伍配置页实例。"""
    return TeamPresetsPage(context)
