"""Luxcavation 设置页：EXP / Thread 的执行次数任务项，以及各自使用的队伍。"""
from PySide6.QtWidgets import QApplication, QHBoxLayout, QTabWidget, QVBoxLayout, QWidget
from qfluentwidgets import CaptionLabel, CardWidget, ComboBox, FluentIcon, PushButton, StrongBodyLabel, TitleLabel

PAGE_ID = "luxcavation.settings"
PAGE_NAME = "Luxcavation"
PAGE_NAMES = {"zh_CN": "采光", "en_US": "Luxcavation"}
# 页面图标：进入副本开始战斗（EXP / Thread 刷取），使用 qfluentwidgets 的 Play 图标
PAGE_ICON = FluentIcon.PLAY

# 任务 ID 必须出现在 Plan 模块级字面量 SUPPORTED_TASK_IDS 中，Dashboard 才会显示
TASKS = [
    {
        "id": "exp",
        "name": "Exp",
        "show_task_count": True,
        "names": {"zh_CN": "经验采光", "en_US": "Exp"},
    },
    {
        "id": "thread",
        "name": "Thread",
        "show_task_count": True,
        "names": {"zh_CN": "纺锤采光", "en_US": "Thread"},
    },
]

# 队伍数量与队伍配置页一致，选择框里放 1..MAX_TEAMS
MAX_TEAMS = 40
DEFAULT_TEAM = 1
# 队伍配置页的 PAGE_ID，同时是页面控件的 objectName，用来定位跳转目标
TEAM_PAGE_ID = "sinners.team_presets"


def _team_index(raw):
    """把保存的队伍序号规范到 1..MAX_TEAMS，非法值退回默认队伍。"""
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_TEAM
    return value if 1 <= value <= MAX_TEAMS else DEFAULT_TEAM


class LuxcavationPage(QWidget):
    """Luxcavation 设置页：EXP 与 Thread 各自使用哪个队伍，并可跳转到队伍配置。"""

    def __init__(self, context):
        super().__init__()
        self._context = context
        tr = context.translate
        config = context.load({"exp_team": DEFAULT_TEAM, "thread_team": DEFAULT_TEAM})
        self._saved = {key: _team_index(config.get(key)) for key in ("exp_team", "thread_team")}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 12, 20, 10)
        layout.setSpacing(10)
        layout.addWidget(TitleLabel(tr("采光", "Luxcavation")))
        note = CaptionLabel(tr(
            "为各任务选择出战队伍。运行次数在仪表盘设置。",
            "Choose a team for each task. Set run counts on the dashboard.",
        ))
        note.setWordWrap(True)
        layout.addWidget(note)
        self._exp_combo = self._add_team_row(layout, "exp_team", tr("经验采光", "EXP Luxcavation"))
        self._thread_combo = self._add_team_row(layout, "thread_team", tr("纺锤采光", "Thread Luxcavation"))
        self._error = QWidget()
        error = QHBoxLayout(self._error)
        error.setContentsMargins(0, 0, 0, 0)
        warning = CaptionLabel(tr("队伍选择未保存。", "Team selection was not saved."))
        warning.setWordWrap(True)
        error.addWidget(warning, 1)
        retry = PushButton(tr("重试", "Retry"))
        retry.clicked.connect(self._save)
        error.addWidget(retry)
        layout.addWidget(self._error)
        self._error.hide()
        layout.addStretch(1)

    def _add_team_row(self, layout, key, title):
        """选择队伍和编辑队伍分别用独立控件。"""
        tr = self._context.translate
        card = CardWidget()
        row = QHBoxLayout(card)
        row.setContentsMargins(14, 12, 14, 12)
        label = StrongBodyLabel(title)
        label.setWordWrap(True)
        row.addWidget(label, 1)
        combo = ComboBox()
        combo.setAccessibleName(tr("{0}出战队伍", "Team for {0}").format(title))
        for index in range(1, MAX_TEAMS + 1):
            combo.addItem(tr("队伍 {0}", "Team {0}").format(index))
        combo.setCurrentIndex(self._saved[key] - 1)
        combo.setMinimumWidth(128)
        row.addWidget(combo)
        edit = PushButton()

        def update_label():
            team = combo.currentIndex() + 1
            edit.setText(tr("编辑队伍 {0} ↗", "Edit Team {0} ↗").format(team))

        def change_team():
            update_label()
            self._save()

        update_label()
        combo.currentIndexChanged.connect(change_team)
        edit.clicked.connect(lambda: self._open_team_page(combo.currentIndex() + 1))
        edit.setToolTip(tr("在队伍配置中打开该队伍", "Open the team in Team Presets"))
        row.addWidget(edit)
        layout.addWidget(card)
        return combo

    def _save(self):
        """有效选队后自动保存；失败时保留选择供重试。"""
        result = self.submit()
        values = {key: result[key] for key in self._saved}
        if values != self._saved:
            try:
                self._context.save(result)
            except (OSError, ValueError, RuntimeError):
                self._error.show()
                return
            self._saved = values
        self._error.hide()

    def _open_team_page(self, team):
        """跳转到队伍配置页面并定位到指定队伍；该页面不可用时保持当前页面。"""
        window = self.window()
        team_page = None
        if window is not None and callable(getattr(window, "switchTo", None)):
            team_page = window.findChild(QWidget, TEAM_PAGE_ID)
        if team_page is None:
            app = QApplication.instance()
            for top in list(app.topLevelWidgets()) if app is not None else []:
                candidate = top.findChild(QWidget, TEAM_PAGE_ID)
                if candidate is not None and callable(getattr(top, "switchTo", None)):
                    window = top
                    team_page = candidate
                    break
        if team_page is None or not callable(getattr(window, "switchTo", None)):
            return
        window.switchTo(team_page)
        tabs = getattr(team_page, "_tabs", None)
        if isinstance(tabs, QTabWidget):
            tabs.setCurrentIndex(0)
        focus = getattr(team_page, "focus_team", None)
        if not callable(focus):
            focus = getattr(team_page, "_select_team", None)
        if callable(focus):
            focus(team - 1)

    def submit(self) -> dict:
        """提交 EXP 与 Thread 各自使用的队伍序号（从 1 开始）。"""
        return {
            **self._context.load(),
            "exp_team": self._exp_combo.currentIndex() + 1,
            "thread_team": self._thread_combo.currentIndex() + 1,
        }


def create_page(context):
    """返回 Luxcavation 设置页实例。"""
    return LuxcavationPage(context)
