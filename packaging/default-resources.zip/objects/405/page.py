"""通用事件选项：设置所有事件共用的优先关键词。"""

from PySide6.QtCore import QEvent
from PySide6.QtWidgets import QHBoxLayout, QVBoxLayout, QWidget
from qfluentwidgets import BodyLabel, CaptionLabel, CardWidget, FluentIcon, PlainTextEdit, PushButton, StrongBodyLabel, TitleLabel

PAGE_ID = "mirror.choices"
PAGE_NAME = "General Event Choices"
PAGE_NAMES = {"zh_CN": "通用事件选项", "en_US": "General Event Choices"}
PAGE_ICON = FluentIcon.EDIT
TASKS = []

KEYWORDS_KEY = "preferred_keywords"
DEFAULT_KEYWORDS = "select to gain\npass to gain\nE.G.O Gift"


class ChoicesPage(QWidget):
    """保留每行一词的编辑方式；编辑完成后保存整份原文。"""

    def __init__(self, context):
        super().__init__()
        self._context = context
        tr = context.translate
        saved = context.load({KEYWORDS_KEY: DEFAULT_KEYWORDS}).get(KEYWORDS_KEY)
        self._saved = saved if isinstance(saved, str) else DEFAULT_KEYWORDS
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 12, 20, 10)
        layout.setSpacing(10)
        layout.addWidget(TitleLabel(tr("通用事件选项", "General Event Choices")))
        scope = BodyLabel(tr(
            "所有事件共用；选项文字命中关键词时优先选择。",
            "Applies to all events. Choices containing a keyword are preferred.",
        ))
        scope.setWordWrap(True)
        layout.addWidget(scope)

        card = CardWidget()
        content = QVBoxLayout(card)
        content.setContentsMargins(15, 12, 15, 12)
        content.setSpacing(7)
        content.addWidget(StrongBodyLabel(tr("优先关键词", "Preferred keywords")))
        content.addWidget(CaptionLabel(tr("每行一个，可整段粘贴。", "One per line. Paste a whole list at once.")))
        self._editor = PlainTextEdit()
        self._editor.setAccessibleName(tr("优先关键词", "Preferred keywords"))
        self._editor.setPlaceholderText(tr("输入关键词…", "Enter keywords…"))
        self._editor.setPlainText(self._saved)
        self._editor.setMinimumHeight(170)
        self._editor.installEventFilter(self)
        self._editor.textChanged.connect(self._update_hint)
        content.addWidget(self._editor)
        self._hint = CaptionLabel()
        self._hint.setWordWrap(True)
        content.addWidget(self._hint)
        self._update_hint()
        controls = QHBoxLayout()
        controls.addStretch(1)
        restore = PushButton(tr("恢复默认关键词", "Restore default keywords"))
        restore.clicked.connect(self._restore_defaults)
        controls.addWidget(restore)
        content.addLayout(controls)
        self._error = QWidget()
        error = QHBoxLayout(self._error)
        error.setContentsMargins(0, 0, 0, 0)
        message = BodyLabel(tr("关键词未保存。", "Keywords were not saved."))
        message.setWordWrap(True)
        error.addWidget(message, 1)
        retry = PushButton(tr("重试", "Retry"))
        retry.clicked.connect(self._save)
        error.addWidget(retry)
        content.addWidget(self._error)
        self._error.hide()
        layout.addWidget(card, 1)
        layout.addStretch(1)

    def eventFilter(self, watched, event):
        if watched is self._editor and event.type() == QEvent.Type.FocusOut:
            self._save()
        return super().eventFilter(watched, event)

    def _update_hint(self):
        tr = self._context.translate
        self._hint.setText(tr(
            "留空时使用内置默认关键词。OCR 不支持韩文。",
            "Leave empty to use built-in keywords. OCR does not support Korean.",
        ) if self._editor.toPlainText().strip() else tr(
            "当前使用内置默认关键词。OCR 不支持韩文。",
            "Using built-in keywords. OCR does not support Korean.",
        ))

    def _restore_defaults(self):
        self._editor.setPlainText(DEFAULT_KEYWORDS)
        self._save()

    def _save(self):
        """保存失败时保留输入，不用默认值回填失败的改动。"""
        value = self._editor.toPlainText()
        if value != self._saved:
            try:
                self._context.save(self.submit())
            except (OSError, ValueError, RuntimeError):
                self._error.show()
                return
            self._saved = value
        self._error.hide()

    def submit(self) -> dict:
        """提交优先关键词原文；工作流继续负责拆分与匹配。"""
        return {**self._context.load(), KEYWORDS_KEY: self._editor.toPlainText()}


def create_page(context):
    return ChoicesPage(context)
