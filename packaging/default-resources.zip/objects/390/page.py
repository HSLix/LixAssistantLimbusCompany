"""镜牢设置页：队伍顺序、星光强化、结算、商店设置、饰品、主题包与楼层饰品 debuff 规避。

队伍顺序只有一份配置：页面资源 team_order.teams。工作流每场领取奖励后直接把轮换后的完整顺序
写回这份资源，页面按同一份显示，运行也按同一份取第一支队伍；不再有 rotation／next_team 指针，
也不保存「轮换中」标记。分页在可见时每秒跟随该资源刷新，所以工作流改动后页面会同步。

饰品的条目完全由素材库镜像 mirror/gift/<流派>/<名字> 派生：页面不再读取或写入任何页面资源，
列表每次都直接从素材目录生成，名字就是素材目录名。饰品没有额外的名称标签，
页面搜索与工作流都只按这个名字匹配。

饰品列表按批创建：首屏只建一批，真正划到列表底部才补下一批；行图标始终取该素材目录的第一张图，
缺图（素材库里没有这张图、读不出或校验不符）的行在图标最左端显示黄色三角形「！」；
多图候选（同一饰品存了多张图）是正常状态，不画警告符号，只用文字说明并可用「多图候选」筛选项单独查看。

主题包的条目同样完全由素材库镜像 mirror/theme_pack/<名字> 派生：页面不再读取包内图片或图鉴资源，
名字就是素材目录名，没有额外的名称标签；卡片按批创建，封面在创建卡片时才从素材库读取。

楼层 Acquire E.G.O Gift 页的 Mounting Trials debuff 规避顺序由本页独立的「楼层饰品」标签配置
（settings 键 floor_gift_debuffs，存游戏内英文关键词原文），工作流按这份顺序先点要规避的卡片。
"""
import re
import unicodedata

from PySide6.QtCore import QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QIcon, QIntValidator, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView,
    QDialog,
    QDoubleSpinBox,
    QSpinBox,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QGridLayout,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QTabWidget,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)
from qfluentwidgets import (
    BodyLabel,
    CheckBox,
    ComboBox,
    FluentIcon,
    LineEdit,
    PrimaryPushButton,
    PushButton,
    isDarkTheme,
)

PAGE_ID = "mirror.settings"
PAGE_NAME = "Mirror Dungeons"
PAGE_NAMES = {"zh_CN": "镜牢", "en_US": "Mirror Dungeons"}
PAGE_SETTINGS_GROUPS = {
    "gifts": {"names": {"zh_CN": "饰品配置", "en_US": "Gift settings"},
              "fields": {"shop_gifts": ["preferences"]}},
    "theme_packs": {"names": {"zh_CN": "主题包", "en_US": "Theme packs"},
                    "fields": {"theme_packs": ["preferences"]}},
    "starlight": {"names": {"zh_CN": "星光强化", "en_US": "Starlight"},
                  "fields": {"star_levels": [], "star_selected": None}},
    "floor_debuffs": {"names": {"zh_CN": "楼层饰品减益", "en_US": "Floor gift debuffs"},
                      "fields": {"floor_gift_debuffs": None}},
    "shop": {"names": {"zh_CN": "商店设置", "en_US": "Shop settings"},
             "fields": {"shop_cost_threshold": None, "shop_stop_gift_slots": None,
                        "shop_buy_unrecorded_gifts": None,
                        "shop_skill_replace": None, "shop_buy_gifts": None,
                        "shop_fuse_gifts": None}},
}
# 页面图标：镜牢副本探索（肉鸽玩法），使用 qfluentwidgets 的 Game 图标
PAGE_ICON = FluentIcon.GAME

# 任务 ID 必须出现在 Plan 模块级字面量 SUPPORTED_TASK_IDS 中，Dashboard 才会显示
TASKS = [
    {
        "id": "mirror",
        "name": "Mirror Dungeons",
        "show_task_count": True,
        "names": {"zh_CN": "镜牢（Mirror Dungeons）", "en_US": "Mirror Dungeons"},
    },
]

# 结算弹窗处理方式：最右 Claim（领取） / 最左 Give Up Rewards（不领取）
REWARD_MODES = (
    ("claim", "领取奖励（Claim）", "Claim rewards"),
    ("give_up", "不领取奖励（Give Up Rewards）", "Give Up Rewards (do not claim)"),
)
# 结算规则按「本场镜牢的结算结果」分三种条件保存；默认值：胜利领取，失败与未知不领取
SETTLEMENT_RULES_KEY = "reward_rules"
SETTLEMENT_CONDITIONS = (
    ("victory", "胜利结算（Victory）", "Just won (Victory)", "claim"),
    ("defeat", "失败结算（Defeat）", "Just lost (Defeat)", "give_up"),
    ("unknown", "未检测到胜利或失败（Unknown）", "No just-win / just-loss detected (Unknown)", "give_up"),
)

# 队伍数量与「队伍配置」页一致：那边编辑每个队伍的罪人与镜牢饰品配置，这里只选使用顺序
MAX_TEAMS = 40
# 队伍顺序的唯一存储：页面资源 team_order.teams。页面显示、页面保存与运行选队都只读写这一份；
# 旧的 mirror_teams／mirror_team 设置键已彻底删除，避免页面保存再覆盖工作流的轮换结果。
ORDER_RESOURCE = "team_order"
ORDER_TEAMS_KEY = "teams"
# 主页只展示有限个队伍徽章，其余折叠成一行提示，避免撑高镜牢配置主页
CHIPS_PER_ROW = 6
MAX_CHIPS = 12

# 商店 Cost 阈值只用于商品处理完后决定是否刷新，工作流沿用原设置键。
# 开发者要求最低 300：输入框与恢复逻辑都把更小的值（含旧配置里的 0）按 300 处理。
SHOP_COST_KEY = "shop_cost_threshold"
MIN_SHOP_COST = 300
DEFAULT_SHOP_COST = MIN_SHOP_COST
MAX_SHOP_COST = 99999
# 商店设置「停止刷新的剩余饰品栏位」：商店里未买下的饰品栏位只剩不多于这么多个时，
# 即使 Cost 高于阈值也不再刷新，直接退出购买循环（默认 1）。
# 0 表示不启用这条规则，仍只按 Cost 阈值决定是否刷新。
# 只在刷新不再是为了技能替换时生效：技能替换还有未买下的栏位时，刷新是为了买技能，照旧进行。
SHOP_STOP_GIFT_SLOTS_KEY = "shop_stop_gift_slots"
MIN_SHOP_STOP_GIFT_SLOTS = 0
DEFAULT_SHOP_STOP_GIFT_SLOTS = 1
MAX_SHOP_STOP_GIFT_SLOTS = 8
# 商店设置「优先购买未记录饰品」：名字不在饰品图鉴里的商品也购买，默认关闭。
SHOP_UNRECORDED_KEY = "shop_buy_unrecorded_gifts"
DEFAULT_SHOP_UNRECORDED = False
# 商店三个自动动作开关（默认全部开启，保持原有行为）：工作流按这些键跳过对应动作，其余流程不变。
# 技能替换＝自动购买技能替换商品；购买饰品＝自动购买本队流派／优先获取的饰品；
# 融合饰品＝购买循环结束后在商店执行一次 Fuse Gifts。
SHOP_SKILL_REPLACE_KEY = "shop_skill_replace"
SHOP_BUY_GIFTS_KEY = "shop_buy_gifts"
SHOP_FUSE_GIFTS_KEY = "shop_fuse_gifts"
DEFAULT_SHOP_SWITCH = True
SHOP_SWITCHES = (
    (SHOP_SKILL_REPLACE_KEY, "技能替换", "Skill replace",
     "打开后按「队伍配置」自动购买技能替换商品；关闭后不再打开技能替换弹窗，商店里只处理饰品。",
     "When enabled, skill replacements configured per team are bought automatically; when off, "
     "no replace popup is opened and only gifts are handled."),
    (SHOP_BUY_GIFTS_KEY, "购买饰品", "Buy gifts",
     "打开后按队伍流派与「饰品配置」自动购买饰品；关闭后不再点开饰品商品，也不为找饰品刷新。",
     "When enabled, gifts are bought by team archetype and gift preferences; when off, gift "
     "offers are neither opened nor refreshed for."),
    (SHOP_FUSE_GIFTS_KEY, "融合饰品", "Fuse gifts",
     "打开后购买结束仍会在商店执行一次 Fuse Gifts；关闭后跳过融合，直接做饰品自维护并离开商店。",
     "When enabled, one Fuse Gifts pass runs after buying; when off, fusion is skipped and the "
     "shop is left right after the gift self-maintenance."),
)
SHOP_GIFTS_KEY = "shop_gifts"
THEME_PACKS_KEY = "theme_packs"
# 主题包目录：列表完全由素材库镜像 mirror/theme_pack/<名字> 派生，页面不读也不写任何页面资源；
# 主题包的名字就是素材目录名，没有额外的名称标签，页面搜索与工作流都只按这个名字匹配
THEME_PACK_ASSET_GROUP = "mirror/theme_pack"
# 选择偏好按素材逻辑名保存，与饰品的获取偏好同一套做法
THEME_PACK_PREFERENCES_KEY = "preferences"
THEME_PACK_PREFERENCES = (
    ("default", "默认选择", "Default"),
    ("prefer", "优先选择", "Prioritize"),
    ("avoid", "尽量不选", "Avoid if possible"),
)
THEME_PACK_PREFERENCE_DEFAULT = "default"
# 卡片固定三列；首屏只建一批，真正划到底部才补下一批，封面在创建卡片时读取
THEME_PACK_COLUMNS = 3
THEME_PACK_BATCH = 12
# 封面显示尺寸（等比缩放）
THEME_PACK_COVER_WIDTH = 140
THEME_PACK_COVER_HEIGHT = 230

# 饰品获取偏好：「优先获取」用于商店里优先买入，「优先消耗」用于优先消耗掉，其余按默认处理。
# 键是素材逻辑名（mirror/gift/<流派>/<名字>），工作流按同一个 id 读取。
GIFT_PREFERENCES = (
    ("prefer", "优先获取", "Prioritize"),
    ("default", "默认获取", "Default"),
    ("consume", "优先消耗", "Consume first"),
)
GIFT_PREFERENCE_DEFAULT = "default"
GIFT_PREFERENCE_KEY = "preferences"
# 饰品目录：列表完全由素材库镜像 mirror/gift/<流派>/<名字> 派生，页面不读也不写页面资源；
# 饰品的名字就是素材目录名，页面与工作流都只按这个名字匹配，没有额外的名称标签
GIFT_ASSET_GROUP = "mirror/gift"
# 饰品列表分批渲染：首屏只建 20 行，真正划到列表底部才补下一批（一次到底只补一批）
GIFT_PAGE_SIZE = 20
# 行图标尺寸与缺图行右侧饰品图的尺寸：缺图行把图标左端留给黄色三角形「！」，其余行（含多图候选）铺满
GIFT_ICON_SIZE = 48
GIFT_ART_SIZE = 32
# 流派目录名 → 中文显示名（页面显示用，不影响工作流判断）
GIFT_KEYWORDS_ZH = {
    "bleed": "流血", "burn": "燃烧", "rupture": "破裂", "poise": "呼吸法",
    "tremor": "震颤", "blunt": "打击", "pierce": "突刺", "slash": "斩击",
    "charge": "充能", "sinking": "沉沦", "sink": "沉沦",
    "keywordless": "泛用", "vestige": "痕迹",
}

# 楼层 Acquire E.G.O Gift 页的 Mounting Trials debuff 规避顺序：
# 越靠前的 debuff 越先被规避——工作流先点带它的卡片，再用后面的点击把选择覆盖下去。
# 存储的是游戏内英文关键词原文（设置键 floor_gift_debuffs），
# 工作流按「去掉空白与符号、转小写」的规则匹配卡片上的 trial 文字。
FLOOR_DEBUFFS_KEY = "floor_gift_debuffs"
# 规避顺序的最大条数：只用于限制数据量，不参与业务判断
FLOOR_DEBUFFS_MAX = 24
# 已知的 trial debuff：第一项是英文关键词（存储值），后两项只用于本页显示
FLOOR_DEBUFF_CATALOG = (
    ("coin power", "硬币威力（Coin Power）", "Coin Power"),
    ("clash power", "拼点威力（Clash Power）", "Clash Power"),
    ("base power", "基础威力（Base Power）", "Base Power"),
    ("offense level", "攻击等级（Offense Level）", "Offense Level"),
    ("damage dealt", "造成伤害（Damage Dealt）", "Damage Dealt"),
    ("damage taken", "承受伤害（Damage Taken）", "Damage Taken"),
    ("defense level", "防御等级（Defense Level）", "Defense Level"),
    ("max hp", "最大生命（Max HP）", "Max HP"),
)
# 默认规避顺序：沿用原先硬编码的 Coin Power → Clash Power → Base Power → Offense Level，
# 后面追加 Damage Dealt → Damage Taken → Defense Level → Max HP
FLOOR_DEBUFFS_DEFAULT = tuple(keyword for keyword, _, _ in FLOOR_DEBUFF_CATALOG)

# 寻路节点权重：七类节点分数（0-99，允许同分）与从相邻行进入时的成本系数；
# 三列寻路按节点分数之和比较第一列各候选，分数越低越优先。
PATH_WEIGHTS_KEY = "path_node_weights"
PATH_WEIGHT_KEYS = ("shop", "event", "regular", "elite", "focused", "abnormality", "boss")
PATH_WEIGHT_LABELS = {
    "shop": ("商店（shop）", "Shop"),
    "event": ("事件（event）", "Event"),
    "regular": ("普通遭遇（regular encounter）", "Regular Encounter"),
    "elite": ("精英遭遇（elite encounter）", "Elite Encounter"),
    "focused": ("集中遭遇（focused encounter）", "Focused Encounter"),
    "abnormality": ("异想体遭遇（abnormality encounter）", "Abnormality Encounter"),
    "boss": ("首领（boss）", "Boss"),
}
PATH_WEIGHT_DEFAULTS = {
    "shop": 0,
    "event": 1,
    "regular": 3,
    "elite": 6,
    "focused": 9,
    "abnormality": 15,
    "boss": 15,
}
PATH_WEIGHT_MIN = 0
PATH_WEIGHT_MAX = 99
PATH_INTERLEAVE_DEFAULT = 1.5
PATH_INTERLEAVE_MIN = 0.5
PATH_INTERLEAVE_MAX = 10.0

# 星光强化每张卡两个独立维度：档位（x=0 / +=1 / ++=2）与启用对勾；
# 重复点击已生效的 + / ++ 只把档位退回 0，不改动对勾与 x；
# x 与对勾重复点击不会取消，整体取消统一走 x；
# 档位沿用旧字段 star_levels，启用状态另存 star_selected，旧配置没有该字段时按档位 > 0 推断
STAR_LEVELS_KEY = "star_levels"
STAR_ENABLED_KEY = "star_selected"
# 星光卡片排列：固定两行、每行 5 张
STAR_COLUMNS = 5

# 键按游戏卡片从左至右、从上至下固定，图片编号与用户提供的资源一致。
STAR_CARDS = (
    ("star_of_the_beginning", "起始之星", "Star of the Beginning"),
    ("cumulating_starcloud", "积聚星云", "Cumulating Starcloud"),
    ("interstellar_travel", "星际旅行", "Interstellar Travel"),
    ("star_shower", "流星雨", "Star-shower"),
    ("binary_star_shop", "双星商店", "Binary Star-shop"),
    ("moon_star_shop", "月星商店", "Moon Star-shop"),
    ("favor_of_the_nebulae", "星云眷顾", "Favor of the Nebulae"),
    ("starlight_guidance", "星光指引", "Starlight Guidance"),
    ("chance_comet", "机遇彗星", "Chance Comet"),
    ("perfected_possibility", "完美可能性", "Perfected Possibility"),
)


def _restore_star_levels(raw):
    """仅接受已知卡片的整数目标档位；旧配置默认全部不选。"""
    raw = raw if isinstance(raw, dict) else {}
    return {key: raw[key] if type(raw.get(key)) is int and raw[key] in (0, 1, 2) else 0
            for key, _, _ in STAR_CARDS}


def _restore_star_enabled(raw, levels):
    """读取对勾（启用）状态：只接受已知卡片键；旧配置没有该字段时按档位 > 0 推断。"""
    if isinstance(raw, list):
        known = {key for key, _, _ in STAR_CARDS}
        return {str(item) for item in raw if str(item) in known}
    return {key for key, level in levels.items() if level > 0}


def _restore_settlement_rules(raw):
    """只接受 victory／defeat／unknown 三个条件的已知取值；缺失或非法时按各自默认值处理。"""
    raw = raw if isinstance(raw, dict) else {}
    restored = {}
    for key, _, _, default in SETTLEMENT_CONDITIONS:
        value = str(raw.get(key) or "").strip().lower()
        restored[key] = value if value in ("claim", "give_up") else default
    return restored


def _restore_shop_cost(raw) -> int:
    """读取商店刷新使用的 Cost 阈值；缺失、非法、低于下限或越界时退回 300。"""
    text = str(raw if raw is not None else DEFAULT_SHOP_COST).strip()
    if not text.isdigit():
        return DEFAULT_SHOP_COST
    cost = int(text)
    return cost if MIN_SHOP_COST <= cost <= MAX_SHOP_COST else DEFAULT_SHOP_COST


def _restore_shop_stop_gift_slots(raw) -> int:
    """读取「停止刷新的剩余饰品栏位」；缺失、非非负整数或超出上限时按默认值 1 处理。"""
    text = str(raw if raw is not None else DEFAULT_SHOP_STOP_GIFT_SLOTS).strip()
    if not text.isdigit():
        return DEFAULT_SHOP_STOP_GIFT_SLOTS
    slots = int(text)
    return (
        slots
        if MIN_SHOP_STOP_GIFT_SLOTS <= slots <= MAX_SHOP_STOP_GIFT_SLOTS
        else DEFAULT_SHOP_STOP_GIFT_SLOTS
    )


def _restore_shop_unrecorded(raw) -> bool:
    """读取「优先购买未记录饰品」开关；只接受布尔值，缺失或非法时按关闭处理。"""
    return raw if isinstance(raw, bool) else DEFAULT_SHOP_UNRECORDED


def _restore_shop_switch(raw) -> bool:
    """读取商店自动动作开关；只接受布尔值，缺失或非法时按开启处理（保持原有行为）。"""
    return raw if isinstance(raw, bool) else DEFAULT_SHOP_SWITCH


def _restore_gift_preferences(raw):
    """只接受三个已知取值；缺失或非法的条目直接忽略，取值时回退默认获取。"""
    raw = raw if isinstance(raw, dict) else {}
    allowed = {value for value, _, _ in GIFT_PREFERENCES}
    return {str(key): str(value) for key, value in raw.items() if str(value) in allowed}


def _restore_theme_pack_preferences(raw):
    """只接受三个已知取值；旧配置里的名称标签与固定 id 图鉴一律丢弃。"""
    raw = raw if isinstance(raw, dict) else {}
    allowed = {value for value, _, _ in THEME_PACK_PREFERENCES}
    return {str(key): str(value) for key, value in raw.items() if str(value) in allowed}


def _choice_index(mode: str) -> int:
    """返回结算处理方式对应的下拉序号，未知值退回第一条。"""
    for index, (value, _, _) in enumerate(REWARD_MODES):
        if value == mode:
            return index
    return 0


def _team_name(context, team: int) -> str:
    """队伍显示名，与「队伍配置」页保持一致（队伍 1 ~ 队伍 40）。"""
    return context.translate(f"队伍 {team}", f"Team {team}")


def _team_number(value) -> int:
    """把配置里的队伍值转成 1~MAX_TEAMS 的整数，非法值返回 0。"""
    text = str(value).strip()
    if not text.isdigit():
        return 0
    team = int(text)
    return team if 1 <= team <= MAX_TEAMS else 0


def _debuff_key(text) -> str:
    """把 debuff 关键词规范成可比较形式：去掉空白与符号并转小写，与工作流匹配规则一致。"""
    return re.sub(r"[^a-z0-9]", "", str(text).lower())


def _restore_floor_debuffs(raw) -> list[str]:
    """
    读取楼层饰品的 debuff 规避顺序：按原顺序去重，只保留能规范化出内容的条目。
    字段缺失（旧配置）时用默认顺序；显式保存的空列表表示不规避任何 debuff。
    """
    if not isinstance(raw, list):
        return list(FLOOR_DEBUFFS_DEFAULT)
    restored: list[str] = []
    keys = set()
    for item in raw:
        text = str(item).strip()
        key = _debuff_key(text)
        if not key or key in keys:
            continue
        keys.add(key)
        restored.append(text)
    return restored[:FLOOR_DEBUFFS_MAX]


def _restore_path_weights(raw) -> dict:
    """读取寻路节点权重与可能交错线路成本；缺失或非法值逐项回落默认值。"""
    raw = raw if isinstance(raw, dict) else {}
    saved = raw.get("weights") if isinstance(raw.get("weights"), dict) else {}
    weights = {}
    for kind in PATH_WEIGHT_KEYS:
        value = saved.get(kind)
        weights[kind] = (
            value
            if isinstance(value, int) and not isinstance(value, bool)
            and PATH_WEIGHT_MIN <= value <= PATH_WEIGHT_MAX
            else PATH_WEIGHT_DEFAULTS[kind]
        )
    cost = raw.get("interleave_cost")
    cost = (
        float(cost)
        if isinstance(cost, (int, float)) and not isinstance(cost, bool)
        and PATH_INTERLEAVE_MIN <= float(cost) <= PATH_INTERLEAVE_MAX
        else PATH_INTERLEAVE_DEFAULT
    )
    return {"weights": weights, "interleave_cost": cost}


def _path_weight_name(context, kind) -> str:
    """节点类型的中英文显示名；未知类型直接显示键名。"""
    zh, en = PATH_WEIGHT_LABELS.get(kind, (kind, kind))
    return context.translate(zh, en)


def _debuff_label(context, keyword) -> str:
    """已知 debuff 显示中英文名，自定义关键词直接显示原文。"""
    key = _debuff_key(keyword)
    for catalog_keyword, zh, en in FLOOR_DEBUFF_CATALOG:
        if _debuff_key(catalog_keyword) == key:
            return context.translate(zh, en)
    return str(keyword).strip()


def _caption_color() -> str:
    """次要文字颜色，跟随主题，避免深色/浅色主题下看不清。"""
    return "#b8a98e" if isDarkTheme() else "#6b5f4b"


def _card_style() -> str:
    """主页队伍卡片样式：浅色主题用浅底深字，深色主题用深底浅字。"""
    if isDarkTheme():
        return (
            "QFrame#mirrorTeamCard { border: 1px solid #4a4034; border-radius: 10px;"
            " background-color: #1d1712; }"
        )
    return (
        "QFrame#mirrorTeamCard { border: 1px solid #ded3bf; border-radius: 10px;"
        " background-color: #fbf7ef; }"
    )


def _chip_style() -> str:
    """已选队伍徽章样式（圆角小标签）。"""
    if isDarkTheme():
        return (
            "QLabel { background-color: #2e2618; color: #ecdfc4; border: 1px solid #5a4a33;"
            " border-radius: 11px; padding: 2px 10px; font-size: 12px; }"
        )
    return (
        "QLabel { background-color: #f0e8d8; color: #2f2619; border: 1px solid #ddceb2;"
        " border-radius: 11px; padding: 2px 10px; font-size: 12px; }"
    )


def _list_style() -> str:
    """弹窗内两个列表的样式：边框加圆角，行高略微放大，列表本身可滚动。"""
    if isDarkTheme():
        return (
            "QListWidget { border: 1px solid #4a4034; border-radius: 8px;"
            " background-color: #17130f; }"
            "QListWidget::item { padding: 5px 8px; }"
            "QListWidget::item:selected { background-color: #3a2d1a; color: #ffe9b5; }"
        )
    return (
        "QListWidget { border: 1px solid #ded3bf; border-radius: 8px;"
        " background-color: #ffffff; }"
        "QListWidget::item { padding: 5px 8px; }"
        "QListWidget::item:selected { background-color: #e9dec9; color: #2f2619; }"
    )


def _labels_list(value) -> list[str]:
    """把标签字段统一成列表：旧页面存的是 {语言: 名字} 映射，当前存的是列表。"""
    if isinstance(value, dict):
        value = [value.get(language, "") for language in ("en", "zh", "ja")]
    if not isinstance(value, list):
        return []
    return [str(label).strip() for label in value if str(label).strip()]


def _gift_label_key(text) -> str:
    """统一全半角、大小写、空格和符号，保留各语言文字。"""
    return "".join(c for c in unicodedata.normalize("NFKC", str(text)).casefold() if c.isalnum())


def _gift_keyword_key(archetype) -> str:
    """沉沦的静态目录名与页面流派键归为同一流派。"""
    key = str(archetype).casefold()
    return "sinking" if key == "sink" else key


def _gift_names(entry) -> list[str]:
    """返回一件饰品的名字：素材目录名，没有额外的名称标签。"""
    name = str(entry.get("name") or "").strip()
    return [name] if name else []


def _unique_hashes(hashes) -> list[str]:
    """按素材库返回的顺序去重：第一张就是列表与详情里默认显示的那张图。"""
    ordered: list[str] = []
    for digest in hashes or []:
        text = str(digest)
        if text and text not in ordered:
            ordered.append(text)
    return ordered


def _paint_warning_mark(painter: QPainter) -> None:
    """在图标左端画黄色三角形「！」：只在缺图行显示，多图候选不画警告符号。"""
    triangle = QPainterPath()
    triangle.moveTo(7.0, 1.2)
    triangle.lineTo(14.0, 14.2)
    triangle.lineTo(0.0, 14.2)
    triangle.closeSubpath()
    painter.setPen(QPen(QColor("#8a5a00"), 1.0))
    painter.setBrush(QColor("#f5c542"))
    painter.drawPath(triangle)
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QColor("#3a2a06"))
    painter.drawRoundedRect(QRectF(6.1, 5.2, 1.8, 4.8), 0.9, 0.9)
    painter.drawEllipse(QRectF(6.1, 11.0, 1.8, 1.8))


class TeamPickerDialog(QDialog):
    """双栏队伍选择器：左侧可用队伍（可搜索、点击勾选），右侧已选队伍（可拖拽排序）。"""

    def __init__(self, context, selected, parent=None):
        super().__init__(parent)
        self._context = context
        self._teams: list[int] = list(selected)
        self.setWindowTitle(context.translate("选择队伍", "Select teams"))
        self.setMinimumSize(760, 560)
        self._build_ui()
        self._render_available()
        for team in self._teams:
            self._append_order_item(team)
        self._sync_from_order()

    # ---------- 构建界面 ----------
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(10)

        head = QHBoxLayout()
        title = BodyLabel(
            self._context.translate(
                "选择参与镜牢的队伍，并调整使用顺序", "Pick teams for Mirror Dungeons and set the order"
            )
        )
        head.addWidget(title, 1)
        self._counter = QLabel("")
        self._counter.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        head.addWidget(self._counter, 0)
        root.addLayout(head)

        columns = QHBoxLayout()
        columns.setSpacing(14)
        columns.addLayout(self._build_available_column(), 1)
        columns.addLayout(self._build_order_column(), 1)
        root.addLayout(columns, 1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        cancel = PushButton(self._context.translate("取消", "Cancel"))
        cancel.clicked.connect(self.reject)
        footer.addWidget(cancel)
        confirm = PrimaryPushButton(self._context.translate("确定", "OK"))
        confirm.clicked.connect(self.accept)
        footer.addWidget(confirm)
        root.addLayout(footer)

    def _build_available_column(self):
        """左栏：可用队伍，搜索框 + 可滚动列表，点击行即勾选/取消。"""
        column = QVBoxLayout()
        column.setSpacing(6)
        column.addWidget(BodyLabel(self._context.translate("可用队伍", "Available teams")))
        self._search = LineEdit(self)
        self._search.setPlaceholderText(
            self._context.translate("按编号或名称搜索…", "Search by number or name…")
        )
        self._search.textChanged.connect(self._render_available)
        column.addWidget(self._search)

        self._available_list = QListWidget(self)
        self._available_list.setStyleSheet(_list_style())
        self._available_list.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self._available_list.setMinimumHeight(360)
        self._available_list.itemClicked.connect(self._toggle_team)
        column.addWidget(self._available_list, 1)

        hint = QLabel(
            self._context.translate(
                "点击队伍即加入右侧；再次点击取消。",
                "Click a team to add it on the right; click again to remove it.",
            )
        )
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        column.addWidget(hint)
        return column

    def _build_order_column(self):
        """右栏：已选队伍，按使用顺序展示，可拖拽、上移/下移、移除或清空。"""
        column = QVBoxLayout()
        column.setSpacing(6)

        head = QHBoxLayout()
        head.addWidget(
            BodyLabel(self._context.translate("已选队伍（循环设置）", "Selected teams (configured cycle)"))
        )
        head.addStretch(1)
        self._clear_button = PushButton(self._context.translate("清空", "Clear"))
        self._clear_button.clicked.connect(self._clear_all)
        head.addWidget(self._clear_button)
        column.addLayout(head)

        self._order_list = QListWidget(self)
        self._order_list.setStyleSheet(_list_style())
        self._order_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._order_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self._order_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self._order_list.setDropIndicatorShown(True)
        self._order_list.setMinimumHeight(360)
        self._order_list.model().rowsMoved.connect(self._on_rows_moved)
        self._order_list.currentRowChanged.connect(self._update_buttons)
        column.addWidget(self._order_list, 1)

        buttons = QHBoxLayout()
        buttons.setSpacing(6)
        self._up_button = PushButton(self._context.translate("↑ 上移", "↑ Up"))
        self._up_button.clicked.connect(lambda: self._move_current(-1))
        buttons.addWidget(self._up_button)
        self._down_button = PushButton(self._context.translate("↓ 下移", "↓ Down"))
        self._down_button.clicked.connect(lambda: self._move_current(1))
        buttons.addWidget(self._down_button)
        self._remove_button = PushButton(self._context.translate("移除", "Remove"))
        self._remove_button.clicked.connect(self._remove_current)
        buttons.addWidget(self._remove_button)
        buttons.addStretch(1)
        column.addLayout(buttons)

        hint = QLabel(
            self._context.translate(
                "可直接拖拽调整顺序，或用上移/下移精调；移除只影响本次镜牢使用顺序。",
                "Drag to reorder, or fine-tune with Up/Down. Removing only affects this mirror run order.",
            )
        )
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        column.addWidget(hint)
        return column

    # ---------- 左栏：可用队伍 ----------
    def _available_text(self, team: int) -> str:
        """左侧一行文字：已选队伍前面带勾选标记，未选留出同样宽度。"""
        marker = "✓" if team in self._teams else "　"
        return f"{marker}  {_team_name(self._context, team)}"

    def _matches_query(self, team: int, query: str) -> bool:
        """按编号或名称匹配：纯数字按编号包含匹配，其余按中英文名称匹配。"""
        if not query:
            return True
        if query.isdigit():
            return query in str(team)
        name = _team_name(self._context, team).lower()
        return query in name or query in str(team)

    def _style_available_item(self, item: QListWidgetItem, selected: bool) -> None:
        """已选队伍加粗，配合勾选标记一起表示选中状态。"""
        font = item.font()
        font.setBold(selected)
        item.setFont(font)

    def _render_available(self, *args):
        """按搜索词重建左侧列表；搜索变化时滚动位置可以回到顶部。"""
        query = self._search.text().strip().lower()
        self._available_list.clear()
        for team in range(1, MAX_TEAMS + 1):
            if not self._matches_query(team, query):
                continue
            item = QListWidgetItem(self._available_text(team))
            item.setData(Qt.ItemDataRole.UserRole, team)
            self._style_available_item(item, team in self._teams)
            self._available_list.addItem(item)

    def _refresh_available_marks(self):
        """只刷新左侧文字的勾选标记，不重建列表，保持滚动位置。"""
        for row in range(self._available_list.count()):
            item = self._available_list.item(row)
            team = int(item.data(Qt.ItemDataRole.UserRole))
            item.setText(self._available_text(team))
            self._style_available_item(item, team in self._teams)

    def _toggle_team(self, item: QListWidgetItem):
        """点击左侧队伍：未选则追加到执行顺序末尾，已选则从右侧移除。"""
        team = int(item.data(Qt.ItemDataRole.UserRole))
        if team in self._teams:
            row = self._order_row(team)
            if row >= 0:
                self._order_list.takeItem(row)
        else:
            self._append_order_item(team)
        self._sync_from_order()

    # ---------- 右栏：已选队伍 ----------
    def _append_order_item(self, team: int):
        """把一个队伍追加到右侧列表末尾，序号由 _renumber_order 统一刷新。"""
        item = QListWidgetItem(_team_name(self._context, team))
        item.setData(Qt.ItemDataRole.UserRole, team)
        self._order_list.addItem(item)

    def _order_row(self, team: int) -> int:
        """返回队伍在右侧列表中的行号，找不到返回 -1。"""
        for row in range(self._order_list.count()):
            if int(self._order_list.item(row).data(Qt.ItemDataRole.UserRole)) == team:
                return row
        return -1

    def _renumber_order(self):
        """按当前行序刷新「1. 队伍 N」前缀。"""
        for row in range(self._order_list.count()):
            item = self._order_list.item(row)
            team = int(item.data(Qt.ItemDataRole.UserRole))
            item.setText(f"{row + 1}. {_team_name(self._context, team)}")

    def _on_rows_moved(self, *args):
        """拖拽完成后延后同步，避免在模型移动过程中改文字。"""
        QTimer.singleShot(0, self._sync_from_order)

    def _move_current(self, delta: int):
        """把当前行上移或下移一位并保持选中。"""
        row = self._order_list.currentRow()
        target = row + delta
        if row < 0 or not 0 <= target < self._order_list.count():
            return
        item = self._order_list.takeItem(row)
        self._order_list.insertItem(target, item)
        self._order_list.setCurrentRow(target)
        self._sync_from_order()

    def _remove_current(self):
        """移除右侧当前选中的队伍。"""
        row = self._order_list.currentRow()
        if row < 0:
            return
        self._order_list.takeItem(row)
        if self._order_list.count():
            self._order_list.setCurrentRow(min(row, self._order_list.count() - 1))
        self._sync_from_order()

    def _clear_all(self):
        """清空已选队伍，左侧勾选状态同步取消。"""
        if self._order_list.count() == 0:
            return
        self._order_list.clear()
        self._sync_from_order()

    def _sync_from_order(self):
        """以右侧列表的实际顺序为准，同步已选队伍、序号、计数与按钮可用状态。"""
        self._teams = [
            int(self._order_list.item(row).data(Qt.ItemDataRole.UserRole))
            for row in range(self._order_list.count())
        ]
        self._renumber_order()
        self._refresh_available_marks()
        self._counter.setText(
            self._context.translate(
                f"{len(self._teams)} / {MAX_TEAMS} 已选择", f"{len(self._teams)} / {MAX_TEAMS} selected"
            )
        )
        self._update_buttons()

    def _update_buttons(self, *args):
        """按当前行位置决定上移/下移/移除/清空是否可用。"""
        row = self._order_list.currentRow()
        count = self._order_list.count()
        self._up_button.setEnabled(row > 0)
        self._down_button.setEnabled(0 <= row < count - 1)
        self._remove_button.setEnabled(row >= 0)
        self._clear_button.setEnabled(count > 0)

    def selected_teams(self) -> list[int]:
        """返回用户确认后的有序队伍列表。"""
        return list(self._teams)


class FloorDebuffDialog(QDialog):
    """楼层饰品 debuff 规避顺序：左侧候选（已知 debuff 与自定义关键词），右侧按优先顺序排列。

    右侧列表的顺序就是工作流的点击依据：越靠前越先点带该 debuff 的卡片，让后面的点击覆盖下去。
    只有点「确定」才采用新顺序，取消或关闭保持页面原配置。
    """

    def __init__(self, context, selected, parent=None):
        super().__init__(parent)
        self._context = context
        self._selected: list[str] = [str(item) for item in selected]
        self.setWindowTitle(context.translate("debuff 规避顺序", "Debuff avoidance order"))
        self.setMinimumSize(720, 540)
        self._build_ui()
        for keyword in self._selected:
            self._append_item(keyword)
        self._sync_from_order()

    # ---------- 构建界面 ----------
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(10)

        title = BodyLabel(
            self._context.translate(
                "越靠前的 debuff 越先被规避：工作流先点带它的卡片，再用后面的点击覆盖选择。",
                "Debuffs higher in the list are avoided first: the workflow clicks those cards first, "
                "then overwrites the choice with later clicks.",
            )
        )
        title.setWordWrap(True)
        root.addWidget(title)

        columns = QHBoxLayout()
        columns.setSpacing(14)
        columns.addLayout(self._build_available_column(), 1)
        columns.addLayout(self._build_order_column(), 1)
        root.addLayout(columns, 1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        cancel = PushButton(self._context.translate("取消", "Cancel"))
        cancel.clicked.connect(self.reject)
        footer.addWidget(cancel)
        confirm = PrimaryPushButton(self._context.translate("确定", "OK"))
        confirm.clicked.connect(self.accept)
        footer.addWidget(confirm)
        root.addLayout(footer)

    def _build_available_column(self):
        """左栏：已知 debuff 列表（点击加入右侧）+ 自定义关键词输入框。"""
        column = QVBoxLayout()
        column.setSpacing(6)
        column.addWidget(BodyLabel(self._context.translate("可用的 debuff", "Available debuffs")))
        self._search = LineEdit(self)
        self._search.setPlaceholderText(self._context.translate("搜索…", "Search…"))
        self._search.textChanged.connect(self._render_available)
        column.addWidget(self._search)

        self._available_list = QListWidget(self)
        self._available_list.setStyleSheet(_list_style())
        self._available_list.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self._available_list.setMinimumHeight(300)
        self._available_list.itemClicked.connect(self._toggle_known)
        column.addWidget(self._available_list, 1)

        custom_row = QHBoxLayout()
        custom_row.setSpacing(6)
        self._custom = LineEdit(self)
        self._custom.setPlaceholderText(
            self._context.translate("自定义关键词（游戏内英文原文）", "Custom keyword (in-game English text)")
        )
        custom_row.addWidget(self._custom, 1)
        add = PushButton(self._context.translate("添加", "Add"))
        add.clicked.connect(self._add_custom)
        custom_row.addWidget(add)
        column.addLayout(custom_row)

        hint = QLabel(
            self._context.translate(
                "点击左侧 debuff 加入右侧；自定义关键词按游戏内英文原文填写，参与匹配的只有字母与数字。",
                "Click a debuff to add it on the right. Type custom keywords as they appear in game; "
                "only letters and digits take part in matching.",
            )
        )
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        column.addWidget(hint)
        return column

    def _build_order_column(self):
        """右栏：规避顺序，可拖拽、上移/下移、移除或清空。"""
        column = QVBoxLayout()
        column.setSpacing(6)

        head = QHBoxLayout()
        head.addWidget(
            BodyLabel(self._context.translate("规避顺序（越靠前越优先）", "Avoidance order (top first)"))
        )
        head.addStretch(1)
        self._clear_button = PushButton(self._context.translate("清空", "Clear"))
        self._clear_button.clicked.connect(self._clear_all)
        head.addWidget(self._clear_button)
        column.addLayout(head)

        self._order_list = QListWidget(self)
        self._order_list.setStyleSheet(_list_style())
        self._order_list.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self._order_list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self._order_list.setDefaultDropAction(Qt.DropAction.MoveAction)
        self._order_list.setDropIndicatorShown(True)
        self._order_list.setMinimumHeight(300)
        self._order_list.model().rowsMoved.connect(self._on_rows_moved)
        self._order_list.currentRowChanged.connect(self._update_buttons)
        column.addWidget(self._order_list, 1)

        buttons = QHBoxLayout()
        buttons.setSpacing(6)
        self._up_button = PushButton(self._context.translate("↑ 上移", "↑ Up"))
        self._up_button.clicked.connect(lambda: self._move_current(-1))
        buttons.addWidget(self._up_button)
        self._down_button = PushButton(self._context.translate("↓ 下移", "↓ Down"))
        self._down_button.clicked.connect(lambda: self._move_current(1))
        buttons.addWidget(self._down_button)
        self._remove_button = PushButton(self._context.translate("移除", "Remove"))
        self._remove_button.clicked.connect(self._remove_current)
        buttons.addWidget(self._remove_button)
        buttons.addStretch(1)
        column.addLayout(buttons)

        hint = QLabel(
            self._context.translate(
                "可直接拖拽调整顺序，或用上移/下移精调；清空后工作流不再规避任何 debuff。",
                "Drag to reorder or fine-tune with Up/Down. With an empty list the workflow avoids "
                "no debuff at all.",
            )
        )
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        column.addWidget(hint)
        return column

    # ---------- 左栏：可用 debuff ----------
    def _is_selected(self, keyword) -> bool:
        """按规范化后的关键词判断该项是否已在右侧顺序里。"""
        key = _debuff_key(keyword)
        return any(_debuff_key(item) == key for item in self._selected)

    def _render_available(self, *args):
        """按搜索词重建左侧候选；已加入右侧的候选加粗并带勾选标记。"""
        query = _debuff_key(self._search.text())
        self._available_list.clear()
        for keyword, zh, en in FLOOR_DEBUFF_CATALOG:
            name = self._context.translate(zh, en)
            if query and query not in _debuff_key(name) and query not in _debuff_key(keyword):
                continue
            chosen = self._is_selected(keyword)
            item = QListWidgetItem(f"{'✓' if chosen else '　'}  {name}")
            item.setData(Qt.ItemDataRole.UserRole, keyword)
            font = item.font()
            font.setBold(chosen)
            item.setFont(font)
            self._available_list.addItem(item)

    def _toggle_known(self, item: QListWidgetItem):
        """点击左侧已知 debuff：未加入则追加到顺序末尾，已加入则从右侧移除。"""
        keyword = str(item.data(Qt.ItemDataRole.UserRole))
        key = _debuff_key(keyword)
        for row in range(self._order_list.count()):
            if _debuff_key(self._order_list.item(row).data(Qt.ItemDataRole.UserRole)) == key:
                self._order_list.takeItem(row)
                self._sync_from_order()
                return
        if len(self._selected) < FLOOR_DEBUFFS_MAX:
            self._append_item(keyword)
        self._sync_from_order()

    def _add_custom(self):
        """追加一个自定义关键词；规范化后为空或已存在时忽略并清空输入框。"""
        text = self._custom.text().strip()
        if not _debuff_key(text) or self._is_selected(text) or len(self._selected) >= FLOOR_DEBUFFS_MAX:
            self._custom.clear()
            return
        self._append_item(text)
        self._custom.clear()
        self._sync_from_order()

    # ---------- 右栏：规避顺序 ----------
    def _append_item(self, keyword):
        """把一项加入右侧列表末尾，序号由 _renumber_order 统一刷新。"""
        item = QListWidgetItem(_debuff_label(self._context, keyword))
        item.setData(Qt.ItemDataRole.UserRole, str(keyword))
        self._order_list.addItem(item)

    def _renumber_order(self):
        """按当前行序刷新「1. 名称」前缀。"""
        for row in range(self._order_list.count()):
            item = self._order_list.item(row)
            item.setText(
                f"{row + 1}. {_debuff_label(self._context, item.data(Qt.ItemDataRole.UserRole))}"
            )

    def _on_rows_moved(self, *args):
        """拖拽完成后延后同步，避免在模型移动过程中改文字。"""
        QTimer.singleShot(0, self._sync_from_order)

    def _move_current(self, delta: int):
        """把当前行上移或下移一位并保持选中。"""
        row = self._order_list.currentRow()
        target = row + delta
        if row < 0 or not 0 <= target < self._order_list.count():
            return
        item = self._order_list.takeItem(row)
        self._order_list.insertItem(target, item)
        self._order_list.setCurrentRow(target)
        self._sync_from_order()

    def _remove_current(self):
        """移除右侧当前选中的一项。"""
        row = self._order_list.currentRow()
        if row < 0:
            return
        self._order_list.takeItem(row)
        if self._order_list.count():
            self._order_list.setCurrentRow(min(row, self._order_list.count() - 1))
        self._sync_from_order()

    def _clear_all(self):
        """清空规避顺序：表示不规避任何 debuff。"""
        if self._order_list.count() == 0:
            return
        self._order_list.clear()
        self._sync_from_order()

    def _sync_from_order(self):
        """以右侧列表的实际顺序为准，同步已选顺序、序号、左侧勾选与按钮可用状态。"""
        self._selected = [
            str(self._order_list.item(row).data(Qt.ItemDataRole.UserRole))
            for row in range(self._order_list.count())
        ]
        self._renumber_order()
        self._render_available()
        self._update_buttons()

    def _update_buttons(self, *args):
        """按当前行位置决定上移/下移/移除/清空是否可用。"""
        row = self._order_list.currentRow()
        count = self._order_list.count()
        self._up_button.setEnabled(row > 0)
        self._down_button.setEnabled(0 <= row < count - 1)
        self._remove_button.setEnabled(row >= 0)
        self._clear_button.setEnabled(count > 0)

    def selected_debuffs(self) -> list[str]:
        """返回用户确认后的规避顺序（英文关键词原文，可能为空列表）。"""
        return list(self._selected)


class PathWeightsDialog(QDialog):
    """寻路节点权重弹窗：七类节点分数 0-99（允许同分，按分数降序排列）与可能交错线路成本。"""

    def __init__(self, context, current, parent=None):
        super().__init__(parent)
        self._context = context
        restored = _restore_path_weights(current)
        self._weights = dict(restored["weights"])
        self._interleave = float(restored["interleave_cost"])
        self._pending_focus = None
        self.setWindowTitle(context.translate("寻路节点权重", "Path node weights"))
        self.setMinimumSize(620, 460)
        root = QVBoxLayout(self)
        root.setSpacing(8)
        intro = BodyLabel(
            context.translate(
                "分数越低越优先，允许同分；七行按当前分数降序排列。",
                "Lower scores are preferred and ties are allowed; rows are sorted by the current score "
                "in descending order.",
            )
        )
        intro.setWordWrap(True)
        root.addWidget(intro)
        self._rows_box = QVBoxLayout()
        self._rows_box.setSpacing(4)
        root.addLayout(self._rows_box)
        self._rows = []
        for kind in PATH_WEIGHT_KEYS:
            row = QWidget(self)
            layout = QHBoxLayout(row)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(BodyLabel(_path_weight_name(context, kind)), 1)
            spin = QSpinBox(row)
            spin.setRange(PATH_WEIGHT_MIN, PATH_WEIGHT_MAX)
            spin.setValue(self._weights[kind])
            spin.setFixedWidth(90)
            spin.valueChanged.connect(self._schedule_reorder)
            layout.addWidget(spin)
            self._rows.append((kind, row, spin))
        self._reorder()

        cost_row = QWidget(self)
        cost_layout = QHBoxLayout(cost_row)
        cost_layout.setContentsMargins(0, 0, 0, 0)
        cost_label = BodyLabel(
            context.translate(
                "可能交错线路成本（从相邻行进入时乘以该系数）",
                "Possible interleaved-route cost (multiplier when entering from an adjacent row)",
            )
        )
        cost_label.setWordWrap(True)
        self._cost = QDoubleSpinBox(cost_row)
        self._cost.setRange(PATH_INTERLEAVE_MIN, PATH_INTERLEAVE_MAX)
        self._cost.setSingleStep(0.1)
        self._cost.setDecimals(2)
        self._cost.setValue(self._interleave)
        self._cost.setFixedWidth(90)
        cost_layout.addWidget(cost_label, 1)
        cost_layout.addWidget(self._cost)
        root.addWidget(cost_row)

        note = BodyLabel(
            context.translate(
                "三列节点（下一列起）：相邻列同行与相邻行连通，跨两行不算路线。"
                "路径成本＝各节点分数之和，从相邻行进入的节点分数乘交错成本；"
                "比较第一列各节点各自最便宜的路，总成本低者优先。"
                "第一列只有一个节点时跳过规划直接点击，未出现确认弹窗则进入固定点保底。",
                "Three columns starting from the next column: same-row and adjacent-row links are "
                "connected, two-row jumps are not. Route cost is the sum of node scores, and entering "
                "from an adjacent row multiplies that node's score by the interleaved cost. The planner "
                "compares each first-column node's cheapest route and prefers the lowest total. With a "
                "single first-column node it skips comparison and clicks it directly; without the Enter "
                "prompt it falls back to fixed probe points.",
            )
        )
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        root.addWidget(note)
        root.addStretch(1)

        footer = QHBoxLayout()
        footer.addStretch(1)
        cancel = PushButton(context.translate("取消", "Cancel"))
        cancel.clicked.connect(self.reject)
        footer.addWidget(cancel)
        confirm = PrimaryPushButton(context.translate("确定", "OK"))
        confirm.clicked.connect(self.accept)
        footer.addWidget(confirm)
        root.addLayout(footer)

    def _schedule_reorder(self, *_):
        """分数变化后延迟重排，避免在 valueChanged 回调里移动控件。"""
        self._pending_focus = self.sender()
        QTimer.singleShot(0, self._reorder)

    def _reorder(self):
        """按当前分数降序排列七行；同分按固定类型顺序，并尽量保留输入焦点。"""
        ordered = sorted(
            self._rows,
            key=lambda item: (-item[2].value(), PATH_WEIGHT_KEYS.index(item[0])),
        )
        for index, (_, row, _) in enumerate(ordered):
            self._rows_box.insertWidget(index, row)
        focus = self._pending_focus
        self._pending_focus = None
        if focus is not None and focus.isVisible():
            focus.setFocus()

    def selected_weights(self) -> dict:
        """返回确认后的权重与交错成本；只有点「确定」才由调用方采用。"""
        return {
            "weights": {kind: int(spin.value()) for kind, _, spin in self._rows},
            "interleave_cost": float(self._cost.value()),
        }


class ShopGiftsPage(QWidget):
    """按素材库镜像 mirror/gift/<流派>/<名字> 展示饰品，并保存每件饰品的获取偏好。

    列表每次打开都直接从素材目录生成，不读也不写页面资源（gift-catalog 已不再使用）；
    饰品名字就是素材目录名，没有额外的名称标签，搜索与工作流匹配都只用这个名字。
    列表每次只建一批行，真正划到底部才补下一批；行图标固定取素材目录的第一张图。
    缺图（没有素材、读不出或校验不符）的行在图标最左端显示黄色三角形「！」；
    多图候选是正常状态，不画警告符号，只用文字说明，并可由「多图候选」筛选单独查看。
    """

    def __init__(self, context, config):
        super().__init__()
        self._context = context
        self._tr = context.translate
        config = config if isinstance(config, dict) else {}
        saved = config.get("catalog")
        # 旧配置里的图鉴快照：只用来把旧 id 的获取偏好按名字迁移到素材目录 id，不再用于名称
        self._saved = saved if isinstance(saved, dict) else {}
        self._preferences = _restore_gift_preferences(config.get(GIFT_PREFERENCE_KEY))
        self._legacy_ids = {}
        self._compact = None
        self._in_detail_dialog = False
        self._selected_images = {}
        self._preference_combos = {}
        self._items = {}
        self._image_states = {}
        self._asset_groups = {}
        self._issue = ""
        self._gifts = {}
        self._ordered = []
        self._matched = []
        self._rendered = 0
        self._appending = False
        self._built = False
        self._placeholder = QIcon()
        self._detail_gift = ""
        layout = QVBoxLayout(self)
        self._filters = QGridLayout()
        self._filters.setColumnStretch(0, 1)
        self._search = LineEdit()
        self._search.setPlaceholderText(self._tr("搜索饰品名字", "Search gift names"))
        self._search.setAccessibleName(self._search.placeholderText())
        self._archetype = ComboBox()
        self._archetype.setAccessibleName(self._tr("流派筛选", "Archetype filter"))
        self._multi_only = CheckBox(self._tr("多图候选", "Multi-candidate"))
        self._missing_only = CheckBox(self._tr("只看缺图", "Missing images only"))
        self._refresh_button = PushButton(self._tr("刷新列表", "Refresh list"))
        self._layout_filters()
        layout.addLayout(self._filters)

        hint = BodyLabel(
            self._tr(
                "饰品列表完全来自素材库镜像 mirror/gift/<流派>/<名字>：在素材库存一张图就会自动出现在这里，"
                "不依赖任何页面资源。饰品名字就是素材目录名，没有额外的名称标签，搜索只按这个名字匹配。"
                "列表每次只建一批，划到底部再加载下一批；"
                "同一饰品存了多张图就是「多图候选」，属于正常状态，不画警告符号，默认使用第一张；"
                "缺图（没有素材、读不出或校验不符）的行才会在图标最左端显示黄色三角形「！」。"
                "两个筛选项可以单独勾选，同时勾选时显示两类行。",
                "The list comes straight from the asset library folder mirror/gift/<archetype>/<name>: "
                "saving an image there makes it appear here, with no page resource involved. The gift "
                "name is that folder name, with no extra name labels, and the search matches that name "
                "only. Rows are built in batches and more are added only when you reach the bottom; "
                "several images for one gift are a normal multi-candidate state with no warning mark, "
                "and the first image is used by default. Only a missing, unreadable or mismatched "
                "image shows the yellow triangle at the far left of its icon. Either filter can be "
                "ticked alone; with both ticked, rows of both kinds are listed.",
            )
        )
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        layout.addWidget(hint)

        self._list = QTreeWidget()
        self._list.setAccessibleName(self._tr("饰品列表", "Gift list"))
        self._list.setRootIsDecorated(False)
        self._list.setUniformRowHeights(True)
        self._list.setIconSize(QSize(GIFT_ICON_SIZE, GIFT_ICON_SIZE))
        self._list.setHeaderLabels([self._tr("饰品", "Gift"), self._tr("流派", "Archetype"),
                                    self._tr("获取偏好", "Acquisition")])
        self._list.header().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self._list.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self._list.header().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self._list.header().setStretchLastSection(False)
        self._split = QSplitter(Qt.Orientation.Horizontal)
        self._split.setChildrenCollapsible(False)
        self._split.addWidget(self._list)
        self._detail = self._create_detail()
        self._split.addWidget(self._detail)
        self._split.setStretchFactor(0, 3)
        self._split.setStretchFactor(1, 2)
        self._split.setSizes([450, 300])
        layout.addWidget(self._split, 1)

        self._count = BodyLabel()
        layout.addWidget(self._count)
        self._search.textChanged.connect(self._filter)
        self._archetype.currentIndexChanged.connect(self._filter)
        self._multi_only.toggled.connect(self._filter)
        self._missing_only.toggled.connect(self._filter)
        self._list.currentItemChanged.connect(self._sync_detail)
        self._list.itemClicked.connect(self._open_compact_detail)
        self._list.itemActivated.connect(self._open_compact_detail)
        # 真正划到列表底部时才补下一批行，避免一次性创建全部饰品行
        self._list.verticalScrollBar().valueChanged.connect(self._on_scroll)
        self._refresh_button.clicked.connect(self._refresh)
        # 首次构建推迟到 showEvent：设置弹窗打开时不再预先解码全部图标

    def _layout_filters(self):
        """窄窗口把搜索移到独立一行，保留全部筛选入口。"""
        widgets = (
            self._search,
            self._archetype,
            self._multi_only,
            self._missing_only,
            self._refresh_button,
        )
        for widget in widgets:
            self._filters.removeWidget(widget)
        if self._compact:
            self._filters.addWidget(self._search, 0, 0, 1, 4)
            for column, widget in enumerate(widgets[1:]):
                self._filters.addWidget(widget, 1, column)
        else:
            for column, widget in enumerate(widgets):
                self._filters.addWidget(widget, 0, column)

    def _create_detail(self):
        """构建可以在分栏和窄窗口详情弹窗之间复用的详情。"""
        detail = QScrollArea()
        detail.setWidgetResizable(True)
        detail.setMinimumWidth(225)
        body = QWidget()
        detail.setWidget(body)
        layout = QVBoxLayout(body)
        self._detail_title = BodyLabel()
        self._detail_title.setTextFormat(Qt.TextFormat.PlainText)
        self._detail_title.setWordWrap(True)
        layout.addWidget(self._detail_title)
        self._detail_status = BodyLabel()
        self._detail_status.setWordWrap(True)
        layout.addWidget(self._detail_status)

        self._preview = QLabel()
        self._preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._preview.setFixedHeight(168)
        self._preview.setAccessibleName(self._tr("饰品图片预览", "Gift image preview"))
        layout.addWidget(self._preview)
        self._zoom = PushButton(self._tr("查看大图", "View full image"))
        self._zoom.clicked.connect(self._open_image)
        layout.addWidget(self._zoom, 0, Qt.AlignmentFlag.AlignHCenter)
        self._candidates = QListWidget()
        self._candidates.setAccessibleName(self._tr("候选图片", "Candidate images"))
        self._candidates.setViewMode(QListWidget.ViewMode.IconMode)
        self._candidates.setFlow(QListWidget.Flow.LeftToRight)
        self._candidates.setWrapping(False)
        self._candidates.setMovement(QListWidget.Movement.Static)
        self._candidates.setIconSize(QSize(56, 56))
        self._candidates.setGridSize(QSize(86, 88))
        self._candidates.setFixedHeight(108)
        self._candidates.currentItemChanged.connect(self._show_candidate)
        self._candidates.itemActivated.connect(self._open_image)
        layout.addWidget(self._candidates)

        self._path_detail = BodyLabel()
        self._path_detail.setTextFormat(Qt.TextFormat.PlainText)
        self._path_detail.setWordWrap(True)
        layout.addWidget(self._path_detail)
        layout.addStretch(1)
        return detail

    def resizeEvent(self, event):
        super().resizeEvent(event)
        compact = event.size().width() < 680
        if compact != self._compact:
            self._compact = compact
            self._layout_filters()
            if not self._in_detail_dialog:
                self._detail.setVisible(not compact)
                if not compact:
                    width = event.size().width()
                    self._split.setSizes([width * 3 // 5, width * 2 // 5])

    def _open_compact_detail(self, *_):
        """窄窗口里把详情放到独立弹窗，关闭后还回分栏。"""
        if not self._compact or self._in_detail_dialog or not self._selected_gift():
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(self._tr("饰品详情", "Gift details"))
        dialog.resize(380, 560)
        layout = QVBoxLayout(dialog)
        self._in_detail_dialog = True
        layout.addWidget(self._detail)
        self._detail.show()
        try:
            dialog.exec()
        finally:
            self._split.addWidget(self._detail)
            self._detail.setVisible(not self._compact)
            self._in_detail_dialog = False
            dialog.deleteLater()

    def _keyword(self, archetype):
        """流派显示名：已知流派用中文/英文对照，未知流派直接显示目录名。"""
        return self._tr(GIFT_KEYWORDS_ZH.get(str(archetype).casefold(), archetype), archetype)

    # ---------- 图鉴：完全由素材库目录派生 ----------
    def _index_asset_groups(self):
        """一次查询素材库，按完整逻辑名索引 mirror/gift/<流派>/<名字> 的图片哈希。"""
        self._asset_groups = {}
        self._issue = ""
        try:
            groups = self._context.list_asset_image_groups(GIFT_ASSET_GROUP)
        except (OSError, ValueError):
            self._issue = self._tr("无法读取饰品素材目录。", "Unable to read gift asset folders.")
            return
        for logical_name, hashes in groups.items():
            if len(str(logical_name).split("/")) != 4:
                continue
            # 保持素材库返回的顺序：第一张就是默认显示的图
            self._asset_groups[str(logical_name)] = _unique_hashes(hashes)
        if not self._asset_groups:
            self._issue = self._tr(
                "素材库里还没有 mirror/gift/<流派>/<名字> 的图片，饰品列表为空。",
                "No images under mirror/gift/<archetype>/<name> yet, so the gift list is empty.",
            )

    def _asset_records(self):
        """素材目录 → 饰品条目：流派取流派目录、名字取名字目录、图片同样取自该目录。"""
        records = {}
        for logical_name, hashes in self._asset_groups.items():
            parts = logical_name.split("/")
            records[logical_name] = {
                "archetype": parts[2],
                "name": parts[3],
                "asset": {"logical_name": logical_name, "sha256": hashes[0] if hashes else ""},
            }
        return records

    def _legacy_entry(self, entry):
        """旧配置里按固定图鉴 id 保存的同名条目，只用于迁移获取偏好。"""
        keys = {_gift_label_key(entry["name"])}
        for legacy_id, legacy in self._saved.items():
            if "/" in str(legacy_id) or not isinstance(legacy, dict):
                continue
            names = [legacy.get("default_label"), *_labels_list(legacy.get("labels"))]
            if any(_gift_label_key(name) in keys for name in names if str(name).strip()):
                return str(legacy_id), legacy
        return "", {}

    def _merge(self):
        """饰品 = 素材目录（唯一来源）；旧固定图鉴 id 只记下来，供获取偏好按名字迁移。"""
        gifts = {}
        self._legacy_ids = {}
        for gift_id, entry in self._asset_records().items():
            gifts[gift_id] = {
                "archetype": entry["archetype"],
                "name": entry["name"],
                "asset": entry["asset"],
            }
            legacy_id, _legacy = self._legacy_entry(entry)
            if legacy_id:
                self._legacy_ids[gift_id] = legacy_id
        return gifts

    def _migrate_preferences(self, gifts):
        """旧固定图鉴 id 的偏好按名字迁移到素材目录 id，页面提交时会用新 id 保存。"""
        for gift_id in gifts:
            if gift_id in self._preferences:
                continue
            legacy_id = self._legacy_ids.get(gift_id)
            if legacy_id and legacy_id in self._preferences:
                self._preferences[gift_id] = self._preferences[legacy_id]

    def _refresh(self):
        """重读素材库并保留筛选、选中项和已选偏好；列表只建首批行。"""
        current_filter = self._archetype.currentData()
        self._index_asset_groups()
        self._gifts = self._merge()
        self._migrate_preferences(self._gifts)
        self._archetype.blockSignals(True)
        self._archetype.clear()
        self._archetype.addItem(self._tr("全部流派", "All archetypes"), userData="")
        archetypes = {}
        for entry in self._gifts.values():
            name = entry["archetype"]
            archetypes.setdefault(_gift_keyword_key(name), name)
        for key, name in sorted(archetypes.items()):
            self._archetype.addItem(self._keyword(name), userData=key)
        if current_filter in archetypes:
            self._archetype.setCurrentIndex(self._archetype.findData(current_filter))
        self._archetype.blockSignals(False)
        placeholder = QPixmap(GIFT_ICON_SIZE, GIFT_ICON_SIZE)
        placeholder.fill(Qt.GlobalColor.transparent)
        painter = QPainter(placeholder)
        painter.setOpacity(0.45)
        painter.drawPixmap(13, 13, FluentIcon.PHOTO.icon().pixmap(22, 22))
        painter.end()
        self._placeholder = QIcon(placeholder)
        # 名字就是素材目录名：列表固定按名字排序，不再有资源里的收录时间
        self._ordered = sorted(self._gifts, key=lambda key: self._gifts[key]["name"].casefold())
        # 每次刷新只保留图片状态缓存为空，行与图标在需要时再逐步建立
        self._image_states = {}
        self._detail_gift = ""
        self._built = True
        self._filter()

    def showEvent(self, event):
        super().showEvent(event)
        self._refresh()

    # ---------- 按需加载图片 ----------
    def _read_pixmap(self, logical_name, digest):
        """加载并校验一张图。缺失、哈希不符或解码失败时返回空图。"""
        pixmap = QPixmap()
        try:
            image = self._context.read_asset_image(logical_name, digest)
            if image:
                pixmap.loadFromData(image, "PNG")
        except (OSError, ValueError):
            pass
        return pixmap

    def _ensure_state(self, gift_id, entry=None):
        """按需解析一件饰品的候选图片（只查索引，不读图片），重复调用复用同一状态。"""
        state = self._image_states.get(gift_id)
        if state is not None:
            return state
        entry = entry if entry is not None else (self._gifts.get(gift_id) or {})
        reference = entry.get("asset") or {}
        logical_name = str(reference.get("logical_name") or "")
        hashes = list(self._asset_groups.get(logical_name) or [])
        registered = reference.get("sha256") if hashes else None
        state = {
            "logical_name": logical_name,
            # 候选顺序就是素材库里的顺序：第一张是列表与详情默认显示的图，已登记哈希只用于标注
            "hashes": hashes,
            "registered": registered,
            "unreadable": set(),
            "issue": "" if hashes else (self._issue or self._tr(
                "素材库里没有这张图。", "No image for this gift in the asset library."
            )),
            "representative": None,
            "pixmap": None,
            "missing": False,
            "multi": False,
            "loaded": False,
        }
        self._image_states[gift_id] = state
        return state

    def _row_pixmap(self, pixmap, missing: bool) -> QPixmap:
        """行图标：缺图行在 48×48 图标的左端画黄色三角形「！」，饰品图缩到右侧；其余行（含多图候选）铺满。"""
        frame = QPixmap(GIFT_ICON_SIZE, GIFT_ICON_SIZE)
        frame.fill(Qt.GlobalColor.transparent)
        painter = QPainter(frame)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        size = GIFT_ART_SIZE if missing else GIFT_ICON_SIZE
        left = GIFT_ICON_SIZE - size
        top = (GIFT_ICON_SIZE - size) // 2
        if pixmap is not None and not pixmap.isNull():
            art = pixmap.scaled(QSize(size, size), Qt.AspectRatioMode.KeepAspectRatio,
                                Qt.TransformationMode.SmoothTransformation)
            painter.drawPixmap(left + (size - art.width()) // 2, top + (size - art.height()) // 2, art)
        else:
            # 没有素材图时用占位图标，位置与异常行的三角形保持一致
            painter.setOpacity(0.45)
            art = FluentIcon.PHOTO.icon().pixmap(size - 8, size - 8)
            painter.drawPixmap(left + 4, top + 4, art)
        if missing:
            _paint_warning_mark(painter)
        painter.end()
        return frame

    def _ensure_image(self, gift_id):
        """首次解码第一张代表图；行是重建出来的，所以每次都用缓存的第一张图重画行图标。"""
        state = self._ensure_state(gift_id)
        if not state["loaded"]:
            state["loaded"] = True
            for digest in state["hashes"]:
                pixmap = self._read_pixmap(state["logical_name"], digest)
                if pixmap.isNull():
                    state["unreadable"].add(digest)
                    continue
                state["representative"] = digest
                state["pixmap"] = pixmap
                break
        self._update_status(gift_id)
        return state

    def _attach_preference(self, gift_id):
        """给每件饰品一个「获取偏好」下拉框，取值随页面配置提交。"""
        combo = ComboBox(self._list)
        for value, zh, en in GIFT_PREFERENCES:
            combo.addItem(self._tr(zh, en), userData=value)
        combo.setCurrentIndex(max(0, combo.findData(
            self._preferences.get(gift_id, GIFT_PREFERENCE_DEFAULT)
        )))
        combo.setAccessibleName(self._tr("{0}的获取偏好", "Acquisition preference for {0}").format(
            self._items[gift_id].text(0)
        ))
        combo.currentIndexChanged.connect(
            lambda index, key=gift_id, box=combo: self._set_preference(key, box.itemData(index))
        )
        self._list.setItemWidget(self._items[gift_id], 2, combo)
        self._preference_combos[gift_id] = combo

    def _set_preference(self, gift_id, value):
        """记录下拉框选择；未知取值一律按默认获取处理，避免写入未定义状态。"""
        allowed = {item[0] for item in GIFT_PREFERENCES}
        self._preferences[gift_id] = value if value in allowed else GIFT_PREFERENCE_DEFAULT

    def _update_status(self, gift_id):
        """缺图才收敛成行图标最左端的黄色三角形；缺图原因与多图候选都只在详情里用文字说明。"""
        state = self._ensure_state(gift_id)
        count = len(state["hashes"]) - len(state["unreadable"])
        issue = state["issue"]
        missing = not state["logical_name"] or not state["hashes"]
        if state["unreadable"]:
            message = self._tr("{0} 张图片缺失或无法读取。", "{0} images are missing or unreadable.").format(
                len(state["unreadable"])
            )
            issue = f"{issue} {message}".strip()
        labels = []
        if missing:
            labels.append(self._tr("缺图（素材库里没有这张图）", "Missing (no image in the asset library)"))
        if count > 1:
            labels.append(self._tr("多图候选：共 {0} 张，默认显示第一张",
                                   "Multi-candidate: {0} images, the first one is shown").format(count))
        if issue and not missing:
            labels.append(self._tr("缺图：{0}", "Missing: {0}").format(issue))
        text = " · ".join(dict.fromkeys(labels))
        # 缺图（没有素材、读不出或校验不符）才画警告符号；多图候选是正常状态，只做文字说明与筛选
        state["missing"] = missing or bool(state["unreadable"])
        state["multi"] = count > 1
        item = self._items.get(gift_id)
        if item is not None:
            item.setIcon(0, QIcon(self._row_pixmap(state.get("pixmap"), state["missing"])))
            if state["missing"] or state["multi"]:
                item.setToolTip(0, issue or text)
        return text, issue

    def _selected_gift(self):
        item = self._list.currentItem()
        return item.data(0, Qt.ItemDataRole.UserRole) if item is not None and not item.isHidden() else None

    def _matched_gifts(self):
        """在素材目录派生的清单上按名字、流派与两个图片筛选项计算命中集，保持 _ordered 的顺序。"""
        phrase = _gift_label_key(self._search.text())
        archetype = self._archetype.currentData()
        multi_only = self._multi_only.isChecked()
        missing_only = self._missing_only.isChecked()
        matched = []
        for gift_id in self._ordered:
            entry = self._gifts[gift_id]
            if archetype and archetype != _gift_keyword_key(entry["archetype"]):
                continue
            if phrase and not any(phrase in _gift_label_key(label) for label in _gift_names(entry)):
                continue
            if multi_only or missing_only:
                # 只有勾了筛选项才逐条读取代表图（多图候选也要先读一张才知道张数）
                state = self._ensure_image(gift_id)
                # 同时勾选两项时按「或」列出：多图候选与缺图的行都算命中
                if not (multi_only and state["multi"]) and not (missing_only and state["missing"]):
                    continue
            matched.append(gift_id)
        return matched

    def _append_row(self, gift_id):
        """创建一行的名称、流派与提示，再按需加载图标和获取偏好下拉框。"""
        entry = self._gifts[gift_id]
        item = QTreeWidgetItem(self._list)
        item.setData(0, Qt.ItemDataRole.UserRole, gift_id)
        item.setText(0, entry["name"])
        item.setText(1, self._keyword(entry["archetype"]))
        item.setToolTip(0, entry["name"])
        self._items[gift_id] = item
        self._ensure_image(gift_id)
        self._attach_preference(gift_id)

    def _render_more(self):
        """追加下一批命中行；已建满命中集时什么都不做。"""
        # 添加行和下拉框时 Qt 可能同步更新滚动条，不能重复构建当前批次。
        if self._appending:
            return
        self._appending = True
        try:
            stop = min(self._rendered + GIFT_PAGE_SIZE, len(self._matched))
            for gift_id in self._matched[self._rendered:stop]:
                self._append_row(gift_id)
                self._rendered += 1
        finally:
            self._appending = False

    def _restore_selection(self, gift_id):
        """只在已经建好的行里恢复原选中项；更靠后的条目等用户划到底再加载，不提前铺开。"""
        if not gift_id or gift_id not in self._matched:
            return None
        if self._matched.index(gift_id) >= self._rendered:
            return None
        item = self._items.get(gift_id)
        if item is None:
            return None
        self._list.setCurrentItem(item)
        return gift_id

    def _ensure_scrollable(self):
        """列表还没撑出滚动条（窗口很高）时补到能滚动为止，否则后面的批次永远划不到。"""
        bar = self._list.verticalScrollBar()
        while self._rendered < len(self._matched) and bar.maximum() <= 0:
            self._render_more()

    def _on_scroll(self, *_):
        """只有真正划到列表底部时才补下一批；一次到底只补一批，不会一下滑就铺开全部饰品。"""
        if self._rendered >= len(self._matched):
            return
        bar = self._list.verticalScrollBar()
        if bar.maximum() <= 0 or bar.value() < bar.maximum():
            return
        self._render_more()

    def _filter(self, *_):
        """按搜索词、流派与两个图片筛选项重建列表：只建前 20 行，划到底再补下一批。"""
        if not self._built:
            return
        previous = self._selected_gift()
        self._matched = self._matched_gifts()
        bar = self._list.verticalScrollBar()
        self._list.blockSignals(True)
        bar.blockSignals(True)
        try:
            self._list.clear()
            self._items = {}
            self._preference_combos = {}
            self._rendered = 0
            self._render_more()
            self._ensure_scrollable()
        finally:
            bar.blockSignals(False)
            self._list.blockSignals(False)
        text = self._tr("{0} 件饰品", "{0} gifts").format(len(self._matched))
        if self._issue:
            text = f"{text}  {self._issue}"
        self._count.setText(text)
        if self._restore_selection(previous) is None:
            # 原选中项不再命中时清空详情，避免显示上一件饰品的信息
            self._detail_gift = ""
        self._sync_detail()

    def _sync_detail(self, *_):
        """选中后校验候选图片并提供放大查看；名字就是素材目录名。"""
        gift_id = self._selected_gift()
        if gift_id == self._detail_gift:
            return
        self._detail_gift = gift_id
        self._detail_title.setToolTip("")
        self._selected_images = {}
        self._candidates.clear()
        self._preview.clear()
        self._preview.hide()
        self._zoom.hide()
        self._path_detail.clear()
        self._detail_status.clear()
        self._detail_status.hide()
        self._candidates.hide()
        if not gift_id:
            self._detail_title.setText(self._tr("选择一件饰品", "Select a gift"))
            return

        entry = self._gifts[gift_id]
        self._detail_title.setText(f'{entry["name"]} · {self._keyword(entry["archetype"])}')
        self._path_detail.setText(
            self._tr("素材目录 {0}", "Asset folder {0}").format(
                (entry.get("asset") or {}).get("logical_name") or gift_id
            )
        )
        state = self._ensure_state(gift_id)
        if state["logical_name"]:
            self._detail_title.setToolTip(state["logical_name"])
            for index, digest in enumerate(state["hashes"]):
                pixmap = self._read_pixmap(state["logical_name"], digest)
                if pixmap.isNull():
                    state["unreadable"].add(digest)
                    continue
                state["unreadable"].discard(digest)
                self._selected_images[digest] = pixmap
                if index == 0:
                    text = self._tr("默认（第一张）", "Default (first)")
                elif digest == state["registered"]:
                    text = self._tr("已登记", "Registered")
                else:
                    text = digest[:8]
                item = QListWidgetItem(QIcon(pixmap), text)
                item.setData(Qt.ItemDataRole.UserRole, digest)
                item.setToolTip(digest)
                self._candidates.addItem(item)
            if self._selected_images:
                self._candidates.setCurrentRow(0)
                self._candidates.setVisible(len(self._selected_images) > 1)
        status, issue = self._update_status(gift_id)
        warning_color = "#ffd078" if isDarkTheme() else "#7a4b00"
        # 只有缺图才用警告色；多图候选是正常状态，按普通正文颜色显示
        self._detail_status.setStyleSheet(f"color: {warning_color};" if issue else "")
        self._detail_status.setText(status)
        self._detail_status.setVisible(bool(status))

    def _show_candidate(self, item, *_):
        digest = item.data(Qt.ItemDataRole.UserRole) if item is not None else None
        pixmap = self._selected_images.get(digest)
        self._preview.setVisible(pixmap is not None)
        self._zoom.setVisible(pixmap is not None)
        if pixmap is not None:
            self._preview.setPixmap(pixmap.scaled(QSize(168, 168), Qt.AspectRatioMode.KeepAspectRatio,
                                                   Qt.TransformationMode.SmoothTransformation))

    def _open_image(self, *_):
        """放大查看选中的候选图，并显示它的完整哈希。"""
        item = self._candidates.currentItem()
        digest = item.data(Qt.ItemDataRole.UserRole) if item is not None else None
        pixmap = self._selected_images.get(digest)
        if pixmap is None:
            return
        dialog = QDialog(self._detail.window())
        dialog.setWindowTitle(self._tr("候选图片", "Candidate image"))
        layout = QVBoxLayout(dialog)
        image = QLabel()
        image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image.setPixmap(pixmap.scaled(QSize(480, 480), Qt.AspectRatioMode.KeepAspectRatio))
        layout.addWidget(image)
        identity = BodyLabel(digest)
        identity.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        identity.setWordWrap(True)
        layout.addWidget(identity)
        dialog.exec()
        dialog.deleteLater()

    def submit(self) -> dict:
        """只提交每件饰品的获取偏好：名字与流派由素材目录决定，页面不再保存图鉴快照。"""
        if not self._built:
            self._refresh()
        return {
            GIFT_PREFERENCE_KEY: {
                **{key: value for key, value in self._preferences.items() if key.startswith(GIFT_ASSET_GROUP + "/")},
                **{key: self._preferences.get(key, GIFT_PREFERENCE_DEFAULT) for key in self._gifts},
            },
        }


class ThemePacksPage(QWidget):
    """按素材库镜像 mirror/theme_pack/<名字> 展示主题包卡片，并按选择偏好保存配置。

    主题包完全由素材目录派生：在素材库存一张图就会出现在这里，页面不读也不写任何页面资源，
    名字就是素材目录名，没有额外的名称标签。
    卡片按批创建（首屏一批，真正划到底部才补下一批），封面在创建卡片时才读取；
    同一主题包存了多张图是「多图候选」，默认使用第一张，没有可读图片时才显示缺图提示。
    """

    def __init__(self, context, config):
        super().__init__()
        self._context = context
        tr = self._tr = context.translate
        config = config if isinstance(config, dict) else {}
        self._preferences = _restore_theme_pack_preferences(
            config.get(THEME_PACK_PREFERENCES_KEY)
        )
        self._packs = {}
        self._cards = {}
        self._combos = {}
        self._matched = []
        self._rendered = 0
        self._issue = ""
        self._built = False
        self._style = _card_style().replace("mirrorTeamCard", "mirrorThemePackCard")

        layout = QVBoxLayout(self)
        filters = QHBoxLayout()
        self._search = LineEdit()
        self._search.setPlaceholderText(tr("搜索主题包", "Search theme packs"))
        self._search.setAccessibleName(self._search.placeholderText())
        filters.addWidget(self._search, 1)
        self._filter_preference = ComboBox()
        self._filter_preference.setAccessibleName(tr("按选择偏好筛选", "Filter by preference"))
        self._filter_preference.addItem(tr("全部偏好", "All preferences"), userData="")
        for preference, zh, en in THEME_PACK_PREFERENCES:
            self._filter_preference.addItem(tr(zh, en), userData=preference)
        filters.addWidget(self._filter_preference)
        self._refresh_button = PushButton(tr("刷新列表", "Refresh list"))
        filters.addWidget(self._refresh_button)
        layout.addLayout(filters)

        hint = BodyLabel(
            tr(
                "主题包列表完全来自素材库镜像 mirror/theme_pack/<名字>：在素材库存一张图就会自动出现在这里，"
                "不依赖任何页面资源。主题包名字就是素材目录名，没有额外的名称标签，搜索只按这个名字匹配。"
                "卡片分批创建，划到底部再加载下一批；同一主题包存了多张图就是「多图候选」，默认使用第一张，"
                "只有没有可读图片时才显示缺图提示。",
                "The list comes straight from the asset library folder mirror/theme_pack/<name>: saving an "
                "image there makes it appear here, with no page resource involved. The pack name is that "
                "folder name, with no extra name labels, and the search matches that name only. Cards are "
                "built in batches and more are added only when you reach the bottom; several images for "
                "one pack are a normal multi-candidate state where the first image is used, and only a "
                "missing or unreadable image shows a warning.",
            )
        )
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        layout.addWidget(hint)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        self._grid = QGridLayout(body)
        self._grid.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._grid.setContentsMargins(0, 0, 0, 0)
        self._grid.setSpacing(12)
        for column in range(THEME_PACK_COLUMNS):
            self._grid.setColumnStretch(column, 1)
        self._scroll.setWidget(body)
        layout.addWidget(self._scroll, 1)

        self._empty = BodyLabel(tr("没有匹配的主题包", "No matching theme packs"))
        layout.addWidget(self._empty)
        self._count = BodyLabel()
        layout.addWidget(self._count)

        self._search.textChanged.connect(self._filter)
        self._filter_preference.currentIndexChanged.connect(self._filter)
        self._refresh_button.clicked.connect(self._refresh)
        # 真正划到列表底部时才补下一批卡片，避免一次性解码全部封面
        self._scroll.verticalScrollBar().valueChanged.connect(self._on_scroll)
        # 首次读取素材库推迟到 showEvent：设置页打开时不预先解码封面

    def showEvent(self, event):
        super().showEvent(event)
        self._refresh()

    # ---------- 素材库：完全由 mirror/theme_pack/<名字> 派生 ----------
    def _index_packs(self):
        """读取素材库一次，按完整逻辑名索引 mirror/theme_pack/<名字> 的图片哈希。"""
        self._issue = ""
        packs = {}
        try:
            groups = self._context.list_asset_image_groups(THEME_PACK_ASSET_GROUP)
        except (OSError, ValueError):
            groups = {}
            self._issue = self._tr(
                "无法读取主题包素材目录。", "Unable to read theme pack asset folders."
            )
        for logical_name, hashes in groups.items():
            parts = str(logical_name).split("/")
            if len(parts) != 3 or not parts[2].strip():
                continue
            unique = _unique_hashes(hashes)
            if not unique:
                continue
            packs[str(logical_name)] = {"name": parts[2].strip(), "hashes": unique}
        self._packs = packs
        if not packs and not self._issue:
            self._issue = self._tr(
                "素材库里还没有 mirror/theme_pack/<名字> 的图片，主题包列表为空。",
                "No images under mirror/theme_pack/<name> yet, so the theme pack list is empty.",
            )

    def _refresh(self):
        """重读素材库并重建卡片；搜索、偏好筛选与已选偏好都保留。"""
        self._index_packs()
        self._built = True
        self._filter()

    def _preference(self, logical_name) -> str:
        """返回该主题包当前的偏好；缺失或未知取值一律按默认选择处理。"""
        allowed = {value for value, _, _ in THEME_PACK_PREFERENCES}
        value = self._preferences.get(logical_name)
        return value if value in allowed else THEME_PACK_PREFERENCE_DEFAULT

    def _set_preference(self, logical_name, value):
        """记录下拉框选择；未知取值一律按默认选择处理。"""
        allowed = {item[0] for item in THEME_PACK_PREFERENCES}
        self._preferences[logical_name] = (
            value if value in allowed else THEME_PACK_PREFERENCE_DEFAULT
        )

    def _on_preference_changed(self, logical_name, combo, index):
        """偏好改变后记录取值；正在按偏好筛选时延后重建，避免在信号里删掉下拉框。"""
        self._set_preference(logical_name, combo.itemData(index))
        if self._filter_preference.currentData():
            QTimer.singleShot(0, self._filter)

    def _filter(self, *_):
        """按搜索词与选择偏好计算命中集，再重建网格的第一批卡片。"""
        if not self._built:
            return
        try:
            phrase = _gift_label_key(self._search.text())
        except RuntimeError:
            # 页面可能已被销毁：延后的重建直接放弃
            return
        preference = self._filter_preference.currentData()
        matched = []
        for logical_name in sorted(
            self._packs, key=lambda key: (self._packs[key]["name"].casefold(), key)
        ):
            if phrase and phrase not in _gift_label_key(self._packs[logical_name]["name"]):
                continue
            if preference and self._preference(logical_name) != preference:
                continue
            matched.append(logical_name)
        self._matched = matched
        self._rebuild_grid()

    def _rebuild_grid(self):
        """清掉旧卡片，按命中集重建首批卡片，并保证列表能滚动。"""
        for logical_name in list(self._cards):
            card = self._cards.pop(logical_name)
            self._grid.removeWidget(card)
            card.setParent(None)
            card.deleteLater()
        self._combos = {}
        self._rendered = 0
        self._render_more()
        self._ensure_scrollable()
        text = self._tr("{0} 个主题包", "{0} theme packs").format(len(self._matched))
        if self._issue:
            text = f"{text}  {self._issue}"
        self._count.setText(text)
        self._empty.setVisible(not self._matched)

    def _render_more(self):
        """追加下一批命中卡片；已建满命中集时什么都不做。"""
        stop = min(self._rendered + THEME_PACK_BATCH, len(self._matched))
        for index in range(self._rendered, stop):
            self._append_card(self._matched[index], index)
        self._rendered = stop

    def _append_card(self, logical_name, index):
        """创建一张卡片并放到网格；封面只在这里读取一次，未创建的卡片不解码图片。"""
        pack = self._packs[logical_name]
        name = pack["name"]
        card = QFrame()
        card.setObjectName("mirrorThemePackCard")
        card.setStyleSheet(self._style)
        stack = QVBoxLayout(card)

        cover = QLabel()
        cover.setAlignment(Qt.AlignmentFlag.AlignCenter)
        cover.setFixedHeight(THEME_PACK_COVER_HEIGHT)
        cover.setAccessibleName(self._tr("{0}的封面", "Cover of {0}").format(name))
        pixmap, digest = self._cover(logical_name, pack["hashes"])
        if pixmap is None:
            cover.setPixmap(FluentIcon.PHOTO.icon().pixmap(48, 48))
        else:
            cover.setPixmap(
                pixmap.scaled(
                    THEME_PACK_COVER_WIDTH,
                    THEME_PACK_COVER_HEIGHT,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
            cover.setToolTip(digest)
        stack.addWidget(cover)

        title = BodyLabel(name)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setTextFormat(Qt.TextFormat.PlainText)
        title.setWordWrap(True)
        title.setMinimumHeight(42)
        title.setToolTip(logical_name)
        stack.addWidget(title, 1)

        combo = ComboBox()
        for preference, zh, en in THEME_PACK_PREFERENCES:
            combo.addItem(self._tr(zh, en), userData=preference)
        combo.setCurrentIndex(max(0, combo.findData(self._preference(logical_name))))
        combo.setAccessibleName(
            self._tr("{0}的选择偏好", "Selection preference for {0}").format(name)
        )
        combo.currentIndexChanged.connect(
            lambda index, key=logical_name, box=combo: self._on_preference_changed(key, box, index)
        )
        stack.addWidget(combo)
        self._combos[logical_name] = combo

        # 状态标签在入布局前可能显示，必须先设定父控件。
        status = QLabel(card)
        status.setWordWrap(True)
        if pixmap is None:
            status.setText(self._tr("缺图：图片无法读取", "Missing: image is unreadable"))
            status.setStyleSheet("color: #ffd078;" if isDarkTheme() else "color: #7a4b00;")
        elif len(pack["hashes"]) > 1:
            status.setText(
                self._tr(
                    "多图候选：共 {0} 张，默认显示第一张",
                    "Multi-candidate: {0} images, the first one is shown",
                ).format(len(pack["hashes"]))
            )
            status.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        status.setVisible(bool(status.text()))
        stack.addWidget(status)

        self._grid.addWidget(card, index // THEME_PACK_COLUMNS, index % THEME_PACK_COLUMNS)
        self._cards[logical_name] = card

    def _cover(self, logical_name, hashes):
        """按素材库顺序读取第一张能解码的封面；都读不出时返回 (None, "")。"""
        for digest in hashes:
            pixmap = QPixmap()
            try:
                image = self._context.read_asset_image(logical_name, digest)
            except (OSError, ValueError):
                continue
            if image and pixmap.loadFromData(image, "PNG") and not pixmap.isNull():
                return pixmap, digest
        return None, ""

    def _ensure_scrollable(self):
        """窗口很高时列表可能撑不出滚动条；只在可见时补一批，避免未打开就解码全部封面。"""
        try:
            visible = self.isVisible()
        except RuntimeError:
            # 页面可能已被销毁：定时补批不再继续
            return
        if not visible or self._rendered >= len(self._matched):
            return
        bar = self._scroll.verticalScrollBar()
        if bar.maximum() > 0:
            return
        self._render_more()
        QTimer.singleShot(0, self._ensure_scrollable)

    def _on_scroll(self, *_):
        """只有真正划到底部才补下一批；一次到底只补一批，不会一下滑就铺开全部主题包。"""
        if self._rendered >= len(self._matched):
            return
        bar = self._scroll.verticalScrollBar()
        if bar.maximum() <= 0 or bar.value() < bar.maximum():
            return
        self._render_more()

    def submit(self) -> dict:
        """只提交每个主题包的选择偏好：名字与封面由素材目录决定，页面不再保存名称标签。"""
        if not self._built:
            self._refresh()
        return {
            THEME_PACK_PREFERENCES_KEY: {
                **self._preferences,
                **{logical_name: self._preference(logical_name) for logical_name in self._packs},
            },
        }


class MirrorPage(QWidget):
    """镜牢设置页，统一提交运行配置、饰品图鉴、主题包偏好与楼层 debuff 规避顺序。"""

    def __init__(self, context):
        super().__init__()
        self._context = context
        config = context.load(
            {
                SETTLEMENT_RULES_KEY: None,
                SHOP_COST_KEY: DEFAULT_SHOP_COST,
                SHOP_STOP_GIFT_SLOTS_KEY: DEFAULT_SHOP_STOP_GIFT_SLOTS,
                SHOP_UNRECORDED_KEY: DEFAULT_SHOP_UNRECORDED,
                SHOP_SKILL_REPLACE_KEY: DEFAULT_SHOP_SWITCH,
                SHOP_BUY_GIFTS_KEY: DEFAULT_SHOP_SWITCH,
                SHOP_FUSE_GIFTS_KEY: DEFAULT_SHOP_SWITCH,
                FLOOR_DEBUFFS_KEY: None,
                PATH_WEIGHTS_KEY: None,
            }
        )
        self._settlement_rules = _restore_settlement_rules(config.get(SETTLEMENT_RULES_KEY))
        # 队伍顺序只读页面资源 team_order：页面显示、页面保存与运行选队共用同一份
        self._teams = self._read_saved_order()
        self._order_timer = QTimer(self)
        self._order_timer.setInterval(1000)
        self._order_timer.timeout.connect(self._refresh_order)
        self._shop_cost = _restore_shop_cost(config.get(SHOP_COST_KEY))
        self._shop_stop_gift_slots = _restore_shop_stop_gift_slots(
            config.get(SHOP_STOP_GIFT_SLOTS_KEY)
        )
        self._shop_unrecorded = _restore_shop_unrecorded(config.get(SHOP_UNRECORDED_KEY))
        # 三个自动动作开关：旧配置没有这些键时一律按开启处理
        self._shop_switches = {
            key: _restore_shop_switch(config.get(key)) for key, *_ in SHOP_SWITCHES
        }
        self._star_levels = _restore_star_levels(config.get(STAR_LEVELS_KEY))
        self._star_enabled = _restore_star_enabled(config.get(STAR_ENABLED_KEY), self._star_levels)
        self._star_buttons = {}
        # 楼层饰品 debuff 规避顺序：旧配置没有该字段时用页面默认顺序
        self._floor_debuffs = _restore_floor_debuffs(config.get(FLOOR_DEBUFFS_KEY))
        # 寻路节点权重：旧配置没有该字段时用默认分数与交错成本
        self._path_weights = _restore_path_weights(config.get(PATH_WEIGHTS_KEY))

        root = QVBoxLayout(self)
        self._tabs = QTabWidget()
        self._tabs.setStyleSheet(
            "QTabWidget::pane { border: 0; }"
            "QTabBar::tab { padding: 10px 18px; border: 0; margin-right: 4px; }"
            "QTabBar::tab:selected { border-bottom: 3px solid #b08a4a; font-weight: bold; }"
        )
        root.addWidget(self._tabs)
        teams_tab = QWidget()
        teams_layout = QVBoxLayout(teams_tab)
        teams_layout.addWidget(self._build_team_card())
        teams_layout.addStretch(1)
        self._tabs.addTab(teams_tab, context.translate("运行与队伍", "Run and teams"))
        # 寻路节点权重独立成一页，不与运行与队伍共用标签
        self._tabs.addTab(
            self._build_path_weights_tab(), context.translate("寻路节点权重", "Path node weights")
        )
        # debuff 规避单独一页，不再挤在「运行与队伍」里
        self._tabs.addTab(self._build_floor_gift_tab(), context.translate("楼层饰品", "Floor gifts"))
        self._tabs.addTab(self._build_star_tab(), context.translate("星光强化", "Starlight"))
        rewards_tab = QWidget()
        self._tabs.addTab(rewards_tab, context.translate("结算设置", "Rewards"))
        layout = QVBoxLayout(rewards_tab)
        layout.setSpacing(10)
        layout.addWidget(
            BodyLabel(context.translate("镜牢结算奖励处理", "Mirror dungeon reward handling"))
        )
        hint = BodyLabel(
            context.translate(
                "按本场镜牢的结算结果决定 Exploration Reward 弹窗点击哪个按钮；"
                "胜利默认领取，失败与未检测到胜负默认不领取。",
                "Choose which button to click in the Exploration Reward popup for each result of the "
                "mirror run just settled. A just-won run claims by default; a just-lost or undetected "
                "result does not claim by default.",
            )
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(8)
        self._rule_combos = {}
        for row, (key, zh_label, en_label, _default) in enumerate(SETTLEMENT_CONDITIONS):
            grid.addWidget(BodyLabel(context.translate(zh_label, en_label)), row, 0)
            combo = ComboBox(self)
            for _, zh_name, en_name in REWARD_MODES:
                combo.addItem(context.translate(zh_name, en_name))
            combo.setCurrentIndex(_choice_index(self._settlement_rules[key]))
            combo.currentIndexChanged.connect(lambda index, k=key: self._set_rule(k, index))
            self._rule_combos[key] = combo
            grid.addWidget(combo, row, 1)
        grid.setColumnStretch(1, 1)
        layout.addLayout(grid)

        note = BodyLabel(
            context.translate(
                "饰品流派与三个饰品的点击顺序仍在「队伍配置」页按队伍编辑；"
                "这里的顺序就是下一场起依次使用的顺序：第一支就是下一场要用的队伍。"
                "每场领取奖励后工作流直接把整份顺序轮换一格并写回这份配置，页面显示会同步。"
                "点「选择队伍…」可编辑顺序。",
                "The gift keyword and the three-gift click order are still edited per team on the "
                "Team Presets page. The order here is the order used from the next run on: the first "
                "team is the next one to play. After each claimed run the workflow rotates the whole "
                "order by one and writes it back to this configuration, so this page follows it. "
                "Click Select teams… to edit the order.",
            )
        )
        note.setWordWrap(True)
        teams_layout.insertWidget(1, note)
        layout.addStretch(1)
        self._tabs.addTab(self._build_shop_tab(), context.translate("商店设置", "Shop settings"))
        self._shop_gifts = ShopGiftsPage(context, config.get(SHOP_GIFTS_KEY))
        self._tabs.addTab(self._shop_gifts, context.translate("饰品配置", "Gift settings"))
        self._theme_packs = ThemePacksPage(context, config.get(THEME_PACKS_KEY))
        self._tabs.addTab(self._theme_packs, context.translate("主题包", "Theme packs"))

        self._refresh_order()
        self._refresh_team_section()

    def showEvent(self, event):
        super().showEvent(event)
        self._refresh_order()
        self._order_timer.start()

    def hideEvent(self, event):
        self._order_timer.stop()
        super().hideEvent(event)

    # ---------- 队伍顺序：唯一一份配置 team_order ----------
    def _read_saved_order(self) -> list[int]:
        """读取页面资源 team_order 里的队伍顺序；资源缺失或内容非法时返回空列表。"""
        try:
            value = self._context.read_resource_json(ORDER_RESOURCE)
        except (OSError, ValueError):
            return []
        raw = value.get(ORDER_TEAMS_KEY) if isinstance(value, dict) else None
        teams: list[int] = []
        if isinstance(raw, list):
            for item in raw:
                team = _team_number(item)
                if team and team not in teams:
                    teams.append(team)
        return teams[:MAX_TEAMS]

    def _refresh_order(self) -> None:
        """页面可见时跟随 team_order 刷新显示：工作流轮换写回新顺序后，这里同步成同一份。"""
        teams = self._read_saved_order()
        if not teams or teams == self._teams:
            return
        self._teams = teams
        self._refresh_team_section()

    def _save_order(self, teams: list[int]) -> None:
        """用户改完顺序立刻写回 team_order，让运行和页面读到的始终是同一份最新顺序。"""
        try:
            previous = self._context.read_resource_json(ORDER_RESOURCE)
        except (OSError, ValueError):
            previous = None
        if not isinstance(previous, dict):
            previous = {}
        if previous.get(ORDER_TEAMS_KEY) == list(teams):
            return
        try:
            self._context.commit_resource_json(
                ORDER_RESOURCE, previous, {ORDER_TEAMS_KEY: list(teams)}
            )
        except (OSError, ValueError):
            pass

    def _build_star_tab(self):
        """按游戏顺序展示十张卡：两行、每行 5 张，卡内左侧图标与名字、右侧堆叠四个按钮。"""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        layout = QVBoxLayout(body)

        head = QHBoxLayout()
        head.setSpacing(10)
        self._star_count = BodyLabel()
        head.addWidget(self._star_count, 0, Qt.AlignmentFlag.AlignVCenter)
        head.addStretch(1)
        clear = PushButton(self._context.translate("清空选择", "Clear selection"))
        clear.clicked.connect(self._clear_stars)
        head.addWidget(clear, 0, Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignTop)
        layout.addLayout(head)

        note = BodyLabel(self._context.translate(
            "x 表示不选；对勾是独立的启用状态，与 x 互斥；+ / ++ 为目标档位，点击会自动勾上对勾。"
            "再次点击已选中的 + / ++ 只取消该档位，不会改动对勾与 x："
            "对勾仍勾着就表示只选中、不强化；x 和对勾重复点击也不会取消，整体取消请点 x。"
            "工作流会在星光页面按这里的档位点 + / ++，再点卡面本体选中该强化。",
            "x means off. The check mark is an independent enabled flag and excludes x. + / ++ set "
            "the target tier and tick the check mark automatically. Clicking an already selected "
            "+ / ++ only clears that tier and leaves the check mark and x untouched: with the tick "
            "still on, the card counts as selected without upgrading. Repeated clicks on x or the "
            "check mark never clear them, so click x to cancel the whole card. The workflow clicks "
            "+ / ++ for the saved tier on the starlight page, then clicks the card itself to select "
            "the grace.",
        ))
        note.setWordWrap(True)
        layout.addWidget(note)
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(10)
        # 五列等宽，保证两行五张排列整齐
        for column in range(STAR_COLUMNS):
            grid.setColumnStretch(column, 1)
        for index, (key, zh, en) in enumerate(STAR_CARDS):
            card = QFrame()
            card.setObjectName("mirrorTeamCard")
            card.setStyleSheet(_card_style())
            card_row = QHBoxLayout(card)
            card_row.setContentsMargins(8, 8, 8, 8)
            card_row.setSpacing(6)

            # 左侧：图片在上、名字在下
            info = QVBoxLayout()
            info.setSpacing(4)
            icon = QLabel()
            pixmap = QPixmap(str(self._context.resource_path(f"assets/stars/{index + 1}.png")))
            if not pixmap.isNull():
                icon.setPixmap(pixmap.scaled(48, 48, Qt.AspectRatioMode.KeepAspectRatio,
                                             Qt.TransformationMode.SmoothTransformation))
            icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            info.addWidget(icon)
            title = BodyLabel(self._context.translate(zh, en))
            title.setWordWrap(True)
            title.setAlignment(Qt.AlignmentFlag.AlignCenter)
            info.addWidget(title)
            info.addStretch(1)
            card_row.addLayout(info, 1)

            # 右侧：x / 对勾 / + / ++ 上下堆叠
            buttons_column = QVBoxLayout()
            buttons_column.setSpacing(3)
            buttons = {}
            for name, caption, accessible in (
                ("x", "x", self._context.translate("不选", "Off")),
                ("check", "✓", self._context.translate("启用", "Enabled")),
                ("plus", "+", "+"),
                ("plus2", "++", "++"),
            ):
                button = PushButton(caption)
                button.setCheckable(True)
                button.setFixedWidth(40)
                button.setStyleSheet(
                    "QPushButton:checked { background-color: #3a2d1a; color: #ffe9b5;"
                    " border: 2px solid #d9a441; border-radius: 6px; font-weight: bold; }"
                )
                button.setAccessibleName(self._context.translate(zh, en) + " " + accessible)
                button.clicked.connect(
                    lambda checked=False, k=key, n=name: self._star_button_clicked(k, n)
                )
                buttons_column.addWidget(button)
                buttons[name] = button
            self._star_buttons[key] = buttons
            card_row.addLayout(buttons_column, 0)
            # 每行 STAR_COLUMNS 张：第一行 1~5，第二行 6~10
            grid.addWidget(card, index // STAR_COLUMNS, index % STAR_COLUMNS)
        layout.addLayout(grid)
        layout.addStretch(1)
        scroll.setWidget(body)
        self._refresh_stars()
        return scroll

    def _build_shop_tab(self) -> QWidget:
        """商店设置页：说明自动购买范围、未记录饰品开关、停止刷新的 Cost 阈值与剩余饰品栏位。"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(10)

        layout.addWidget(
            BodyLabel(self._context.translate("镜牢商店自动购买", "Mirror shop auto purchase"))
        )
        intro = BodyLabel(
            self._context.translate(
                "下面的三个开关分别控制技能替换、购买饰品与融合饰品，关闭后工作流会跳过对应动作；"
                "饰品条目由素材库镜像 mirror/gift/<流派>/<名字> 自动派生，"
                "当前商品处理完后，商店再决定是否刷新。",
                "The shop buys skill replacements from Team Presets and gifts matching the team's "
                "archetype. Gift entries are derived from the asset library folders "
                "mirror/gift/<archetype>/<name>. It decides whether to refresh after handling "
                "current offers.",
            )
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        # 三个自动动作开关：默认开启；关闭后只跳过对应动作，其设置与流程保持不变
        self._shop_switch_checks = {}
        switch_grid = QGridLayout()
        switch_grid.setHorizontalSpacing(12)
        switch_grid.setVerticalSpacing(4)
        for row, (key, zh, en, zh_hint, en_hint) in enumerate(SHOP_SWITCHES):
            check = CheckBox(self._context.translate(zh, en))
            check.setChecked(self._shop_switches[key])
            check.setAccessibleName(self._context.translate(zh, en))
            switch_grid.addWidget(check, row * 2, 0)
            hint = BodyLabel(self._context.translate(zh_hint, en_hint))
            hint.setWordWrap(True)
            hint.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
            switch_grid.addWidget(hint, row * 2 + 1, 0)
            self._shop_switch_checks[key] = check
        switch_grid.setColumnStretch(0, 1)
        layout.addLayout(switch_grid)

        # 优先购买未记录饰品：默认关闭；打开后工作流连名字不在图鉴里的商品一起买
        self._shop_unrecorded_check = CheckBox(
            self._context.translate("优先购买未记录饰品", "Buy unrecorded gifts first")
        )
        self._shop_unrecorded_check.setChecked(self._shop_unrecorded)
        self._shop_unrecorded_check.setAccessibleName(
            self._context.translate("优先购买未记录饰品", "Buy unrecorded gifts first")
        )
        layout.addWidget(self._shop_unrecorded_check)
        unrecorded_note = BodyLabel(
            self._context.translate(
                "打开后，名字与饰品图鉴所有条目都差距过大的商品（即可视为还没有记录的饰品）也会买下；"
                "默认关闭，关闭时这类商品仍不购买。",
                "When enabled, offers whose names match no gift catalog entry (treated as "
                "unrecorded gifts) are bought as well. Off by default; when off those offers are "
                "still not bought.",
            )
        )
        unrecorded_note.setWordWrap(True)
        unrecorded_note.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        layout.addWidget(unrecorded_note)

        grid = QGridLayout()
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(8)
        grid.addWidget(
            BodyLabel(
                self._context.translate("停止刷新的 Cost 阈值", "Stop refreshing at this Cost")
            ),
            0,
            0,
        )
        self._shop_cost_edit = LineEdit(self)
        self._shop_cost_edit.setValidator(QIntValidator(MIN_SHOP_COST, MAX_SHOP_COST, self))
        self._shop_cost_edit.setText(str(self._shop_cost))
        self._shop_cost_edit.setPlaceholderText(str(DEFAULT_SHOP_COST))
        self._shop_cost_edit.setFixedWidth(140)
        grid.addWidget(self._shop_cost_edit, 0, 1)
        grid.setColumnStretch(2, 1)
        layout.addLayout(grid)

        note = BodyLabel(
            self._context.translate(
                f"Cost 不高于此值时，先处理当前可买的商品，之后不再刷新"
                f"（范围 {MIN_SHOP_COST} ~ {MAX_SHOP_COST}，低于 {MIN_SHOP_COST} 按 {MIN_SHOP_COST} 处理）。",
                f"At or below this Cost, the workflow finishes buying eligible current offers and "
                f"leaves without refreshing (range {MIN_SHOP_COST} - {MAX_SHOP_COST}; values below "
                f"{MIN_SHOP_COST} are treated as {MIN_SHOP_COST}).",
            )
        )
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        layout.addWidget(note)

        # 停止刷新的剩余饰品栏位：默认 1；只剩不多于这么多个未买下的饰品栏位时，
        # 即使 Cost 高于阈值也不再刷新（0 表示不启用，仍只按 Cost 阈值判断）
        slot_grid = QGridLayout()
        slot_grid.setHorizontalSpacing(12)
        slot_grid.setVerticalSpacing(8)
        slot_grid.addWidget(
            BodyLabel(
                self._context.translate(
                    "停止刷新的剩余饰品栏位",
                    "Stop refreshing with this many gift slots left",
                )
            ),
            0,
            0,
        )
        self._shop_stop_gift_slots_spin = QSpinBox(self)
        self._shop_stop_gift_slots_spin.setRange(
            MIN_SHOP_STOP_GIFT_SLOTS, MAX_SHOP_STOP_GIFT_SLOTS
        )
        self._shop_stop_gift_slots_spin.setValue(self._shop_stop_gift_slots)
        self._shop_stop_gift_slots_spin.setFixedWidth(140)
        self._shop_stop_gift_slots_spin.setAccessibleName(
            self._context.translate(
                "停止刷新的剩余饰品栏位",
                "Stop refreshing with this many gift slots left",
            )
        )
        slot_grid.addWidget(self._shop_stop_gift_slots_spin, 0, 1)
        slot_grid.setColumnStretch(2, 1)
        layout.addLayout(slot_grid)

        slot_note = BodyLabel(
            self._context.translate(
                f"商店里未买下的饰品栏位只剩不多于这个数时，即使 Cost 高于阈值也不再刷新，"
                f"直接退出购买循环（默认 {DEFAULT_SHOP_STOP_GIFT_SLOTS}，范围 "
                f"{MIN_SHOP_STOP_GIFT_SLOTS} ~ {MAX_SHOP_STOP_GIFT_SLOTS}；"
                f"{MIN_SHOP_STOP_GIFT_SLOTS} 表示不启用这条规则）。"
                "技能替换还有未买下的栏位时刷新是为了买技能，不受这条规则限制。",
                f"When no more than this many gift slots are left unpurchased, the workflow stops "
                f"refreshing even if Cost is above the threshold and leaves the shop "
                f"(default {DEFAULT_SHOP_STOP_GIFT_SLOTS}, range "
                f"{MIN_SHOP_STOP_GIFT_SLOTS} - {MAX_SHOP_STOP_GIFT_SLOTS}; "
                f"{MIN_SHOP_STOP_GIFT_SLOTS} disables this rule). Refreshes still needed for unbought "
                "skill replacements are not affected.",
            )
        )
        slot_note.setWordWrap(True)
        slot_note.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        layout.addWidget(slot_note)
        layout.addStretch(1)
        return tab

    def _star_button_clicked(self, key, name):
        """x 与对勾互斥；+ / ++ 自动勾上对勾，再次点击已生效的档位只取消档位本身。

        x 幂等（重复点击保持不选），对勾只负责勾上、重复点击不会取消；取消已选中的 + / ++
        不会改动对勾与 x，整体取消统一走 x。
        """
        if name == "x":
            # 不选：清掉档位与对勾，重复点击保持同一状态
            self._star_levels[key] = 0
            self._star_enabled.discard(key)
        elif name == "check":
            # 启用：只勾上，不因为重复点击取消
            self._star_enabled.add(key)
        else:
            target = 1 if name == "plus" else 2
            if self._star_levels[key] == target and key in self._star_enabled:
                # 重复点击同一个已生效的档位：只把档位退回 0，对勾与 x 保持原状
                self._star_levels[key] = 0
            else:
                self._star_levels[key] = target
                self._star_enabled.add(key)
        self._refresh_stars()

    def _clear_stars(self):
        """清空选择：取消所有对勾，并全部回到 x。"""
        self._star_levels = _restore_star_levels(None)
        self._star_enabled = set()
        self._refresh_stars()

    def _refresh_stars(self):
        """按启用状态与档位同步按钮勾选，并按对勾数量统计已配置项。"""
        for key, buttons in self._star_buttons.items():
            enabled = key in self._star_enabled
            level = self._star_levels[key]
            buttons["x"].setChecked(not enabled and level == 0)
            buttons["check"].setChecked(enabled)
            buttons["plus"].setChecked(level == 1)
            buttons["plus2"].setChecked(level == 2)
        count = sum(1 for key, _, _ in STAR_CARDS if key in self._star_enabled)
        self._star_count.setText(
            self._context.translate(f"已配置 {count} / 10 项", f"{count} / 10 configured")
        )

    # ---------- 主页队伍卡片 ----------
    def _build_team_card(self) -> QWidget:
        """主页简要展示：已选数量、顺序徽章与「选择队伍…」入口。"""
        card = QFrame(self)
        card.setObjectName("mirrorTeamCard")
        card.setStyleSheet(_card_style())
        outer = QVBoxLayout(card)
        outer.setContentsMargins(14, 12, 14, 12)
        outer.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(10)
        texts = QVBoxLayout()
        texts.setSpacing(2)
        texts.addWidget(BodyLabel(self._context.translate("接下来的队伍顺序", "Upcoming team order")))
        self._count_label = QLabel("")
        self._count_label.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        texts.addWidget(self._count_label)
        head.addLayout(texts, 1)
        self._select_button = PushButton(self._context.translate("选择队伍…", "Select teams…"))
        self._select_button.clicked.connect(self._open_picker)
        head.addWidget(self._select_button, 0, Qt.AlignmentFlag.AlignTop)
        outer.addLayout(head)

        self._chips_layout = QVBoxLayout()
        self._chips_layout.setSpacing(4)
        outer.addLayout(self._chips_layout)
        return card

    # ---------- 寻路节点权重：独立标签页 ----------
    def _build_path_weights_tab(self) -> QWidget:
        """独立标签页：直接编辑七类节点分数（0-99，按分数降序排列）与可能交错线路成本。"""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        layout = QVBoxLayout(body)
        layout.setSpacing(10)
        layout.addWidget(BodyLabel(self._context.translate("寻路节点权重", "Path node weights")))
        intro = BodyLabel(
            self._context.translate(
                "分数越低越优先，允许同分；七行按当前分数降序排列。这里的配置只用于镜牢寻路，"
                "不影响队伍与商店设置。",
                "Lower scores are preferred and ties are allowed; rows are sorted by the current "
                "score in descending order. These values only affect Mirror Dungeon path planning.",
            )
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        self._path_weight_rows_box = QVBoxLayout()
        self._path_weight_rows_box.setSpacing(6)
        layout.addLayout(self._path_weight_rows_box)
        self._path_weight_rows = []
        self._path_weight_pending_focus = None
        for kind in PATH_WEIGHT_KEYS:
            row = QWidget(body)
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.addWidget(BodyLabel(_path_weight_name(self._context, kind)), 1)
            spin = QSpinBox(row)
            spin.setRange(PATH_WEIGHT_MIN, PATH_WEIGHT_MAX)
            spin.setValue(self._path_weights["weights"][kind])
            spin.setFixedWidth(90)
            spin.valueChanged.connect(self._schedule_path_weight_reorder)
            row_layout.addWidget(spin)
            self._path_weight_rows.append((kind, row, spin))
        self._reorder_path_weight_rows()

        cost_row = QWidget(body)
        cost_layout = QHBoxLayout(cost_row)
        cost_layout.setContentsMargins(0, 0, 0, 0)
        cost_label = BodyLabel(
            self._context.translate(
                "可能交错线路成本（从相邻行进入时乘以该系数）",
                "Possible interleaved-route cost (multiplier when entering from an adjacent row)",
            )
        )
        cost_label.setWordWrap(True)
        self._path_interleave = QDoubleSpinBox(cost_row)
        self._path_interleave.setRange(PATH_INTERLEAVE_MIN, PATH_INTERLEAVE_MAX)
        self._path_interleave.setSingleStep(0.1)
        self._path_interleave.setDecimals(2)
        self._path_interleave.setValue(float(self._path_weights["interleave_cost"]))
        self._path_interleave.setFixedWidth(90)
        cost_layout.addWidget(cost_label, 1)
        cost_layout.addWidget(self._path_interleave)
        layout.addWidget(cost_row)

        note = BodyLabel(
            self._context.translate(
                "三列节点（下一列起）：相邻列同行与相邻行连通，跨两行不算路线。"
                "路径成本＝各节点分数之和，从相邻行进入的节点分数乘交错成本；"
                "比较第一列各节点各自最便宜的路，总成本低者优先，同成本优先离火车头（默认第二行）近。"
                "第一列只有一个节点时跳过规划直接点击，未出现确认弹窗则进入固定点保底。",
                "Three columns starting from the next column: same-row and adjacent-row links are "
                "connected, two-row jumps are not. Route cost is the sum of node scores, and entering "
                "from an adjacent row multiplies that node's score by the interleaved cost. The planner "
                "compares each first-column node's cheapest route and prefers the lowest total; ties "
                "prefer the row nearer the train head (second row by default). With a single "
                "first-column node it skips comparison and clicks it directly; without the Enter "
                "prompt it falls back to fixed probe points.",
            )
        )
        note.setWordWrap(True)
        note.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        layout.addWidget(note)

        buttons = QHBoxLayout()
        reset = PushButton(self._context.translate("恢复默认", "Restore defaults"))
        reset.clicked.connect(self._reset_path_weights)
        buttons.addWidget(reset)
        buttons.addStretch(1)
        layout.addLayout(buttons)
        layout.addStretch(1)
        scroll.setWidget(body)
        return scroll

    def _schedule_path_weight_reorder(self, *_):
        """分数变化后延迟重排，避免在 valueChanged 回调里移动控件。"""
        self._path_weight_pending_focus = self.sender()
        QTimer.singleShot(0, self._reorder_path_weight_rows)

    def _reorder_path_weight_rows(self):
        """按当前分数降序排列七行；同分按固定类型顺序，并尽量保留输入焦点。"""
        ordered = sorted(
            self._path_weight_rows,
            key=lambda item: (-item[2].value(), PATH_WEIGHT_KEYS.index(item[0])),
        )
        for index, (_, row, _) in enumerate(ordered):
            self._path_weight_rows_box.insertWidget(index, row)
        focus = self._path_weight_pending_focus
        self._path_weight_pending_focus = None
        if focus is not None and focus.isVisible():
            focus.setFocus()

    def _reset_path_weights(self):
        """把七项分数与交错成本恢复为默认值，并立即按分数重排。"""
        for kind, _, spin in self._path_weight_rows:
            spin.setValue(PATH_WEIGHT_DEFAULTS[kind])
        self._path_interleave.setValue(PATH_INTERLEAVE_DEFAULT)
        self._reorder_path_weight_rows()

    # ---------- 楼层饰品：debuff 规避顺序（独立标签） ----------
    def _build_floor_gift_tab(self) -> QWidget:
        """「楼层饰品」标签：把 debuff 规避卡片从「运行与队伍」独立成单独一页。"""
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        layout = QVBoxLayout(body)
        layout.setSpacing(10)
        layout.addWidget(self._build_debuff_card())
        layout.addStretch(1)
        scroll.setWidget(body)
        return scroll

    def _build_debuff_card(self) -> QWidget:
        """debuff 规避摘要卡片：当前顺序与「编辑 debuff 规避…」入口（弹窗内容不变）。"""
        card = QFrame(self)
        card.setObjectName("mirrorTeamCard")
        card.setStyleSheet(_card_style())
        outer = QVBoxLayout(card)
        outer.setContentsMargins(14, 12, 14, 12)
        outer.setSpacing(6)

        head = QHBoxLayout()
        head.setSpacing(10)
        texts = QVBoxLayout()
        texts.setSpacing(2)
        texts.addWidget(
            BodyLabel(self._context.translate(
                "楼层饰品选择的 debuff 规避", "Debuff avoidance when picking floor gifts"
            ))
        )
        self._debuff_label = QLabel("")
        self._debuff_label.setWordWrap(True)
        self._debuff_label.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        texts.addWidget(self._debuff_label)
        head.addLayout(texts, 1)
        self._debuff_button = PushButton(
            self._context.translate("编辑 debuff 规避…", "Edit debuff avoidance…")
        )
        self._debuff_button.clicked.connect(self._open_debuff_dialog)
        head.addWidget(self._debuff_button, 0, Qt.AlignmentFlag.AlignTop)
        outer.addLayout(head)

        hint = QLabel(
            self._context.translate(
                "只影响楼层 Acquire E.G.O Gift 页：识别到 Mounting Trials 时，先点带规避 debuff 的卡片，"
                "再点其余卡片把选择覆盖下去；越靠前的 debuff 越先被规避。",
                "Only affects the floor Acquire E.G.O Gift page: when Mounting Trials is detected, the "
                "cards with an avoided debuff are clicked first and then overwritten by the other "
                "cards. Debuffs higher in the list are avoided first.",
            )
        )
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
        outer.addWidget(hint)
        self._refresh_debuff_label()
        return card

    def _refresh_debuff_label(self):
        """摘要只显示顺序本身；为空时说明工作流不做规避。"""
        if self._floor_debuffs:
            text = " → ".join(
                _debuff_label(self._context, keyword) for keyword in self._floor_debuffs
            )
        else:
            text = self._context.translate(
                "（顺序为空，工作流不规避任何 debuff）", "(empty order: no debuff is avoided)"
            )
        self._debuff_label.setText(text)

    def _open_debuff_dialog(self):
        """打开 debuff 规避顺序弹窗；只有点「确定」才采用新顺序，取消或关闭保持原配置。"""
        dialog = FloorDebuffDialog(self._context, self._floor_debuffs, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._floor_debuffs = dialog.selected_debuffs()
            self._refresh_debuff_label()

    def _clear_chips(self):
        """清空旧的徽章行，重新按当前选择渲染。"""
        while self._chips_layout.count():
            entry = self._chips_layout.takeAt(0)
            row = entry.layout()
            if row is not None:
                while row.count():
                    cell = row.takeAt(0)
                    widget = cell.widget()
                    if widget is not None:
                        widget.setParent(None)
                        widget.deleteLater()
                row.deleteLater()
                continue
            widget = entry.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()

    def _render_chips(self):
        """把已选队伍渲染成「序号. 队伍 N」徽章，每行若干枚，超出部分折叠成提示。"""
        self._clear_chips()
        if not self._teams:
            empty = QLabel(
                self._context.translate(
                    "（尚未选择队伍，运行时会按队伍 1 处理）",
                    "(no team selected yet; the workflow falls back to Team 1)",
                )
            )
            empty.setWordWrap(True)
            empty.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
            self._chips_layout.addWidget(empty)
            return

        # 配置顺序的第一支就是下一场要用的队伍，直接按配置顺序展示，不再按轮换指针旋转
        shown = self._teams[:MAX_CHIPS]
        for start in range(0, len(shown), CHIPS_PER_ROW):
            row = QHBoxLayout()
            row.setSpacing(6)
            for order, team in enumerate(shown[start : start + CHIPS_PER_ROW], start + 1):
                chip = QLabel(f"{order}. {_team_name(self._context, team)}")
                chip.setStyleSheet(_chip_style())
                row.addWidget(chip)
            row.addStretch(1)
            self._chips_layout.addLayout(row)

        extra = len(self._teams) - len(shown)
        if extra > 0:
            tail = QLabel(
                self._context.translate(
                    f"…另有 {extra} 个队伍，点「选择队伍…」查看全部",
                    f"…and {extra} more team(s); click Select teams… to see all",
                )
            )
            tail.setWordWrap(True)
            tail.setStyleSheet(f"color: {_caption_color()}; font-size: 12px;")
            self._chips_layout.addWidget(tail)

    def _refresh_team_section(self):
        """刷新主页队伍卡片上的数量文字与顺序徽章。"""
        self._count_label.setText(
            self._context.translate(
                f"已选择 {len(self._teams)} 个队伍", f"{len(self._teams)} team(s) selected"
            )
        )
        self._render_chips()

    def _open_picker(self):
        """打开双栏选择器；只有点「确定」才写回，取消或关闭保持原配置。"""
        dialog = TeamPickerDialog(self._context, self._teams, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self._teams = dialog.selected_teams()
            # 用户改的顺序就是唯一那份配置：立刻写回 team_order，运行与页面都按它来
            self._save_order(self._teams)
            self._refresh_team_section()

    def _shop_cost_value(self) -> int:
        """读取商店刷新阈值输入框；空值、非数字、低于 300 或越界时按 300 处理。"""
        return _restore_shop_cost(self._shop_cost_edit.text().strip())

    def _set_rule(self, key, index):
        """按下拉选择更新该结算条件的处理方式；索引越界时保持原值。"""
        if 0 <= index < len(REWARD_MODES):
            self._settlement_rules[key] = REWARD_MODES[index][0]

    def submit(self) -> dict:
        """提交镜牢原有设置和供 Workflow 读取的饰品、主题包配置与 debuff 规避顺序。

        队伍顺序不在这里写回：team_order 是工作流每场轮换后写回的唯一一份配置，
        页面只在用户点「选择队伍…」并确定时写回（见 _open_picker）。
        以前这里无条件 _save_order(self._teams)，页面实例若在运行前打开过、
        之后隐藏（定时器停止，内存顺序停留在旧值），Run 结束提交设置时就会用旧顺序
        覆盖工作流刚写入的轮换结果（Run 563 写回 [1..6]，Run 564 又读到 [6..5]）。
        页面显示仍由 _refresh_order 在可见时跟随资源刷新。
        """
        return {
            SETTLEMENT_RULES_KEY: dict(self._settlement_rules),
            SHOP_COST_KEY: self._shop_cost_value(),
            SHOP_STOP_GIFT_SLOTS_KEY: int(self._shop_stop_gift_slots_spin.value()),
            SHOP_UNRECORDED_KEY: self._shop_unrecorded_check.isChecked(),
            SHOP_SKILL_REPLACE_KEY: self._shop_switch_checks[SHOP_SKILL_REPLACE_KEY].isChecked(),
            SHOP_BUY_GIFTS_KEY: self._shop_switch_checks[SHOP_BUY_GIFTS_KEY].isChecked(),
            SHOP_FUSE_GIFTS_KEY: self._shop_switch_checks[SHOP_FUSE_GIFTS_KEY].isChecked(),
            SHOP_GIFTS_KEY: self._shop_gifts.submit(),
            THEME_PACKS_KEY: self._theme_packs.submit(),
            FLOOR_DEBUFFS_KEY: list(self._floor_debuffs),
            PATH_WEIGHTS_KEY: {
                "weights": {
                    kind: int(spin.value()) for kind, _, spin in self._path_weight_rows
                },
                "interleave_cost": float(self._path_interleave.value()),
            },
            STAR_LEVELS_KEY: dict(self._star_levels),
            STAR_ENABLED_KEY: [key for key, _, _ in STAR_CARDS if key in self._star_enabled],
        }


def create_page(context):
    """返回 Mirror Dungeons 设置页实例。"""
    return MirrorPage(context)
